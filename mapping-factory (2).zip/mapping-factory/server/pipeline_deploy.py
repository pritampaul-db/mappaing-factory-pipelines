"""Create a git-backed Spark Declarative Pipeline for a published mapping, and record
it in the Execution Monitor. Used by the Deploy-as-Pipeline wizard after the bundle is
committed to GitHub.

The pipeline points at the committed `src/mapping_pipeline.py` inside a Databricks
Git folder (linked to the pushed repo/branch), so re-pushing the repo updates the code
the pipeline runs — real CICD, not an inline notebook.
"""
from __future__ import annotations

import posixpath
from typing import Any

from server import config, db


def _ensure_git_folder(w, *, repo_url: str, branch: str, path: str) -> tuple[str, bool]:
    """Idempotently create/point a Databricks Git folder (repo) at repo_url@branch.
    Returns (workspace_path, reused) — reused=True when an existing folder was pointed."""
    # Reuse an existing repo at this path if present.
    try:
        for r in w.repos.list():
            if (r.path or "") == path:
                try:
                    w.repos.update(repo_id=r.id, branch=branch)
                except Exception:  # noqa: BLE001
                    pass
                return path, True
    except Exception:  # noqa: BLE001
        pass
    w.workspace.mkdirs(posixpath.dirname(path))
    # ReposAPI.create() takes no `branch` — it clones the default branch; switch after.
    created = w.repos.create(url=repo_url, provider="gitHub", path=path)
    if branch:
        try:
            w.repos.update(repo_id=created.id, branch=branch)
        except Exception:  # noqa: BLE001 — default branch is an acceptable fallback
            pass
    return path, False


def deploy_git_pipeline(*, spec_id: str, pipeline_name: str, catalog: str, schema: str,
                        repo_url: str, branch: str, src_rel_path: str = "src/mapping_pipeline.py",
                        schedule: str | None = None) -> dict[str, Any]:
    """Create (or reuse) a serverless SDP pipeline whose library is the git-folder file.
    Records an Execution Monitor row. Returns {pipeline_id, git_folder, url}.

    Runs as the app SERVICE PRINCIPAL, not the OBO user: creating Repos git-folders and
    pipelines needs the `workspace` scope, which the forwarded user token doesn't carry
    (it only has the OBO scopes sql/serving/files). This is infrastructure, so the SP is
    the right identity — and the SP is also who later triggers runs."""
    from databricks.sdk.service import pipelines as pl

    w = config.get_sp_client()
    # A SHARED git-folder path (not /Users/<sp>) so both the SP and users can read it.
    folder = f"/Workspace/Shared/mapping-factory/pipelines/{_safe(pipeline_name)}"
    git_folder, reused_git_folder = _ensure_git_folder(w, repo_url=repo_url, branch=branch, path=folder)
    lib_path = f"{git_folder}/{src_rel_path}"

    existing = _find_pipeline(w, pipeline_name)
    # Tell the generic pipeline code WHERE to read its config from the UC table (the config
    # itself is a mf_pipeline_config row keyed by config_key=pipeline_name — not in the code).
    cfg = {"mf.catalog": catalog, "mf.schema": schema,
           "mf.config_catalog": catalog, "mf.config_schema": schema, "mf.config_key": pipeline_name}
    trigger = None
    if schedule:
        trigger = pl.PipelineTrigger(cron=pl.CronTrigger(quartz_cron_schedule=schedule, timezone_id="UTC"))
    if existing:
        w.pipelines.update(pipeline_id=existing, name=pipeline_name, serverless=True, catalog=catalog,
                           schema=schema, continuous=False, configuration=cfg,
                           libraries=[pl.PipelineLibrary(file=pl.FileLibrary(path=lib_path))],
                           trigger=trigger)
        pid = existing
    else:
        created = w.pipelines.create(name=pipeline_name, serverless=True, catalog=catalog, schema=schema,
                                     continuous=False, configuration=cfg,
                                     libraries=[pl.PipelineLibrary(file=pl.FileLibrary(path=lib_path))],
                                     trigger=trigger)
        pid = created.pipeline_id
    _grant_app_sp(w, pid)
    _record_execution(pipeline_name, "created")
    host = config.get_workspace_host().rstrip("/")
    return {"pipeline_id": pid, "git_folder": git_folder, "library_path": lib_path,
            "url": f"{host}/pipelines/{pid}", "reused": bool(existing),
            "reused_git_folder": reused_git_folder}


def _sp_sql(w, sql: str) -> None:
    """Run a statement as the SP against the serverless warehouse; raise on failure."""
    from databricks.sdk.service.sql import StatementState

    resp = w.statement_execution.execute_statement(
        warehouse_id=config.WAREHOUSE_ID, statement=sql, wait_timeout="50s")
    state = resp.status.state if resp.status else None
    if state == StatementState.PENDING or state == StatementState.RUNNING:
        import time
        for _ in range(60):
            time.sleep(2)
            resp = w.statement_execution.get_statement(resp.statement_id)
            state = resp.status.state if resp.status else None
            if state not in (StatementState.PENDING, StatementState.RUNNING):
                break
    if state != StatementState.SUCCEEDED:
        msg = resp.status.error.message if resp.status and resp.status.error else ""
        raise RuntimeError(f"seed SQL failed ({state}): {msg}\n---\n{sql[:200]}")


def seed_dummy_sources(spec: dict, config_inputs: dict[str, Any]) -> dict[str, Any]:
    """Create + populate the pipeline's SOURCE tables with dummy data at the EXACT
    fully-qualified names the deployed pipeline reads (config_inputs[name]['table']).

    Reuses the agentic loop's LLM/synthetic row generation + join-key alignment so the
    LEFT JOINs actually match. Runs as the SP (the identity that owns the target schema
    and runs the pipeline). Idempotent: each table is DROP+CREATE'd."""
    from server import agentic_validate as av
    from server import llm

    w = config.get_sp_client()
    sources = spec.get("sources") or []
    # joins in the split shape align_join_keys expects
    joins = []
    for j in spec.get("joins") or []:
        lt, _, lc = (j.get("left") or "").partition(".")
        rt, _, rc = (j.get("right") or "").partition(".")
        if lt and lc and rt and rc:
            joins.append({"left_table": lt, "left_col": lc, "right_table": rt, "right_col": rc})

    rows_by_table: dict[str, list] = {}
    for a in sources:
        try:
            rows = llm.generate_dummy_rows(a["fields"], n=25)
        except Exception:  # noqa: BLE001 — never let one table's gen stall the seed
            rows = av._synthetic_rows(a["fields"], n=25)
        rows_by_table[a["name"]] = rows or av._synthetic_rows(a["fields"], n=25)
    av._align_join_keys(sources, joins, rows_by_table)

    seeded = []
    for a in sources:
        meta = config_inputs.get(a["name"]) or {}
        fqn = meta.get("table")
        if not fqn:
            continue  # no qualified target (shouldn't happen when source_schema is set)
        _write_dummy_table_sp(w, fqn, a["fields"], rows_by_table[a["name"]])
        seeded.append({"asset": a["name"], "table": fqn, "rows": len(rows_by_table[a["name"]])})
    return {"seeded": seeded}


def _write_dummy_table_sp(w, fqn: str, fields: list[dict], rows: list) -> None:
    """SP-run analogue of agentic_validate._write_dummy_table (all-STRING landing table)."""
    from server import agentic_validate as av

    parts = fqn.split(".")
    if len(parts) == 3:
        _sp_sql(w, f"CREATE SCHEMA IF NOT EXISTS {parts[0]}.{parts[1]}")
    cols = ", ".join(f"`{f['name']}` STRING" for f in fields)
    _sp_sql(w, f"DROP TABLE IF EXISTS {fqn}")
    _sp_sql(w, f"CREATE TABLE {fqn} ({cols})")
    n = len(fields)
    batch = []
    for r in rows:
        vals = list(r) + [None] * (n - len(r)) if len(r) < n else list(r)[:n]
        batch.append("(" + ", ".join(av._lit(v) for v in vals) + ")")
    if batch:
        colnames = ", ".join(f"`{f['name']}`" for f in fields)
        _sp_sql(w, f"INSERT INTO {fqn} ({colnames}) VALUES {', '.join(batch)}")


def run_pipeline(pipeline_id: str, *, full_refresh: bool = False) -> dict[str, Any]:
    """Trigger an update of the deployed pipeline (used by the wizard's test step).
    SP client — start_update needs the workspace scope the OBO token lacks."""
    w = config.get_sp_client()
    upd = w.pipelines.start_update(pipeline_id=pipeline_id, full_refresh=full_refresh)
    _record_execution_by_id(pipeline_id, "running")
    return {"update_id": getattr(upd, "update_id", None), "pipeline_id": pipeline_id}


def wait_for_update(pipeline_id: str, update_id: str, *, tries: int = 120, delay: float = 5.0,
                    on_state=None) -> str:
    """Poll a pipeline update to a terminal state; return the final state string.
    `on_state(state)` is called each time the state CHANGES (for live commentary)."""
    import time

    w = config.get_sp_client()
    last = None
    for _ in range(tries):
        u = w.pipelines.get_update(pipeline_id=pipeline_id, update_id=update_id).update
        state = (u.state.value if u and u.state else "?")
        if state != last:
            last = state
            if on_state:
                on_state(state)
        if state in ("COMPLETED", "FAILED", "CANCELED"):
            return state
        time.sleep(delay)
    return last or "?"


def recent_error_events(pipeline_id: str, limit: int = 25) -> list[str]:
    """Return recent ERROR-level event messages for a pipeline (for failure commentary)."""
    w = config.get_sp_client()
    out = []
    try:
        for ev in list(w.pipelines.list_pipeline_events(pipeline_id=pipeline_id, max_results=limit)):
            lvl = getattr(ev, "level", None)
            if lvl and lvl.value == "ERROR":
                msg = getattr(ev, "message", "") or ""
                if msg:
                    out.append(msg)
    except Exception:  # noqa: BLE001
        pass
    return out


def _safe(s: str) -> str:
    import re

    return re.sub(r"[^0-9A-Za-z_-]+", "-", s).strip("-") or "pipeline"


def _find_pipeline(w, name: str) -> str | None:
    try:
        for p in w.pipelines.list_pipelines():
            if p.name == name:
                return p.pipeline_id
    except Exception:  # noqa: BLE001
        pass
    return None


def _grant_app_sp(w, pid: str) -> None:
    import os

    from databricks.sdk.service import pipelines as pl

    sp = os.environ.get("DATABRICKS_CLIENT_ID") or os.environ.get("MF_APP_SP_ID")
    if not sp:
        return
    try:
        w.pipelines.update_permissions(pipeline_id=pid, access_control_list=[
            pl.PipelineAccessControlRequest(service_principal_name=sp, permission_level=pl.PipelinePermissionLevel.CAN_MANAGE)])
    except Exception:  # noqa: BLE001
        pass


def _record_execution(pipeline_name: str, status: str) -> None:
    """Insert an Execution Monitor row (best-effort) so the deploy shows up there."""
    try:
        with db.pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SET search_path TO mapping_factory, public")
                cur.execute(
                    "INSERT INTO execution (pipeline_name, status, validation_status) VALUES (%s,%s,%s)",
                    (pipeline_name, status, "Pending"),
                )
            conn.commit()
    except Exception:  # noqa: BLE001
        pass


def _record_execution_by_id(pipeline_id: str, status: str) -> None:
    try:
        w = config.get_sp_client()
        name = pipeline_id
        try:
            name = w.pipelines.get(pipeline_id=pipeline_id).name or pipeline_id
        except Exception:  # noqa: BLE001
            pass
        _record_execution(name, status)
    except Exception:  # noqa: BLE001
        pass
