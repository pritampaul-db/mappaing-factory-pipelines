"""Pydantic request/response models for the API surface."""
from __future__ import annotations

from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, Field


class FieldIn(BaseModel):
    name: str
    datatype: str
    nullable: bool = True
    ordinal: int | None = None
    semantic_type: str | None = None
    sample_profile: dict[str, Any] | None = None


class AssetCreate(BaseModel):
    name: str
    object_type: Literal["uc_table", "uploaded_csv", "ddl", "target_schema"]
    role: Literal["source", "target"]
    system: str | None = None
    locator: str | None = None
    fields: list[FieldIn] = Field(default_factory=list)


class FieldOut(BaseModel):
    id: UUID
    name: str
    datatype: str
    nullable: bool
    ordinal: int | None = None
    semantic_type: str | None = None
    sample_profile: dict[str, Any] | None = None


class AssetIngest(BaseModel):
    """Register an asset by deterministically inferring its schema from a source."""
    name: str
    object_type: Literal["uc_table", "ddl", "uploaded_csv"]
    role: Literal["source", "target"]
    locator: str | None = None  # required for uc_table
    content: str | None = None  # DDL text or CSV text


class AssetOut(BaseModel):
    id: UUID
    name: str
    system: str | None = None
    locator: str | None = None
    object_type: str
    role: str
    created_by: str
    fields: list[FieldOut] = Field(default_factory=list)


class SpecCreate(BaseModel):
    name: str
    source_asset_id: UUID
    target_asset_id: UUID
    source_system: str | None = None
    target_system: str | None = None


class MappingCurate(BaseModel):
    action: Literal["accept", "edit", "reject"]
    transform_spec: dict[str, Any] | None = None   # required for edit
    source_field_ids: list[UUID] | None = None      # optional re-wire


class LayoutPut(BaseModel):
    nodes: Any = None
    edges: Any = None
    viewport: Any = None
