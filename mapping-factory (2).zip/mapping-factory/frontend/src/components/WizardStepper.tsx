import { Check } from "lucide-react";

// Numbered step pills with connectors, matching the 4-step wizards in the wireframes.
export function WizardStepper({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className="flex items-center gap-2">
      {steps.map((label, i) => {
        const done = i < current;
        const active = i === current;
        return (
          <div key={label} className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <span
                className={`w-6 h-6 rounded-full grid place-items-center text-xs font-medium ${
                  active ? "bg-brand text-white" : done ? "bg-brand text-white" : "bg-gray-200 text-gray-500"
                }`}
              >
                {done ? <Check className="w-3.5 h-3.5" /> : i + 1}
              </span>
              <span className={`text-sm ${active ? "text-brand font-medium" : done ? "text-gray-700" : "text-gray-400"}`}>{label}</span>
            </div>
            {i < steps.length - 1 && <span className="w-8 h-px bg-gray-300 mx-1" />}
          </div>
        );
      })}
    </div>
  );
}
