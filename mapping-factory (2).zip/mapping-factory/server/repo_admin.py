"""Administration repository — admin users (Lakebase `admin_user`).

Admin users bypass maker-checker (they may approve their own mappings/
transformations) and are the only ones allowed to manage the admin list.
Same psycopg-pool pattern as server/repo.py.
"""
from __future__ import annotations

from typing import Any

from psycopg.rows import dict_row, tuple_row
from psycopg_pool import ConnectionPool


def _norm(user: str | None) -> str:
    """Canonical form for identity comparison/storage: trimmed, lower-cased."""
    return (user or "").strip().lower()


def list_admins(pool: ConnectionPool) -> list[dict[str, Any]]:
    # Set row_factory PER CURSOR (not on the pooled connection) — mutating
    # conn.row_factory leaks the factory to the next borrower of this pooled
    # connection and breaks positional-index reads elsewhere.
    with pool.connection() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute("SET search_path TO mapping_factory, public")
            cur.execute("SELECT user_name, added_by, created_at FROM admin_user ORDER BY created_at")
            return cur.fetchall()


def is_admin(pool: ConnectionPool, user: str | None) -> bool:
    u = _norm(user)
    if not u:
        return False
    try:
        with pool.connection() as conn:
            with conn.cursor(row_factory=tuple_row) as cur:
                cur.execute("SET search_path TO mapping_factory, public")
                cur.execute("SELECT 1 FROM admin_user WHERE user_name = %s", (u,))
                return cur.fetchone() is not None
    except Exception:  # noqa: BLE001 — admin check is best-effort; a DB hiccup means "not admin"
        return False


def add_admin(pool: ConnectionPool, user: str, added_by: str | None) -> dict[str, Any]:
    """Idempotently add an admin. Returns the row (existing or new)."""
    u = _norm(user)
    if not u:
        raise ValueError("user_name is required")
    with pool.connection() as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute("SET search_path TO mapping_factory, public")
            cur.execute(
                """INSERT INTO admin_user (user_name, added_by) VALUES (%s, %s)
                   ON CONFLICT (user_name) DO UPDATE SET added_by = COALESCE(admin_user.added_by, EXCLUDED.added_by)
                   RETURNING user_name, added_by, created_at""",
                (u, _norm(added_by) or None),
            )
            row = cur.fetchone()
        conn.commit()
    return row


def remove_admin(pool: ConnectionPool, user: str) -> bool:
    """Remove an admin. Returns True if a row was deleted."""
    u = _norm(user)
    with pool.connection() as conn:
        with conn.cursor(row_factory=tuple_row) as cur:
            cur.execute("SET search_path TO mapping_factory, public")
            cur.execute("DELETE FROM admin_user WHERE user_name = %s", (u,))
            deleted = cur.rowcount > 0
        conn.commit()
    return deleted


def count_admins(pool: ConnectionPool) -> int:
    with pool.connection() as conn:
        # Pooled connections may carry a dict_row factory set by a sibling call, so
        # don't index the row positionally — read the count by column name-agnostic
        # means. Force a tuple row for this cursor to be safe.
        with conn.cursor(row_factory=tuple_row) as cur:
            cur.execute("SET search_path TO mapping_factory, public")
            cur.execute("SELECT COUNT(*) AS n FROM admin_user")
            return int(cur.fetchone()[0])


def ensure_bootstrap_admin(pool: ConnectionPool, user: str) -> None:
    """Seed the first admin on startup if the admin list is empty. Best-effort."""
    try:
        if count_admins(pool) == 0 and _norm(user):
            add_admin(pool, user, added_by="bootstrap")
    except Exception:  # noqa: BLE001 — never let bootstrap crash startup
        pass
