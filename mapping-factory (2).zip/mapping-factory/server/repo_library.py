"""Repository access for the library domains: rules, transformations, validations.

Read-mostly over the seeded operational tables. Same psycopg-pool pattern as
server/repo.py; this module keeps the Pass-2 domains separate from the core
mapping repo.
"""
from __future__ import annotations

from typing import Any
from uuid import UUID

from psycopg.rows import dict_row, tuple_row
from psycopg.types.json import Json
from psycopg_pool import ConnectionPool

_PUBLISHED = ("Published", "Approved", "Active", "Live")


# --- reuse-first catalogs (fed to the LLM so Suggest/Validate reuse before inventing) ---

def published_transformation_catalog(pool: ConnectionPool, limit: int = 200) -> list[dict[str, Any]]:
    """Published transformations as a compact reuse catalog: {id, code, name, description, logic, category}."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """SELECT id, code, name, description, category, COALESCE(logic_expr, logic_sql) AS logic
                   FROM mapping_factory.transformation
                   WHERE status = ANY(%s) ORDER BY reuse_count DESC NULLS LAST LIMIT %s""",
                (list(_PUBLISHED), limit),
            )
            return cur.fetchall()


def published_rule_catalog(pool: ConnectionPool, limit: int = 200) -> list[dict[str, Any]]:
    """Published Rule Library rules as a reuse catalog: {id, code, name, description, logic, rule_type}."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """SELECT id, code, name, description, rule_type, COALESCE(logic_sql, logic_preview) AS logic
                   FROM mapping_factory.rule
                   WHERE status = ANY(%s) ORDER BY usage_count DESC NULLS LAST LIMIT %s""",
                (list(_PUBLISHED), limit),
            )
            return cur.fetchall()


def transformation_usage(pool: ConnectionPool) -> dict[str, int]:
    """Live reuse count per transformation id — the number of DISTINCT mappings (specs)
    whose accepted/edited field_mappings reused it (provenance.reused_transformation_id).
    Authoritative (derived from real links), vs the drifting reuse_count counter."""
    # tuple_row per cursor: a pooled connection may carry a dict_row factory set by a
    # sibling call (list_rules/list_transformations), which would break row[0] indexing.
    with pool.connection() as conn:
        with conn.cursor(row_factory=tuple_row) as cur:
            cur.execute(
                """SELECT fm.provenance->>'reused_transformation_id' AS tid,
                          COUNT(DISTINCT fm.spec_id) AS n
                   FROM mapping_factory.field_mapping fm
                   WHERE fm.state IN ('accepted','edited')
                     AND fm.provenance->>'reused_transformation_id' IS NOT NULL
                   GROUP BY 1"""
            )
            return {row[0]: int(row[1]) for row in cur.fetchall() if row[0]}


def rule_usage(pool: ConnectionPool) -> dict[str, int]:
    """Live usage count per Rule Library rule id — the number of dataset-tagged
    validation_rule instances that were applied FROM it (tag `rule:<id>`)."""
    with pool.connection() as conn:
        with conn.cursor(row_factory=tuple_row) as cur:
            cur.execute(
                """SELECT SPLIT_PART(t, ':', 2) AS rid, COUNT(*) AS n
                   FROM mapping_factory.validation_rule v, UNNEST(v.tags) AS t
                   WHERE t LIKE 'rule:%'
                   GROUP BY 1"""
            )
            return {row[0]: int(row[1]) for row in cur.fetchall() if row[0]}


def get_transformation_by_code(pool: ConnectionPool, code: str) -> dict[str, Any] | None:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM mapping_factory.transformation WHERE code=%s", (code,))
            return cur.fetchone()


def get_rule_by_code(pool: ConnectionPool, code: str) -> dict[str, Any] | None:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM mapping_factory.rule WHERE code=%s", (code,))
            return cur.fetchone()


# --- rules (Rule Library — dataset-agnostic reusable rules) ------------------

# rule columns + sidecar governance fields (LEFT JOIN so pre-governance rows return).
_RULE_SELECT = """SELECT r.*, g.submitted_by, g.approved_by, g.rationale
                  FROM mapping_factory.rule r
                  LEFT JOIN mapping_factory.rule_governance g ON g.rule_id = r.id"""


def list_rules(pool: ConnectionPool) -> list[dict[str, Any]]:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(f"{_RULE_SELECT} ORDER BY r.usage_count DESC, r.updated_at DESC")
            rows = cur.fetchall()
    # Attach a LIVE used_by count (dataset-tagged validations applied from each rule).
    usage = rule_usage(pool)
    for r in rows:
        r["used_by"] = usage.get(str(r["id"]), 0)
    return rows


def get_rule(pool: ConnectionPool, rule_id: UUID) -> dict[str, Any] | None:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(f"{_RULE_SELECT} WHERE r.id=%s", (rule_id,))
            return cur.fetchone()


def create_rule(pool: ConnectionPool, r: dict[str, Any], owner: str) -> dict[str, Any]:
    """Create a Rule Library rule. `status` is the governance lifecycle status
    (Draft default; seed passes 'Published'). Rules are dataset-AGNOSTIC — they are
    tagged to a dataset only when applied (see apply_rule_to_dataset)."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO mapping_factory.rule
                   (name, code, rule_type, domain, data_type, description, logic_sql, logic_preview, sample_io, owner, status, tags)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *""",
                (
                    r["name"], r.get("code") or r["name"].upper().replace(" ", "_"),
                    r.get("rule_type", "custom"), r.get("domain"), r.get("data_type"),
                    r.get("description"), r.get("logic_sql"), r.get("logic_preview"),
                    Json(r.get("sample_io")) if r.get("sample_io") is not None else None,
                    owner, r.get("status") or "Draft", r.get("tags") or [],
                ),
            )
            row = cur.fetchone()
        conn.commit()
    return row


class RuleGovernanceError(Exception):
    """Raised on Rule Library workflow violations (bad state, maker==checker)."""


def submit_rule(pool: ConnectionPool, rule_id: UUID, submitter: str) -> dict[str, Any]:
    """Draft → Proposed (Pending Approval). Requires logic to review."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT status, logic_sql, logic_preview FROM mapping_factory.rule WHERE id=%s FOR UPDATE", (rule_id,))
            r = cur.fetchone()
            if r is None:
                raise RuleGovernanceError("rule not found")
            if r["status"] not in ("Draft", "Rejected"):
                raise RuleGovernanceError(f"cannot submit from status {r['status']}")
            if not ((r["logic_sql"] or r["logic_preview"] or "").strip()):
                raise RuleGovernanceError("nothing to approve: add rule logic first")
            cur.execute("UPDATE mapping_factory.rule SET status='Proposed', updated_at=now() WHERE id=%s", (rule_id,))
            cur.execute(
                """INSERT INTO mapping_factory.rule_governance (rule_id, submitted_by, approved_by, rationale, updated_at)
                   VALUES (%s,%s,NULL,NULL,now())
                   ON CONFLICT (rule_id)
                   DO UPDATE SET submitted_by=EXCLUDED.submitted_by, approved_by=NULL, rationale=NULL, updated_at=now()""",
                (rule_id, submitter),
            )
        conn.commit()
    return get_rule(pool, rule_id)


def decide_rule(pool: ConnectionPool, rule_id: UUID, *, decision: str, checker: str, rationale: str | None, is_admin: bool = False) -> dict[str, Any]:
    """Approve (→ Published) or reject (→ Rejected). Maker != checker unless admin."""
    if decision not in ("approved", "rejected"):
        raise RuleGovernanceError("decision must be 'approved' or 'rejected'")
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """SELECT r.status, r.owner, g.submitted_by
                   FROM mapping_factory.rule r
                   LEFT JOIN mapping_factory.rule_governance g ON g.rule_id = r.id
                   WHERE r.id=%s FOR UPDATE OF r""",
                (rule_id,),
            )
            r = cur.fetchone()
            if r is None:
                raise RuleGovernanceError("rule not found")
            if r["status"] != "Proposed":
                raise RuleGovernanceError(f"cannot decide from status {r['status']}")
            maker = r["submitted_by"] or r["owner"]
            if decision == "approved" and maker and maker == checker and not is_admin:
                raise RuleGovernanceError("segregation of duties: the maker cannot approve their own rule")
            new_status = "Published" if decision == "approved" else "Rejected"
            cur.execute("UPDATE mapping_factory.rule SET status=%s, updated_at=now() WHERE id=%s", (new_status, rule_id))
            cur.execute(
                """INSERT INTO mapping_factory.rule_governance (rule_id, submitted_by, approved_by, rationale, updated_at)
                   VALUES (%s,%s,%s,%s,now())
                   ON CONFLICT (rule_id)
                   DO UPDATE SET approved_by=EXCLUDED.approved_by, rationale=EXCLUDED.rationale, updated_at=now()""",
                (rule_id, maker, checker if decision == "approved" else None, rationale),
            )
        conn.commit()
    return get_rule(pool, rule_id)


def apply_rule_to_dataset(pool: ConnectionPool, rule_id: UUID, *, dataset: str, column_name: str | None, severity: str, owner: str) -> dict[str, Any]:
    """Instantiate a Published library rule against a dataset — creates a dataset-TAGGED
    validation_rule row (this is the 'use = tag to dataset' step). Bumps rule usage."""
    import uuid as _uuid

    rule = get_rule(pool, rule_id)
    if rule is None:
        raise RuleGovernanceError("rule not found")
    if rule["status"] not in ("Published", "Approved", "Active", "Live"):
        raise RuleGovernanceError("only a published rule can be applied to a dataset")
    logic = rule.get("logic_sql") or rule.get("logic_preview") or ""
    base = f"{dataset}_{column_name or 'rule'}_{rule['code']}".upper().replace(".", "_").replace(" ", "_")[:44]
    code = f"{base}_{_uuid.uuid4().hex[:6].upper()}"
    created = create_validation(
        pool,
        {
            "name": f"{rule['name']} — {dataset}",
            "code": code,
            "rule_type": rule.get("rule_type") if rule.get("rule_type") in (
                "completeness", "validity", "accuracy", "business_rule", "consistency", "uniqueness", "referential",
            ) else "validity",
            "dataset": dataset,
            "column_name": column_name,
            "severity": severity or "medium",
            "description": rule.get("description"),
            "logic": logic,
            "status": "Published",  # applying a published rule is itself the governed action
            "tags": ["applied-rule", f"rule:{rule_id}"],
        },
        owner,
    )
    # Bump usage on the source library rule (best-effort).
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute("UPDATE mapping_factory.rule SET usage_count = COALESCE(usage_count,0)+1 WHERE id=%s", (rule_id,))
            conn.commit()
    except Exception:  # noqa: BLE001
        pass
    return created


# --- transformations ---------------------------------------------------------

# Select the transformation columns plus the sidecar governance fields. The sidecar
# is LEFT-JOINed so pre-governance rows (no sidecar row) still return, with NULLs.
_XFORM_SELECT = """SELECT t.*, g.submitted_by, g.approved_by, g.rationale
                   FROM mapping_factory.transformation t
                   LEFT JOIN mapping_factory.transformation_governance g ON g.transformation_id = t.id"""


def list_transformations(pool: ConnectionPool) -> list[dict[str, Any]]:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(f"{_XFORM_SELECT} ORDER BY t.reuse_count DESC, t.updated_at DESC")
            rows = cur.fetchall()
    # Attach a LIVE used_by count (distinct mappings reusing each transform).
    usage = transformation_usage(pool)
    for r in rows:
        r["used_by"] = usage.get(str(r["id"]), 0)
    return rows


def get_transformation(pool: ConnectionPool, tid: UUID) -> dict[str, Any] | None:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(f"{_XFORM_SELECT} WHERE t.id=%s", (tid,))
            return cur.fetchone()


def create_transformation(pool: ConnectionPool, t: dict[str, Any], owner: str) -> dict[str, Any]:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO mapping_factory.transformation
                   (name, code, ttype, category, description, logic_expr, logic_sql, test_cases, owner, status, tags)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *""",
                (
                    t["name"], t.get("code") or t["name"].upper().replace(" ", "_"),
                    t.get("ttype", "custom"), t.get("category"), t.get("description"),
                    t.get("logic_expr"), t.get("logic_sql"),
                    Json(t.get("test_cases")) if t.get("test_cases") is not None else None,
                    owner, t.get("status") or "Draft", t.get("tags") or [],
                ),
            )
            row = cur.fetchone()
        conn.commit()
    return row


class TransformationGovernanceError(Exception):
    """Raised on transformation workflow violations (bad state, maker==checker)."""


def submit_transformation(pool: ConnectionPool, tid: UUID, submitter: str) -> dict[str, Any]:
    """Draft → Proposed (Pending Approval). Requires an expression to review.

    Governance metadata lives in the SP-owned sidecar `transformation_governance`
    (the app SP can't ALTER the pre-existing `transformation` table); `status` is
    a plain DML update on `transformation`, which the SP is granted.
    """
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT status, logic_expr FROM mapping_factory.transformation WHERE id=%s FOR UPDATE", (tid,))
            t = cur.fetchone()
            if t is None:
                raise TransformationGovernanceError("transformation not found")
            if t["status"] not in ("Draft", "Rejected"):
                raise TransformationGovernanceError(f"cannot submit from status {t['status']}")
            if not (t["logic_expr"] or "").strip():
                raise TransformationGovernanceError("nothing to approve: add an expression first")
            cur.execute("UPDATE mapping_factory.transformation SET status='Proposed', updated_at=now() WHERE id=%s", (tid,))
            cur.execute(
                """INSERT INTO mapping_factory.transformation_governance (transformation_id, submitted_by, approved_by, rationale, updated_at)
                   VALUES (%s,%s,NULL,NULL,now())
                   ON CONFLICT (transformation_id)
                   DO UPDATE SET submitted_by=EXCLUDED.submitted_by, approved_by=NULL, rationale=NULL, updated_at=now()""",
                (tid, submitter),
            )
        conn.commit()
    return get_transformation(pool, tid)


def decide_transformation(pool: ConnectionPool, tid: UUID, *, decision: str, checker: str, rationale: str | None, is_admin: bool = False) -> dict[str, Any]:
    """Approve (→ Published) or reject (→ Rejected).

    Enforces maker != checker UNLESS the checker is an administrator — admins
    bypass segregation of duties and may approve their own transformation.
    """
    if decision not in ("approved", "rejected"):
        raise TransformationGovernanceError("decision must be 'approved' or 'rejected'")
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """SELECT t.status, t.owner, g.submitted_by
                   FROM mapping_factory.transformation t
                   LEFT JOIN mapping_factory.transformation_governance g ON g.transformation_id = t.id
                   WHERE t.id=%s FOR UPDATE OF t""",
                (tid,),
            )
            t = cur.fetchone()
            if t is None:
                raise TransformationGovernanceError("transformation not found")
            if t["status"] != "Proposed":
                raise TransformationGovernanceError(f"cannot decide from status {t['status']}")
            # Segregation of duties: the maker (submitter, else owner) can't approve —
            # unless the checker is an admin, who is allowed to self-approve.
            maker = t["submitted_by"] or t["owner"]
            if decision == "approved" and maker and maker == checker and not is_admin:
                raise TransformationGovernanceError("segregation of duties: the maker cannot approve their own transformation")
            new_status = "Published" if decision == "approved" else "Rejected"
            cur.execute("UPDATE mapping_factory.transformation SET status=%s, updated_at=now() WHERE id=%s", (new_status, tid))
            cur.execute(
                """INSERT INTO mapping_factory.transformation_governance (transformation_id, submitted_by, approved_by, rationale, updated_at)
                   VALUES (%s,%s,%s,%s,now())
                   ON CONFLICT (transformation_id)
                   DO UPDATE SET approved_by=EXCLUDED.approved_by, rationale=EXCLUDED.rationale, updated_at=now()""",
                (tid, maker, checker if decision == "approved" else None, rationale),
            )
        conn.commit()
    return get_transformation(pool, tid)


# --- validations -------------------------------------------------------------

# validation columns + sidecar governance fields (LEFT JOIN so pre-governance rows return).
_VALIDATION_SELECT = """SELECT v.*, g.submitted_by, g.approved_by, g.rationale, dq.dq_action
                        FROM mapping_factory.validation_rule v
                        LEFT JOIN mapping_factory.validation_governance g ON g.validation_id = v.id
                        LEFT JOIN mapping_factory.validation_dq dq ON dq.validation_id = v.id"""


def list_validations(pool: ConnectionPool) -> list[dict[str, Any]]:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(f"{_VALIDATION_SELECT} ORDER BY v.last_run_at DESC NULLS LAST")
            return cur.fetchall()


def get_validation(pool: ConnectionPool, vid: UUID) -> dict[str, Any] | None:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(f"{_VALIDATION_SELECT} WHERE v.id=%s", (vid,))
            return cur.fetchone()


def update_validation_logic(pool: ConnectionPool, vid: UUID, *, logic: str, name: str | None = None,
                            description: str | None = None, reused_rule_id: str | None = None) -> dict[str, Any] | None:
    """Rewrite a saved validation's logic (per-item regenerate / reuse-a-rule). When a
    library rule is reused, swap the 'new-rule' tag for 'rule:<id>' so used-by is accurate."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            sets = ["logic=%s"]
            params: list[Any] = [logic]
            if name is not None:
                sets.append("name=%s"); params.append(name)
            if description is not None:
                sets.append("description=%s"); params.append(description)
            if reused_rule_id is not None:
                # drop 'new-rule', add 'rule:<id>' (no dup).
                sets.append("tags = (SELECT array_agg(t) FROM unnest(array_append(array_remove(tags,'new-rule'), %s)) AS t)")
                params.append(f"rule:{reused_rule_id}")
            params.append(vid)
            cur.execute(f"UPDATE mapping_factory.validation_rule SET {', '.join(sets)} WHERE id=%s RETURNING *", tuple(params))
            row = cur.fetchone()
        conn.commit()
    return row


def set_validation_dq_action(pool: ConnectionPool, vid: UUID, *, dq_action: str) -> dict[str, Any] | None:
    """Human override of the pipeline DQ routing for a validation: 'warn' | 'fail'."""
    action = (dq_action or "").strip().lower()
    if action not in ("warn", "fail"):
        raise ValueError("dq_action must be 'warn' or 'fail'")
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            # Ensure the rule exists (so a 404 is distinguishable from a no-op upsert).
            cur.execute("SELECT id FROM mapping_factory.validation_rule WHERE id=%s", (vid,))
            if cur.fetchone() is None:
                return None
            # dq_action lives in the SP-owned sidecar, not on validation_rule.
            cur.execute(
                """INSERT INTO mapping_factory.validation_dq (validation_id, dq_action, updated_at)
                   VALUES (%s,%s, now())
                   ON CONFLICT (validation_id) DO UPDATE SET dq_action=EXCLUDED.dq_action, updated_at=now()""",
                (vid, action),
            )
        conn.commit()
    return {"id": str(vid), "dq_action": action}


def list_validation_runs(pool: ConnectionPool) -> list[dict[str, Any]]:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM mapping_factory.validation_run ORDER BY run_at DESC")
            return cur.fetchall()


def create_validation(pool: ConnectionPool, v: dict[str, Any], owner: str) -> dict[str, Any]:
    """Create a DQ rule. `status` is the governance lifecycle status (Draft default;
    the seed passes 'Published' for System rules; user-created rules start Draft and
    go through submit → approve)."""
    from server.pipeline_config import default_dq_action

    rule_type = v.get("rule_type", "validity")
    dq_action = v.get("dq_action") or default_dq_action(rule_type)
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO mapping_factory.validation_rule
                   (name, code, rule_type, dataset, column_name, severity, description, logic, owner, status, tags)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING *""",
                (
                    v["name"], v.get("code") or v["name"].upper().replace(" ", "_"),
                    rule_type, v.get("dataset"), v.get("column_name"),
                    v.get("severity", "medium"), v.get("description"), v.get("logic"),
                    owner, v.get("status") or "Draft", v.get("tags") or [],
                ),
            )
            row = cur.fetchone()
            # dq_action lives in the SP-owned sidecar (validation_dq), not on validation_rule.
            cur.execute(
                """INSERT INTO mapping_factory.validation_dq (validation_id, dq_action, updated_at)
                   VALUES (%s,%s, now())
                   ON CONFLICT (validation_id) DO UPDATE SET dq_action=EXCLUDED.dq_action, updated_at=now()""",
                (row["id"], dq_action),
            )
        conn.commit()
    row["dq_action"] = dq_action
    return row


class ValidationGovernanceError(Exception):
    """Raised on validation-rule workflow violations (bad state, maker==checker)."""


def submit_validation(pool: ConnectionPool, vid: UUID, submitter: str) -> dict[str, Any]:
    """Draft → Proposed (Pending Approval). Requires logic to review."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT status, logic FROM mapping_factory.validation_rule WHERE id=%s FOR UPDATE", (vid,))
            r = cur.fetchone()
            if r is None:
                raise ValidationGovernanceError("validation rule not found")
            if r["status"] not in ("Draft", "Rejected"):
                raise ValidationGovernanceError(f"cannot submit from status {r['status']}")
            if not (r["logic"] or "").strip():
                raise ValidationGovernanceError("nothing to approve: add rule logic first")
            cur.execute("UPDATE mapping_factory.validation_rule SET status='Proposed' WHERE id=%s", (vid,))
            cur.execute(
                """INSERT INTO mapping_factory.validation_governance (validation_id, submitted_by, approved_by, rationale, updated_at)
                   VALUES (%s,%s,NULL,NULL,now())
                   ON CONFLICT (validation_id)
                   DO UPDATE SET submitted_by=EXCLUDED.submitted_by, approved_by=NULL, rationale=NULL, updated_at=now()""",
                (vid, submitter),
            )
        conn.commit()
    return get_validation(pool, vid)


def decide_validation(pool: ConnectionPool, vid: UUID, *, decision: str, checker: str, rationale: str | None, is_admin: bool = False) -> dict[str, Any]:
    """Approve (→ Published) or reject (→ Rejected). Enforces maker != checker
    unless the checker is an administrator."""
    if decision not in ("approved", "rejected"):
        raise ValidationGovernanceError("decision must be 'approved' or 'rejected'")
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """SELECT v.status, v.owner, g.submitted_by
                   FROM mapping_factory.validation_rule v
                   LEFT JOIN mapping_factory.validation_governance g ON g.validation_id = v.id
                   WHERE v.id=%s FOR UPDATE OF v""",
                (vid,),
            )
            r = cur.fetchone()
            if r is None:
                raise ValidationGovernanceError("validation rule not found")
            if r["status"] != "Proposed":
                raise ValidationGovernanceError(f"cannot decide from status {r['status']}")
            maker = r["submitted_by"] or r["owner"]
            if decision == "approved" and maker and maker == checker and not is_admin:
                raise ValidationGovernanceError("segregation of duties: the maker cannot approve their own validation rule")
            new_status = "Published" if decision == "approved" else "Rejected"
            cur.execute("UPDATE mapping_factory.validation_rule SET status=%s WHERE id=%s", (new_status, vid))
            cur.execute(
                """INSERT INTO mapping_factory.validation_governance (validation_id, submitted_by, approved_by, rationale, updated_at)
                   VALUES (%s,%s,%s,%s,now())
                   ON CONFLICT (validation_id)
                   DO UPDATE SET approved_by=EXCLUDED.approved_by, rationale=EXCLUDED.rationale, updated_at=now()""",
                (vid, maker, checker if decision == "approved" else None, rationale),
            )
        conn.commit()
    return get_validation(pool, vid)
