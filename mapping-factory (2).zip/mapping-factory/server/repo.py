"""Repository access layer over the Lakebase operational tier.

Sync functions (FastAPI runs sync route handlers in a threadpool, which is the
correct model for psycopg's sync pool). Every function takes the pool and
returns plain dicts/rows so routes stay thin. This is the ONLY module that
writes SQL against Postgres, so the metadata invariants live in one place.
"""
from __future__ import annotations

from typing import Any
from uuid import UUID

from psycopg.rows import dict_row
from psycopg.types.json import Json
from psycopg_pool import ConnectionPool


# --- schema bootstrap --------------------------------------------------------

def apply_schema(pool: ConnectionPool, schema_sql: str) -> None:
    """Run the idempotent operational DDL, statement-by-statement.

    Each statement gets its own transaction so a single failing DDL (e.g. an
    ALTER on a table the running identity doesn't own) is isolated and does NOT
    abort the rest — otherwise one owner-restricted statement early in the file
    would block every later CREATE/ALTER (incl. new migrations). Per-statement
    errors are swallowed best-effort; genuinely-missing tables still surface on
    the real request path.
    """
    # Strip full-line SQL comments so they don't confuse the naive ';' split, then
    # execute each non-empty statement independently. The schema is plain DDL
    # (no function bodies), so splitting on ';' is safe here.
    ddl = "\n".join(line for line in schema_sql.splitlines() if not line.strip().startswith("--"))
    for stmt in (s.strip() for s in ddl.split(";")):
        if not stmt:
            continue
        try:
            with pool.connection() as conn:
                with conn.cursor() as cur:
                    # search_path must be re-applied on EVERY statement: each runs in
                    # its own transaction, so an in-file `SET search_path` wouldn't
                    # carry over — unqualified ALTER/CREATE would then hit the wrong
                    # schema (public) and silently no-op.
                    cur.execute("SET search_path TO mapping_factory, public")
                    cur.execute(stmt)
                conn.commit()
        except Exception:  # noqa: BLE001 — isolate per-statement failures (ownership, races)
            pass


# --- assets & fields ---------------------------------------------------------

def create_asset(
    pool: ConnectionPool,
    *,
    name: str,
    object_type: str,
    role: str,
    created_by: str,
    system: str | None = None,
    locator: str | None = None,
    fields: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Insert an asset and its fields in one transaction; return the asset with fields."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO mapping_factory.physical_asset
                   (name, system, locator, object_type, role, created_by)
                   VALUES (%s,%s,%s,%s,%s,%s) RETURNING *""",
                (name, system, locator, object_type, role, created_by),
            )
            asset = cur.fetchone()
            asset_id = asset["id"]
            inserted_fields = []
            for i, f in enumerate(fields or []):
                cur.execute(
                    """INSERT INTO mapping_factory.physical_field
                       (asset_id, name, datatype, nullable, ordinal, semantic_type, sample_profile)
                       VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING *""",
                    (
                        asset_id,
                        f["name"],
                        f["datatype"],
                        f.get("nullable", True),
                        f.get("ordinal", i),
                        f.get("semantic_type"),
                        Json(f["sample_profile"]) if f.get("sample_profile") else None,
                    ),
                )
                inserted_fields.append(cur.fetchone())
        conn.commit()
    asset["fields"] = inserted_fields
    return asset


def get_asset(pool: ConnectionPool, asset_id: UUID) -> dict[str, Any] | None:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM mapping_factory.physical_asset WHERE id=%s", (asset_id,))
            asset = cur.fetchone()
            if asset is None:
                return None
            cur.execute(
                "SELECT * FROM mapping_factory.physical_field WHERE asset_id=%s ORDER BY ordinal",
                (asset_id,),
            )
            asset["fields"] = cur.fetchall()
    return asset


def list_assets(pool: ConnectionPool, role: str | None = None) -> list[dict[str, Any]]:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            if role:
                cur.execute(
                    "SELECT * FROM mapping_factory.physical_asset WHERE role=%s ORDER BY created_at DESC",
                    (role,),
                )
            else:
                cur.execute("SELECT * FROM mapping_factory.physical_asset ORDER BY created_at DESC")
            return cur.fetchall()


# --- mapping specs -----------------------------------------------------------

def create_spec(
    pool: ConnectionPool,
    *,
    name: str,
    source_asset_id: UUID,
    target_asset_id: UUID,
    owner: str,
) -> dict[str, Any]:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO mapping_factory.mapping_spec
                   (name, source_asset_id, target_asset_id, owner)
                   VALUES (%s,%s,%s,%s) RETURNING *""",
                (name, source_asset_id, target_asset_id, owner),
            )
            spec = cur.fetchone()
        conn.commit()
    return spec


def rename_spec(pool: ConnectionPool, spec_id: UUID, name: str) -> None:
    """Rename a mapping spec (updates the display name + touches updated_at)."""
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE mapping_factory.mapping_spec SET name=%s, updated_at=now() WHERE id=%s",
                (name, spec_id),
            )
        conn.commit()


def set_spec_systems(pool: ConnectionPool, spec_id: UUID, *, source_system: str | None, target_system: str | None) -> None:
    """Set the source/target SYSTEM names on a spec (COALESCE-free overwrite when provided)."""
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """UPDATE mapping_factory.mapping_spec
                   SET source_system = COALESCE(%s, source_system),
                       target_system = COALESCE(%s, target_system),
                       updated_at = now()
                   WHERE id=%s""",
                (source_system, target_system, spec_id),
            )
        conn.commit()


def delete_spec(pool: ConnectionPool, spec_id: UUID) -> bool:
    """Delete a mapping spec and its dependent rows. Returns True if a spec was deleted.

    field_mapping has ON DELETE CASCADE, but we clean the other spec-scoped tables
    explicitly (join-table, approval tasks, comments) so no orphans remain."""
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM mapping_factory.mapping_spec WHERE id=%s", (spec_id,))
            if cur.fetchone() is None:
                return False
            cur.execute("DELETE FROM mapping_factory.mapping_spec_asset WHERE spec_id=%s", (spec_id,))
            cur.execute("DELETE FROM mapping_factory.approval_task WHERE spec_id=%s", (spec_id,))
            # mapping_comment may not exist on very old schemas — best-effort.
            try:
                cur.execute("DELETE FROM mapping_factory.mapping_comment WHERE spec_id=%s", (spec_id,))
            except Exception:  # noqa: BLE001
                pass
            cur.execute("DELETE FROM mapping_factory.field_mapping WHERE spec_id=%s", (spec_id,))
            cur.execute("DELETE FROM mapping_factory.mapping_spec WHERE id=%s", (spec_id,))
        conn.commit()
    return True


def clone_spec(pool: ConnectionPool, spec_id: UUID, *, owner: str, new_name: str | None = None) -> dict[str, Any] | None:
    """Deep-copy a spec into a NEW Draft owned by `owner`: same source/target assets,
    systems, joins, and every non-rejected field_mapping (with its transform_rule), all
    reset to 'suggested' state so the clone is freshly reviewable. Returns the new spec."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM mapping_factory.mapping_spec WHERE id=%s", (spec_id,))
            src = cur.fetchone()
            if src is None:
                return None
            name = new_name or f"Copy of {src['name']}"
            cur.execute(
                """INSERT INTO mapping_factory.mapping_spec
                   (name, source_asset_id, target_asset_id, owner, status,
                    source_system, target_system, mapping_type, description, ai_confidence, joins)
                   VALUES (%s,%s,%s,%s,'Draft',%s,%s,%s,%s,%s,%s) RETURNING *""",
                (name, src["source_asset_id"], src["target_asset_id"], owner,
                 src.get("source_system"), src.get("target_system"), src.get("mapping_type"),
                 src.get("description"), src.get("ai_confidence"), Json(src.get("joins")) if src.get("joins") is not None else None),
            )
            new = cur.fetchone()
            new_id = new["id"]
            # Copy the multi-table asset links.
            cur.execute(
                """INSERT INTO mapping_factory.mapping_spec_asset (spec_id, asset_id, role)
                   SELECT %s, asset_id, role FROM mapping_factory.mapping_spec_asset WHERE spec_id=%s""",
                (new_id, spec_id),
            )
            # Copy each non-rejected field_mapping + its transform_rule (new ids).
            cur.execute(
                """SELECT fm.id, fm.target_field_id, fm.source_field_ids, fm.provenance, fm.confidence,
                          tr.kind, tr.spec_json, tr.sql_expression
                   FROM mapping_factory.field_mapping fm
                   LEFT JOIN mapping_factory.transform_rule tr ON tr.id = fm.transform_rule_id
                   WHERE fm.spec_id=%s AND fm.state <> 'rejected'""",
                (spec_id,),
            )
            for r in cur.fetchall():
                new_rule_id = None
                if r["kind"] is not None:
                    cur.execute(
                        """INSERT INTO mapping_factory.transform_rule (kind, spec_json, sql_expression)
                           VALUES (%s,%s,%s) RETURNING id""",
                        (r["kind"], Json(r["spec_json"]) if r["spec_json"] is not None else None, r["sql_expression"]),
                    )
                    new_rule_id = cur.fetchone()["id"]
                cur.execute(
                    """INSERT INTO mapping_factory.field_mapping
                       (spec_id, target_field_id, source_field_ids, transform_rule_id, provenance, confidence, state)
                       VALUES (%s,%s,%s,%s,%s,%s,'suggested')""",
                    (new_id, r["target_field_id"], r["source_field_ids"], new_rule_id,
                     Json(r["provenance"]) if r["provenance"] is not None else Json({}), r["confidence"]),
                )
        conn.commit()
    return get_spec(pool, new_id)


def set_spec_joins(pool: ConnectionPool, spec_id: UUID, joins: list[dict[str, Any]]) -> None:
    """Persist the AI-proposed join keys for a multi-table spec."""
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE mapping_factory.mapping_spec SET joins=%s, updated_at=now() WHERE id=%s",
                (Json(joins), spec_id),
            )
        conn.commit()


def create_spec_multi(
    pool: ConnectionPool,
    *,
    name: str,
    source_asset_ids: list[UUID],
    target_asset_ids: list[UUID],
    owner: str,
) -> dict[str, Any]:
    """Create a spec spanning MULTIPLE source/target tables. The first of each list
    is the 'primary' (kept on mapping_spec.source/target_asset_id for single-table
    back-compat); all are recorded in mapping_spec_asset."""
    if not source_asset_ids or not target_asset_ids:
        raise ValueError("need at least one source and one target asset")
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO mapping_factory.mapping_spec
                   (name, source_asset_id, target_asset_id, owner)
                   VALUES (%s,%s,%s,%s) RETURNING *""",
                (name, source_asset_ids[0], target_asset_ids[0], owner),
            )
            spec = cur.fetchone()
            sid = spec["id"]
            for aid in source_asset_ids:
                cur.execute(
                    "INSERT INTO mapping_factory.mapping_spec_asset (spec_id, asset_id, role) VALUES (%s,%s,'source') ON CONFLICT DO NOTHING",
                    (sid, aid),
                )
            for aid in target_asset_ids:
                cur.execute(
                    "INSERT INTO mapping_factory.mapping_spec_asset (spec_id, asset_id, role) VALUES (%s,%s,'target') ON CONFLICT DO NOTHING",
                    (sid, aid),
                )
        conn.commit()
    return spec


def list_specs(pool: ConnectionPool) -> list[dict[str, Any]]:
    """All mapping specs with display metadata for the Mapping List screen.

    Also computes, from the live field mappings, per-spec signals the tabs use:
      - `mapping_count`  : active (non-rejected) field mappings
      - `pending_count`  : still-suggested (unreviewed) field mappings
      - `ai_authored`    : fraction of active mappings whose provenance.origin='AI'
      - `avg_confidence` : mean confidence of active mappings (falls back to spec.ai_confidence)
    so the list can drive "My", "AI Suggested" (mostly-AI + high confidence), etc.
    """
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """SELECT s.id, s.name, s.description, s.source_system, s.target_system, s.status,
                          s.mapping_type, s.ai_confidence, s.owner, s.updated_at,
                          COALESCE(m.n_active, 0)   AS mapping_count,
                          COALESCE(m.n_pending, 0)  AS pending_count,
                          m.n_ai, m.avg_conf
                   FROM mapping_factory.mapping_spec s
                   LEFT JOIN (
                     SELECT spec_id,
                            COUNT(*) FILTER (WHERE state <> 'rejected')                          AS n_active,
                            COUNT(*) FILTER (WHERE state = 'suggested')                          AS n_pending,
                            COUNT(*) FILTER (WHERE state <> 'rejected' AND provenance->>'origin' = 'AI') AS n_ai,
                            AVG(confidence) FILTER (WHERE state <> 'rejected')                   AS avg_conf
                     FROM mapping_factory.field_mapping GROUP BY spec_id
                   ) m ON m.spec_id = s.id
                   ORDER BY s.updated_at DESC NULLS LAST, s.created_at DESC"""
            )
            out = cur.fetchall()
            for r in out:
                n_active = r.pop("mapping_count", 0) or 0
                n_ai = r.pop("n_ai", None) or 0
                avg_conf = r.pop("avg_conf", None)
                r["mapping_count"] = n_active
                r["ai_authored"] = round(n_ai / n_active, 3) if n_active else 0.0
                # Prefer computed avg confidence; fall back to the stored display value.
                if avg_conf is not None:
                    r["ai_confidence"] = round(float(avg_conf), 3)
            return out


def get_spec(pool: ConnectionPool, spec_id: UUID) -> dict[str, Any] | None:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM mapping_factory.mapping_spec WHERE id=%s", (spec_id,))
            spec = cur.fetchone()
            if spec is None:
                return None
            spec["mappings"] = _mappings_for_spec(cur, spec_id)
            # Multi-table: the full source/target asset sets from the join table.
            # Fall back to the singular primary ids for older single-table specs.
            cur.execute(
                "SELECT asset_id, role FROM mapping_factory.mapping_spec_asset WHERE spec_id=%s",
                (spec_id,),
            )
            rows = cur.fetchall()
            src_ids = [r["asset_id"] for r in rows if r["role"] == "source"]
            tgt_ids = [r["asset_id"] for r in rows if r["role"] == "target"]
            if not src_ids and spec.get("source_asset_id"):
                src_ids = [spec["source_asset_id"]]
            if not tgt_ids and spec.get("target_asset_id"):
                tgt_ids = [spec["target_asset_id"]]
    # Load each asset (with fields) via get_asset — its own connection is fine here.
    spec["sources"] = [a for a in (get_asset(pool, i) for i in src_ids) if a]
    spec["targets"] = [a for a in (get_asset(pool, i) for i in tgt_ids) if a]

    # Attach each mapping's compiled SQL expression (for the Details Transformations
    # tab's code snippet). Deterministic lowering; best-effort per column. Pooled
    # source types (qualified + bare) so multi-table refs resolve.
    try:
        from server import compiler

        src_types: dict[str, str] = {}
        for a in spec["sources"]:
            for f in a["fields"]:
                src_types[f["name"]] = f["datatype"]
                src_types[f"{a['name']}.{f['name']}"] = f["datatype"]
        for m in spec["mappings"]:
            sql = None
            try:
                if (m.get("transform_kind") or "spec") == "spec" and m.get("transform_spec"):
                    sql, _ = compiler._lower_spec_to_sql(m["transform_spec"], src_types)
                elif m.get("transform_sql"):
                    sql = m["transform_sql"]
            except Exception:  # noqa: BLE001 — a column we can't lower still shows its spec
                sql = m.get("transform_sql")
            m["compiled_sql"] = sql
    except Exception:  # noqa: BLE001 — never fail get_spec over the display-only field
        pass
    return spec


def specs_with_metadata(pool: ConnectionPool) -> list[dict[str, Any]]:
    """Every spec with its source/target asset names + column-name sets — the
    substrate for metadata-based 'find similar mappings' (system + column overlap)."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            # Column sets union ALL assets on each side (multi-table specs record every
            # table in mapping_spec_asset); fall back to the singular primary id so old
            # single-table specs still contribute. Same for the display name — show the
            # primary table name plus a "+N" hint when the spec spans more tables.
            cur.execute(
                """SELECT s.id, s.name, s.status, s.owner, s.source_system, s.target_system,
                          src.name AS source_name, tgt.name AS target_name,
                          (SELECT array_agg(DISTINCT f.name) FROM mapping_factory.physical_field f
                             WHERE f.asset_id IN (
                               SELECT asset_id FROM mapping_factory.mapping_spec_asset WHERE spec_id = s.id AND role = 'source'
                               UNION SELECT s.source_asset_id
                             )) AS source_cols,
                          (SELECT array_agg(DISTINCT f.name) FROM mapping_factory.physical_field f
                             WHERE f.asset_id IN (
                               SELECT asset_id FROM mapping_factory.mapping_spec_asset WHERE spec_id = s.id AND role = 'target'
                               UNION SELECT s.target_asset_id
                             )) AS target_cols,
                          (SELECT COUNT(*) FROM mapping_factory.mapping_spec_asset WHERE spec_id = s.id AND role = 'source') AS n_sources,
                          (SELECT COUNT(*) FROM mapping_factory.mapping_spec_asset WHERE spec_id = s.id AND role = 'target') AS n_targets
                   FROM mapping_factory.mapping_spec s
                   LEFT JOIN mapping_factory.physical_asset src ON src.id = s.source_asset_id
                   LEFT JOIN mapping_factory.physical_asset tgt ON tgt.id = s.target_asset_id"""
            )
            return cur.fetchall()


def governance_trail(pool: ConnectionPool, spec_id: UUID) -> dict[str, Any]:
    """Approval task(s) + feedback-event summary for a spec (documentation/audit)."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                "SELECT maker, checker, decision, rationale, created_at, decided_at "
                "FROM mapping_factory.approval_task WHERE spec_id=%s ORDER BY created_at",
                (spec_id,),
            )
            approvals = cur.fetchall()
            cur.execute(
                """SELECT fe.action, COUNT(*) AS n
                   FROM mapping_factory.feedback_event fe
                   JOIN mapping_factory.field_mapping fm ON fm.id = fe.field_mapping_id
                   WHERE fm.spec_id=%s GROUP BY fe.action""",
                (spec_id,),
            )
            feedback = {r["action"]: r["n"] for r in cur.fetchall()}
    return {"approvals": approvals, "feedback": feedback}


def audit_log(pool: ConnectionPool, spec_id: UUID) -> list[dict[str, Any]]:
    """A chronological work log for a mapping — merges spec lifecycle, maker-checker
    decisions, and per-column curation (accept/edit/reject) into one audit trail."""
    events: list[dict[str, Any]] = []
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                "SELECT name, owner, status, created_at, updated_at FROM mapping_factory.mapping_spec WHERE id=%s",
                (spec_id,),
            )
            s = cur.fetchone()
            if s is None:
                return []
            events.append({"at": s["created_at"], "actor": s["owner"], "action": "created", "detail": f"Mapping “{s['name']}” created", "kind": "lifecycle"})

            # Maker-checker: submission + decision.
            cur.execute(
                "SELECT maker, checker, decision, rationale, created_at, decided_at "
                "FROM mapping_factory.approval_task WHERE spec_id=%s ORDER BY created_at",
                (spec_id,),
            )
            for a in cur.fetchall():
                events.append({"at": a["created_at"], "actor": a["maker"], "action": "submitted", "detail": "Submitted for approval", "kind": "governance"})
                if a["decided_at"] and a["decision"]:
                    events.append({
                        "at": a["decided_at"], "actor": a["checker"] or "checker",
                        "action": a["decision"],
                        "detail": (a["rationale"] or ("Approved & published" if a["decision"] == "approved" else "Rejected")),
                        "kind": "governance",
                    })

            # Per-column curation (the learning signal doubles as the audit trail).
            cur.execute(
                """SELECT fe.action, fe.actor, fe.created_at, pf.name AS target_field
                   FROM mapping_factory.feedback_event fe
                   JOIN mapping_factory.field_mapping fm ON fm.id = fe.field_mapping_id
                   JOIN mapping_factory.physical_field pf ON pf.id = fm.target_field_id
                   WHERE fm.spec_id=%s ORDER BY fe.created_at""",
                (spec_id,),
            )
            verb = {"accept": "accepted", "edit": "edited", "reject": "rejected"}
            for f in cur.fetchall():
                events.append({
                    "at": f["created_at"], "actor": f["actor"] or "unknown",
                    "action": verb.get(f["action"], f["action"]),
                    "detail": f"{verb.get(f['action'], f['action']).capitalize()} transformation for `{f['target_field']}`",
                    "kind": "curation",
                })
    events.sort(key=lambda e: (e["at"] is None, e["at"]))
    return events


def list_comments(pool: ConnectionPool, spec_id: UUID) -> list[dict[str, Any]]:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, section, author, body, created_at FROM mapping_factory.mapping_comment "
                "WHERE spec_id=%s ORDER BY created_at",
                (spec_id,),
            )
            return cur.fetchall()


def add_comment(pool: ConnectionPool, spec_id: UUID, *, section: str, author: str, body: str) -> dict[str, Any]:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO mapping_factory.mapping_comment (spec_id, section, author, body) "
                "VALUES (%s,%s,%s,%s) RETURNING id, section, author, body, created_at",
                (spec_id, section, author, body),
            )
            row = cur.fetchone()
        conn.commit()
    return row


def _mappings_for_spec(cur, spec_id: UUID) -> list[dict[str, Any]]:
    """Field mappings joined with their transform rule + target field name."""
    cur.execute(
        """SELECT fm.*, pf.name AS target_field_name,
                  tr.kind AS transform_kind, tr.spec_json AS transform_spec,
                  tr.sql_expression AS transform_sql, tr.description AS transform_description,
                  tr.test_cases AS transform_test_cases
           FROM mapping_factory.field_mapping fm
           JOIN mapping_factory.physical_field pf ON pf.id = fm.target_field_id
           LEFT JOIN mapping_factory.transform_rule tr ON tr.id = fm.transform_rule_id
           WHERE fm.spec_id=%s
           ORDER BY pf.ordinal""",
        (spec_id,),
    )
    return cur.fetchall()


def replace_ai_suggestions(
    pool: ConnectionPool, spec_id: UUID, candidates: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Persist AI candidates as Draft field mappings (+ transform rules).

    Clears prior *suggested* AND *rejected* rows for the spec so re-running Suggest
    yields a fresh batch (a rejected suggestion shouldn't linger and inflate counts;
    its FeedbackEvent already captured the rejection signal). Human accepted/edited
    rows are preserved — re-suggesting never clobbers a decision someone made.
    """
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM mapping_factory.field_mapping WHERE spec_id=%s AND state IN ('suggested','rejected')",
                (spec_id,),
            )
            for c in candidates:
                cur.execute(
                    """INSERT INTO mapping_factory.transform_rule
                       (kind, spec_json, sql_expression, description)
                       VALUES (%s,%s,%s,%s) RETURNING id""",
                    (
                        c["transform_kind"],
                        Json(c["transform_spec"]) if c.get("transform_spec") is not None else None,
                        c.get("transform_sql"),
                        c.get("description"),
                    ),
                )
                rule_id = cur.fetchone()["id"]
                cur.execute(
                    """INSERT INTO mapping_factory.field_mapping
                       (spec_id, target_field_id, source_field_ids, transform_rule_id,
                        confidence, provenance, state)
                       VALUES (%s,%s,%s,%s,%s,%s,'suggested')""",
                    (
                        spec_id,
                        c["target_field_id"],
                        c["source_field_ids"],
                        rule_id,
                        c.get("confidence"),
                        Json(c["provenance"]),
                    ),
                )
            spec_mappings = _mappings_for_spec(cur, spec_id)
        conn.commit()
    return spec_mappings


def set_mapping_provenance(pool: ConnectionPool, mapping_id: UUID, patch: dict[str, Any], *, reset_state: str | None = None) -> None:
    """Merge keys into a field_mapping's provenance JSON (used by the per-item feedback
    actions to stamp reused/regenerated flags). Optionally reset the mapping's state
    (e.g. back to 'suggested' so a regenerated/reused item stays pending review)."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT provenance FROM mapping_factory.field_mapping WHERE id=%s", (mapping_id,))
            row = cur.fetchone()
            if row is None:
                raise KeyError("mapping not found")
            prov = dict(row["provenance"] or {})
            prov.update(patch)
            if reset_state is not None:
                cur.execute(
                    "UPDATE mapping_factory.field_mapping SET provenance=%s, state=%s WHERE id=%s",
                    (Json(prov), reset_state, mapping_id),
                )
            else:
                cur.execute(
                    "UPDATE mapping_factory.field_mapping SET provenance=%s WHERE id=%s",
                    (Json(prov), mapping_id),
                )
        conn.commit()


def update_mapping_state(
    pool: ConnectionPool,
    *,
    mapping_id: UUID,
    action: str,             # accept | edit | reject
    actor: str,
    transform_spec: dict[str, Any] | None = None,
    source_field_ids: list[UUID] | None = None,
) -> dict[str, Any]:
    """Human curation of a suggestion; records a FeedbackEvent (learning signal)."""
    state = {"accept": "accepted", "edit": "edited", "reject": "rejected"}[action]
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            # Capture the AI candidate before mutating, for the feedback trail.
            cur.execute(
                "SELECT provenance, confidence FROM mapping_factory.field_mapping WHERE id=%s",
                (mapping_id,),
            )
            before = cur.fetchone()
            if before is None:
                raise KeyError("mapping not found")

            if action == "edit" and transform_spec is not None:
                # Edited transform: mark provenance HUMAN and rewrite the rule.
                cur.execute(
                    "SELECT transform_rule_id FROM mapping_factory.field_mapping WHERE id=%s",
                    (mapping_id,),
                )
                rule_id = cur.fetchone()["transform_rule_id"]
                cur.execute(
                    "UPDATE mapping_factory.transform_rule SET kind='spec', spec_json=%s WHERE id=%s",
                    (Json(transform_spec), rule_id),
                )
            if source_field_ids is not None:
                cur.execute(
                    "UPDATE mapping_factory.field_mapping SET source_field_ids=%s WHERE id=%s",
                    (source_field_ids, mapping_id),
                )

            new_prov = dict(before["provenance"] or {})
            if action in ("edit", "accept"):
                # Human touched it: attribute accordingly (accept affirms AI, edit overrides).
                new_prov["reviewed_by"] = actor
                if action == "edit":
                    new_prov["origin"] = "HUMAN"
            # An edited transform_spec DIVERGES from any reused library transformation, so
            # clear the reuse stamp — otherwise the detail panel keeps showing "Reused
            # library transformation" for a now-custom expression (optimize/regenerate/hand-edit).
            if action == "edit" and transform_spec is not None:
                new_prov["is_new_transformation"] = True
                for k in ("reused_transformation_code", "reused_transformation_id", "reused_transformation_name"):
                    new_prov.pop(k, None)
            cur.execute(
                "UPDATE mapping_factory.field_mapping SET state=%s, provenance=%s WHERE id=%s RETURNING *",
                (state, Json(new_prov), mapping_id),
            )
            updated = cur.fetchone()

            cur.execute(
                """INSERT INTO mapping_factory.feedback_event
                   (field_mapping_id, action, ai_candidate, human_value, actor)
                   VALUES (%s,%s,%s,%s,%s)""",
                (
                    mapping_id,
                    action,
                    Json(before["provenance"]),
                    Json(transform_spec) if transform_spec is not None else None,
                    actor,
                ),
            )
        conn.commit()
    return updated


def get_layout(pool: ConnectionPool, spec_id: UUID) -> dict[str, Any] | None:
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM mapping_factory.canvas_layout WHERE spec_id=%s", (spec_id,))
            return cur.fetchone()


def put_layout(
    pool: ConnectionPool, spec_id: UUID, *, nodes: Any, edges: Any, viewport: Any
) -> None:
    """Upsert VISUAL canvas state only — never domain truth."""
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """INSERT INTO mapping_factory.canvas_layout (spec_id, nodes, edges, viewport)
                   VALUES (%s,%s,%s,%s)
                   ON CONFLICT (spec_id) DO UPDATE SET
                     nodes=EXCLUDED.nodes, edges=EXCLUDED.edges, viewport=EXCLUDED.viewport""",
                (spec_id, Json(nodes), Json(edges), Json(viewport)),
            )
        conn.commit()
