import { create } from "zustand";
import { api, type Asset, type Spec, type Mapping, type Optimization, type ValidationProposal, type Validation, type MappingDoc, type ValidateRun, type SimilarMapping, type TransformSpec, type ParseTablesResult, type ParsedTable } from "./api";

// Domain state (assets, spec, mappings) is canonical and lives on the server;
// the store mirrors it for the UI. Canvas node positions (visual state) are
// handled separately by the Canvas component and persisted via the layout API.
// One entry on the undo stack: which mapping was rewritten and its prior
// transform_spec, plus any sibling mappings a MERGE absorbed (hidden on apply,
// rejected on save) with their prior state — so Undo can restore everything.
interface OptEdit {
  optId: string;
  mappingId: string;
  prevSpec: TransformSpec | null | undefined;
  mergedIds: string[];              // sibling mappings this merge folded in
  mergedPrevStates: { id: string; state: Mapping["state"] }[];
}

interface AppState {
  source: Asset | null;
  target: Asset | null;
  spec: Spec | null;
  busy: string | null;
  error: string | null;

  // Source/target SYSTEM names typed in the New Mapping setup (before the spec
  // exists). Applied to the spec when it's created; also editable after via setSpecSystems.
  sourceSystem: string;
  targetSystem: string;
  setSystem: (side: "source" | "target", value: string) => void;

  // Optimize Transformations (AI Assistant action). Proposals are fetched, then
  // applied optimistically to the in-store spec (so the canvas reflects them
  // immediately) and only PERSISTED on Save. Undo pops the stack until saved.
  optimizations: Optimization[] | null;   // null = not yet run
  appliedOpts: OptEdit[];                  // undo stack (most recent last)
  optDirty: boolean;                       // applied-but-unsaved edits exist
  optSavedCount: number;                   // # persisted in the last Save (for the confirmation)

  // Validate Mapping (AI Assistant action). Proposals are fetched, selected
  // (Apply toggles selection), then PERSISTED to the DQ Library on Save.
  validations: ValidationProposal[] | null; // null = not yet run
  valCoverage: { covered: number; total: number } | null;
  valDataset: string | null;
  valSelected: string[];                     // ids of proposals marked to save
  valSavedCount: number;                     // # persisted in the last Save

  // Persisted DQ-Library validations for the CURRENT target dataset — surfaced on
  // the canvas as the validation stage (source → transform → validation → target).
  appliedValidations: Validation[];

  // Generate Documentation (AI Assistant action). The generated spec document,
  // shown in a wide doc view; published to the Knowledge Assistant on demand.
  doc: MappingDoc | null;
  docPublished: boolean;

  // Agentic Mapping Validation run — progress shown in the bottom panel.
  valRun: ValidateRun | null;
  valRunError: string | null;

  // Find Similar Mappings (AI Assistant action).
  similar: SimilarMapping[] | null;
  similarBusy: boolean;

  // Multi-table: tables parsed out of the uploaded source/target documents,
  // pending the user's multi-select in the table picker. Null = nothing parsed
  // for that side yet; a spec is created once tables are picked from BOTH sides.
  parsedSources: ParseTablesResult | null;
  parsedTargets: ParseTablesResult | null;

  setError: (e: string | null) => void;
  reset: () => void;
  bootstrapDemo: () => Promise<void>;
  bootstrapComplexDemo: () => Promise<void>;
  ingestDocumentAsSource: (file: File) => Promise<void>;
  // Independent source/target setup — a spec is created once BOTH sides exist.
  setDocument: (file: File, role: "source" | "target") => Promise<void>;
  setFromDDL: (ddl: string, role: "source" | "target", name?: string) => Promise<void>;
  setFromUcTable: (locator: string, role: "source" | "target") => Promise<void>;
  // Multi-table: parse a document into tables (fills parsedSources/parsedTargets
  // for the picker); then create a multi-table spec from the picked tables.
  parseTablesFor: (file: File, role: "source" | "target") => Promise<void>;
  clearParsed: (role: "source" | "target") => void;
  createMultiSpec: (sources: ParsedTable[], targets: ParsedTable[], name?: string) => Promise<void>;
  suggest: () => Promise<void>;
  curate: (m: Mapping, action: "accept" | "edit" | "reject") => Promise<void>;
  curateBulk: (ids: string[], action: "accept" | "reject") => Promise<void>;
  // Per-column feedback loops (Designer detail panel).
  regenerateMapping: (mappingId: string, feedback: string) => Promise<void>;
  useTransformation: (mappingId: string, code: string) => Promise<void>;
  regenerateValidation: (vid: string, feedback: string) => Promise<void>;
  useRuleForValidation: (vid: string, code: string) => Promise<void>;
  setValidationDqAction: (vid: string, action: "warn" | "fail") => Promise<void>;
  addValidationCheck: (dataset: string, column: string, description: string) => Promise<void>;
  addValidationFromRule: (dataset: string, column: string, ruleCode: string) => Promise<void>;
  propagateValidation: (validationId: string, alsoDatasets: string[]) => Promise<void>;
  propagateTransformation: (mappingId: string, alsoDatasets: string[]) => Promise<void>;
  renameSpec: (name: string) => Promise<void>;
  loadSpec: (id: string) => Promise<void>;
  refreshSpec: () => Promise<void>;
  submit: () => Promise<void>;
  decide: (decision: "approved" | "rejected") => Promise<void>;

  optimize: () => Promise<void>;
  clearOptimizations: () => void;
  applyOptimization: (o: Optimization) => void;
  rejectOptimization: (optId: string) => void;
  undoOptimization: () => void;
  saveOptimizations: () => Promise<void>;
  _revertEdit: (e: OptEdit) => void;

  validate: () => Promise<void>;
  clearValidations: () => void;
  toggleValidation: (id: string) => void;
  rejectValidation: (id: string) => void;
  saveValidations: () => Promise<void>;
  loadAppliedValidations: () => Promise<void>;

  generateDoc: () => Promise<void>;
  publishDoc: () => Promise<void>;
  downloadDocPdf: () => Promise<void>;
  clearDoc: () => void;

  startAgenticValidation: () => Promise<void>;
  clearValidationRun: () => void;

  findSimilar: () => Promise<void>;
  clearSimilar: () => void;
}

const withBusy = async (
  set: (p: Partial<AppState>) => void,
  label: string,
  fn: () => Promise<void>,
) => {
  set({ busy: label, error: null });
  try {
    await fn();
  } catch (e) {
    set({ error: String(e instanceof Error ? e.message : e) });
  } finally {
    set({ busy: null });
  }
};

// Create the spec once BOTH a source and a target are registered (and no spec
// exists yet). Called after each independent source/target setup step.
async function _maybeCreateSpec(
  get: () => AppState,
  set: (p: Partial<AppState>) => void,
): Promise<void> {
  const { source, target, spec, sourceSystem, targetSystem } = get();
  if (source && target && !spec) {
    const created = await api.createSpec({
      name: `${source.name} → ${target.name}`,
      source_asset_id: source.id,
      target_asset_id: target.id,
      source_system: sourceSystem.trim() || null,
      target_system: targetSystem.trim() || null,
    });
    set({ spec: created });
  }
}

export const useStore = create<AppState>((set, get) => ({
  source: null,
  target: null,
  spec: null,
  sourceSystem: "",
  targetSystem: "",
  setSystem: (side, value) => {
    set(side === "source" ? { sourceSystem: value } : { targetSystem: value });
    // If the spec already exists, persist immediately so it's not lost.
    const spec = get().spec;
    if (spec) {
      api.setSpecSystems(spec.id, side === "source" ? { source_system: value } : { target_system: value })
        .then((s) => set({ spec: s }))
        .catch(() => {});
    }
  },
  busy: null,
  error: null,
  optimizations: null,
  appliedOpts: [],
  optDirty: false,
  optSavedCount: 0,
  validations: null,
  valCoverage: null,
  valDataset: null,
  valSelected: [],
  valSavedCount: 0,
  appliedValidations: [],
  doc: null,
  docPublished: false,
  valRun: null,
  valRunError: null,
  similar: null,
  similarBusy: false,
  parsedSources: null,
  parsedTargets: null,

  setError: (e) => set({ error: e }),

  // Clear all mapping state back to a blank slate. Called when the New Mapping
  // screen mounts so it always starts empty (the store is a global singleton, so
  // a previously-loaded demo would otherwise persist across navigations).
  reset: () =>
    set({
      source: null,
      target: null,
      spec: null,
      busy: null,
      error: null,
      optimizations: null,
      appliedOpts: [],
      optDirty: false,
      optSavedCount: 0,
      validations: null,
      valCoverage: null,
      valDataset: null,
      valSelected: [],
      valSavedCount: 0,
      appliedValidations: [],
      doc: null,
      docPublished: false,
      valRun: null,
      valRunError: null,
      similar: null,
      similarBusy: false,
      parsedSources: null,
      parsedTargets: null,
    }),

  // One-click golden-path bootstrap: register the seeded source + a target,
  // create a spec. Idempotent enough for a demo (creates fresh each click).
  bootstrapDemo: () =>
    withBusy(set, "Setting up demo…", async () => {
      const source = await api.ingestAsset({
        name: "src_customers",
        object_type: "uc_table",
        role: "source",
        locator: "pritam_demo_workspace_catalog.mapping_factory.src_customers",
      });
      const target = await api.ingestAsset({
        name: "dim_customer",
        object_type: "ddl",
        role: "target",
        content:
          "CREATE TABLE dim_customer (customer_id BIGINT NOT NULL, full_name STRING, balance DOUBLE, signup_date STRING)",
      });
      const spec = await api.createSpec({
        name: "customers → dim_customer",
        source_asset_id: source.id,
        target_asset_id: target.id,
      });
      set({ source, target, spec });
    }),

  // Complex Customer-360 demo: a wide, messy landing-zone table standardized into
  // a conformed dimension. ~24 target columns, most with COMPOUND multi-op
  // transforms — so the canvas is substantial and Optimize has real material.
  // Server does the introspect/create/seed; we just receive the finished spec.
  bootstrapComplexDemo: () =>
    withBusy(set, "Setting up complex demo…", async () => {
      const { source, target, spec } = await api.complexDemo();
      set({ source, target, spec, optimizations: null, appliedOpts: [], optDirty: false, optSavedCount: 0, validations: null, valCoverage: null, valDataset: null, valSelected: [], valSavedCount: 0, appliedValidations: [] });
      get().loadAppliedValidations();
    }),

  // Heterogeneous-document ingestion (Schema Extraction Agent): upload a spec /
  // data-dictionary doc, extract its schema, register as a DRAFT source, then
  // pair it with the demo target + a spec so the same golden path continues.
  ingestDocumentAsSource: (file) =>
    withBusy(set, "Extracting schema from document…", async () => {
      const source = await api.ingestDocument(file, "source");
      const target = await api.ingestAsset({
        name: "dim_customer",
        object_type: "ddl",
        role: "target",
        content:
          "CREATE TABLE dim_customer (customer_id BIGINT NOT NULL, full_name STRING, balance DOUBLE, signup_date STRING)",
      });
      const spec = await api.createSpec({
        name: `${source.name} → dim_customer`,
        source_asset_id: source.id,
        target_asset_id: target.id,
      });
      set({ source, target, spec });
    }),

  // --- Independent source/target setup ------------------------------------
  // Each of these registers ONE side (source or target); once both a source and
  // a target exist, a spec is created linking them. This lets the user bring the
  // target via a data dictionary, a pasted DDL, or an existing UC table — just
  // like the source — instead of the old hardcoded demo target.
  setDocument: (file, role) =>
    withBusy(set, `Extracting ${role} schema from document…`, async () => {
      const asset = await api.ingestDocument(file, role);
      set(role === "source" ? { source: asset } : { target: asset });
      await _maybeCreateSpec(get, set);
    }),

  setFromDDL: (ddl, role, name) =>
    withBusy(set, `Registering ${role} from DDL…`, async () => {
      // Derive the asset name from the DDL's CREATE TABLE <name> when not given.
      const m = ddl.match(/create\s+table\s+(?:if\s+not\s+exists\s+)?[`"]?([\w.]+)[`"]?/i);
      const derived = m ? m[1].split(".").pop()! : `${role}_from_ddl`;
      const asset = await api.ingestAsset({ name: name || derived, object_type: "ddl", role, content: ddl });
      set(role === "source" ? { source: asset } : { target: asset });
      await _maybeCreateSpec(get, set);
    }),

  setFromUcTable: (locator, role) =>
    withBusy(set, `Registering ${role} from UC table…`, async () => {
      const asset = await api.ingestAsset({ name: locator.split(".").pop() || locator, object_type: "uc_table", role, locator });
      set(role === "source" ? { source: asset } : { target: asset });
      await _maybeCreateSpec(get, set);
    }),

  // --- Multi-table setup ---------------------------------------------------
  // Parse a document into its constituent tables and stash them for the picker.
  // NO assets/spec are created yet — the user first multi-selects which tables
  // to map (createMultiSpec does the creation).
  parseTablesFor: (file, role) =>
    withBusy(set, `Extracting ${role} tables from document…`, async () => {
      const res = await api.parseTables(file, role);
      set(role === "source" ? { parsedSources: res } : { parsedTargets: res });
    }),

  clearParsed: (role) => set(role === "source" ? { parsedSources: null } : { parsedTargets: null }),

  // Create a multi-table spec from the picked source/target tables (each becomes
  // an asset). Loads the full spec (with sources[]/targets[]) into the store and
  // clears the picker state.
  createMultiSpec: (sources, targets, name) =>
    withBusy(set, "Creating mapping…", async () => {
      const spec = await api.createSpecMulti({ name, sources, targets });
      set({
        spec,
        source: spec.sources?.[0] ?? null,
        target: spec.targets?.[0] ?? null,
        parsedSources: null,
        parsedTargets: null,
      });
      await get().loadAppliedValidations();
    }),

  suggest: () =>
    withBusy(set, "Asking AI…", async () => {
      const spec = get().spec;
      if (!spec) return;
      await api.suggest(spec.id);
      set({ spec: await api.getSpec(spec.id) });
    }),

  curate: (m, action) =>
    withBusy(set, `${action}…`, async () => {
      const spec = get().spec;
      if (!spec) return;
      await api.curate(spec.id, m.id, { action });
      set({ spec: await api.getSpec(spec.id) });
    }),

  // Regenerate ONE column's transform from feedback; refetch so the canvas + detail update.
  regenerateMapping: (mappingId, feedback) =>
    withBusy(set, "Regenerating transformation…", async () => {
      const spec = get().spec;
      if (!spec) return;
      const fresh = await api.regenerateMapping(spec.id, mappingId, feedback);
      set({ spec: fresh });
    }),
  useTransformation: (mappingId, code) =>
    withBusy(set, "Applying library transformation…", async () => {
      const spec = get().spec;
      if (!spec) return;
      const fresh = await api.useTransformation(spec.id, mappingId, code);
      set({ spec: fresh });
    }),
  // Validation feedback loops — refetch applied validations so the canvas stage updates.
  regenerateValidation: (vid, feedback) =>
    withBusy(set, "Regenerating check…", async () => {
      await api.regenerateValidation(vid, feedback);
      await get().loadAppliedValidations();
    }),
  useRuleForValidation: (vid, code) =>
    withBusy(set, "Applying library rule…", async () => {
      await api.useRuleForValidation(vid, code);
      await get().loadAppliedValidations();
    }),
  setValidationDqAction: (vid, action) =>
    withBusy(set, "Updating DQ action…", async () => {
      await api.setValidationDqAction(vid, action);
      await get().loadAppliedValidations();
    }),
  addValidationCheck: (dataset, column, description) =>
    withBusy(set, "Adding check…", async () => {
      const spec = get().spec;
      if (!spec) return;
      await api.addValidation(spec.id, { dataset, column, description });
      await get().loadAppliedValidations();
    }),
  addValidationFromRule: (dataset, column, ruleCode) =>
    withBusy(set, "Adding library rule…", async () => {
      const spec = get().spec;
      if (!spec) return;
      await api.addValidation(spec.id, { dataset, column, rule_code: ruleCode });
      await get().loadAppliedValidations();
    }),
  propagateValidation: (validationId, alsoDatasets) =>
    withBusy(set, "Applying to other tables…", async () => {
      const spec = get().spec;
      if (!spec || !alsoDatasets.length) return;
      await api.propagateValidation(spec.id, validationId, alsoDatasets);
      await get().loadAppliedValidations();
    }),
  propagateTransformation: (mappingId, alsoDatasets) =>
    withBusy(set, "Applying to other tables…", async () => {
      const spec = get().spec;
      if (!spec || !alsoDatasets.length) return;
      await api.propagateTransformation(spec.id, mappingId, alsoDatasets);
      set({ spec: await api.getSpec(spec.id) });
    }),

  // Bulk accept/reject a set of mappings (Approve all / Reject all on a transform
  // block). Curates each then refetches the spec ONCE so the canvas updates in one shot.
  curateBulk: (ids, action) =>
    withBusy(set, `${action === "accept" ? "Approving" : "Rejecting"} ${ids.length}…`, async () => {
      const spec = get().spec;
      if (!spec || !ids.length) return;
      for (const id of ids) {
        try {
          await api.curate(spec.id, id, { action });
        } catch {
          /* skip individual failures; keep going */
        }
      }
      set({ spec: await api.getSpec(spec.id) });
    }),

  // Rename the mapping (editable name in the designer header). Optimistic: update
  // the in-store name immediately, then persist; re-sync from the server response.
  renameSpec: async (name) => {
    const spec = get().spec;
    const trimmed = name.trim();
    if (!spec || !trimmed || trimmed === spec.name) return;
    set({ spec: { ...spec, name: trimmed } });
    try {
      const updated = await api.renameSpec(spec.id, trimmed);
      set({ spec: updated });
    } catch (e) {
      set({ error: String(e instanceof Error ? e.message : e) });
    }
  },

  // Load an EXISTING spec into the studio (open a Draft to keep editing). Resets
  // the transient AI-action state, hydrates source/target from the spec's primary
  // assets, then loads that spec's applied validations.
  loadSpec: (id) =>
    withBusy(set, "Loading mapping…", async () => {
      get().reset();
      const spec = await api.getSpec(id);
      set({
        spec,
        source: spec.sources?.[0] ?? null,
        target: spec.targets?.[0] ?? null,
      });
      await get().loadAppliedValidations();
    }),

  refreshSpec: () =>
    withBusy(set, "Refreshing…", async () => {
      const spec = get().spec;
      if (!spec) return;
      set({ spec: await api.getSpec(spec.id) });
    }),

  submit: () =>
    withBusy(set, "Submitting…", async () => {
      const spec = get().spec;
      if (!spec) return;
      set({ spec: await api.submit(spec.id) });
    }),

  decide: (decision) =>
    withBusy(set, "Deciding…", async () => {
      const spec = get().spec;
      if (!spec) return;
      set({ spec: await api.decide(spec.id, { decision }) });
    }),

  // Ask the AI to review current transforms and return sqlglot-validated
  // optimizations (propose-only). Clears any previously-applied-but-unsaved edits
  // first by re-fetching the spec, so a fresh review starts from a clean slate.
  optimize: () =>
    withBusy(set, "Reviewing transformations…", async () => {
      const spec = get().spec;
      if (!spec) return;
      const fresh = get().optDirty ? await api.getSpec(spec.id) : spec;
      const res = await api.optimize(spec.id);
      set({ spec: fresh, optimizations: res.optimizations, appliedOpts: [], optDirty: false, optSavedCount: 0 });
    }),

  clearOptimizations: () => set({ optimizations: null, appliedOpts: [], optDirty: false, optSavedCount: 0 }),

  // Apply optimistically: rewrite the target mapping's transform_spec in the
  // in-store spec so the canvas/transform panel reflect it at once. If the proposal
  // MERGES several transformers for one column, the absorbed siblings are marked
  // rejected here so only the merged one remains on the canvas. Push everything onto
  // the undo stack. Nothing is persisted until Save.
  applyOptimization: (o) => {
    const spec = get().spec;
    if (!spec) return;
    if (get().appliedOpts.some((e) => e.optId === o.id)) return; // already applied
    const mergedIds = o.merged_mapping_ids ?? [];
    let prevSpec: TransformSpec | null | undefined;
    const mergedPrevStates: { id: string; state: Mapping["state"] }[] = [];
    const mappings = (spec.mappings ?? []).map((m) => {
      if (m.id === o.mapping_id) {
        prevSpec = m.transform_spec;
        // Flag it optimized (drives the canvas "optimized · unsaved" cue) + surface the title.
        // An optimization DIVERGES from the library transform, so clear the reuse stamp —
        // otherwise the detail panel keeps showing "Reused library transformation".
        return {
          ...m, transform_kind: "spec", transform_spec: o.transform_spec, transform_description: o.title,
          provenance: {
            ...m.provenance, optimized: true, is_new_transformation: true,
            reused_transformation_code: null, reused_transformation_id: null, reused_transformation_name: null,
          },
        };
      }
      if (mergedIds.includes(m.id)) {
        mergedPrevStates.push({ id: m.id, state: m.state });
        return { ...m, state: "rejected" as const };
      }
      return m;
    });
    set({
      spec: { ...spec, mappings },
      appliedOpts: [...get().appliedOpts, { optId: o.id, mappingId: o.mapping_id, prevSpec, mergedIds, mergedPrevStates }],
      optDirty: true,
    });
  },

  // Revert one applied edit in the in-store spec: restore the primary mapping's
  // prior transform, and un-reject any siblings the merge had absorbed.
  _revertEdit: (e: OptEdit) => {
    const spec = get().spec;
    if (!spec) return;
    const restore = new Map(e.mergedPrevStates.map((s) => [s.id, s.state]));
    const mappings = (spec.mappings ?? []).map((m) => {
      if (m.id === e.mappingId) return { ...m, transform_spec: e.prevSpec };
      if (restore.has(m.id)) return { ...m, state: restore.get(m.id)! };
      return m;
    });
    set({ spec: { ...spec, mappings } });
  },

  // Reject a proposal: drop it from the list (and, if it happened to be applied,
  // undo that specific edit too).
  rejectOptimization: (optId) => {
    const { optimizations, appliedOpts } = get();
    const applied = appliedOpts.find((e) => e.optId === optId);
    if (applied) {
      get()._revertEdit(applied);
      const remaining = appliedOpts.filter((e) => e.optId !== optId);
      set({ appliedOpts: remaining, optDirty: remaining.length > 0 });
    }
    set({ optimizations: (optimizations ?? []).filter((o) => o.id !== optId) });
  },

  // Undo the most recent apply (until saved): restore its mapping(s) prior state.
  undoOptimization: () => {
    const { appliedOpts } = get();
    if (!appliedOpts.length) return;
    get()._revertEdit(appliedOpts[appliedOpts.length - 1]);
    const remaining = appliedOpts.slice(0, -1);
    set({ appliedOpts: remaining, optDirty: remaining.length > 0 });
  },

  // Persist all applied optimizations via the maker-checker curate path — each edit
  // becomes a FeedbackEvent with provenance HUMAN, and any sibling mappings a merge
  // absorbed are rejected server-side (so a merged column ends up as ONE mapping).
  saveOptimizations: () =>
    withBusy(set, "Saving optimizations…", async () => {
      const { spec, appliedOpts } = get();
      if (!spec || !appliedOpts.length) return;
      // Latest edit per mapping wins (a column may have been optimized then re-optimized).
      const latestByMapping = new Map<string, TransformSpec>();
      const toReject = new Set<string>();
      for (const e of appliedOpts) {
        const opt = (get().optimizations ?? []).find((o) => o.id === e.optId);
        const m = (spec.mappings ?? []).find((x) => x.id === e.mappingId);
        const ts = opt?.transform_spec ?? m?.transform_spec ?? undefined;
        if (ts) latestByMapping.set(e.mappingId, ts);
        e.mergedIds.forEach((id) => toReject.add(id));
      }
      for (const [mappingId, transform_spec] of latestByMapping) {
        await api.curate(spec.id, mappingId, { action: "edit", transform_spec });
      }
      for (const mappingId of toReject) {
        await api.curate(spec.id, mappingId, { action: "reject" });
      }
      set({
        spec: await api.getSpec(spec.id),
        optimizations: null,
        appliedOpts: [],
        optDirty: false,
        optSavedCount: latestByMapping.size,
      });
    }),

  // Ask the AI to review the mapping and propose post-transformation DQ checks
  // (propose-only, sqlglot-gated). All proposals start SELECTED so Save-all is easy.
  validate: () =>
    withBusy(set, "Reviewing data quality…", async () => {
      const spec = get().spec;
      if (!spec) return;
      const res = await api.validateMapping(spec.id);
      set({
        validations: res.validations,
        valCoverage: res.coverage,
        valDataset: res.dataset,
        valSelected: res.validations.map((v) => v.id),
        valSavedCount: 0,
      });
    }),

  clearValidations: () => set({ validations: null, valCoverage: null, valDataset: null, valSelected: [], valSavedCount: 0 }),

  // Toggle whether a proposal is included in the Save.
  toggleValidation: (id) => {
    const sel = get().valSelected;
    set({ valSelected: sel.includes(id) ? sel.filter((x) => x !== id) : [...sel, id] });
  },

  // Reject drops a proposal from the list entirely (and from the selection).
  rejectValidation: (id) =>
    set({
      validations: (get().validations ?? []).filter((v) => v.id !== id),
      valSelected: get().valSelected.filter((x) => x !== id),
    }),

  // Persist the selected checks into the DQ Library (validation_rule) via the apply
  // endpoint. Multi-table: each proposal carries its own dataset (target table), so
  // we group by dataset and apply once per table.
  saveValidations: () =>
    withBusy(set, "Saving validations…", async () => {
      const { spec, validations, valSelected, valDataset } = get();
      if (!spec || !validations || !valSelected.length) return;
      const items = validations.filter((v) => valSelected.includes(v.id));
      const byDataset = new Map<string, typeof items>();
      for (const it of items) {
        const ds = it.dataset || it.target_table || valDataset || "";
        if (!ds) continue;
        (byDataset.get(ds) ?? byDataset.set(ds, []).get(ds)!).push(it);
      }
      let created = 0;
      for (const [dataset, group] of byDataset) {
        const res = await api.applyValidations(spec.id, { dataset, items: group });
        created += res.created;
      }
      set({ validations: null, valCoverage: null, valDataset: null, valSelected: [], valSavedCount: created });
      await get().loadAppliedValidations(); // refresh the canvas validation stage
    }),

  // Load the DQ-Library validations THAT BELONG TO THIS SPEC so each target table's
  // validation stage renders. Scoped by the `spec:<id>` tag written at apply time —
  // NOT by dataset name alone (two mappings can target a table of the same name, so a
  // brand-new mapping must NOT inherit another mapping's saved checks). Best-effort.
  loadAppliedValidations: async () => {
    const { spec } = get();
    if (!spec) {
      set({ appliedValidations: [] });
      return;
    }
    const specTag = `spec:${spec.id}`;
    try {
      const all = await api.listValidations();
      set({ appliedValidations: all.filter((v) => (v.tags ?? []).includes(specTag)) });
    } catch {
      set({ appliedValidations: [] });
    }
  },

  // Generate the full mapping-specification document (facts + AI prose).
  generateDoc: () =>
    withBusy(set, "Generating documentation…", async () => {
      const spec = get().spec;
      if (!spec) return;
      const doc = await api.generateDocumentation(spec.id);
      set({ doc, docPublished: false });
    }),

  // Feed the generated doc to the Knowledge Assistant (evidence volume + sync).
  publishDoc: () =>
    withBusy(set, "Publishing to Knowledge Assistant…", async () => {
      const { spec, doc } = get();
      if (!spec || !doc) return;
      await api.publishDocumentation(spec.id, doc.markdown);
      set({ docPublished: true });
    }),

  // Download the document as a real .pdf file (server-generated, one click).
  downloadDocPdf: () =>
    withBusy(set, "Preparing PDF…", async () => {
      const spec = get().spec;
      if (!spec) return;
      await api.downloadDocumentationPdf(spec.id);
    }),

  clearDoc: () => set({ doc: null, docPublished: false }),

  // Kick off an Agentic Mapping Validation run and poll it to completion. The
  // pipeline is provisioned on first use if setup hasn't run yet. Progress lands
  // in valRun (rendered in the bottom panel); polling stops at a terminal status.
  startAgenticValidation: async () => {
    const spec = get().spec;
    if (!spec) return;
    set({ valRun: null, valRunError: null });
    try {
      // Ensure the test pipeline exists (idempotent; slow only the very first time).
      const st = await api.pipelineStatus();
      if (!st.provisioned) {
        set({ valRun: { run_id: "", spec_id: spec.id, status: "running", steps: [{ key: "provision", agent: "Setup", description: "Provisioning the test pipeline (first run only)…", status: "running", elapsed_sec: null }] } });
        await api.provisionPipeline();
      }
      const run = await api.startValidateRun(spec.id);
      set({ valRun: run });
      // Poll — RESILIENT: a single failed fetch (a transient network/proxy blip,
      // common on Databricks Apps) must NOT kill the loop, or the UI freezes at the
      // current step forever while the backend run keeps going. Retry with backoff;
      // surface a soft "reconnecting" note; only give up after many consecutive fails.
      let fails = 0;
      const MAX_FAILS = 10;
      const poll = async () => {
        const cur = get().valRun;
        if (!cur || cur.status !== "running" || !cur.run_id) return;
        try {
          const next = await api.getValidateRun(spec.id, cur.run_id);
          fails = 0;
          set({ valRun: next, valRunError: null }); // clear any transient note on success
          if (next.status === "running") setTimeout(poll, 4000);
        } catch (e) {
          fails += 1;
          if (fails >= MAX_FAILS) {
            set({ valRunError: `Lost connection to the run after ${MAX_FAILS} retries (${String(e instanceof Error ? e.message : e)}). The pipeline may still be running — use “Run again” to reconnect.` });
            return; // give up polling; the run continues server-side
          }
          // Transient: keep the run visible, show a soft reconnect note, back off.
          set({ valRunError: `Reconnecting… (attempt ${fails} of ${MAX_FAILS})` });
          setTimeout(poll, Math.min(3000 * fails, 15000));
        }
      };
      setTimeout(poll, 3000);
    } catch (e) {
      set({ valRunError: String(e instanceof Error ? e.message : e), valRun: null });
    }
  },

  clearValidationRun: () => set({ valRun: null, valRunError: null }),

  // Find mappings similar to the current spec by table + column metadata.
  findSimilar: async () => {
    const spec = get().spec;
    if (!spec) return;
    set({ similarBusy: true, similar: null });
    try {
      const res = await api.similarMappings(spec.id);
      set({ similar: res.matches, similarBusy: false });
    } catch (e) {
      set({ similarBusy: false, error: String(e instanceof Error ? e.message : e) });
    }
  },
  clearSimilar: () => set({ similar: null }),
}));
