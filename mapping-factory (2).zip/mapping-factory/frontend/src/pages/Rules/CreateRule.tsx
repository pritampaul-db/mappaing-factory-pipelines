import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sparkles, Wand2, CheckCircle2, LayoutTemplate, Braces, FileCode2, Check } from "lucide-react";
import { usePage } from "../../AppShell";
import { api } from "../../api";
import { WizardStepper } from "../../components/WizardStepper";
import { Button, Breadcrumbs } from "../../components/primitives";

const STEPS = ["Define Rule", "Set Logic", "Test & Preview", "Review & Submit"];
type Method = "AI Assisted" | "Template Based" | "Expression Builder" | "Custom SQL";
const METHODS: { icon: typeof Sparkles; label: Method; sub: string; rec?: boolean }[] = [
  { icon: Sparkles, label: "AI Assisted", sub: "Describe the rule and let AI generate the logic.", rec: true },
  { icon: LayoutTemplate, label: "Template Based", sub: "Start from a pre-built rule template." },
  { icon: Braces, label: "Expression Builder", sub: "Compose the logic from input / operation / output." },
  { icon: FileCode2, label: "Custom SQL", sub: "Write the Spark SQL logic directly." },
];
const RULE_TYPES = ["standardization", "business", "validation", "derivation", "custom"];
const DATA_TYPES = ["String", "Numeric", "Date", "Boolean"];

// Reusable, dataset-agnostic rule templates (use <input> as the column placeholder).
const TEMPLATES: { label: string; rule_type: string; logic: string }[] = [
  { label: "Trim Whitespace", rule_type: "standardization", logic: "TRIM(<input>)" },
  { label: "Proper Case", rule_type: "standardization", logic: "INITCAP(<input>)" },
  { label: "Remove Special Chars", rule_type: "standardization", logic: "REGEXP_REPLACE(<input>, '[^a-zA-Z0-9 ]', '')" },
  { label: "Date To ISO", rule_type: "standardization", logic: "DATE_FORMAT(TO_DATE(<input>), 'yyyy-MM-dd')" },
  { label: "Valid Email", rule_type: "validation", logic: "<input> RLIKE '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'" },
  { label: "Numeric Range", rule_type: "validation", logic: "<input> BETWEEN <min> AND <max>" },
  { label: "Age From DOB", rule_type: "derivation", logic: "FLOOR(DATEDIFF(CURRENT_DATE(), TO_DATE(<input>)) / 365.25)" },
  { label: "Concatenate", rule_type: "derivation", logic: "CONCAT_WS(' ', <a>, <b>)" },
];
const OPERATIONS = ["TRIM", "UPPER", "LOWER", "INITCAP", "CAST", "COALESCE", "REGEXP_REPLACE", "DATE_FORMAT"];

interface Gen { name?: string; description?: string; logic_sql: string; logic_preview: string; explanation: string; sample_io: { input: string; output: string }[]; }

export function CreateRule() {
  const nav = useNavigate();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [ruleType, setRuleType] = useState("standardization");
  const [domain, setDomain] = useState("Customer");
  const [dataType, setDataType] = useState("String");
  const [description, setDescription] = useState("");
  const [method, setMethod] = useState<Method>("AI Assisted");
  const [prompt, setPrompt] = useState("");
  const [logic, setLogic] = useState("");
  const [gen, setGen] = useState<Gen | null>(null);
  const [validation, setValidation] = useState<{ valid: boolean; error?: string } | null>(null);
  const [exprOp, setExprOp] = useState("TRIM");
  const [exprArg, setExprArg] = useState("<input>");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  usePage({ title: "Create Rule", subtitle: "Define a reusable rule, then submit it for approval" });

  const generate = async () => {
    setBusy(true); setErr(null);
    try {
      const g = await api.generateRule({ description: prompt || description, rule_type: ruleType, data_type: dataType });
      setGen(g);
      if (g.logic_sql) { setLogic(g.logic_sql); setValidation(null); }
      if (g.name && !name.trim()) setName(g.name);
      if (g.description && !description.trim()) setDescription(g.description);
    } catch (e) {
      setErr(String(e instanceof Error ? e.message : e));
    } finally {
      setBusy(false);
    }
  };

  const validate = async () => setValidation(await api.validateRuleLogicExpression(logic));
  const applyExpr = () => { setLogic(`${exprOp}(${exprArg})`); setValidation(null); };
  const templatesForType = useMemo(() => TEMPLATES.filter((t) => t.rule_type === ruleType || method === "Template Based"), [ruleType, method]);

  const save = async (mode: "draft" | "submit") => {
    setErr(null);
    if (!name.trim()) { setErr("Rule name is required."); setStep(0); return; }
    if (!logic.trim()) { setErr("Rule logic is required — generate, pick a template, build, or write it."); setStep(1); return; }
    setBusy(true);
    try {
      const created = await api.createRule({
        name: name.trim(), rule_type: ruleType, domain, data_type: dataType,
        description: description || null, logic_sql: logic, logic_preview: gen?.logic_preview || logic,
        sample_io: gen?.sample_io ?? null, tags: [ruleType, domain.toLowerCase()], status: "Draft",
      });
      if (mode === "submit") await api.submitRule(created.id);
      nav("/rules");
    } catch (e) {
      setErr(String(e instanceof Error ? e.message : e));
    } finally {
      setBusy(false);
    }
  };

  const next = () => (step < STEPS.length - 1 ? setStep(step + 1) : save("submit"));

  return (
    <div className="flex flex-col h-full">
      <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
        <WizardStepper steps={STEPS} current={step} />
        <div className="flex items-center gap-2">
          <Button variant="secondary" onClick={() => save("draft")} disabled={busy}>Save Draft</Button>
          <Button variant="secondary" onClick={() => nav("/rules")}>Cancel</Button>
          {step > 0 && <Button variant="secondary" onClick={() => setStep(step - 1)}>Back</Button>}
          <Button onClick={next} disabled={busy}>{step < STEPS.length - 1 ? "Next" : busy ? "Submitting…" : "Submit for Approval"}</Button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <Breadcrumbs items={[{ label: "Rule Library" }, { label: "Create Rule" }]} />
        {err && <p className="text-xs text-red-600 mt-3">{err}</p>}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5 mt-4">
          <div className="xl:col-span-2 space-y-5">
            {step === 0 && (
              <Section n="1" title="Rule Information">
                <div className="grid grid-cols-2 gap-4">
                  <Labeled label="Rule Name *"><input value={name} onChange={(e) => setName(e.target.value)} className="inp" placeholder="Trim Whitespace" /></Labeled>
                  <Labeled label="Rule Type *"><select value={ruleType} onChange={(e) => setRuleType(e.target.value)} className="inp">{RULE_TYPES.map((t) => <option key={t}>{t}</option>)}</select></Labeled>
                  <Labeled label="Domain *"><input value={domain} onChange={(e) => setDomain(e.target.value)} className="inp" /></Labeled>
                  <Labeled label="Data Type *"><select value={dataType} onChange={(e) => setDataType(e.target.value)} className="inp">{DATA_TYPES.map((t) => <option key={t}>{t}</option>)}</select></Labeled>
                  <div className="col-span-2"><Labeled label="Description"><textarea value={description} onChange={(e) => setDescription(e.target.value)} className="inp h-16" placeholder="Removes leading and trailing whitespace." /></Labeled></div>
                </div>
                <p className="text-[11px] text-gray-400 mt-2">Rules are reusable and dataset-agnostic — you tag a rule to a dataset later by applying it from the library.</p>
              </Section>
            )}

            {step === 1 && (
              <Section n="2" title="Rule Definition Method">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {METHODS.map((m) => (
                    <button key={m.label} onClick={() => setMethod(m.label)} className={`border rounded-lg p-3 text-left ${method === m.label ? "border-brand bg-brand-soft/40" : "border-gray-200 hover:border-brand/40"}`}>
                      <m.icon className="w-5 h-5 text-brand mb-1" />
                      <div className="text-xs font-medium text-gray-800">{m.label}{m.rec && <span className="ml-1 text-[9px] bg-green-100 text-green-700 px-1 rounded">Recommended</span>}</div>
                      <div className="text-[10px] text-gray-400 leading-tight mt-0.5">{m.sub}</div>
                    </button>
                  ))}
                </div>
                <div className="mt-4">
                  {method === "AI Assisted" && (
                    <Labeled label="Describe the rule"><textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} className="inp h-20" placeholder="Remove leading/trailing spaces and collapse repeated spaces." /></Labeled>
                  )}
                  {method === "Template Based" && (
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Pick a template — it prefills the logic.</div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {templatesForType.map((t) => (
                          <button key={t.label} onClick={() => { setLogic(t.logic); setRuleType(t.rule_type); setValidation(null); }} className="border border-gray-200 rounded-lg p-2 text-left hover:border-brand/40">
                            <div className="text-xs font-medium text-gray-800">{t.label}</div>
                            <code className="text-[10px] text-gray-400 font-mono line-clamp-1">{t.logic}</code>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  {method === "Expression Builder" && (
                    <div className="flex items-end gap-2">
                      <Labeled label="Operation"><select value={exprOp} onChange={(e) => setExprOp(e.target.value)} className="inp w-44">{OPERATIONS.map((o) => <option key={o}>{o}</option>)}</select></Labeled>
                      <Labeled label="Argument(s)"><input value={exprArg} onChange={(e) => setExprArg(e.target.value)} className="inp w-52" placeholder="<input>" /></Labeled>
                      <Button variant="secondary" onClick={applyExpr}>Apply</Button>
                    </div>
                  )}
                  <div className="mt-4">
                    <Labeled label="Rule Logic (Spark SQL) *">
                      <textarea value={logic} onChange={(e) => { setLogic(e.target.value); setValidation(null); }} className="inp font-mono text-xs h-24" placeholder="TRIM(<input>)" />
                    </Labeled>
                    <div className="flex items-center gap-2 mt-2">
                      <Button variant="secondary" onClick={validate} disabled={!logic.trim()}>Validate Expression</Button>
                      {validation && <span className={`text-xs ${validation.valid ? "text-green-600" : "text-red-600"}`}>{validation.valid ? "✓ Valid Spark expression" : `✗ ${validation.error}`}</span>}
                    </div>
                    <p className="text-[10px] text-gray-400 mt-1">Use &lt;input&gt; (or &lt;a&gt;, &lt;b&gt;, &lt;min&gt;…) as placeholders — actual columns are bound when the rule is applied to a dataset.</p>
                  </div>
                </div>
              </Section>
            )}

            {step === 2 && (
              <Section n="3" title="Test & Preview">
                <div className="text-xs text-gray-500 mb-2">Rule logic:</div>
                <code className="block bg-[#0d1117] text-emerald-300 rounded px-3 py-2 text-[11px] font-mono whitespace-pre-wrap">{logic || "— no logic defined —"}</code>
                <div className="flex items-center gap-2 mt-2">
                  <Button variant="secondary" onClick={validate} disabled={!logic.trim()}>Re-validate</Button>
                  {validation && <span className={`text-xs ${validation.valid ? "text-green-600" : "text-red-600"}`}>{validation.valid ? "✓ Valid" : `✗ ${validation.error}`}</span>}
                </div>
                {gen?.sample_io && gen.sample_io.length > 0 && (
                  <table className="w-full text-xs mt-3">
                    <thead><tr className="text-gray-400 text-left"><th className="font-normal py-1">Input</th><th className="font-normal py-1">Output</th></tr></thead>
                    <tbody>{gen.sample_io.map((s, i) => <tr key={i} className="border-t border-gray-100"><td className="py-1 font-mono text-gray-600">{s.input}</td><td className="py-1 font-mono text-gray-800">{s.output}</td></tr>)}</tbody>
                  </table>
                )}
              </Section>
            )}

            {step === 3 && (
              <Section n="4" title="Review & Submit">
                <dl className="text-sm grid grid-cols-2 gap-y-2">
                  <Row k="Name" v={name || "—"} /><Row k="Rule Type" v={ruleType} />
                  <Row k="Domain" v={domain} /><Row k="Data Type" v={dataType} />
                </dl>
                {description && <p className="text-xs text-gray-500 mt-2">{description}</p>}
                <div className="text-xs text-gray-500 mt-3 mb-1">Logic</div>
                <code className="block bg-[#0d1117] text-emerald-300 rounded px-3 py-2 text-[11px] font-mono whitespace-pre-wrap">{logic || "—"}</code>
                <p className="text-[11px] text-gray-500 mt-3">Submitting sends this rule for approval — it becomes <b>Pending Approval</b> until a reviewer (or admin) approves it, then it is Published and available to apply to datasets.</p>
              </Section>
            )}
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-5 self-start">
            <div className="flex items-center gap-2 mb-1"><Sparkles className="w-4 h-4 text-brand" /><span className="font-semibold text-gray-800">AI Assistant</span></div>
            <div className="text-xs text-gray-500 mb-2">Describe what you want to achieve</div>
            <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} className="inp h-24" placeholder="Remove leading and trailing spaces from customer name" />
            <Button className="w-full justify-center mt-2" onClick={generate} disabled={busy || (!prompt.trim() && !description.trim())}><Wand2 className="w-4 h-4" /> {busy ? "Generating…" : "Generate Rule"}</Button>
            {gen && (
              <div className="mt-4 border border-gray-200 rounded-lg p-3">
                <div className="flex items-center gap-2 text-sm font-medium text-gray-800 mb-1"><CheckCircle2 className="w-4 h-4 text-green-600" /> Generated</div>
                <p className="text-xs text-gray-600">{gen.explanation}</p>
                <code className="block bg-gray-900 text-green-300 rounded px-2 py-2 text-[11px] font-mono whitespace-pre-wrap mt-2">{gen.logic_sql}</code>
                <Button variant="secondary" className="w-full justify-center mt-2" onClick={() => { setLogic(gen.logic_sql); setValidation(null); }}><Check className="w-3.5 h-3.5" /> Use this logic</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ n, title, children }: { n: string; title: string; children: React.ReactNode }) {
  return <div className="bg-white rounded-xl border border-gray-200 p-5"><div className="text-sm font-semibold text-gray-800 mb-3">{n}. {title}</div>{children}</div>;
}
function Labeled({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block"><span className="text-xs text-gray-500 mb-1 block">{label}</span>{children}</label>;
}
function Row({ k, v }: { k: string; v: string }) {
  return <><dt className="text-gray-500">{k}</dt><dd className="text-gray-800 capitalize">{v}</dd></>;
}
