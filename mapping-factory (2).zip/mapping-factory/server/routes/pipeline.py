"""Deploy-as-Pipeline — git credential + repo/branch discovery + the deploy orchestrator.

Endpoints back the wizard opened from the Mapping List three-dots menu:
  GET  /git/credential                      → is a git PAT stored for me? (safe metadata)
  POST /git/credential   {git_username,token}→ store it encrypted (+ Databricks git-cred)
  GET  /git/repos                            → list my GitHub repos
  POST /git/repos        {name}              → create a new repo
  GET  /git/branches?repo=…                  → list a repo's branches (+ default)
  POST /specs/{id}/deploy-pipeline {…}       → generate DAB+SDP, commit, create pipeline
  POST /pipelines/{pid}/run                  → trigger a run (test with dummy data)
"""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from server import (
    config,
    db,
    githubapi,
    pipeline_deploy,
    pipeline_deploy_run,
    pipeline_test_run,
    repo,
    repo_git,
)

router = APIRouter(tags=["pipeline"])

# Only finalized (approved) mappings are deployable. In this lifecycle the terminal
# approved state is stored as "Approved" (the "Published" tab is its display label);
# the extra values are accepted defensively in case a deployment is labelled Live/Published.
_DEPLOYABLE_STATUSES = {"Approved", "Published", "Live"}


def _user() -> str:
    try:
        return config.get_workspace_client().current_user.me().user_name or "unknown"
    except Exception:  # noqa: BLE001
        return "unknown"


def _token_or_402(user: str) -> tuple[str, str]:
    got = repo_git.get_token(db.pool, user)
    if not got:
        raise HTTPException(status_code=428, detail="no git credential stored — add a GitHub token first")
    return got  # (git_username, token)


# --- git credential ----------------------------------------------------------

@router.get("/pipeline/defaults")
def pipeline_defaults() -> dict:
    """Default catalog/schema so the wizard can prefill (empty field → this fallback)."""
    return {"catalog": config.UC_CATALOG, "schema": config.UC_SCHEMA}


@router.get("/git/credential")
def get_git_credential() -> dict:
    row = repo_git.has_credential(db.pool, _user())
    return {"stored": bool(row), "git_username": (row or {}).get("git_username")}


class GitCredIn(BaseModel):
    git_username: str
    token: str


@router.post("/git/credential")
def save_git_credential(body: GitCredIn) -> dict:
    if not body.token.strip():
        raise HTTPException(status_code=422, detail="token is required")
    # Validate the token against GitHub before storing.
    try:
        with githubapi.GitHub(body.token) as gh:
            login = gh.whoami()
    except githubapi.GitHubError as e:
        raise HTTPException(status_code=400, detail=f"token rejected by GitHub: {e}")
    row = repo_git.save_credential(db.pool, _user(), git_username=body.git_username or login, token=body.token)
    return {"stored": True, "git_username": row.get("git_username"), "github_login": login}


# --- repos & branches --------------------------------------------------------

@router.get("/git/repos")
def list_repos() -> dict:
    _u, token = _token_or_402(_user())
    with githubapi.GitHub(token) as gh:
        return {"repos": gh.list_repos()}


class NewRepoIn(BaseModel):
    name: str
    private: bool = True
    description: str = "Mapping Factory pipeline"


@router.post("/git/repos")
def create_repo(body: NewRepoIn) -> dict:
    _u, token = _token_or_402(_user())
    with githubapi.GitHub(token) as gh:
        return gh.create_repo(body.name, private=body.private, description=body.description)


@router.get("/git/branches")
def list_branches(repo: str) -> dict:  # repo = full_name owner/name
    _u, token = _token_or_402(_user())
    with githubapi.GitHub(token) as gh:
        default = gh.default_branch(repo)
    return {"default_branch": default}


# --- the deploy orchestrator -------------------------------------------------

class DeployPipelineIn(BaseModel):
    repo_full_name: str                 # owner/name (existing or just-created)
    branch: str                         # target branch
    new_branch_from: str | None = None  # if set, create `branch` off this base
    pipeline_name: str
    source_catalog: str | None = None    # catalog the source tables are read FROM
    source_schema: str                   # schema  the source tables are read FROM
    target_catalog: str | None = None    # catalog the target tables are written TO
    target_schema: str                   # schema  the target tables are written TO
    table_type: str = "streaming_table"  # streaming_table | materialized_view | delta_table
    schedule: str | None = None          # quartz cron, optional
    commit_message: str | None = None


@router.post("/specs/{spec_id}/deploy-pipeline")
def deploy_pipeline(spec_id: UUID, body: DeployPipelineIn) -> dict:
    """Kick off the deploy on a background thread and return a deploy_id to poll.

    The wizard shows live commentary (prepare → bundle → commit → git folder →
    pipeline) by polling GET /pipeline/deploy/{deploy_id}; on failure the runner
    rolls back the Databricks artifacts it created this run."""
    user = _user()
    _git_username, token = _token_or_402(user)

    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    # Only APPROVED mappings are deployable — Draft/Proposed/etc. aren't finalized.
    if (spec.get("status") or "") not in _DEPLOYABLE_STATUSES:
        raise HTTPException(status_code=409,
                            detail=f"only approved mappings can be deployed (this one is '{spec.get('status')}')")
    if not (spec.get("sources") and spec.get("targets")):
        raise HTTPException(status_code=422, detail="spec has no source/target assets")

    run = pipeline_deploy_run.start_deploy(spec_id, body, token=token)
    return {"deploy_id": run["deploy_id"], "status": run["status"], "steps": run["steps"]}


@router.get("/pipeline/deploy/{deploy_id}")
def deploy_status(deploy_id: str) -> dict:
    """Poll the live status/commentary of a deploy run."""
    run = pipeline_deploy_run.get_run(deploy_id)
    if run is None:
        raise HTTPException(status_code=404, detail="deploy run not found")
    return run


@router.post("/pipelines/{pipeline_id}/run")
def run_pipeline(pipeline_id: str) -> dict:
    try:
        return pipeline_deploy.run_pipeline(pipeline_id)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"pipeline run failed: {e}")


class TestRunIn(BaseModel):
    pipeline_id: str
    source_catalog: str | None = None
    source_schema: str
    target_catalog: str | None = None
    target_schema: str
    table_type: str = "streaming_table"


@router.post("/specs/{spec_id}/pipelines/test")
def seed_and_run(spec_id: UUID, body: TestRunIn) -> dict:
    """Kick off 'Test with dummy data' on a background thread; return a test_id to poll.

    The wizard shows live commentary (seed → config → start → run → audit) via
    GET /pipeline/test/{test_id}. The deployed pipeline reads real source tables that
    don't exist in a test schema, so we seed them, write a fresh config row, run, wait,
    then roll up DQ results into the audit table."""
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    run = pipeline_test_run.start_test(
        spec_id, pipeline_id=body.pipeline_id,
        source_catalog=body.source_catalog, source_schema=body.source_schema,
        target_catalog=body.target_catalog, target_schema=body.target_schema,
        table_type=body.table_type)
    return {"test_id": run["test_id"], "status": run["status"], "steps": run["steps"]}


@router.get("/pipeline/test/{test_id}")
def test_status(test_id: str) -> dict:
    """Poll the live status/commentary of a Test-with-dummy-data run."""
    run = pipeline_test_run.get_run(test_id)
    if run is None:
        raise HTTPException(status_code=404, detail="test run not found")
    return run