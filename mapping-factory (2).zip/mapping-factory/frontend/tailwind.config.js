/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Deep-maroon sidebar gradient (from the wireframes).
        sidebar: {
          from: "#6d0e13",
          to: "#3d0508",
          active: "#a51420",
          hover: "#540a0e",
        },
        // Primary brand red for actions/links.
        brand: {
          DEFAULT: "#c9252d",
          hover: "#a51420",
          soft: "#fdecec",
        },
        // Status palette for badges.
        status: {
          published: "#16a34a",
          approved: "#16a34a",
          draft: "#d97706",
          pending: "#ea580c",
          ai: "#a855f7",
          review: "#2563eb",
          deprecated: "#9ca3af",
        },
        // Confidence tints for suggested mapping edges.
        conf: {
          high: "#16a34a",
          med: "#d97706",
          low: "#dc2626",
        },
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"],
      },
    },
  },
  plugins: [],
};
