"""Background deploy runner with live commentary + cleanup-on-failure.

The Deploy-as-Pipeline wizard used to POST one synchronous request and then jump
straight to the Execution Monitor. This module runs the same work on a background
thread as a series of named steps the UI polls, so the user watches the whole
process (build config → commit to GitHub → create git folder → create pipeline).

If any step fails, the runner rolls back the Databricks-side artifacts it created
this run (the SDP pipeline + the Repos git folder) so a failed deploy doesn't leave
junk behind. The GitHub commit is intentionally NOT reverted — committed code in the
repo is a valid artifact and safe to leave / re-use on retry.
"""
from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from server import (
    config,
    dab_template,
    db,
    githubapi,
    pipeline_config,
    pipeline_config_store,
    pipeline_deploy,
    repo,
    repo_library,
)

# In-memory run registry (deploy_id -> state); short-lived, polled by the UI.
_RUNS: dict[str, dict[str, Any]] = {}
_LOCK = threading.Lock()

# The deploy workflow — mirrored in the wizard's live commentary panel.
_STEP_DEFS = [
    ("prepare", "Prepare", "Load mapping + build transformation/validation config"),
    ("bundle", "Bundle", "Generate the DAB (generic pipeline code + config + databricks.yml)"),
    ("commit", "Commit", "Push the bundle to the Git repository"),
    ("config", "Config", "Store the mapping config in the pipeline config table"),
    ("git_folder", "Git folder", "Clone into a Databricks Git folder"),
    ("pipeline", "Pipeline", "Create the Lakeflow SDP pipeline"),
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_run(spec_id: str) -> dict[str, Any]:
    deploy_id = uuid.uuid4().hex[:12]
    run = {
        "deploy_id": deploy_id,
        "spec_id": spec_id,
        "status": "running",  # running | succeeded | failed
        "started_at": _now(),
        "steps": [
            {"key": k, "label": lbl, "description": d, "status": "pending", "detail": None, "elapsed_sec": None}
            for k, lbl, d in _STEP_DEFS
        ],
        "result": None,   # {repo, branch, commit_sha, commit_url, files, pipeline_id, pipeline_url, git_folder, reused}
        "error": None,
        "cleanup": None,   # human-readable note on rollback, when a failure triggers it
    }
    with _LOCK:
        _RUNS[deploy_id] = run
    return run


def get_run(deploy_id: str) -> dict[str, Any] | None:
    import time as _t

    with _LOCK:
        r = _RUNS.get(deploy_id)
        if not r:
            return None
        for s in r["steps"]:
            if s["status"] == "running" and s.get("_started_mono") is not None:
                s["elapsed_sec"] = round(_t.monotonic() - s["_started_mono"], 1)
        snap = json.loads(json.dumps(r))
    for s in snap["steps"]:
        s.pop("_started_mono", None)
    return snap


def _set_step(run: dict, key: str, status: str, detail: str | None = None) -> None:
    import time as _t

    with _LOCK:
        for s in run["steps"]:
            if s["key"] == key:
                if status == "running" and s.get("_started_mono") is None:
                    s["_started_mono"] = _t.monotonic()
                if s.get("_started_mono") is not None:
                    s["elapsed_sec"] = round(_t.monotonic() - s["_started_mono"], 1)
                s["status"] = status
                if detail is not None:
                    s["detail"] = detail
                break


def start_deploy(spec_id: UUID, body: Any, *, token: str) -> dict[str, Any]:
    """Kick off the deploy on a background thread; return the initial run state."""
    run = _new_run(str(spec_id))
    t = threading.Thread(target=_execute, args=(str(spec_id), body, token, run), daemon=True)
    t.start()
    return run


def _execute(spec_id: str, body: Any, token: str, run: dict) -> None:
    # Track what we created so we can roll back on failure.
    created_pipeline_id: str | None = None
    created_git_folder: str | None = None
    reused_pipeline = False
    reused_git_folder = False
    try:
        spec = repo.get_spec(db.pool, UUID(spec_id))
        if spec is None:
            raise ValueError("spec not found")
        if not (spec.get("sources") and spec.get("targets")):
            raise ValueError("spec has no source/target assets")

        # --- prepare: config -------------------------------------------------
        _set_step(run, "prepare", "running")
        spec_tag = f"spec:{spec_id}"
        try:
            vals = [v for v in repo_library.list_validations(db.pool) if spec_tag in (v.get("tags") or [])]
        except Exception:  # noqa: BLE001
            vals = []
        source_catalog = body.source_catalog or config.UC_CATALOG
        target_catalog = body.target_catalog or config.UC_CATALOG
        cfg = pipeline_config.build_mapping_config(spec, vals, catalog=source_catalog, source_schema=body.source_schema)
        n_cols = sum(len(t.get("columns", [])) for t in cfg.get("targets", []))
        _set_step(run, "prepare", "done",
                  f"{len(cfg.get('inputs', {}))} source(s), {len(cfg.get('targets', []))} target(s), "
                  f"{n_cols} column transform(s), {len(cfg.get('joins', []))} join(s)")

        # --- bundle ----------------------------------------------------------
        _set_step(run, "bundle", "running")
        files = dab_template.build_bundle_files(
            spec=spec, config=cfg, pipeline_name=body.pipeline_name,
            catalog=target_catalog, schema=body.target_schema,
            source_catalog=source_catalog, source_schema=body.source_schema,
            schedule=body.schedule, table_type=body.table_type,
        )
        _set_step(run, "bundle", "done", f"{len(files)} files: {', '.join(sorted(files))}")

        # --- commit ----------------------------------------------------------
        _set_step(run, "commit", "running", f"{body.repo_full_name} @ {body.branch}")
        try:
            with githubapi.GitHub(token) as gh:
                if body.new_branch_from:
                    gh.create_branch(body.repo_full_name, body.branch, body.new_branch_from)
                elif gh.get_branch_sha(body.repo_full_name, body.branch) is None:
                    gh.create_branch(body.repo_full_name, body.branch, gh.default_branch(body.repo_full_name))
                commit = gh.commit_files(body.repo_full_name, body.branch, files,
                                         body.commit_message or f"Mapping Factory: deploy {spec['name']} pipeline")
        except githubapi.GitHubError as e:
            raise RuntimeError(f"git commit failed: {e}") from e
        _set_step(run, "commit", "done", f"commit {commit['commit_sha'][:10]}")

        # --- config: store the mapping config in the UC table ----------------
        # The committed code is generic; the pipeline reads its config from this table at
        # runtime (keyed by config_key = pipeline_name). This keeps the code manageable.
        _set_step(run, "config", "running")
        full_config = {**cfg, "catalog": target_catalog, "schema": body.target_schema,
                       "source_catalog": source_catalog, "source_schema": body.source_schema,
                       "table_type": body.table_type, "spec_name": spec.get("name"),
                       "pipeline_name": body.pipeline_name}
        stored = pipeline_config_store.write_config(
            full_config, catalog=target_catalog, schema=body.target_schema,
            pipeline_name=body.pipeline_name)
        _set_step(run, "config", "done",
                  f"config_key={stored['config_key']} → {pipeline_config_store.config_table(target_catalog, body.target_schema)}")

        # --- git_folder + pipeline (SDP) ------------------------------------
        # deploy_git_pipeline does both; we split the commentary and capture the ids it
        # created so a later failure can roll them back.
        _set_step(run, "git_folder", "running")
        repo_url = f"https://github.com/{body.repo_full_name}.git"
        _set_step(run, "pipeline", "pending")
        deployed = pipeline_deploy.deploy_git_pipeline(
            spec_id=spec_id, pipeline_name=body.pipeline_name, catalog=target_catalog,
            schema=body.target_schema, repo_url=repo_url, branch=body.branch, schedule=body.schedule,
        )
        created_pipeline_id = deployed["pipeline_id"]
        created_git_folder = deployed["git_folder"]
        reused_pipeline = bool(deployed.get("reused"))
        reused_git_folder = bool(deployed.get("reused_git_folder"))
        _set_step(run, "git_folder", "done", created_git_folder)
        _set_step(run, "pipeline", "done",
                  f"{'reused' if reused_pipeline else 'created'} · {body.pipeline_name}")

        with _LOCK:
            run["status"] = "succeeded"
            run["result"] = {
                "repo": body.repo_full_name, "branch": body.branch,
                "commit_sha": commit["commit_sha"], "commit_url": commit["html_url"],
                "files": sorted(files.keys()),
                "pipeline_id": deployed["pipeline_id"], "pipeline_url": deployed["url"],
                "git_folder": deployed["git_folder"], "reused": reused_pipeline,
                "source_catalog": source_catalog, "source_schema": body.source_schema,
                "target_catalog": target_catalog, "target_schema": body.target_schema,
            }
    except Exception as e:  # noqa: BLE001
        # mark the running step failed
        with _LOCK:
            for s in run["steps"]:
                if s["status"] == "running":
                    s["status"] = "failed"
                    s["detail"] = str(e)[:300]
                    break
            run["status"] = "failed"
            run["error"] = str(e)
        _cleanup(run, created_pipeline_id, reused_pipeline, created_git_folder, reused_git_folder)


def _cleanup(run: dict, pipeline_id: str | None, reused_pipeline: bool,
             git_folder: str | None, reused_git_folder: bool) -> None:
    """Roll back Databricks artifacts created THIS run (never ones we merely reused).
    The GitHub commit is left in place on purpose."""
    notes: list[str] = []
    try:
        w = config.get_sp_client()
    except Exception as e:  # noqa: BLE001
        with _LOCK:
            run["cleanup"] = f"cleanup skipped (no SP client): {e}"
        return
    if pipeline_id and not reused_pipeline:
        try:
            w.pipelines.delete(pipeline_id=pipeline_id)
            notes.append("deleted pipeline")
        except Exception as e:  # noqa: BLE001
            notes.append(f"pipeline delete failed: {e}")
    if git_folder and not reused_git_folder:
        # Prefer removing the Repos entry; fall back to a recursive workspace delete.
        removed = False
        try:
            for r in w.repos.list():
                if (r.path or "") == git_folder:
                    w.repos.delete(repo_id=r.id)
                    removed = True
                    break
        except Exception:  # noqa: BLE001
            pass
        if not removed:
            try:
                w.workspace.delete(git_folder, recursive=True)
                removed = True
            except Exception as e:  # noqa: BLE001
                notes.append(f"git-folder delete failed: {e}")
        if removed:
            notes.append("removed git folder")
    with _LOCK:
        run["cleanup"] = "; ".join(notes) if notes else "nothing to clean up"
