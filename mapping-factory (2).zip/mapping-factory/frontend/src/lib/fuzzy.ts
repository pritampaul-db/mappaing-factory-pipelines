// Lightweight fuzzy matcher — subsequence match with a light relevance score.
// Good enough for filtering a rules/validation list by name + description without a
// dependency. Empty query matches everything.

/** True if every char of `q` appears in `text` in order (case-insensitive). */
export function fuzzyMatch(text: string, q: string): boolean {
  if (!q) return true;
  const t = text.toLowerCase();
  const query = q.toLowerCase().trim();
  if (!query) return true;
  // Fast path: direct substring.
  if (t.includes(query)) return true;
  // Subsequence match (typo-tolerant-ish: "custemail" ~ "customer email").
  let i = 0;
  for (const ch of t) {
    if (ch === query[i]) i++;
    if (i === query.length) return true;
  }
  return i === query.length;
}

/** Filter rows by a fuzzy match over the given text-accessor fields. */
export function fuzzyFilter<T>(rows: T[], q: string, fields: (r: T) => (string | null | undefined)[]): T[] {
  if (!q.trim()) return rows;
  return rows.filter((r) => fields(r).some((f) => f != null && fuzzyMatch(String(f), q)));
}
