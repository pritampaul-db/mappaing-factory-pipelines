import { useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Sparkles, Wand2, CheckCircle2, ArrowRight, Copy, Braces } from "lucide-react";
import { usePage } from "../../AppShell";
import { api } from "../../api";
import { Button, Tabs, Breadcrumbs } from "../../components/primitives";

const PALETTE = ["Input Column", "Output Column", "Constant", "Trim", "Upper Case", "Lower Case", "Substring", "Replace", "Split", "Concat", "Regex Replace", "Date Format", "Lookup", "Conditional", "Cast"];

interface Gen {
  logic_expr: string;
  logic_sql: string;
  explanation: string;
  steps: { name: string; detail: string }[];
}

interface CloneState {
  name: string;
  description: string;
  logic_expr: string;
  logic_sql: string;
  category: string | null;
  tags: string[];
  clonedFrom: string;
}

export function TransformationBuilder() {
  const nav = useNavigate();
  const loc = useLocation();
  const clone = (loc.state as { clone?: CloneState } | null)?.clone;

  const [name, setName] = useState(clone?.name ?? "");
  const [desc, setDesc] = useState(clone?.description ?? "");
  const [prompt, setPrompt] = useState("");
  const [codeTab, setCodeTab] = useState("Expression");
  const [gen, setGen] = useState<Gen | null>(null);
  const [expr, setExpr] = useState(clone?.logic_expr ?? "");
  const [sql, setSql] = useState(clone?.logic_sql ?? "");
  const [category] = useState<string | null>(clone?.category ?? null);
  const [tags] = useState<string[]>(clone?.tags ?? []);
  const [validation, setValidation] = useState<{ valid: boolean; error?: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  usePage({ title: clone ? "Clone Transformation" : "New Transformation", subtitle: "Create, manage and reuse transformations" });

  const generate = async () => {
    setBusy(true);
    try {
      const g = await api.generateTransformation({ description: prompt || desc });
      setGen(g);
      if (g.logic_expr) setExpr(g.logic_expr);
      if (g.logic_sql) setSql(g.logic_sql);
      // Populate name + description from the AI, but only when the user hasn't
      // already typed their own — never clobber manual input.
      if (g.name && !name.trim()) setName(g.name);
      if (g.description && !desc.trim()) setDesc(g.description);
      setValidation(null);
    } finally {
      setBusy(false);
    }
  };

  const validate = async () => setValidation(await api.validateExpression(expr));

  // Save Draft persists as Draft; Submit for Approval creates then submits →
  // Proposed (Pending Approval). Publishing only happens on a reviewer's approval.
  const save = async (mode: "draft" | "submit") => {
    setSaveError(null);
    if (!name.trim()) { setSaveError("Transformation name is required."); return; }
    if (!expr.trim()) { setSaveError("An expression is required — write one or generate it with AI."); return; }
    setBusy(true);
    try {
      const created = await api.createTransformation({
        name: name.trim(),
        description: desc || null,
        ttype: gen ? "ai_assisted" : "custom",
        category,
        logic_expr: expr,
        logic_sql: sql || expr,
        tags,
        status: "Draft",
      });
      if (mode === "submit") await api.submitTransformation(created.id);
      nav("/transformations");
    } catch (e) {
      setSaveError(e instanceof Error ? e.message : "Failed to save transformation.");
    } finally {
      setBusy(false);
    }
  };

  // Steps are derived from the AI generation when present; otherwise a simple
  // input → apply → output outline. No hardcoded demo steps.
  const steps = useMemo(() => {
    if (gen?.steps?.length) return gen.steps;
    return [
      { name: "Input", detail: "Source column(s)" },
      { name: "Apply", detail: expr ? "Expression" : "Define logic" },
      { name: "Output", detail: "Target column" },
    ];
  }, [gen, expr]);

  return (
    <div className="p-6 space-y-4">
      <Breadcrumbs items={[{ label: "Transformations" }, { label: clone ? "Clone Transformation" : "New Transformation" }]} />

      {clone && (
        <div className="flex items-center gap-2 text-xs text-brand bg-brand-soft border border-brand/20 rounded-lg px-3 py-2">
          <Copy className="w-3.5 h-3.5" /> Cloned from <span className="font-semibold">{clone.clonedFrom}</span> — edit and save as your own transformation.
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="flex gap-4 items-end flex-1">
          <label className="block w-72"><span className="text-xs text-gray-500 mb-1 block">Transformation Name *</span><input value={name} onChange={(e) => setName(e.target.value)} className="inp" placeholder="Standardize Customer Name" /></label>
          <label className="block flex-1"><span className="text-xs text-gray-500 mb-1 block">Description</span><input value={desc} onChange={(e) => setDesc(e.target.value)} className="inp" placeholder="Trim, remove special chars, convert to proper case" /></label>
        </div>
        <div className="flex flex-col items-end ml-4">
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => save("draft")} disabled={busy}>Save Draft</Button>
            <Button onClick={() => save("submit")} disabled={busy}>{busy ? "Saving…" : "Submit for Approval"}</Button>
          </div>
          {saveError && <span className="text-xs text-red-600 mt-1">{saveError}</span>}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
        {/* palette */}
        <div className="bg-white rounded-xl border border-gray-200 p-4 self-start">
          <div className="text-sm font-semibold text-gray-800 mb-2">Components</div>
          <div className="grid grid-cols-3 gap-2">
            {PALETTE.map((c) => (
              <div key={c} className="border border-gray-200 rounded-lg p-2 text-center text-[10px] text-gray-600">{c}</div>
            ))}
          </div>
          <p className="text-[10px] text-gray-400 mt-3">Reference of the building blocks available in an expression.</p>
        </div>

        {/* flow + code */}
        <div className="xl:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="text-sm font-semibold text-gray-800 mb-3">Transformation Logic</div>
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              {steps.map((s, i) => (
                <div key={i} className="flex items-center gap-2 shrink-0">
                  <div className="border border-gray-200 rounded-lg p-2 min-w-[120px]">
                    <div className="flex items-center gap-1 text-xs font-medium text-gray-800">
                      <Braces className="w-3 h-3 text-brand" /> {s.name}
                    </div>
                    <div className="text-[10px] text-gray-400 mt-0.5">{s.detail}</div>
                  </div>
                  {i < steps.length - 1 && <ArrowRight className="w-4 h-4 text-gray-300 shrink-0" />}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <Tabs tabs={["Expression", "SQL"]} active={codeTab} onChange={setCodeTab} />
            <div className="mt-3">
              {codeTab === "SQL" ? (
                <>
                  <textarea
                    value={sql}
                    onChange={(e) => setSql(e.target.value)}
                    className="inp font-mono text-xs h-24"
                    placeholder="Equivalent Spark SQL — generated by AI, or write it here."
                  />
                  <p className="text-[10px] text-gray-400 mt-1">Defaults to the expression on save if left blank.</p>
                </>
              ) : (
                <>
                  <textarea
                    value={expr}
                    onChange={(e) => { setExpr(e.target.value); setValidation(null); }}
                    className="inp font-mono text-xs h-24"
                    placeholder="e.g. INITCAP(REGEXP_REPLACE(TRIM(Customer_Name), '[^a-zA-Z0-9 ]', ''))"
                  />
                  <div className="flex items-center gap-2 mt-2">
                    <Button variant="secondary" onClick={validate} disabled={!expr.trim()}>Validate Expression</Button>
                    {validation && (
                      <span className={`text-xs ${validation.valid ? "text-green-600" : "text-red-600"}`}>
                        {validation.valid ? "✓ Valid Spark expression" : `✗ ${validation.error}`}
                      </span>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* AI assistant */}
        <div className="bg-white rounded-xl border border-gray-200 p-4 self-start">
          <div className="flex items-center gap-2 mb-1"><Sparkles className="w-4 h-4 text-brand" /><span className="font-semibold text-gray-800">AI Assistant</span></div>
          <div className="text-xs text-gray-500 mb-2">Describe what you want to build</div>
          <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} className="inp h-24" placeholder="Standardize customer name by trimming spaces, removing special characters and converting to proper case" />
          <Button className="w-full justify-center mt-2" onClick={generate} disabled={busy || (!prompt.trim() && !desc.trim())}><Wand2 className="w-4 h-4" /> {busy ? "Generating…" : "Generate Transformation"}</Button>
          {gen && (
            <div className="mt-3 border border-gray-200 rounded-lg p-3">
              <div className="text-sm font-medium text-gray-800 mb-1">AI Suggestion</div>
              <p className="text-xs text-gray-600">{gen.explanation}</p>
              <div className="mt-2 space-y-1">
                {gen.steps.map((s, i) => (
                  <div key={i} className="flex items-center gap-1.5 text-xs text-gray-700"><CheckCircle2 className="w-3 h-3 text-green-600 shrink-0" /> {s.name} — <span className="text-gray-400">{s.detail}</span></div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
