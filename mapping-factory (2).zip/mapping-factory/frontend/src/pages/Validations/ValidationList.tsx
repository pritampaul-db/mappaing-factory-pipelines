import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { BookOpen, CheckCircle2, ShieldCheck, AlertOctagon, Database, Star, X, Check, Search } from "lucide-react";
import { usePage, useIdentity, useIsAdmin } from "../../AppShell";
import { api, type Validation, type ValidationsSummary, type PipelineDqMetrics } from "../../api";
import { Button, Tabs, StatusBadge, SeverityBadge, Avatar, Card } from "../../components/primitives";
import { DataTable, LinkCell, type Column } from "../../components/DataTable";
import { DonutChart, LegendList, BreakdownBars } from "../../components/charts";
import { timeAgo } from "../../theme";
import { fuzzyFilter } from "../../lib/fuzzy";

const TABS = ["All Rules", "By Dataset", "By Rule Type", "By Status", "Execution History", "Pipeline DQ"];
const PENDING_STATUSES = new Set(["Proposed", "Pending Approval", "In Review"]);
const PUBLISHED_STATUSES = new Set(["Published", "Approved", "Active", "Live"]);

export function ValidationList() {
  const nav = useNavigate();
  const identity = useIdentity();
  const [rows, setRows] = useState<Validation[]>([]);
  const [sum, setSum] = useState<ValidationsSummary | null>(null);
  const [pdq, setPdq] = useState<PipelineDqMetrics | null>(null);
  const [tab, setTab] = useState(TABS[0]);
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<Validation | null>(null);

  usePage({
    title: "Data Quality Rules",
    subtitle: "Data-quality rules tagged to datasets. Create reusable rules in the Rule Library, then apply them here.",
    actions: (
      <Button variant="secondary" onClick={() => nav("/rules")}>
        <BookOpen className="w-4 h-4" /> Rule Library
      </Button>
    ),
  });

  const load = () => {
    api.listValidations().then((r) => {
      setRows(r);
      setSelected((prev) => (prev ? r.find((x) => x.id === prev.id) ?? null : null));
    });
    api.validationsSummary().then(setSum);
  };
  useEffect(() => { load(); }, []);
  // Pipeline DQ metrics (mf_dq_audit + quarantine) — fetched once, lazily, on first need.
  useEffect(() => {
    if (pdq === null) api.pipelineDqMetrics().then(setPdq).catch(() => setPdq({ available: false, summary: {}, by_rule: [], by_target: [], quarantine: [], recent_runs: [] }));
  }, [pdq]);

  const datasetCount = new Set(rows.map((r) => r.dataset).filter(Boolean)).size;

  const kpis = [
    { icon: BookOpen, label: "Tagged Rules", value: sum?.total ?? rows.length, tint: "#fdecec", color: "#c9252d" },
    { icon: Database, label: "Datasets Covered", value: datasetCount, tint: "#e0e7ff", color: "#4f46e5" },
    { icon: ShieldCheck, label: "Published", value: sum?.active ?? rows.filter((r) => PUBLISHED_STATUSES.has(r.status)).length, tint: "#dcfce7", color: "#16a34a" },
    { icon: CheckCircle2, label: "Pipeline Pass Rate", value: pdq?.summary?.overall_pass_rate != null ? `${Math.round(pdq.summary.overall_pass_rate * 100)}%` : "—", tint: "#dcfce7", color: "#16a34a" },
    { icon: AlertOctagon, label: "Quarantined Rows", value: pdq?.summary?.quarantined_rows ?? 0, tint: "#fef3c7", color: "#d97706" },
    { icon: AlertOctagon, label: "Failing Checks", value: pdq?.summary?.failing_checks ?? 0, tint: "#fee2e2", color: "#dc2626" },
  ];

  const columns: Column<Validation>[] = [
    { key: "name", header: "Rule Name", sortValue: (r) => r.name, render: (r) => <LinkCell title={r.name} subtitle={r.code} /> },
    { key: "type", header: "Rule Type", render: (r) => <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded capitalize">{r.rule_type.replace("_", " ")}</span> },
    { key: "ds", header: "Dataset / Column", render: (r) => <LinkCell title={r.dataset ?? "—"} subtitle={r.column_name ?? undefined} color="#374151" /> },
    { key: "sev", header: "Severity", render: (r) => <SeverityBadge severity={r.severity} />, sortValue: (r) => r.severity },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} />, sortValue: (r) => r.status },
    { key: "runstatus", header: "Last Run", render: (r) => <StatusBadge status={r.last_status ?? "—"} /> },
    { key: "owner", header: "Owner", render: (r) => <Avatar name={r.owner ?? "—"} /> },
  ];

  const filtered = useMemo(() => {
    let out = rows;
    if (tab === "By Dataset") out = [...rows].sort((a, b) => (a.dataset ?? "").localeCompare(b.dataset ?? ""));
    else if (tab === "By Status") out = [...rows].sort((a, b) => a.status.localeCompare(b.status));
    else if (tab === "By Rule Type") out = [...rows].sort((a, b) => a.rule_type.localeCompare(b.rule_type));
    // Fuzzy search over name + description + dataset + column.
    return fuzzyFilter(out, q, (r) => [r.name, r.description, r.dataset, r.column_name]);
  }, [rows, tab, q]);

  return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white rounded-xl border border-gray-200 p-3 flex items-center gap-3">
            <span className="w-9 h-9 rounded-lg grid place-items-center shrink-0" style={{ background: k.tint, color: k.color }}><k.icon className="w-4 h-4" /></span>
            <div><div className="text-[11px] text-gray-500">{k.label}</div><div className="text-lg font-semibold text-gray-900">{k.value}</div></div>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <Tabs tabs={TABS} active={tab} onChange={setTab} />
        <div className="relative w-72">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-full bg-white border border-gray-200 rounded-lg pl-9 pr-8 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"
            placeholder="Search rules by name or description…"
          />
          {q && <button onClick={() => setQ("")} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><X className="w-3.5 h-3.5" /></button>}
        </div>
      </div>

      {tab === "Pipeline DQ" ? (
        <PipelineDqPanel pdq={pdq} />
      ) : (
        <>
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 items-start">
            <div className="xl:col-span-2 bg-white rounded-xl border border-gray-200 p-4">
              {q && <div className="text-[11px] text-gray-400 mb-2">{filtered.length} match{filtered.length === 1 ? "" : "es"} for “{q}”</div>}
              <DataTable columns={columns} rows={filtered} rowKey={(r) => r.id} pageSize={10} onRowClick={setSelected} />
            </div>
            {selected ? (
              <RuleDetail v={selected} identity={identity} onClose={() => setSelected(null)} onChanged={load} />
            ) : (
              sum && (
                <div className="space-y-4">
                  <Card title="Rules by Severity">
                    <BreakdownBars data={sum.by_severity.map((s) => ({ label: s.name, value: s.value, color: { critical: "#dc2626", high: "#ea580c", medium: "#d97706", low: "#9ca3af" }[s.name] }))} />
                  </Card>
                  <Card title="Rule Type Distribution">
                    <div className="grid grid-cols-2 gap-2 items-center">
                      <DonutChart data={sum.by_type} totalLabel="Total" />
                      <LegendList data={sum.by_type} />
                    </div>
                  </Card>
                </div>
              )
            )}
          </div>

          {sum && (
            <Card title="Recent Executions">
              <ul className="divide-y divide-gray-100">
                {sum.recent_runs.map((r, i) => (
                  <li key={i} className="flex items-center justify-between py-2 text-sm">
                    <span className="flex items-center gap-2 text-gray-700"><Star className="w-3.5 h-3.5 text-gray-300" /> {r.run_name}</span>
                    <span className="flex items-center gap-4">
                      <span className="text-xs text-gray-400">{timeAgo(r.run_at)}</span>
                      <span className="font-medium text-gray-800">{Math.round(r.passed_pct * 100)}%</span>
                    </span>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

// Live data-quality metrics from DEPLOYED pipelines (mf_dq_audit history + quarantine
// counts). Rows failing a FAIL rule are quarantined; warn-only violations are logged.
function PipelineDqPanel({ pdq }: { pdq: PipelineDqMetrics | null }) {
  if (pdq === null) return <div className="text-sm text-gray-400 py-10 text-center">Loading pipeline metrics…</div>;
  if (!pdq.available)
    return (
      <Card>
        <div className="text-sm text-gray-500 py-6 text-center">
          No pipeline data-quality metrics yet.
          <div className="text-xs text-gray-400 mt-1">Deploy a mapping as a pipeline and run it — quarantine + audit metrics will appear here.</div>
          {pdq.reason && <div className="text-[11px] text-gray-300 mt-1">({pdq.reason})</div>}
        </div>
      </Card>
    );
  const pct = (v?: number | null) => (v == null ? "—" : `${Math.round(v * 100)}%`);
  const rateColor = (v?: number | null) => (v == null ? "#9ca3af" : v >= 0.99 ? "#16a34a" : v >= 0.9 ? "#d97706" : "#dc2626");
  return (
    <div className="space-y-4">
      {(pdq.by_target.length > 0) && (
        <Card title="By target">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left text-[11px] text-gray-400 border-b border-gray-100">
                <th className="py-1.5 pr-3">Target</th><th className="py-1.5 px-3">Checks</th>
                <th className="py-1.5 px-3">Failing</th><th className="py-1.5 px-3">Quarantined</th><th className="py-1.5 pl-3">Rows</th>
              </tr></thead>
              <tbody>
                {pdq.by_target.map((t) => (
                  <tr key={t.target} className="border-b border-gray-50">
                    <td className="py-1.5 pr-3 font-medium text-gray-800 break-all">{t.target}</td>
                    <td className="py-1.5 px-3 text-gray-600 tabular-nums">{t.checks}</td>
                    <td className="py-1.5 px-3 tabular-nums" style={{ color: t.failing ? "#dc2626" : "#16a34a" }}>{t.failing}</td>
                    <td className="py-1.5 px-3 tabular-nums" style={{ color: (t.quarantined ?? 0) ? "#d97706" : "#9ca3af" }}>{t.quarantined ?? 0}</td>
                    <td className="py-1.5 pl-3 text-gray-500 tabular-nums">{t.total_rows}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Card title="By rule (latest run)">
        {pdq.by_rule.length === 0 ? (
          <div className="text-xs text-gray-400 py-3">No audited rules yet.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left text-[11px] text-gray-400 border-b border-gray-100">
                <th className="py-1.5 pr-3">Rule</th><th className="py-1.5 px-3">Target · Column</th>
                <th className="py-1.5 px-3">Action</th><th className="py-1.5 px-3">Failed / Total</th><th className="py-1.5 pl-3">Pass rate</th>
              </tr></thead>
              <tbody>
                {pdq.by_rule.map((r, i) => (
                  <tr key={i} className="border-b border-gray-50">
                    <td className="py-1.5 pr-3 font-medium text-gray-800 break-all">{r.rule}</td>
                    <td className="py-1.5 px-3 text-gray-500 break-all">{r.target}{r.column_name ? ` · ${r.column_name}` : ""}</td>
                    <td className="py-1.5 px-3">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded capitalize ${r.action === "fail" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}`}>
                        {r.action === "fail" ? "fail · quarantine" : "warn · log"}
                      </span>
                    </td>
                    <td className="py-1.5 px-3 text-gray-600 tabular-nums">{r.failed_rows ?? 0} / {r.total_rows ?? 0}</td>
                    <td className="py-1.5 pl-3 font-medium tabular-nums" style={{ color: rateColor(r.pass_rate) }}>{pct(r.pass_rate)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {pdq.recent_runs.length > 0 && (
        <Card title="Recent pipeline runs">
          <ul className="divide-y divide-gray-100">
            {pdq.recent_runs.map((r) => (
              <li key={r.run_id} className="flex items-center justify-between py-2 text-sm">
                <span className="flex items-center gap-2 text-gray-700"><Star className="w-3.5 h-3.5 text-gray-300" /> {r.pipeline_name} <span className="text-[11px] text-gray-400 font-mono">{r.run_id}</span></span>
                <span className="flex items-center gap-4">
                  <span className="text-xs text-gray-400">{r.checks} check{r.checks === 1 ? "" : "s"}</span>
                  <span className="text-xs text-gray-400">{timeAgo(r.run_ts ?? null)}</span>
                  <span className="font-medium" style={{ color: rateColor(r.pass_rate) }}>{pct(r.pass_rate)}</span>
                </span>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {pdq.locations && pdq.locations.length > 0 && (
        <div className="text-[11px] text-gray-400">Scanned: {pdq.locations.join(", ")}</div>
      )}
    </div>
  );
}

function RuleDetail({ v, identity, onClose, onChanged }: { v: Validation; identity?: string | null; onClose: () => void; onChanged: () => void }) {
  const isAdmin = useIsAdmin();
  const isPending = PENDING_STATUSES.has(v.status);
  const maker = (v.submitted_by || v.owner || "").toLowerCase();
  const isMaker = !!maker && maker === (identity ?? "").toLowerCase();
  return (
    <Card className="self-start sticky top-4">
      <div className="flex items-start justify-between mb-2">
        <div>
          <h3 className="font-semibold text-gray-800 leading-tight">{v.name}</h3>
          <div className="text-[11px] text-gray-400 font-mono mt-0.5">{v.code}</div>
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        <StatusBadge status={v.status} />
        <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded capitalize">{v.rule_type.replace("_", " ")}</span>
        <SeverityBadge severity={v.severity} />
      </div>

      {isPending && <ReviewBar v={v} isMaker={isMaker} isAdmin={isAdmin} onChanged={onChanged} />}
      {PUBLISHED_STATUSES.has(v.status) && v.approved_by && (
        <p className="text-[11px] text-green-700 bg-green-50 border border-green-100 rounded px-2 py-1.5 mt-3">Approved &amp; published by {v.approved_by}.</p>
      )}
      {v.status === "Rejected" && (
        <p className="text-[11px] text-red-700 bg-red-50 border border-red-100 rounded px-2 py-1.5 mt-3">Rejected{v.rationale ? `: ${v.rationale}` : "."}</p>
      )}

      {v.description && <p className="text-xs text-gray-600 mt-3 leading-relaxed">{v.description}</p>}
      <dl className="text-sm mt-3 space-y-1.5">
        <Row k="Dataset" v={v.dataset ?? "—"} /><Row k="Column" v={v.column_name ?? "—"} /><Row k="Owner" v={v.owner ?? "—"} />
      </dl>
      {v.logic && (
        <div className="mt-3">
          <div className="text-xs font-medium text-gray-500 mb-1">Rule Logic</div>
          <pre className="bg-[#0d1117] text-emerald-300 rounded px-2.5 py-2 text-[11px] font-mono overflow-x-auto whitespace-pre-wrap">{v.logic}</pre>
        </div>
      )}
      {v.tags && v.tags.length > 0 && <div className="mt-3 flex flex-wrap gap-1">{v.tags.map((t) => <span key={t} className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{t}</span>)}</div>}
    </Card>
  );
}

function ReviewBar({ v, isMaker, isAdmin, onChanged }: { v: Validation; isMaker: boolean; isAdmin: boolean; onChanged: () => void }) {
  const blockApprove = isMaker && !isAdmin;
  const [decision, setDecision] = useState<null | "approved" | "rejected">(null);
  const [rationale, setRationale] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const confirm = async (d: "approved" | "rejected") => {
    setBusy(true); setErr(null);
    try {
      await api.decideValidation(v.id, { decision: d, rationale: rationale || undefined });
      onChanged();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed to record decision.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="border border-orange-200 bg-orange-50/50 rounded-lg p-3 mt-3">
      <div className="flex items-center gap-2 text-sm font-semibold text-gray-800"><ShieldCheck className="w-4 h-4 text-orange-600" /> Pending approval</div>
      <p className="text-[11px] text-gray-500 mt-0.5">Submitted by {v.submitted_by ?? v.owner ?? "—"}. Review the logic, then approve to publish or reject.</p>
      {isMaker && isAdmin && <p className="text-[11px] text-brand mt-1">You submitted this — as an administrator you may approve your own (SoD bypassed).</p>}
      {isMaker && !isAdmin && <p className="text-[11px] text-amber-700 mt-1">You submitted this — a different reviewer must approve it. You can still reject it.</p>}
      {decision === null ? (
        <div className="flex gap-2 mt-2">
          <Button onClick={() => setDecision("approved")} disabled={blockApprove || busy}><Check className="w-4 h-4" /> Approve &amp; Publish</Button>
          <Button variant="secondary" onClick={() => setDecision("rejected")} disabled={busy}><X className="w-4 h-4" /> Reject</Button>
        </div>
      ) : (
        <div className="mt-2">
          <textarea value={rationale} onChange={(e) => setRationale(e.target.value)} rows={2} placeholder={decision === "approved" ? "Looks correct — approving." : "Why is this being rejected?"} className="w-full border border-gray-300 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand/30" />
          <div className="flex gap-2 mt-1.5">
            <Button onClick={() => confirm(decision)} disabled={busy}>{busy ? "Saving…" : decision === "approved" ? "Confirm approve" : "Confirm reject"}</Button>
            <Button variant="secondary" onClick={() => setDecision(null)} disabled={busy}>Cancel</Button>
          </div>
        </div>
      )}
      {err && <p className="text-[11px] text-red-600 mt-1.5">{err}</p>}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between"><dt className="text-gray-500">{k}</dt><dd className="text-gray-800">{v}</dd></div>;
}
