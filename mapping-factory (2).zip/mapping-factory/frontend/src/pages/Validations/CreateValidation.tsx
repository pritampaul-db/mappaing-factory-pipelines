import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sparkles, Wand2, CheckCircle2, LayoutTemplate, Braces, FileCode2, Check } from "lucide-react";
import { usePage } from "../../AppShell";
import { api } from "../../api";
import { WizardStepper } from "../../components/WizardStepper";
import { Button, Breadcrumbs } from "../../components/primitives";

const STEPS = ["Define Rule", "Set Logic", "Test & Preview", "Review & Publish"];
type Method = "AI Assisted" | "Template Based" | "Expression Builder" | "Custom SQL";
const METHODS: { icon: typeof Sparkles; label: Method; sub: string; rec?: boolean }[] = [
  { icon: Sparkles, label: "AI Assisted", sub: "Describe what you want to validate and let AI generate the rule logic.", rec: true },
  { icon: LayoutTemplate, label: "Template Based", sub: "Choose from pre-built rule templates and customize." },
  { icon: Braces, label: "Expression Builder", sub: "Compose the predicate from column / operator / value." },
  { icon: FileCode2, label: "Custom SQL", sub: "Write a boolean SQL expression to define the rule logic." },
];
const RULE_TYPES = ["completeness", "validity", "accuracy", "business_rule", "consistency", "uniqueness", "referential"];

// Templates keyed by rule type — {label, logic(col)} — prefill the logic editor.
const TEMPLATES: { label: string; rule_type: string; logic: (c: string) => string }[] = [
  { label: "Not Null", rule_type: "completeness", logic: (c) => `${c} IS NOT NULL` },
  { label: "Not Empty", rule_type: "completeness", logic: (c) => `${c} IS NOT NULL AND TRIM(${c}) <> ''` },
  { label: "Valid Email", rule_type: "validity", logic: (c) => `${c} RLIKE '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'` },
  { label: "In Value Set", rule_type: "validity", logic: (c) => `${c} IN ('A','B','C')` },
  { label: "Numeric Range", rule_type: "accuracy", logic: (c) => `${c} BETWEEN 0 AND 100` },
  { label: "Positive", rule_type: "business_rule", logic: (c) => `${c} > 0` },
  { label: "Not Future Date", rule_type: "consistency", logic: (c) => `${c} <= CURRENT_DATE()` },
  { label: "Unique", rule_type: "uniqueness", logic: (c) => `COUNT(*) = COUNT(DISTINCT ${c})` },
  { label: "Referential", rule_type: "referential", logic: (c) => `${c} IN (SELECT code FROM ref_table)` },
];
const OPERATORS = ["IS NOT NULL", "IS NULL", ">", ">=", "<", "<=", "=", "<>", "BETWEEN", "IN", "RLIKE"];

interface Gen { logic: string; explanation: string; checks: string[]; }

export function CreateValidation() {
  const nav = useNavigate();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [ruleType, setRuleType] = useState("validity");
  const [domain, setDomain] = useState("Customer");
  const [criticality, setCriticality] = useState("high");
  const [description, setDescription] = useState("");
  const [dataset, setDataset] = useState("customer_master");
  const [table, setTable] = useState("customer_master");
  const [column, setColumn] = useState("Email_ID");
  const [method, setMethod] = useState<Method>("AI Assisted");
  const [prompt, setPrompt] = useState("");
  const [logic, setLogic] = useState("");
  const [gen, setGen] = useState<Gen | null>(null);
  const [validation, setValidation] = useState<{ valid: boolean; error?: string } | null>(null);
  // Expression builder pieces
  const [exprOp, setExprOp] = useState("IS NOT NULL");
  const [exprVal, setExprVal] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  usePage({ title: "Create Validation Rule", subtitle: "Define a data quality rule, then submit it for approval" });

  const generate = async () => {
    setBusy(true); setErr(null);
    try {
      const g = await api.generateValidation({ description: prompt || description, rule_type: ruleType, column_name: column });
      setGen(g);
      if (g.logic) { setLogic(g.logic); setValidation(null); }
    } catch (e) {
      setErr(String(e instanceof Error ? e.message : e));
    } finally {
      setBusy(false);
    }
  };

  const validate = async () => setValidation(await api.validateRuleExpression(logic));

  const applyExprBuilder = () => {
    const needsVal = !["IS NOT NULL", "IS NULL"].includes(exprOp);
    setLogic(`${column} ${exprOp}${needsVal ? ` ${exprVal || "…"}` : ""}`.trim());
    setValidation(null);
  };

  const templatesForType = useMemo(() => TEMPLATES.filter((t) => t.rule_type === ruleType || method === "Template Based"), [ruleType, method]);

  const save = async (mode: "draft" | "submit") => {
    setErr(null);
    if (!name.trim()) { setErr("Rule name is required."); setStep(0); return; }
    if (!logic.trim()) { setErr("Rule logic is required — generate, pick a template, build, or write it."); setStep(1); return; }
    setBusy(true);
    try {
      const created = await api.createValidation({
        name: name.trim(), rule_type: ruleType, dataset, column_name: column,
        severity: criticality, description: description || null, logic,
        tags: [ruleType, domain.toLowerCase()], status: "Draft",
      });
      if (mode === "submit") await api.submitValidation(created.id);
      nav("/validations");
    } catch (e) {
      setErr(String(e instanceof Error ? e.message : e));
    } finally {
      setBusy(false);
    }
  };

  const next = () => (step < STEPS.length - 1 ? setStep(step + 1) : save("submit"));

  return (
    <div className="flex flex-col h-full">
      <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between">
        <WizardStepper steps={STEPS} current={step} />
        <div className="flex items-center gap-2">
          <Button variant="secondary" onClick={() => save("draft")} disabled={busy}>Save Draft</Button>
          <Button variant="secondary" onClick={() => nav("/validations")}>Cancel</Button>
          {step > 0 && <Button variant="secondary" onClick={() => setStep(step - 1)}>Back</Button>}
          <Button onClick={next} disabled={busy}>{step < STEPS.length - 1 ? "Next" : busy ? "Submitting…" : "Submit for Approval"}</Button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <Breadcrumbs items={[{ label: "Validation" }, { label: "Data Quality Rules" }, { label: "Create Rule" }]} />
        {err && <p className="text-xs text-red-600 mt-3">{err}</p>}

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5 mt-4">
          <div className="xl:col-span-2 space-y-5">
            {/* Step 0: Define */}
            {step === 0 && (
              <>
                <Section n="1" title="Rule Information">
                  <div className="grid grid-cols-2 gap-4">
                    <Labeled label="Rule Name *"><input value={name} onChange={(e) => setName(e.target.value)} className="inp" placeholder="Customer Email - Valid Format" /></Labeled>
                    <Labeled label="Rule Type *">
                      <select value={ruleType} onChange={(e) => setRuleType(e.target.value)} className="inp">{RULE_TYPES.map((t) => <option key={t}>{t}</option>)}</select>
                    </Labeled>
                    <Labeled label="Domain *"><input value={domain} onChange={(e) => setDomain(e.target.value)} className="inp" /></Labeled>
                    <Labeled label="Criticality *">
                      <select value={criticality} onChange={(e) => setCriticality(e.target.value)} className="inp">{["critical", "high", "medium", "low"].map((t) => <option key={t}>{t}</option>)}</select>
                    </Labeled>
                    <div className="col-span-2"><Labeled label="Description"><textarea value={description} onChange={(e) => setDescription(e.target.value)} className="inp h-16" placeholder="Validates that customer email is in a proper format." /></Labeled></div>
                  </div>
                </Section>
                <Section n="2" title="Scope">
                  <div className="grid grid-cols-3 gap-4">
                    <Labeled label="Dataset *"><input value={dataset} onChange={(e) => setDataset(e.target.value)} className="inp" /></Labeled>
                    <Labeled label="Table *"><input value={table} onChange={(e) => setTable(e.target.value)} className="inp" /></Labeled>
                    <Labeled label="Column(s) *"><input value={column} onChange={(e) => setColumn(e.target.value)} className="inp" /></Labeled>
                  </div>
                </Section>
              </>
            )}

            {/* Step 1: Set Logic */}
            {step === 1 && (
              <Section n="3" title="Rule Definition Method">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {METHODS.map((m) => (
                    <button key={m.label} onClick={() => setMethod(m.label)} className={`border rounded-lg p-3 text-left ${method === m.label ? "border-brand bg-brand-soft/40" : "border-gray-200 hover:border-brand/40"}`}>
                      <m.icon className="w-5 h-5 text-brand mb-1" />
                      <div className="text-xs font-medium text-gray-800">{m.label}{m.rec && <span className="ml-1 text-[9px] bg-green-100 text-green-700 px-1 rounded">Recommended</span>}</div>
                      <div className="text-[10px] text-gray-400 leading-tight mt-0.5">{m.sub}</div>
                    </button>
                  ))}
                </div>

                <div className="mt-4">
                  {method === "AI Assisted" && (
                    <Labeled label="Describe what you want to validate">
                      <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} className="inp h-20" placeholder="Email should contain @ and a domain with a valid extension." />
                    </Labeled>
                  )}
                  {method === "Template Based" && (
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Pick a template — it prefills the logic for {column}.</div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                        {templatesForType.map((t) => (
                          <button key={t.label} onClick={() => { setLogic(t.logic(column)); setRuleType(t.rule_type); setValidation(null); }} className="border border-gray-200 rounded-lg p-2 text-left hover:border-brand/40">
                            <div className="text-xs font-medium text-gray-800">{t.label}</div>
                            <code className="text-[10px] text-gray-400 font-mono line-clamp-1">{t.logic(column)}</code>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                  {method === "Expression Builder" && (
                    <div className="flex items-end gap-2">
                      <Labeled label="Column"><input value={column} onChange={(e) => setColumn(e.target.value)} className="inp w-40" /></Labeled>
                      <Labeled label="Operator"><select value={exprOp} onChange={(e) => setExprOp(e.target.value)} className="inp w-40">{OPERATORS.map((o) => <option key={o}>{o}</option>)}</select></Labeled>
                      {!["IS NOT NULL", "IS NULL"].includes(exprOp) && <Labeled label="Value"><input value={exprVal} onChange={(e) => setExprVal(e.target.value)} className="inp w-40" placeholder="e.g. 0  or  'A','B'" /></Labeled>}
                      <Button variant="secondary" onClick={applyExprBuilder}>Apply</Button>
                    </div>
                  )}

                  {/* Logic editor — shared across methods */}
                  <div className="mt-4">
                    <Labeled label="Rule Logic (boolean SQL expression) *">
                      <textarea value={logic} onChange={(e) => { setLogic(e.target.value); setValidation(null); }} className="inp font-mono text-xs h-24" placeholder="Email_ID IS NOT NULL" />
                    </Labeled>
                    <div className="flex items-center gap-2 mt-2">
                      <Button variant="secondary" onClick={validate} disabled={!logic.trim()}>Validate Expression</Button>
                      {validation && <span className={`text-xs ${validation.valid ? "text-green-600" : "text-red-600"}`}>{validation.valid ? "✓ Valid Spark expression" : `✗ ${validation.error}`}</span>}
                    </div>
                  </div>
                </div>
              </Section>
            )}

            {/* Step 2: Test & Preview */}
            {step === 2 && (
              <Section n="4" title="Test & Preview">
                <div className="text-xs text-gray-500 mb-2">Rule logic (validated deterministically with sqlglot):</div>
                <code className="block bg-[#0d1117] text-emerald-300 rounded px-3 py-2 text-[11px] font-mono whitespace-pre-wrap">{logic || "— no logic defined —"}</code>
                <div className="flex items-center gap-2 mt-2">
                  <Button variant="secondary" onClick={validate} disabled={!logic.trim()}>Re-validate</Button>
                  {validation && <span className={`text-xs ${validation.valid ? "text-green-600" : "text-red-600"}`}>{validation.valid ? "✓ Valid" : `✗ ${validation.error}`}</span>}
                </div>
                {validation?.valid === false && <p className="text-xs text-amber-700 mt-2">Fix the expression before submitting — invalid logic can't be approved.</p>}
              </Section>
            )}

            {/* Step 3: Review */}
            {step === 3 && (
              <Section n="5" title="Review & Submit">
                <dl className="text-sm grid grid-cols-2 gap-y-2">
                  <Row k="Name" v={name || "—"} /><Row k="Rule Type" v={ruleType} />
                  <Row k="Domain" v={domain} /><Row k="Criticality" v={criticality} />
                  <Row k="Dataset / Table" v={`${dataset} / ${table}`} /><Row k="Column" v={column} />
                </dl>
                {description && <p className="text-xs text-gray-500 mt-2">{description}</p>}
                <div className="text-xs text-gray-500 mt-3 mb-1">Logic</div>
                <code className="block bg-[#0d1117] text-emerald-300 rounded px-3 py-2 text-[11px] font-mono whitespace-pre-wrap">{logic || "—"}</code>
                <p className="text-[11px] text-gray-500 mt-3">
                  Submitting sends this rule for approval — it becomes <b>Pending Approval</b> until a reviewer (or an admin) approves it, then it is Published.
                </p>
              </Section>
            )}
          </div>

          {/* AI Assistant rail — always available */}
          <div className="bg-white rounded-xl border border-gray-200 p-5 self-start">
            <div className="flex items-center gap-2 mb-1"><Sparkles className="w-4 h-4 text-brand" /><span className="font-semibold text-gray-800">AI Assistant</span></div>
            <div className="text-xs text-gray-500 mb-2">Describe your requirement</div>
            <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} className="inp h-20" placeholder="Email should be in a valid format…" />
            <Button className="w-full justify-center mt-2" onClick={generate} disabled={busy || (!prompt.trim() && !description.trim())}><Wand2 className="w-4 h-4" /> {busy ? "Generating…" : "Generate Rule"}</Button>
            {gen && (
              <div className="mt-4">
                <div className="text-xs font-medium text-gray-500 mb-1">Suggested rule logic</div>
                <code className="block bg-gray-900 text-green-300 rounded px-2 py-2 text-[11px] font-mono whitespace-pre-wrap">{gen.logic}</code>
                <div className="text-xs text-gray-500 mt-2">Why this rule?</div>
                <p className="text-xs text-gray-600">{gen.explanation}</p>
                <ul className="mt-2 space-y-1">
                  {gen.checks.map((c, i) => <li key={i} className="flex items-center gap-1.5 text-xs text-gray-700"><CheckCircle2 className="w-3 h-3 text-green-600 shrink-0" /> {c}</li>)}
                </ul>
                <Button variant="secondary" className="w-full justify-center mt-2" onClick={() => { setLogic(gen.logic); setValidation(null); }}><Check className="w-3.5 h-3.5" /> Use this logic</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ n, title, children }: { n: string; title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <div className="text-sm font-semibold text-gray-800 mb-3">{n}. {title}</div>
      {children}
    </div>
  );
}
function Labeled({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block"><span className="text-xs text-gray-500 mb-1 block">{label}</span>{children}</label>;
}
function Row({ k, v }: { k: string; v: string }) {
  return <><dt className="text-gray-500">{k}</dt><dd className="text-gray-800 capitalize">{v}</dd></>;
}
