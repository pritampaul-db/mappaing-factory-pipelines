"""Publish-time metadata indexing (Metadata Explorer).

When a mapping is APPROVED/published, its metadata is indexed into the catalog so
it shows up in the Metadata Explorer — the source & target tables (and their
columns) as data assets, the mapping itself as a data product, business-glossary
terms for each target table, source-system counts, and the relationship-graph edges
(source → mapping → target, plus source↔source joins and table → column).

This runs on a BACKGROUND THREAD — `index_spec_async` returns immediately so the
approve/publish request never waits on it. Everything is best-effort: an indexing
hiccup must never fail (or roll back) an approval that already succeeded.

Idempotent: every row this writes carries the spec_id, so re-indexing a spec first
deletes only its own prior rows — seeded catalog rows (spec_id NULL) are untouched.
"""
from __future__ import annotations

import threading
from typing import Any
from uuid import UUID

# Domain guess by target-system / name keyword — keeps the Business Domain donut
# meaningful without asking the user. Falls back to "Operations".
_DOMAIN_KEYWORDS = [
    ("Customer Management", ("customer", "cust", "party", "contact")),
    ("Finance", ("finance", "gl", "ledger", "account", "balance", "pnl", "revenue")),
    ("Risk & Compliance", ("risk", "rwa", "exposure", "reg_reporting", "compliance", "reg")),
    ("Reference Data", ("ref", "lookup", "code", "country", "currency")),
]


def _domain_for(*names: str) -> str:
    hay = " ".join(n.lower() for n in names if n)
    for domain, kws in _DOMAIN_KEYWORDS:
        if any(k in hay for k in kws):
            return domain
    return "Operations"


def index_spec_async(spec_id: str | UUID) -> None:
    """Fire-and-forget: index a published spec's metadata on a daemon thread."""
    t = threading.Thread(target=_safe_index, args=(str(spec_id),), daemon=True)
    t.start()


def _safe_index(spec_id: str) -> None:
    try:
        _index_spec(spec_id)
    except Exception as e:  # noqa: BLE001 — never let indexing surface as an error
        print(f"[metadata_index] indexing spec {spec_id} failed: {e}")


def _index_spec(spec_id: str) -> None:
    from server import db, repo

    spec = repo.get_spec(db.pool, UUID(spec_id))
    if spec is None:
        return
    sources = spec.get("sources") or []
    targets = spec.get("targets") or []
    if not sources and spec.get("source_asset_id"):
        a = repo.get_asset(db.pool, spec["source_asset_id"])
        sources = [a] if a else []
    if not targets and spec.get("target_asset_id"):
        a = repo.get_asset(db.pool, spec["target_asset_id"])
        targets = [a] if a else []

    mapping_name = spec["name"]
    owner = spec.get("owner")
    src_sys = spec.get("source_system")
    tgt_sys = spec.get("target_system")
    domain = _domain_for(mapping_name, tgt_sys or "", *(t["name"] for t in targets))
    active = [m for m in spec.get("mappings", []) if m.get("state") != "rejected"]

    # Rows to write (name, asset_type, system, domain, criticality, owner, description).
    assets: list[tuple] = []
    edges: list[tuple] = []   # (src_name, src_type, dst_name, dst_type, edge_type)
    terms: list[tuple] = []   # (name, definition, term_type, domain, steward)

    for a in sources:
        assets.append((a["name"], "table", src_sys, domain, "Medium", owner, f"Source table for mapping “{mapping_name}”."))
        edges.append((a["name"], "table", mapping_name, "mapping", "feeds"))
    # source ↔ source join edges (from the AI-proposed joins).
    for j in (spec.get("joins") or []):
        lt = (j.get("left") or "").split(".")[0]
        rt = (j.get("right") or "").split(".")[0]
        if lt and rt and lt != rt:
            edges.append((lt, "table", rt, "table", "join"))

    # The mapping itself — the data product hub.
    assets.append((mapping_name, "data_product", tgt_sys or src_sys, domain, "High", owner,
                   f"Published mapping: {src_sys or '—'} → {tgt_sys or '—'} ({len(active)} columns)."))

    tgt_by_field = {str(f["id"]): t for t in targets for f in t["fields"]}
    for t in targets:
        assets.append((t["name"], "table", tgt_sys, domain, "High", owner, f"Target table produced by mapping “{mapping_name}”."))
        edges.append((mapping_name, "mapping", t["name"], "table", "produces"))
        # Target table as a business-glossary term (idempotent by name).
        terms.append((t["name"], f"Conformed target table from mapping “{mapping_name}” ({tgt_sys or '—'}).", "business_term", domain, owner))
        # Each target column as a column asset + table→column edge.
        for f in t["fields"]:
            col = f"{t['name']}.{f['name']}"
            assets.append((col, "column", tgt_sys, domain, "Low", owner, f"{f.get('datatype', 'string')} column of {t['name']}."))
            edges.append((t["name"], "table", col, "column", "has_column"))

    systems = {s for s in (src_sys, tgt_sys) if s}

    with db.pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SET search_path TO mapping_factory, public")
            # Replace this spec's prior rows only.
            cur.execute("DELETE FROM data_asset WHERE spec_id=%s", (spec_id,))
            cur.execute("DELETE FROM metadata_edge WHERE spec_id=%s", (spec_id,))

            for name, atype, system, dom, crit, own, desc in assets:
                cur.execute(
                    "INSERT INTO data_asset (name, asset_type, system, domain, criticality, owner, description, spec_id, updated_at) "
                    "VALUES (%s,%s,%s,%s,%s,%s,%s,%s, now())",
                    (name, atype, system, dom, crit, own, desc, spec_id),
                )
            for src_name, src_type, dst_name, dst_type, etype in edges:
                cur.execute(
                    "INSERT INTO metadata_edge (src_name, src_type, dst_name, dst_type, edge_type, spec_id) "
                    "VALUES (%s,%s,%s,%s,%s,%s)",
                    (src_name, src_type, dst_name, dst_type, etype, spec_id),
                )
            # Glossary terms — insert only if a term of that name doesn't already exist.
            for name, definition, ttype, dom, steward in terms:
                cur.execute("SELECT 1 FROM glossary_term WHERE name=%s", (name,))
                if cur.fetchone() is None:
                    cur.execute(
                        "INSERT INTO glossary_term (name, definition, term_type, domain, steward) VALUES (%s,%s,%s,%s,%s)",
                        (name, definition, ttype, dom, steward),
                    )
            # Source-system asset counts (upsert; recompute from data_asset).
            for code in systems:
                cur.execute(
                    "INSERT INTO source_system (code, name, asset_count) VALUES (%s,%s,%s) "
                    "ON CONFLICT (code) DO UPDATE SET asset_count = "
                    "(SELECT COUNT(*) FROM data_asset WHERE system = EXCLUDED.code)",
                    (code, code, 0),
                )
            # Activity feed entry.
            cur.execute(
                "INSERT INTO activity (actor, action, target, target_type) VALUES (%s,%s,%s,%s)",
                (owner or "system", f"indexed {len(assets)} assets into the catalog for", mapping_name, "mapping"),
            )
        conn.commit()
    print(f"[metadata_index] indexed spec {spec_id}: {len(assets)} assets, {len(edges)} edges, {len(terms)} terms")
