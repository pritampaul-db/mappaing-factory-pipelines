import { createBrowserRouter, Navigate } from "react-router-dom";
import { AppShell } from "./AppShell";
import { Placeholder } from "./pages/Placeholder";
import { Dashboard } from "./pages/Dashboard";
import { MappingList } from "./pages/MappingStudio/MappingList";
import { NewMapping } from "./pages/MappingStudio/NewMapping";
import { MappingDetails } from "./pages/MappingStudio/MappingDetails";
import { RuleLibrary } from "./pages/Rules/RuleLibrary";
import { CreateRule } from "./pages/Rules/CreateRule";
import { TransformationsLibrary } from "./pages/Transformations/TransformationsLibrary";
import { TransformationBuilder } from "./pages/Transformations/TransformationBuilder";
import { ValidationList } from "./pages/Validations/ValidationList";
import { MetadataExplorer } from "./pages/MetadataExplorer";
import { ExecutionMonitor } from "./pages/ExecutionMonitor";
import { Administration } from "./pages/Administration";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <AppShell />,
    children: [
      { index: true, element: <Dashboard /> },
      { path: "mappings", element: <MappingList /> },
      { path: "mappings/new", element: <NewMapping /> },
      { path: "mappings/:id/edit", element: <NewMapping /> },
      { path: "mappings/:id", element: <MappingDetails /> },
      { path: "rules", element: <RuleLibrary /> },
      { path: "rules/new", element: <CreateRule /> },
      { path: "transformations", element: <TransformationsLibrary /> },
      { path: "transformations/new", element: <TransformationBuilder /> },
      { path: "validations", element: <ValidationList /> },
      // Rule creation moved to the Rule Library; old create route redirects there.
      { path: "validations/new", element: <Navigate to="/rules/new" replace /> },
      { path: "metadata", element: <MetadataExplorer /> },
      { path: "executions", element: <ExecutionMonitor /> },
      // Not-yet-wireframed nav items.
      { path: "explainability", element: <Placeholder title="Explainability" /> },
      { path: "lineage", element: <Placeholder title="Lineage Explorer" /> },
      { path: "impact", element: <Placeholder title="Impact Analysis" /> },
      { path: "governance", element: <Placeholder title="Governance" /> },
      { path: "assistant", element: <Placeholder title="AI Assistant" /> },
      { path: "knowledge", element: <Placeholder title="Knowledge Hub" /> },
      { path: "admin", element: <Administration /> },
    ],
  },
]);
