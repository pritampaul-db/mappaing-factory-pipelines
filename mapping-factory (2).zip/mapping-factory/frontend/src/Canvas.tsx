import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ReactFlow,
  Background,
  Controls,
  Handle,
  Position,
  MarkerType,
  useNodesState,
  useEdgesState,
  type Node,
  type Edge,
  type NodeProps,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { FileText, Table2, Shuffle, Check, X, Search, ShieldCheck, KeyRound, CheckCheck, Ban, AlertCircle, Wand2, Library } from "lucide-react";
import { useStore } from "./store";
import { api, type Asset, type Mapping, type Transformation, type Validation } from "./api";

const SEV_COLOR: Record<string, string> = {
  critical: "#dc2626",
  high: "#ea580c",
  medium: "#d97706",
  low: "#9ca3af",
};

// Color an edge/step by AI confidence (green ≥0.9, amber 0.6–0.9, red <0.6).
function confColor(c?: number | null): string {
  if (c == null) return "#9ca3af";
  if (c >= 0.9) return "#16a34a";
  if (c >= 0.6) return "#d97706";
  return "#dc2626";
}
function stateColor(state: string): string {
  return state === "accepted" || state === "edited" ? "#16a34a" : state === "rejected" ? "#9ca3af" : "#a855f7";
}

// --- Schema node: white card, tinted header, per-field port, column search ---
type SchemaNodeData = {
  label: string;
  sublabel: string;
  role: "source" | "target";
  fields: Asset["fields"];   // already filtered for display
  total: number;             // total column count (for "N of M")
  query: string;
  onQuery: (q: string) => void;
  unmappedIds?: Set<string>; // target-only: fields with no active mapping (flagged amber)
  keyIds?: Set<string>;      // fields that are keys (PK/FK) — badge
};

function SchemaNode({ data }: NodeProps<Node<SchemaNodeData>>) {
  const isSource = data.role === "source";
  const headerCls = isSource ? "bg-emerald-50 text-emerald-800 border-emerald-100" : "bg-purple-50 text-purple-800 border-purple-100";
  const filtered = data.fields.length !== data.total;
  return (
    <div className="rounded-xl border border-gray-200 bg-white shadow-sm min-w-[230px] overflow-hidden">
      <div className={`px-3 py-2 border-b ${headerCls}`}>
        <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide opacity-70">
          {isSource ? <FileText className="w-3 h-3" /> : <Table2 className="w-3 h-3" />}
          {isSource ? "Source" : "Target"}
        </div>
        <div className="text-sm font-semibold leading-tight">{data.label}</div>
        <div className="text-[10px] opacity-60 truncate max-w-[200px]">{data.sublabel}</div>
      </div>

      {/* Column search — nodrag so typing/clicking doesn't drag the node. */}
      <div className="px-2 pt-2 pb-1 nodrag">
        <div className="relative">
          <Search className="w-3 h-3 text-gray-400 absolute left-2 top-1/2 -translate-y-1/2" />
          <input
            value={data.query}
            onChange={(e) => data.onQuery(e.target.value)}
            placeholder="Search columns"
            className="nodrag w-full bg-gray-50 border border-gray-200 rounded-md pl-6 pr-6 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-brand/30"
          />
          {data.query && (
            <button onClick={() => data.onQuery("")} className="nodrag absolute right-1.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      <div className="pb-1">
        <div className="px-3 py-1 text-[10px] text-gray-400">
          {filtered ? `${data.fields.length} of ${data.total}` : data.total} Columns
        </div>
        {data.fields.map((f) => {
          const unmapped = data.unmappedIds?.has(f.id);
          const isKey = data.keyIds?.has(f.id);
          return (
            <div key={f.id} className={`relative px-3 py-1.5 text-xs flex items-center justify-between gap-2 hover:bg-gray-50 ${unmapped ? "bg-amber-50/60" : ""}`} title={unmapped ? "No mapping yet — needs manual mapping" : undefined}>
              <span className="flex items-center gap-1 min-w-0">
                {isKey && <KeyRound className="w-2.5 h-2.5 text-amber-500 shrink-0" />}
                <span className="text-gray-700 truncate">{f.name}</span>
                {unmapped && <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />}
              </span>
              <span className="text-gray-400 shrink-0">{f.datatype}</span>
              <Handle
                id={f.id}
                type={isSource ? "source" : "target"}
                position={isSource ? Position.Right : Position.Left}
                style={{ background: "#cbd5e1", width: 8, height: 8, border: "1px solid #94a3b8", [isSource ? "right" : "left"]: -5 }}
              />
            </div>
          );
        })}
        {data.fields.length === 0 && <div className="px-3 py-3 text-[11px] text-gray-400">No matching columns.</div>}
      </div>
    </div>
  );
}

// --- Transform node: one per TARGET TABLE. Each step row has its own in/out
// handle, approve/reject, detail; a header with Approve-all/Reject-all for the
// block's pending steps, and a list of unmapped target columns needing attention.
type Step = { id: string; label: string; state: string; confidence?: number | null; optimized?: boolean };
type TransformNodeData = {
  title: string;             // target table name this block feeds
  steps: Step[];
  unmapped: string[];        // target column names with no active mapping
  selectedId: string | null;
  busy: boolean;
  onSelect: (id: string) => void;
  onAccept: (id: string) => void;
  onReject: (id: string) => void;
  onApproveAll: (ids: string[]) => void;
  onRejectAll: (ids: string[]) => void;
};

function TransformNode({ data }: NodeProps<Node<TransformNodeData>>) {
  const pending = data.steps.filter((s) => s.state === "suggested");
  const pendingIds = pending.map((s) => s.id);
  return (
    <div className="rounded-xl border border-blue-100 bg-white shadow-sm min-w-[280px] max-w-[340px] overflow-hidden">
      <div className="px-3 py-2 bg-blue-50 text-blue-800 border-b border-blue-100">
        <div className="flex items-center gap-1.5">
          <Shuffle className="w-3.5 h-3.5 shrink-0" />
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold leading-tight truncate" title={data.title}>→ {data.title}</div>
            <div className="text-[10px] opacity-60">{data.steps.length} step{data.steps.length === 1 ? "" : "s"}{pending.length ? ` · ${pending.length} pending` : ""}</div>
          </div>
        </div>
        {pending.length > 0 && (
          <div className="flex gap-1.5 mt-2 nodrag">
            <button onClick={() => data.onApproveAll(pendingIds)} disabled={data.busy} className="flex-1 flex items-center justify-center gap-1 text-[10px] px-2 py-1 rounded bg-green-600 text-white hover:bg-green-500 disabled:opacity-40">
              <CheckCheck className="w-3 h-3" /> Approve all
            </button>
            <button onClick={() => data.onRejectAll(pendingIds)} disabled={data.busy} className="flex-1 flex items-center justify-center gap-1 text-[10px] px-2 py-1 rounded bg-white border border-red-200 text-red-600 hover:bg-red-50 disabled:opacity-40">
              <Ban className="w-3 h-3" /> Reject all
            </button>
          </div>
        )}
      </div>
      <ul className="py-1">
        {data.steps.map((s, i) => {
          const selected = data.selectedId === s.id;
          const approved = s.state === "accepted" || s.state === "edited";
          return (
            <li
              key={s.id}
              onClick={() => data.onSelect(s.id)}
              className={`relative px-3 py-2 text-xs flex items-center gap-2 cursor-pointer ${selected ? "bg-blue-50" : "hover:bg-gray-50"}`}
            >
              <Handle id={`in-${s.id}`} type="target" position={Position.Left} style={{ background: confColor(s.confidence), width: 8, height: 8, left: -5 }} />
              <Handle id={`out-${s.id}`} type="source" position={Position.Right} style={{ background: confColor(s.confidence), width: 8, height: 8, right: -5 }} />
              <span className="w-4 h-4 rounded-full grid place-items-center text-[9px] text-white shrink-0" style={{ background: stateColor(s.state) }}>{i + 1}</span>
              <span className="text-gray-700 truncate flex-1">{s.label}</span>
              {s.optimized && <span className="text-[9px] bg-brand-soft text-brand px-1 py-0.5 rounded shrink-0 nodrag" title="Optimized — unsaved until you Save">✨ optimized</span>}
              {approved ? (
                <span className="flex items-center gap-0.5 text-[10px] text-green-600 shrink-0"><Check className="w-3 h-3" /> Approved</span>
              ) : (
                <span className="flex items-center gap-1 shrink-0 nodrag">
                  <button title="Approve" onClick={(e) => { e.stopPropagation(); data.onAccept(s.id); }} disabled={data.busy} className="w-5 h-5 grid place-items-center rounded bg-green-100 text-green-700 hover:bg-green-200 disabled:opacity-40"><Check className="w-3 h-3" /></button>
                  <button title="Reject" onClick={(e) => { e.stopPropagation(); data.onReject(s.id); }} disabled={data.busy} className="w-5 h-5 grid place-items-center rounded bg-red-100 text-red-700 hover:bg-red-200 disabled:opacity-40"><X className="w-3 h-3" /></button>
                </span>
              )}
            </li>
          );
        })}
        {data.steps.length === 0 && <li className="px-3 py-3 text-[11px] text-gray-400">No transformations match the current column filter.</li>}
      </ul>
      {data.unmapped.length > 0 && (
        <div className="border-t border-amber-100 bg-amber-50/50 px-3 py-2">
          <div className="flex items-center gap-1 text-[10px] font-medium text-amber-700 mb-1">
            <AlertCircle className="w-3 h-3" /> {data.unmapped.length} column{data.unmapped.length === 1 ? "" : "s"} need manual mapping
          </div>
          <div className="flex flex-wrap gap-1">
            {data.unmapped.map((c) => (
              <span key={c} className="text-[10px] px-1.5 py-0.5 rounded bg-white border border-amber-200 text-amber-700">{c}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// --- Validation node: one row per target column that has DQ check(s) ---------
// Each row carries in/out handles keyed by the target column id, so a column's
// journey routes transform → validation(col) → target. Columns without a check
// bypass this node (edge goes transform → target directly).
type ValRow = { targetFieldId: string; column: string; count: number; severity: string; label: string };
type ValidationNodeData = { title: string; rows: ValRow[]; selected: string | null; onSelect: (col: string) => void };

function ValidationNode({ data }: NodeProps<Node<ValidationNodeData>>) {
  return (
    <div className="rounded-xl border border-rose-100 bg-white shadow-sm min-w-[240px] overflow-hidden">
      <div className="px-3 py-2 bg-rose-50 text-rose-800 border-b border-rose-100 flex items-center gap-1.5">
        <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
        <div className="min-w-0">
          <div className="text-sm font-semibold leading-tight truncate" title={data.title}>Validations · {data.title}</div>
          <div className="text-[10px] opacity-60">{data.rows.reduce((a, r) => a + r.count, 0)} checks</div>
        </div>
      </div>
      <ul className="py-1">
        {data.rows.map((r) => {
          const sel = data.selected === r.targetFieldId;
          const color = SEV_COLOR[r.severity] ?? "#9ca3af";
          return (
            <li
              key={r.targetFieldId}
              onClick={() => data.onSelect(r.targetFieldId)}
              className={`relative px-3 py-2 text-xs flex items-center gap-2 cursor-pointer ${sel ? "bg-rose-50" : "hover:bg-gray-50"}`}
            >
              <Handle id={`vin-${r.targetFieldId}`} type="target" position={Position.Left} style={{ background: color, width: 8, height: 8, left: -5 }} />
              <Handle id={`vout-${r.targetFieldId}`} type="source" position={Position.Right} style={{ background: color, width: 8, height: 8, right: -5 }} />
              <ShieldCheck className="w-3 h-3 shrink-0" style={{ color }} />
              <span className="text-gray-700 truncate flex-1">{r.label}</span>
              {r.count > 1 && <span className="text-[9px] text-gray-400 shrink-0">×{r.count}</span>}
            </li>
          );
        })}
        {data.rows.length === 0 && <li className="px-3 py-3 text-[11px] text-gray-400">No validations yet — use “Validate mapping”.</li>}
      </ul>
    </div>
  );
}

const nodeTypes = { schema: SchemaNode, transform: TransformNode, validation: ValidationNode };

export function Canvas() {
  const { source, target, spec, busy, curate, curateBulk, appliedValidations, loadAppliedValidations,
          regenerateMapping, useTransformation, regenerateValidation, useRuleForValidation,
          setValidationDqAction, propagateTransformation, propagateValidation } = useStore();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedValCol, setSelectedValCol] = useState<string | null>(null);
  // Cross-table propagation prompt: after a transform/validation change on a field that
  // ALSO exists in other target tables, offer to apply the change there too.
  const [propagate, setPropagate] = useState<
    | { kind: "transform"; mappingId: string; field: string; candidates: string[] }
    | { kind: "validation"; validationId: string; field: string; candidates: string[] }
    | null
  >(null);
  const [srcQuery, setSrcQuery] = useState("");
  const [tgtQuery, setTgtQuery] = useState("");
  const [nodes, setNodes, onNodesChange] = useNodesState<Node>([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState<Edge>([]);

  const active = useMemo(() => (spec?.mappings ?? []).filter((m) => m.state !== "rejected"), [spec]);
  const hasTransforms = active.length > 0;

  // Multi-table: one box per source/target ASSET. Falls back to the singular
  // source/target for single-table specs. Field ids are global, so a mapping's
  // edges resolve to whichever box holds each field regardless of table.
  const sourceAssets = useMemo(() => (spec?.sources?.length ? spec.sources : source ? [source] : []), [spec, source]);
  const targetAssets = useMemo(() => (spec?.targets?.length ? spec.targets : target ? [target] : []), [spec, target]);

  // Load the DQ-Library validations for this target on mount / target change.
  useEffect(() => { loadAppliedValidations(); }, [target?.id, loadAppliedValidations]);

  // Group validations by the target FIELD they guard, scoped to the field's TABLE —
  // keyed by the globally-unique target_field_id. A validation matches a field when its
  // dataset == the field's table name AND its column_name == the field name. This keeps
  // the same column name in two different tables (e.g. DEBIT_VALUE) as SEPARATE buckets,
  // so each table's field shows only its own checks (was: merged by name → false "x2").
  const valsByFieldId = useMemo(() => {
    // (dataset|column) → validations, then attach to each target field by its table+name.
    const byDatasetCol = new Map<string, Validation[]>();
    for (const v of appliedValidations) {
      if (!v.column_name) continue;
      const key = `${(v.dataset ?? "").toLowerCase()}|${v.column_name.toLowerCase()}`;
      (byDatasetCol.get(key) ?? byDatasetCol.set(key, []).get(key)!).push(v);
    }
    const m = new Map<string, Validation[]>();  // target_field_id → its table's checks
    for (const a of targetAssets) {
      const ds = (a.name ?? "").toLowerCase();
      for (const f of a.fields) {
        const vs = byDatasetCol.get(`${ds}|${(f.name ?? "").toLowerCase()}`);
        if (vs && vs.length) m.set(f.id, vs);
      }
    }
    return m;
  }, [appliedValidations, targetAssets]);
  const hasValidations = valsByFieldId.size > 0;

  const byId = useMemo(() => new Map(active.map((m) => [m.id, m])), [active]);

  // Other target tables (by name) that also have a field named `field`, excluding
  // `exceptTable`. Used to offer cross-table propagation of a transform/validation change.
  const otherTablesWithField = useCallback((field: string, exceptTable: string): string[] => {
    const out: string[] = [];
    for (const a of targetAssets) {
      if (a.name === exceptTable) continue;
      if (a.fields.some((f) => f.name === field)) out.push(a.name);
    }
    return out;
  }, [targetAssets]);

  // After a transform change on a mapping, if its target field exists in other tables,
  // raise the propagation prompt (default all checked).
  const maybePromptTransform = useCallback((mappingId: string) => {
    const m = active.find((x) => x.id === mappingId) ?? spec?.mappings?.find((x) => x.id === mappingId);
    if (!m) return;
    const table = (targetAssets.find((a) => a.fields.some((f) => f.id === m.target_field_id)) || {}).name ?? "";
    const candidates = otherTablesWithField(m.target_field_name, table);
    if (candidates.length) setPropagate({ kind: "transform", mappingId, field: m.target_field_name, candidates });
  }, [active, spec, targetAssets, otherTablesWithField]);

  const regenerateThenPrompt = useCallback(async (mappingId: string, fb: string) => {
    await regenerateMapping(mappingId, fb); maybePromptTransform(mappingId);
  }, [regenerateMapping, maybePromptTransform]);
  const useLibraryThenPrompt = useCallback(async (mappingId: string, code: string) => {
    await useTransformation(mappingId, code); maybePromptTransform(mappingId);
  }, [useTransformation, maybePromptTransform]);

  // Same for a validation change: after regenerate / from-library, if the guarded field
  // exists in other tables, offer to add the same check there too.
  const maybePromptValidation = useCallback((validationId: string, column: string, dataset: string) => {
    const candidates = otherTablesWithField(column, dataset);
    if (candidates.length) setPropagate({ kind: "validation", validationId, field: column, candidates });
  }, [otherTablesWithField]);
  const regenValThenPrompt = useCallback(async (vid: string, fb: string, column: string, dataset: string) => {
    await regenerateValidation(vid, fb); maybePromptValidation(vid, column, dataset);
  }, [regenerateValidation, maybePromptValidation]);
  const useRuleThenPrompt = useCallback(async (vid: string, code: string, column: string, dataset: string) => {
    await useRuleForValidation(vid, code); maybePromptValidation(vid, column, dataset);
  }, [useRuleForValidation, maybePromptValidation]);

  const onAccept = useCallback((id: string) => { const m = byId.get(id); if (m) curate(m, "accept"); }, [byId, curate]);
  const onReject = useCallback((id: string) => { const m = byId.get(id); if (m) curate(m, "reject"); }, [byId, curate]);
  const onApproveAll = useCallback((ids: string[]) => { if (ids.length) curateBulk(ids, "accept"); }, [curateBulk]);
  // Reject-all operates on the CURRENT mappings (incl. suggested), not just `active`.
  const onRejectAll = useCallback((ids: string[]) => { if (ids.length) curateBulk(ids, "reject"); }, [curateBulk]);

  // Field-id → node-id, so a mapping's edges attach to whichever box holds each
  // field (fields are globally unique across all source/target tables).
  const srcNodeByField = useMemo(() => {
    const m = new Map<string, string>();
    for (const a of sourceAssets) for (const f of a.fields) m.set(f.id, `source:${a.id}`);
    return m;
  }, [sourceAssets]);
  // field id → target asset id, so a mapping routes to ITS table's transform /
  // validation / target box (fields are globally unique across all tables).
  const targetAssetByField = useMemo(() => {
    const m = new Map<string, string>();
    for (const a of targetAssets) for (const f of a.fields) m.set(f.id, a.id);
    return m;
  }, [targetAssets]);

  // Derive the visible "view" from the column searches. Searching a column
  // focuses the canvas: only its mapping(s), transform step(s), and the opposite
  // card's connected column(s) stay visible. Whole mappings are kept intact so
  // no edge is ever left dangling (e.g. a concat keeps both source columns).
  const view = useMemo(() => {
    const sq = srcQuery.trim().toLowerCase();
    const tq = tgtQuery.trim().toLowerCase();
    const filtering = sq !== "" || tq !== "";
    const matchS = (n: string) => sq === "" || n.toLowerCase().includes(sq);
    const matchT = (n: string) => tq === "" || n.toLowerCase().includes(tq);

    const focused = active.filter(
      (m) =>
        (sq === "" || (m.provenance.source_field_names ?? []).some((n) => n.toLowerCase().includes(sq))) &&
        (tq === "" || m.target_field_name.toLowerCase().includes(tq)),
    );
    const shown = filtering ? focused : active;
    const focusedSrcIds = new Set(focused.flatMap((m) => m.source_field_ids));
    const focusedTgtIds = new Set(focused.map((m) => m.target_field_id));

    // Per-asset visible fields (respects the source/target column search).
    const srcFieldsByAsset = new Map<string, Asset["fields"]>();
    for (const a of sourceAssets) {
      srcFieldsByAsset.set(a.id, !filtering ? a.fields : a.fields.filter((f) => focusedSrcIds.has(f.id) || (sq !== "" && matchS(f.name))));
    }
    const tgtFieldsByAsset = new Map<string, Asset["fields"]>();
    for (const a of targetAssets) {
      tgtFieldsByAsset.set(a.id, !filtering ? a.fields : a.fields.filter((f) => focusedTgtIds.has(f.id) || (tq !== "" && matchT(f.name))));
    }

    return { shown, srcFieldsByAsset, tgtFieldsByAsset };
  }, [active, srcQuery, tgtQuery, sourceAssets, targetAssets]);

  // Rebuild nodes on data/filter/selection change, PRESERVING dragged positions.
  // Layout: sources stacked on the left, targets on the right; between them, ONE
  // transform block (and optional validation block) PER TARGET TABLE, vertically
  // aligned with that table's box so each dimension's derivation reads left→right.
  useEffect(() => {
    if (!sourceAssets.length || !targetAssets.length) {
      setNodes([]);
      return;
    }
    const ROW_H = 360;          // vertical spacing between stacked boxes per side
    const anyVal = hasValidations;
    const targetX = anyVal ? 1180 : 900;

    // Group the in-view mappings + validation rows by their target TABLE.
    const stepsByTarget = new Map<string, Step[]>();
    const valRowsByTarget = new Map<string, ValRow[]>();
    for (const m of view.shown) {
      const tid = targetAssetByField.get(m.target_field_id);
      if (!tid) continue;
      (stepsByTarget.get(tid) ?? stepsByTarget.set(tid, []).get(tid)!).push({ id: m.id, label: transformSummary(m), state: m.state, confidence: m.confidence, optimized: (m.provenance as { optimized?: boolean })?.optimized });
      const vs = valsByFieldId.get(m.target_field_id);  // scoped to THIS field's table
      if (vs && vs.length) {
        const worst = ["critical", "high", "medium", "low"].find((s) => vs.some((v) => v.severity === s)) ?? "medium";
        const label = vs.length === 1 ? vs[0].name : `${m.target_field_name} (${vs.length} checks)`;
        (valRowsByTarget.get(tid) ?? valRowsByTarget.set(tid, []).get(tid)!).push({ targetFieldId: m.target_field_id, column: m.target_field_name, count: vs.length, severity: worst, label });
      }
    }
    // Unmapped target columns per table (no active mapping) — for the manual-map list.
    const mappedFieldIds = new Set(active.map((m) => m.target_field_id));
    const unmappedByTarget = new Map<string, string[]>();
    for (const a of targetAssets) {
      unmappedByTarget.set(a.id, a.fields.filter((f) => !mappedFieldIds.has(f.id)).map((f) => f.name));
    }

    setNodes((prev) => {
      const pos = Object.fromEntries(prev.map((n) => [n.id, n.position]));
      const built: Node[] = [];
      sourceAssets.forEach((a, i) => {
        built.push({
          id: `source:${a.id}`,
          type: "schema",
          position: pos[`source:${a.id}`] ?? { x: 0, y: i * ROW_H },
          data: { label: a.name, sublabel: a.locator ?? a.object_type, role: "source", fields: view.srcFieldsByAsset.get(a.id) ?? [], total: a.fields.length, query: srcQuery, onQuery: setSrcQuery },
        });
      });
      targetAssets.forEach((a, i) => {
        const y = i * ROW_H;
        built.push({
          id: `target:${a.id}`,
          type: "schema",
          position: pos[`target:${a.id}`] ?? { x: targetX, y },
          data: {
            label: a.name, sublabel: a.object_type, role: "target",
            fields: view.tgtFieldsByAsset.get(a.id) ?? [], total: a.fields.length, query: tgtQuery, onQuery: setTgtQuery,
            unmappedIds: new Set(a.fields.filter((f) => !mappedFieldIds.has(f.id)).map((f) => f.id)),
            keyIds: new Set(a.fields.filter((f) => f.semantic_type === "key").map((f) => f.id)),
          },
        });
        // One transform block per target table (only if it has steps or unmapped cols).
        const steps = stepsByTarget.get(a.id) ?? [];
        const unmapped = unmappedByTarget.get(a.id) ?? [];
        if (steps.length || unmapped.length) {
          built.push({
            id: `transform:${a.id}`,
            type: "transform",
            position: pos[`transform:${a.id}`] ?? { x: 480, y: y + 20 },
            data: {
              title: a.name, steps, unmapped, selectedId, busy: !!busy,
              onSelect: setSelectedId, onAccept, onReject, onApproveAll, onRejectAll,
            },
          });
        }
        // One validation block per target table that has DQ checks.
        const valRows = valRowsByTarget.get(a.id) ?? [];
        if (anyVal && valRows.length) {
          built.push({
            id: `validation:${a.id}`,
            type: "validation",
            position: pos[`validation:${a.id}`] ?? { x: 840, y: y + 40 },
            data: { title: a.name, rows: valRows, selected: selectedValCol, onSelect: setSelectedValCol },
          });
        }
      });
      return built;
    });
  }, [sourceAssets, targetAssets, active, view, hasValidations, valsByFieldId, targetAssetByField, selectedId, selectedValCol, busy, srcQuery, tgtQuery, onAccept, onReject, onApproveAll, onRejectAll, setNodes]);

  // Edges follow the filtered view: source col → its step → its target col.
  // With multiple boxes, each endpoint resolves to the box that owns the field.
  useEffect(() => {
    if (!spec) {
      setEdges([]);
      return;
    }
    const out: Edge[] = [];
    // AI-proposed join keys between source tables (dotted amber, labeled).
    for (const [i, j] of (spec.joins ?? []).entries()) {
      const ln = j.left_id ? srcNodeByField.get(j.left_id) : undefined;
      const rn = j.right_id ? srcNodeByField.get(j.right_id) : undefined;
      if (!ln || !rn || !j.left_id || !j.right_id) continue;
      out.push({
        id: `join:${i}`,
        source: ln, sourceHandle: j.left_id, target: rn, targetHandle: j.right_id,
        animated: false, label: `join${j.confidence != null ? ` · ${Math.round(j.confidence * 100)}%` : ""}`,
        labelStyle: { fontSize: 9, fill: "#b45309" }, labelBgStyle: { fill: "#fffbeb" },
        style: { stroke: "#d97706", strokeWidth: 1.5, strokeDasharray: "2 3" },
        markerEnd: { type: MarkerType.ArrowClosed, color: "#d97706" },
      });
    }
    for (const m of view.shown) {
      const color = m.state === "suggested" ? confColor(m.confidence) : stateColor(m.state);
      const dashed = m.state === "suggested";
      const base = { animated: dashed, style: { stroke: color, strokeWidth: 1.5, strokeDasharray: dashed ? "6 4" : undefined }, markerEnd: { type: MarkerType.ArrowClosed, color } };
      const tgtAssetId = targetAssetByField.get(m.target_field_id);
      if (!tgtAssetId) continue;
      const tgtNode = `target:${tgtAssetId}`;
      const xfNode = `transform:${tgtAssetId}`;   // this target table's own transform block
      const valNode = `validation:${tgtAssetId}`;
      const hasVal = valsByFieldId.has(m.target_field_id);
      if (hasTransforms) {
        for (const sid of m.source_field_ids) {
          const srcNode = srcNodeByField.get(sid);
          if (!srcNode) continue;
          out.push({ id: `${m.id}:in:${sid}`, source: srcNode, sourceHandle: sid, target: xfNode, targetHandle: `in-${m.id}`, ...base });
        }
        if (hasVal) {
          // transform → validation(col) → target, all within this target table's blocks
          out.push({ id: `${m.id}:tv`, source: xfNode, sourceHandle: `out-${m.id}`, target: valNode, targetHandle: `vin-${m.target_field_id}`, ...base });
          out.push({ id: `${m.id}:vt`, source: valNode, sourceHandle: `vout-${m.target_field_id}`, target: tgtNode, targetHandle: m.target_field_id, ...base });
        } else {
          out.push({ id: `${m.id}:out`, source: xfNode, sourceHandle: `out-${m.id}`, target: tgtNode, targetHandle: m.target_field_id, ...base });
        }
      } else {
        for (const sid of m.source_field_ids) {
          const srcNode = srcNodeByField.get(sid);
          if (!srcNode) continue;
          out.push({ id: `${m.id}:${sid}`, source: srcNode, sourceHandle: sid, target: tgtNode, targetHandle: m.target_field_id, ...base });
        }
      }
    }
    setEdges(out);
  }, [spec, view, hasTransforms, valsByFieldId, srcNodeByField, targetAssetByField, setEdges]);

  const selected = selectedId ? byId.get(selectedId) : undefined;
  // selectedValCol now holds a target FIELD id (unique per table), not a bare column name.
  const selectedVals = selectedValCol ? valsByFieldId.get(selectedValCol) : undefined;
  const selectedValField = useMemo(() => {
    if (!selectedValCol) return undefined;
    for (const a of targetAssets) {
      const f = a.fields.find((x) => x.id === selectedValCol);
      if (f) return { column: f.name, dataset: a.name, fieldId: f.id };
    }
    return undefined;
  }, [selectedValCol, targetAssets]);

  return (
    <div className="relative h-full w-full">
      <ReactFlow nodes={nodes} edges={edges} onNodesChange={onNodesChange} onEdgesChange={onEdgesChange} nodeTypes={nodeTypes} fitView minZoom={0.3} proOptions={{ hideAttribution: true }}>
        <Background color="#e5e7eb" gap={16} />
        <Controls showInteractive={false} />
      </ReactFlow>
      {selected && <TransformDetail m={selected} onClose={() => setSelectedId(null)} onAccept={onAccept} onReject={onReject} busy={!!busy}
        onRegenerate={(fb) => regenerateThenPrompt(selected.id, fb)} onUseLibrary={(code) => useLibraryThenPrompt(selected.id, code)} />}
      {selectedVals && selectedValField && <ValidationDetail column={selectedValField.column} dataset={selectedValField.dataset} vals={selectedVals} onClose={() => setSelectedValCol(null)} busy={!!busy}
        onRegenerate={(vid, fb) => regenValThenPrompt(vid, fb, selectedValField.column, selectedValField.dataset)}
        onUseRule={(vid, code) => useRuleThenPrompt(vid, code, selectedValField.column, selectedValField.dataset)}
        onSetDqAction={(vid, a) => setValidationDqAction(vid, a)} />}
      {propagate && (
        <PropagatePrompt
          kind={propagate.kind} field={propagate.field} candidates={propagate.candidates} busy={!!busy}
          onCancel={() => setPropagate(null)}
          onApply={async (tables) => {
            if (propagate.kind === "transform") await propagateTransformation(propagate.mappingId, tables);
            else await propagateValidation(propagate.validationId, tables);
            setPropagate(null);
          }}
        />
      )}
    </div>
  );
}

// After a transform/validation change on a field present in multiple target tables,
// offer to apply the same change to that field in the other tables (all checked default).
function PropagatePrompt({ kind, field, candidates, busy, onCancel, onApply }: {
  kind: "transform" | "validation"; field: string; candidates: string[]; busy: boolean;
  onCancel: () => void; onApply: (tables: string[]) => void;
}) {
  const [checked, setChecked] = useState<Set<string>>(new Set(candidates));
  const toggle = (t: string) => setChecked((s) => { const n = new Set(s); n.has(t) ? n.delete(t) : n.add(t); return n; });
  const sel = candidates.filter((t) => checked.has(t));
  return (
    <div className="absolute inset-0 grid place-items-center bg-black/20 z-20 nodrag" onClick={onCancel}>
      <div className="w-80 bg-white rounded-xl border border-gray-200 shadow-xl p-4" onClick={(e) => e.stopPropagation()}>
        <h4 className="text-sm font-semibold text-gray-800 mb-1">Apply to other tables?</h4>
        <p className="text-[11px] text-gray-500 mb-2">
          <span className="font-medium">{field}</span> also exists in these target tables. Apply the same {kind === "transform" ? "transformation" : "check"} there too?
        </p>
        <ul className="space-y-1 mb-3 max-h-52 overflow-y-auto">
          {candidates.map((t) => (
            <li key={t}>
              <label className="flex items-center gap-2 text-xs text-gray-700 cursor-pointer">
                <input type="checkbox" checked={checked.has(t)} onChange={() => toggle(t)} className="accent-brand" />
                {t}
              </label>
            </li>
          ))}
        </ul>
        <div className="flex gap-2">
          <button onClick={() => onApply(sel)} disabled={busy || !sel.length}
            className="flex-1 text-xs px-2 py-1.5 rounded bg-brand hover:bg-brand-hover text-white disabled:opacity-40">
            Apply to {sel.length}
          </button>
          <button onClick={onCancel} className="text-xs px-3 py-1.5 rounded border border-gray-300 text-gray-600">Skip</button>
        </div>
      </div>
    </div>
  );
}

function ValidationDetail({ column, dataset, vals, onClose, busy, onRegenerate, onUseRule, onSetDqAction }: {
  column: string; dataset: string; vals: Validation[]; onClose: () => void; busy: boolean;
  onRegenerate: (vid: string, feedback: string) => void; onUseRule: (vid: string, code: string) => void;
  onSetDqAction: (vid: string, action: "warn" | "fail") => void;
}) {
  const { addValidationCheck, addValidationFromRule } = useStore();
  const [openId, setOpenId] = useState<string | null>(null);
  const [mode, setMode] = useState<null | "regen" | "library">(null);
  const [feedback, setFeedback] = useState("");
  // "Add check" for this field: AI-generate from a description, or pick a library rule.
  const [addMode, setAddMode] = useState<null | "ai" | "library">(null);
  const [addDesc, setAddDesc] = useState("");
  const startRegen = (id: string) => { setOpenId(id); setMode("regen"); setFeedback(""); };
  const startLib = (id: string) => { setOpenId(id); setMode("library"); };
  const reset = () => { setOpenId(null); setMode(null); setFeedback(""); };
  const resetAdd = () => { setAddMode(null); setAddDesc(""); };
  return (
    <div className="absolute top-3 right-3 w-80 bg-white rounded-xl border border-gray-200 shadow-lg p-4 z-10 nodrag max-h-[calc(100%-24px)] overflow-y-auto">
      <div className="flex items-start justify-between mb-2">
        <h4 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-rose-600" /> {column}</h4>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
      </div>
      {/* Table scope, so it's unambiguous which table's checks these are. */}
      <div className="text-[11px] text-gray-400 mb-1">on <span className="font-medium text-gray-600">{dataset}</span></div>
      <div className="text-[11px] text-gray-500 mb-2">{vals.length} data-quality check{vals.length > 1 ? "s" : ""} after transformation</div>
      <ul className="space-y-2">
        {vals.map((v) => (
          <li key={v.id} className="border border-gray-100 rounded-lg p-2">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-medium text-gray-800 truncate flex-1">{v.name}</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded capitalize" style={{ background: `${SEV_COLOR[v.severity] ?? "#9ca3af"}22`, color: SEV_COLOR[v.severity] ?? "#6b7280" }}>{v.severity}</span>
            </div>
            <div className="text-[10px] text-gray-400 capitalize mb-1">{(v.rule_type ?? "").replace("_", " ")}</div>
            {/* Pipeline DQ routing: fail => quarantine the row, warn => keep in target + log. */}
            <div className="flex items-center gap-1.5 mb-1">
              <span className="text-[10px] text-gray-400">On failure:</span>
              <div className="inline-flex rounded border border-gray-200 overflow-hidden">
                {(["warn", "fail"] as const).map((a) => {
                  const on = (v.dq_action ?? "warn") === a;
                  return (
                    <button key={a} onClick={() => onSetDqAction(v.id, a)} disabled={busy || on}
                      title={a === "fail" ? "Quarantine violating rows (keep out of target)" : "Keep in target, just log the violation"}
                      className={`text-[10px] px-1.5 py-0.5 capitalize ${on ? (a === "fail" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700") : "bg-white text-gray-500 hover:bg-gray-50"}`}>
                      {a === "fail" ? "Fail · quarantine" : "Warn · log"}
                    </button>
                  );
                })}
              </div>
            </div>
            {v.logic && <div className="font-mono text-[10px] text-gray-700 bg-gray-50 border border-gray-100 rounded p-1.5 break-all">{v.logic}</div>}
            {openId === v.id && mode === "regen" ? (
              <div className="mt-2">
                <textarea value={feedback} onChange={(e) => setFeedback(e.target.value)} rows={2} placeholder="e.g. also allow NULL for optional rows"
                  className="w-full border border-gray-300 rounded-lg px-2 py-1 text-[11px] focus:outline-none focus:ring-2 focus:ring-brand/30" />
                <div className="flex gap-2 mt-1.5">
                  <button onClick={() => { onRegenerate(v.id, feedback); reset(); }} disabled={busy || !feedback.trim()} className="flex-1 text-[11px] px-2 py-1 rounded bg-brand hover:bg-brand-hover text-white disabled:opacity-40 flex items-center justify-center gap-1"><Wand2 className="w-3 h-3" /> Regenerate</button>
                  <button onClick={reset} className="text-[11px] px-2 py-1 rounded border border-gray-300 text-gray-600">Cancel</button>
                </div>
              </div>
            ) : openId === v.id && mode === "library" ? (
              <LibraryPicker kind="rule" busy={busy} onPick={(code) => { onUseRule(v.id, code); reset(); }} onCancel={reset} />
            ) : (
              <div className="flex gap-2 mt-1.5">
                <button onClick={() => startRegen(v.id)} disabled={busy} className="text-[11px] px-2 py-1 rounded border border-gray-300 text-gray-700 hover:border-brand/40 hover:bg-brand-soft/30 disabled:opacity-40 flex items-center gap-1"><Wand2 className="w-3 h-3 text-brand" /> Regenerate</button>
                <button onClick={() => startLib(v.id)} disabled={busy} className="text-[11px] px-2 py-1 rounded border border-gray-300 text-gray-700 hover:border-brand/40 hover:bg-brand-soft/30 disabled:opacity-40 flex items-center gap-1"><Library className="w-3 h-3 text-brand" /> From library</button>
              </div>
            )}
          </li>
        ))}
      </ul>

      {/* Add another check to THIS field (AI-generated or an existing library rule). */}
      <div className="mt-3 border-t border-gray-100 pt-2">
        {addMode === "ai" ? (
          <div>
            <div className="text-[11px] font-medium text-gray-600 mb-1">Describe the check to add</div>
            <textarea value={addDesc} onChange={(e) => setAddDesc(e.target.value)} rows={2}
              placeholder={`e.g. ${column} must be non-negative`}
              className="w-full border border-gray-300 rounded-lg px-2 py-1 text-[11px] focus:outline-none focus:ring-2 focus:ring-brand/30" />
            <div className="flex gap-2 mt-1.5">
              <button onClick={() => { addValidationCheck(dataset, column, addDesc); resetAdd(); }} disabled={busy || !addDesc.trim()}
                className="flex-1 text-[11px] px-2 py-1 rounded bg-brand hover:bg-brand-hover text-white disabled:opacity-40 flex items-center justify-center gap-1"><Wand2 className="w-3 h-3" /> Generate check</button>
              <button onClick={resetAdd} className="text-[11px] px-2 py-1 rounded border border-gray-300 text-gray-600">Cancel</button>
            </div>
          </div>
        ) : addMode === "library" ? (
          <LibraryPicker kind="rule" busy={busy} onPick={(code) => { addValidationFromRule(dataset, column, code); resetAdd(); }} onCancel={resetAdd} />
        ) : (
          <div className="flex gap-2">
            <button onClick={() => setAddMode("ai")} disabled={busy} className="flex-1 text-[11px] px-2 py-1 rounded border border-dashed border-gray-300 text-gray-600 hover:border-brand/40 hover:bg-brand-soft/30 disabled:opacity-40 flex items-center justify-center gap-1"><Wand2 className="w-3 h-3 text-brand" /> Add check (AI)</button>
            <button onClick={() => setAddMode("library")} disabled={busy} className="flex-1 text-[11px] px-2 py-1 rounded border border-dashed border-gray-300 text-gray-600 hover:border-brand/40 hover:bg-brand-soft/30 disabled:opacity-40 flex items-center justify-center gap-1"><Library className="w-3 h-3 text-brand" /> Add from library</button>
          </div>
        )}
      </div>
    </div>
  );
}

function TransformDetail({ m, onClose, onAccept, onReject, busy, onRegenerate, onUseLibrary }: {
  m: Mapping; onClose: () => void; onAccept: (id: string) => void; onReject: (id: string) => void; busy: boolean;
  onRegenerate: (feedback: string) => void; onUseLibrary: (code: string) => void;
}) {
  const t = m.transform_spec;
  const pct = m.confidence == null ? null : Math.round(m.confidence <= 1 ? m.confidence * 100 : m.confidence);
  const approved = m.state === "accepted" || m.state === "edited";
  const [mode, setMode] = useState<null | "regen" | "library">(null);
  const [feedback, setFeedback] = useState("");
  const reusedName = (m.provenance as { reused_transformation_name?: string }).reused_transformation_name;
  return (
    <div className="absolute top-3 right-3 w-80 bg-white rounded-xl border border-gray-200 shadow-lg p-4 z-10 nodrag max-h-[calc(100%-24px)] overflow-y-auto">
      <div className="flex items-start justify-between mb-2">
        <h4 className="text-sm font-semibold text-gray-800">{m.target_field_name}</h4>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
      </div>
      <dl className="text-xs space-y-1.5">
        <Row k="Transform" v={t?.op ?? m.transform_kind ?? "—"} />
        <Row k="Source field(s)" v={(m.provenance.source_field_names ?? []).join(", ") || "—"} />
        <Row k="Target field" v={m.target_field_name} />
        {t?.to && <Row k="Cast to" v={t.to} />}
        {t?.expr && (
          <div>
            <dt className="text-gray-500 mb-1">Expression</dt>
            <dd className="font-mono text-[10px] text-gray-700 bg-gray-50 border border-gray-100 rounded p-1.5 break-all whitespace-pre-wrap">{t.expr}</dd>
          </div>
        )}
        <div className="flex justify-between items-center">
          <dt className="text-gray-500">Confidence</dt>
          <dd className="flex items-center gap-2">
            <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden"><div className="h-full rounded-full" style={{ width: `${pct ?? 0}%`, background: confColor(m.confidence) }} /></div>
            <span className="text-gray-700 w-8 text-right">{pct != null ? `${pct}%` : "—"}</span>
          </dd>
        </div>
        <Row k="Origin" v={m.provenance.origin} />
        <Row k="Status" v={m.state} />
      </dl>
      {reusedName && <p className="text-[11px] text-blue-700 bg-blue-50 border border-blue-100 rounded px-2 py-1 mt-2">↻ Reused library transformation: {reusedName}</p>}
      {m.provenance.rationale && <p className="text-[11px] text-gray-500 mt-2 italic">{m.provenance.rationale}</p>}

      {/* Feedback loops */}
      {mode === "regen" ? (
        <div className="mt-3 border-t border-gray-100 pt-3">
          <div className="text-xs font-medium text-gray-700 mb-1">Describe the change</div>
          <textarea value={feedback} onChange={(e) => setFeedback(e.target.value)} rows={2} placeholder="e.g. also trim whitespace and coalesce with the journal account id"
            className="w-full border border-gray-300 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand/30" />
          <div className="flex gap-2 mt-2">
            <button onClick={() => { onRegenerate(feedback); setMode(null); setFeedback(""); }} disabled={busy || !feedback.trim()} className="flex-1 text-xs px-2 py-1.5 rounded bg-brand hover:bg-brand-hover text-white disabled:opacity-40 flex items-center justify-center gap-1"><Wand2 className="w-3 h-3" /> Regenerate</button>
            <button onClick={() => setMode(null)} disabled={busy} className="text-xs px-2 py-1.5 rounded border border-gray-300 text-gray-600 hover:bg-gray-50">Cancel</button>
          </div>
        </div>
      ) : mode === "library" ? (
        <LibraryPicker kind="transformation" busy={busy} onPick={(code) => { onUseLibrary(code); setMode(null); }} onCancel={() => setMode(null)} />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-2 mt-3">
            <button onClick={() => setMode("regen")} disabled={busy} className="text-xs px-2 py-1.5 rounded border border-gray-300 text-gray-700 hover:border-brand/40 hover:bg-brand-soft/30 disabled:opacity-40 flex items-center justify-center gap-1"><Wand2 className="w-3 h-3 text-brand" /> Regenerate</button>
            <button onClick={() => setMode("library")} disabled={busy} className="text-xs px-2 py-1.5 rounded border border-gray-300 text-gray-700 hover:border-brand/40 hover:bg-brand-soft/30 disabled:opacity-40 flex items-center justify-center gap-1"><Library className="w-3 h-3 text-brand" /> From library</button>
          </div>
          {!approved ? (
            <div className="flex gap-2 mt-2">
              <button onClick={() => onAccept(m.id)} disabled={busy} className="flex-1 text-xs px-2 py-1.5 rounded bg-green-600 hover:bg-green-500 text-white disabled:opacity-40 flex items-center justify-center gap-1"><Check className="w-3 h-3" /> Approve</button>
              <button onClick={() => onReject(m.id)} disabled={busy} className="flex-1 text-xs px-2 py-1.5 rounded bg-white border border-gray-300 text-gray-600 hover:bg-gray-50 disabled:opacity-40 flex items-center justify-center gap-1"><X className="w-3 h-3" /> Reject</button>
            </div>
          ) : (
            <div className="mt-2 text-xs text-green-600 flex items-center gap-1"><Check className="w-3.5 h-3.5" /> Approved — included in this mapping</div>
          )}
        </>
      )}
    </div>
  );
}

// Searchable picker over the PUBLISHED library (transformations or Rule Library rules).
function LibraryPicker({ kind, busy, onPick, onCancel }: { kind: "transformation" | "rule"; busy: boolean; onPick: (code: string) => void; onCancel: () => void }) {
  const [items, setItems] = useState<{ code: string; name: string; logic?: string | null }[] | null>(null);
  const [q, setQ] = useState("");
  useEffect(() => {
    const PUB = new Set(["Published", "Approved", "Active", "Live"]);
    if (kind === "transformation") {
      api.listTransformations().then((r) => setItems(r.filter((x) => PUB.has(x.status)).map((x: Transformation) => ({ code: x.code, name: x.name, logic: x.logic_expr || x.logic_sql }))));
    } else {
      api.listRules().then((r) => setItems(r.filter((x) => PUB.has(x.status)).map((x) => ({ code: x.code, name: x.name, logic: x.logic_sql || x.logic_preview }))));
    }
  }, [kind]);
  const shown = (items ?? []).filter((x) => !q.trim() || `${x.name} ${x.code} ${x.logic ?? ""}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="mt-3 border-t border-gray-100 pt-3">
      <div className="flex items-center justify-between mb-1.5">
        <div className="text-xs font-medium text-gray-700">Choose from library</div>
        <button onClick={onCancel} className="text-[11px] text-gray-400 hover:text-gray-600">Cancel</button>
      </div>
      <div className="relative mb-2">
        <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2 top-1/2 -translate-y-1/2" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search…" className="w-full border border-gray-200 rounded-lg pl-7 pr-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand/30" />
      </div>
      {items === null ? (
        <div className="text-[11px] text-gray-400 py-3 text-center">Loading library…</div>
      ) : (
        <ul className="space-y-1 max-h-52 overflow-y-auto">
          {shown.map((x) => (
            <li key={x.code}>
              <button onClick={() => onPick(x.code)} disabled={busy} className="w-full text-left border border-gray-200 rounded-lg p-2 hover:border-brand/40 hover:bg-brand-soft/20 disabled:opacity-40">
                <div className="text-xs font-medium text-gray-800 truncate">{x.name}</div>
                {x.logic && <code className="text-[10px] text-gray-400 font-mono line-clamp-1 break-all">{x.logic}</code>}
              </button>
            </li>
          ))}
          {shown.length === 0 && <li className="text-[11px] text-gray-400 py-3 text-center">No matches.</li>}
        </ul>
      )}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between gap-3"><dt className="text-gray-500 shrink-0">{k}</dt><dd className="text-gray-800 text-right truncate">{v}</dd></div>;
}

export function transformSummary(m: Mapping): string {
  const t = m.transform_spec;
  if (!t?.op) return m.transform_kind ?? m.target_field_name;
  const src = m.provenance.source_field_names?.join(", ") ?? "";
  switch (t.op) {
    case "rename":
      return `Rename → ${m.target_field_name}`;
    case "cast":
      return `Cast ${src} → ${t.to}`;
    case "concat":
      return `Concat ${(t.sources ?? []).join(" + ")}`;
    case "date_format":
      return `Date format ${src}`;
    case "expr":
      return t.expr ? `Custom: ${t.expr}` : `Custom → ${m.target_field_name}`;
    default:
      return `${t.op} ${src}`;
  }
}
