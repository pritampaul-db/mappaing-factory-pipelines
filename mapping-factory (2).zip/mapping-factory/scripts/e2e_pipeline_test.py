"""End-to-end test of the Deploy-as-Pipeline SDP execution path.

Bypasses the GitHub hop (no PAT needed): writes the generated pipeline source
straight to a workspace file, creates a real serverless SDP pipeline pointing at
it, seeds dummy source tables, runs the pipeline, waits, and verifies the target
table materialized with rows + a DQ expectation. Cleans up after itself.

Run:  python scripts/e2e_pipeline_test.py
"""
from __future__ import annotations

import sys
import time

from databricks.sdk.service import pipelines as pl

from server import config, dab_template

from server import pipeline_config, pipeline_config_store, pipeline_deploy

# Distinct catalog+schema for source vs. target (proves both split through). The SP can
# only CREATE in the default catalog, so both catalogs are that one here — but the values
# still flow through build_mapping_config / build_bundle_files exactly as distinct inputs.
SRC_CATALOG = config.UC_CATALOG
SRC_SCHEMA = "mf_e2e_src"    # sources read FROM here
TGT_CATALOG = config.UC_CATALOG
TGT_SCHEMA = "mf_e2e_tgt"    # targets written TO here
CATALOG = TGT_CATALOG        # pipeline's own catalog = target catalog
SCHEMA = TGT_SCHEMA          # pipeline's own schema  = target schema
WH = config.WAREHOUSE_ID
BASE = "/Workspace/Shared/mapping-factory/e2e-test"
PIPELINE = "mf_e2e_test_pipeline"

# A representative published SPEC (not a hand-written config) so the test drives the REAL
# product code path: build_mapping_config(source_catalog, source_schema) → build_bundle_files.
# Source assets have NO locator, so they get qualified under SRC_CATALOG.SRC_SCHEMA.
SPEC = {
    "name": "E2E Financial Account",
    "sources": [
        {"name": "e2e_src_accounts", "locator": "",
         "fields": [{"name": "acct_id", "datatype": "string"}, {"name": "name", "datatype": "string"},
                    {"name": "raw_status", "datatype": "string"}]},
        {"name": "e2e_src_balances", "locator": "",
         "fields": [{"name": "acct_id", "datatype": "string"}, {"name": "bal_amt", "datatype": "double"}]},
    ],
    "targets": [{"name": "e2e_dim_financial_account",
                 "fields": [{"id": 1, "name": "account_id"}, {"id": 2, "name": "account_name"},
                            {"id": 3, "name": "status"}, {"id": 4, "name": "balance"}]}],
    "joins": [{"left": "e2e_src_accounts.acct_id", "right": "e2e_src_balances.acct_id"}],
    "mappings": [
        {"target_field_id": 1, "target_field_name": "account_id", "state": "approved",
         "transform_kind": "sql", "transform_sql": "`e2e_src_accounts`.`acct_id`",
         "provenance": {"source_tables": ["e2e_src_accounts"]}},
        {"target_field_id": 2, "target_field_name": "account_name", "state": "approved",
         "transform_kind": "sql", "transform_sql": "upper(`e2e_src_accounts`.`name`)",
         "provenance": {"source_tables": ["e2e_src_accounts"]}},
        # `case` op with a pre-formed `expr` (regression guard for UNRESOLVED_COLUMN:
        # this shape used to raise in the compiler → column silently dropped).
        {"target_field_id": 3, "target_field_name": "status", "state": "approved",
         "transform_kind": "spec",
         "transform_spec": {"op": "case",
                            "expr": "CASE WHEN `e2e_src_accounts`.`raw_status` = 'active' THEN 'ACTIVE' ELSE 'INACTIVE' END"},
         "provenance": {"source_tables": ["e2e_src_accounts"]}},
        {"target_field_id": 4, "target_field_name": "balance", "state": "approved",
         "transform_kind": "sql", "transform_sql": "coalesce(`e2e_src_balances`.`bal_amt`, 0)",
         "provenance": {"source_tables": ["e2e_src_balances"]}},
    ],
}
VALIDATIONS = [
    # FAIL rule → violating rows go to <target>_quarantine (kept out of target).
    {"code": "acct_id_not_null", "column_name": "account_id", "logic": "account_id IS NOT NULL",
     "dataset": "e2e_dim_financial_account", "rule_type": "completeness", "dq_action": "fail", "severity": "high"},
    # WARN rule → violating rows still land in the target, only logged in audit.
    {"code": "status_known", "column_name": "status", "logic": "status IN ('ACTIVE','INACTIVE')",
     "dataset": "e2e_dim_financial_account", "rule_type": "validity", "dq_action": "warn", "severity": "low"},
]


def _sql(w, stmt: str):
    r = w.statement_execution.execute_statement(warehouse_id=WH, statement=stmt, wait_timeout="50s")
    st = r.status.state.value if r.status and r.status.state else "?"
    if st not in ("SUCCEEDED",):
        # poll if still running
        sid = r.statement_id
        for _ in range(30):
            r = w.statement_execution.get_statement(sid)
            st = r.status.state.value if r.status and r.status.state else "?"
            if st in ("SUCCEEDED", "FAILED", "CANCELED"):
                break
            time.sleep(2)
    if st != "SUCCEEDED":
        raise RuntimeError(f"SQL failed ({st}): {stmt[:80]} :: {getattr(r.status, 'error', None)}")
    return r


def main() -> int:
    w = config.get_sp_client()
    print(f"catalog={CATALOG} schema={SCHEMA} warehouse={WH}")

    # 1) build the bundle THROUGH THE REAL PRODUCT CODE
    print("→ building config + source via product code…")
    _sql(w, f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{TGT_SCHEMA}")
    cfg = pipeline_config.build_mapping_config(SPEC, VALIDATIONS, catalog=SRC_CATALOG, source_schema=SRC_SCHEMA)
    # sanity: sources must be qualified under the SOURCE catalog/schema
    for nm, meta in cfg["inputs"].items():
        assert meta.get("table") == f"{SRC_CATALOG}.{SRC_SCHEMA}.{nm}", f"bad source table for {nm}: {meta.get('table')}"
    # regression guard: the `case`-with-`expr` column must NOT be dropped by the compiler
    tgt_cols = [c["target_field"] for c in cfg["targets"][0]["columns"]]
    assert "status" in tgt_cols, f"CASE column dropped! target cols = {tgt_cols}"
    print(f"  target columns: {tgt_cols}")

    full_config = {**cfg, "catalog": TGT_CATALOG, "schema": TGT_SCHEMA,
                   "source_catalog": SRC_CATALOG, "source_schema": SRC_SCHEMA,
                   "table_type": "materialized_view", "spec_name": SPEC["name"], "pipeline_name": PIPELINE}

    # 2) SEED dummy data + inject a NULL-account_id row so the FAIL rule quarantines >=1 row.
    print(f"→ seeding dummy sources into {SRC_SCHEMA}…")
    seed = pipeline_deploy.seed_dummy_sources(SPEC, cfg["inputs"])
    print(f"  seeded: {seed['seeded']}")
    assert seed["seeded"], "nothing seeded"
    _sql(w, f"INSERT INTO {SRC_CATALOG}.{SRC_SCHEMA}.e2e_src_accounts (acct_id, name, raw_status) "
            "VALUES (NULL, 'ghost', 'weird_status')")  # -> account_id NULL (FAIL) + status INACTIVE-not-in-set? (status maps to INACTIVE, passes warn)

    # 3) WRITE THE CONFIG TO THE UC TABLE (not inlined in code) — the product path.
    print("→ writing config to mf_pipeline_config…")
    stored = pipeline_config_store.write_config(full_config, catalog=TGT_CATALOG, schema=TGT_SCHEMA,
                                                pipeline_name=PIPELINE)
    print(f"  {stored}")

    # 4) upload the GENERIC code (identical for every mapping — takes no config arg).
    src = dab_template.pipeline_source()
    assert "__MF_CONFIG_JSON__" not in src and "mf_pipeline_config" in src, "code must read config from table"
    import base64
    from databricks.sdk.service import workspace as ws
    w.workspace.mkdirs(f"{BASE}/src")
    w.workspace.import_(path=f"{BASE}/src/mapping_pipeline.py", format=ws.ImportFormat.AUTO,
                        language=ws.Language.PYTHON, content=base64.b64encode(src.encode()).decode(), overwrite=True)

    # 5) create (or reuse) the pipeline with config-locating conf.
    print("→ creating pipeline…")
    existing = None
    for p in w.pipelines.list_pipelines():
        if p.name == PIPELINE:
            existing = p.pipeline_id
            break
    lib = [pl.PipelineLibrary(file=pl.FileLibrary(path=f"{BASE}/src/mapping_pipeline.py"))]
    cfgmap = {"mf.catalog": CATALOG, "mf.schema": SCHEMA,
              "mf.config_catalog": TGT_CATALOG, "mf.config_schema": TGT_SCHEMA, "mf.config_key": PIPELINE}
    if existing:
        w.pipelines.update(pipeline_id=existing, name=PIPELINE, serverless=True, catalog=CATALOG,
                           schema=SCHEMA, continuous=False, configuration=cfgmap, libraries=lib)
        pid = existing
    else:
        pid = w.pipelines.create(name=PIPELINE, serverless=True, catalog=CATALOG, schema=SCHEMA,
                                 continuous=False, configuration=cfgmap, libraries=lib).pipeline_id
    print(f"  pipeline_id={pid}")

    # 6) run + wait
    print("→ starting update…")
    upd = w.pipelines.start_update(pipeline_id=pid, full_refresh=True)
    state = pipeline_deploy.wait_for_update(pid, upd.update_id, on_state=lambda st: print(f"  update state: {st}"))
    if state != "COMPLETED":
        print("!! pipeline did not COMPLETE — recent errors:")
        for m in pipeline_deploy.recent_error_events(pid):
            print(f"   [ERROR] {m}")
        return 2

    # 7) verify target (clean) + quarantine (fail rows) + audit rollup
    print("→ verifying target / quarantine / audit…")
    tgt = f"{TGT_CATALOG}.{TGT_SCHEMA}.e2e_dim_financial_account"
    n_target = int(_sql(w, f"SELECT count(*) FROM {tgt}").result.data_array[0][0])
    n_quar = int(_sql(w, f"SELECT count(*) FROM {tgt}_quarantine").result.data_array[0][0])
    n_null_in_target = int(_sql(w, f"SELECT count(*) FROM {tgt} WHERE account_id IS NULL").result.data_array[0][0])
    print(f"  target rows={n_target}  quarantined={n_quar}  null-id-in-target={n_null_in_target}")

    audit = pipeline_config_store.rollup_audit(full_config, catalog=TGT_CATALOG, schema=TGT_SCHEMA,
                                               pipeline_name=PIPELINE, run_id=stored["run_id"])
    print(f"  audit: {audit}")
    arows = _sql(w, f"SELECT rule, action, failed_rows, total_rows, pass_rate "
                    f"FROM {pipeline_config_store.audit_table(TGT_CATALOG, TGT_SCHEMA)} "
                    f"WHERE pipeline_name='{PIPELINE}' ORDER BY rule").result.data_array or []
    for row in arows:
        print(f"    audit row: {row}")

    ok = (n_target > 0                        # clean rows landed
          and n_quar >= 1                     # the NULL-id row was quarantined
          and n_null_in_target == 0           # FAIL rule kept it OUT of target
          and audit.get("audit_rows_written", 0) >= 2)  # both rules audited
    print("✅ END-TO-END PASS" if ok else "❌ quarantine/audit assertions failed")
    return 0 if ok else 3


if __name__ == "__main__":
    sys.exit(main())
