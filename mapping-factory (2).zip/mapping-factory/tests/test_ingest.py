"""Unit tests for deterministic ingestion (M2). No workspace needed for DDL/CSV."""
from __future__ import annotations

from server.ingest import fields_from_csv, fields_from_ddl


def test_ddl_parse():
    ddl = """CREATE TABLE src_customers (
        cust_id BIGINT NOT NULL,
        first_nm STRING,
        balance_str STRING,
        signup_ts TIMESTAMP
    )"""
    fields = fields_from_ddl(ddl)
    names = [f["name"] for f in fields]
    assert names == ["cust_id", "first_nm", "balance_str", "signup_ts"]
    by = {f["name"]: f for f in fields}
    assert by["cust_id"]["datatype"] == "bigint"
    assert by["cust_id"]["nullable"] is False
    assert by["first_nm"]["nullable"] is True


def test_csv_infer():
    csv_text = "cust_id,first_nm,balance_str,is_active\n1,Ada,10.5,true\n2,Grace,20.0,false\n"
    fields = fields_from_csv(csv_text)
    by = {f["name"]: f for f in fields}
    assert by["cust_id"]["datatype"] == "bigint"
    assert by["balance_str"]["datatype"] == "double"
    assert by["is_active"]["datatype"] == "boolean"
    assert by["first_nm"]["datatype"] == "string"
    assert by["cust_id"]["sample_profile"]["examples"][:1] == ["1"]
