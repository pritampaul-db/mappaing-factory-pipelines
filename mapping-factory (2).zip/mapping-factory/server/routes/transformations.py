"""Transformations Library — list, detail, create, AI-generate, expression validate."""
from __future__ import annotations

from uuid import UUID

import sqlglot
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from server import config, db, llm, repo_library

router = APIRouter(tags=["transformations"])


def _user() -> str:
    try:
        return config.get_workspace_client().current_user.me().user_name or "unknown"
    except Exception:
        return "unknown"


@router.get("/transformations")
def list_transformations() -> list[dict]:
    return repo_library.list_transformations(db.pool)


@router.get("/transformations/{tid}")
def get_transformation(tid: UUID) -> dict:
    t = repo_library.get_transformation(db.pool, tid)
    if t is None:
        raise HTTPException(status_code=404, detail="transformation not found")
    return t


class XformCreate(BaseModel):
    name: str
    code: str | None = None
    ttype: str = "custom"
    category: str | None = None
    description: str | None = None
    logic_expr: str | None = None
    logic_sql: str | None = None
    test_cases: list[dict] | None = None
    tags: list[str] | None = None
    status: str | None = None  # Draft (default) | Published


@router.post("/transformations")
def create_transformation(body: XformCreate) -> dict:
    import uuid as _uuid

    data = body.model_dump()
    # Generate a unique code when none was supplied — name alone isn't unique (two
    # clones of the same transform would collide on the UNIQUE(code) constraint).
    if not data.get("code"):
        base = (data["name"].upper().replace(" ", "_"))[:44] or "XFORM"
        data["code"] = f"{base}_{_uuid.uuid4().hex[:6].upper()}"
    return repo_library.create_transformation(db.pool, data, _user())


@router.post("/transformations/{tid}/submit")
def submit_transformation(tid: UUID) -> dict:
    """Draft → Proposed (Pending Approval)."""
    try:
        return repo_library.submit_transformation(db.pool, tid, _user())
    except repo_library.TransformationGovernanceError as e:
        raise HTTPException(status_code=409, detail=str(e))


class XformDecision(BaseModel):
    decision: str  # approved | rejected
    rationale: str | None = None


@router.post("/transformations/{tid}/decide")
def decide_transformation(tid: UUID, body: XformDecision) -> dict:
    """Approve (→ Published) or reject (→ Rejected). Enforces maker != checker,
    except administrators, who may approve their own."""
    from server import repo_admin

    checker = _user()
    try:
        return repo_library.decide_transformation(
            db.pool, tid, decision=body.decision, checker=checker, rationale=body.rationale,
            is_admin=repo_admin.is_admin(db.pool, checker),
        )
    except repo_library.TransformationGovernanceError as e:
        raise HTTPException(status_code=409, detail=str(e))


class XformGenerate(BaseModel):
    description: str


@router.post("/transformations/generate")
def generate_transformation(body: XformGenerate) -> dict:
    try:
        return llm.generate_transformation(body.description)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"AI transformation generation failed: {e}")


class ExprValidate(BaseModel):
    expression: str


@router.post("/transformations/validate-expression")
def validate_expression(body: ExprValidate) -> dict:
    """Deterministic expression check via sqlglot (same engine as the compiler)."""
    try:
        ast = sqlglot.parse_one(body.expression, read="spark")
        cols = sorted({c.name for c in ast.find_all(sqlglot.exp.Column)})
        return {"valid": True, "normalized": ast.sql(dialect="spark"), "columns": cols}
    except Exception as e:  # noqa: BLE001
        return {"valid": False, "error": str(e)}
