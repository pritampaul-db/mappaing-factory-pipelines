"""Maker-checker governance + the two-tier approval saga (M5).

The approval boundary is the seam between the Lakebase hot tier (drafts) and the
Delta governed tier (approved truth). Because a Postgres commit followed by a
Delta write can partially fail, approval is staged and idempotent:

  1. Lakebase: spec.status Proposed -> Approving        (enforces maker != checker)
  2. Warehouse: MERGE artifact_version + approved snapshot into Delta,
     keyed by content_hash (safe to re-run)
  3. Lakebase: status -> Approved, store delta_content_hash

If step 2 fails the spec stays 'Approving' and is retryable; nothing is ever
falsely marked Approved. A reconciler can complete a spec that made it into Delta
but not back into Lakebase.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any
from uuid import UUID

from psycopg.rows import dict_row
from psycopg.types.json import Json
from psycopg_pool import ConnectionPool

from server import config, warehouse


class GovernanceError(Exception):
    """Raised on workflow violations (bad state, maker==checker, no mappings)."""


def submit_for_approval(pool: ConnectionPool, spec_id: UUID) -> dict[str, Any]:
    """Draft -> Proposed. Requires at least one accepted/edited mapping."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT status, owner FROM mapping_factory.mapping_spec WHERE id=%s FOR UPDATE", (spec_id,))
            spec = cur.fetchone()
            if spec is None:
                raise GovernanceError("spec not found")
            if spec["status"] != "Draft":
                raise GovernanceError(f"cannot submit from status {spec['status']}")
            cur.execute(
                "SELECT COUNT(*) AS n FROM mapping_factory.field_mapping WHERE spec_id=%s AND state IN ('accepted','edited')",
                (spec_id,),
            )
            if cur.fetchone()["n"] == 0:
                raise GovernanceError("nothing to approve: accept at least one mapping first")
            cur.execute(
                "UPDATE mapping_factory.mapping_spec SET status='Proposed', updated_at=now() WHERE id=%s RETURNING *",
                (spec_id,),
            )
            updated = cur.fetchone()
            cur.execute(
                "INSERT INTO mapping_factory.approval_task (spec_id, maker) VALUES (%s,%s)",
                (spec_id, spec["owner"]),
            )
        conn.commit()
    return updated


def _snapshot(cur, spec_id: UUID) -> dict[str, Any]:
    """Build the self-contained approved snapshot from accepted/edited mappings."""
    cur.execute(
        """SELECT s.id AS spec_id, s.name, s.version_no,
                  src.locator AS source_locator, s.owner, s.joins
           FROM mapping_factory.mapping_spec s
           JOIN mapping_factory.physical_asset src ON src.id = s.source_asset_id
           WHERE s.id=%s""",
        (spec_id,),
    )
    head = cur.fetchone()

    # All source tables (multi-table specs record every table in mapping_spec_asset;
    # single-table specs have only the primary, so `sources` is a 1-element list and
    # everything downstream — compile FROM clause, doc — degenerates to today's path).
    cur.execute(
        """SELECT a.name, a.locator
           FROM mapping_factory.mapping_spec_asset msa
           JOIN mapping_factory.physical_asset a ON a.id = msa.asset_id
           WHERE msa.spec_id=%s AND msa.role='source'
           ORDER BY msa.asset_id""",
        (spec_id,),
    )
    src_rows = cur.fetchall()
    sources = [{"name": r["name"], "locator": r["locator"]} for r in src_rows]
    if not sources and head:
        # Old single-table spec with no join-table rows: fall back to the primary.
        sources = [{"name": head["source_locator"], "locator": head["source_locator"]}]
    cur.execute(
        """SELECT fm.id AS mapping_id, pf.name AS target_field, pf.datatype AS target_type,
                  fm.source_field_ids, fm.provenance, fm.state,
                  tr.kind AS transform_kind, tr.spec_json AS transform_spec, tr.sql_expression AS transform_sql,
                  ARRAY(SELECT name FROM mapping_factory.physical_field WHERE id = ANY(fm.source_field_ids)) AS source_names
           FROM mapping_factory.field_mapping fm
           JOIN mapping_factory.physical_field pf ON pf.id = fm.target_field_id
           LEFT JOIN mapping_factory.transform_rule tr ON tr.id = fm.transform_rule_id
           WHERE fm.spec_id=%s AND fm.state IN ('accepted','edited')
           ORDER BY pf.name""",
        (spec_id,),
    )
    rows = cur.fetchall()
    mappings = []
    for r in rows:
        mappings.append(
            {
                "mapping_id": str(r["mapping_id"]),
                "target_field": r["target_field"],
                "target_type": r["target_type"],
                "source_fields": r["source_names"],
                "transform_kind": r["transform_kind"],
                "transform_spec": r["transform_spec"],
                "transform_sql": r["transform_sql"],
                "provenance": r["provenance"],
            }
        )
    return {
        "spec_id": str(head["spec_id"]),
        "name": head["name"],
        "version_no": head["version_no"],
        # Primary source locator kept for back-compat (single-table clients, explain).
        "source_locator": head["source_locator"],
        # Full multi-source structure so the approved version compiles the JOIN
        # deterministically from Delta alone. Single-table = 1-element `sources`, no joins.
        "sources": sources,
        "joins": head.get("joins") or [],
        "author": head["owner"],
        "mappings": mappings,
    }


def _content_hash(snapshot: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(snapshot, sort_keys=True, default=str).encode()).hexdigest()


def _ensure_delta_schema() -> None:
    tmpl_path = config_path()
    with open(tmpl_path) as fh:
        raw = fh.read().replace("{CAT}", config.UC_CATALOG).replace("{SCH}", config.UC_SCHEMA)
    # Strip full-line SQL comments so they don't leak into split statements.
    ddl = "\n".join(line for line in raw.splitlines() if not line.strip().startswith("--"))
    for stmt in [s.strip() for s in ddl.split(";") if s.strip()]:
        warehouse.execute(stmt)


def config_path() -> str:
    import os

    return os.path.join(os.path.dirname(__file__), "sql", "delta_schema.sql.tmpl")


def _sql_str(v: Any) -> str:
    """Escape a value as a Spark SQL string literal (single-quote doubling)."""
    s = v if isinstance(v, str) else json.dumps(v, default=str)
    return "'" + s.replace("'", "''") + "'"


def _materialize_to_delta(snapshot: dict[str, Any], content_hash: str, approved_by: str) -> None:
    """Idempotently write the approved snapshot into Delta (keyed by content_hash)."""
    _ensure_delta_schema()
    cat, sch = config.UC_CATALOG, config.UC_SCHEMA

    # If this exact version is already materialized, we're done (idempotent re-run).
    existing = warehouse.execute(
        f"SELECT COUNT(*) FROM {cat}.{sch}.artifact_version WHERE content_hash = {_sql_str(content_hash)}"
    )
    if existing and int(existing[0][0]) > 0:
        return

    snap_lit = _sql_str(json.dumps(snapshot, default=str))
    warehouse.execute(
        f"""INSERT INTO {cat}.{sch}.artifact_version
            (content_hash, spec_id, version_no, change_summary, author, approved_by, ts, snapshot_json)
            VALUES ({_sql_str(content_hash)}, {_sql_str(snapshot['spec_id'])}, {int(snapshot['version_no'])},
                    'approved via maker-checker', {_sql_str(snapshot['author'])}, {_sql_str(approved_by)},
                    current_timestamp(), {snap_lit})"""
    )
    for m in snapshot["mappings"]:
        src_arr = ", ".join(_sql_str(s) for s in (m["source_fields"] or [])) or ""
        warehouse.execute(
            f"""INSERT INTO {cat}.{sch}.approved_field_mapping
                (content_hash, spec_id, target_field, target_type, source_fields, transform_kind, transform_spec, transform_sql, provenance)
                VALUES ({_sql_str(content_hash)}, {_sql_str(snapshot['spec_id'])}, {_sql_str(m['target_field'])},
                        {_sql_str(m['target_type'])}, array({src_arr}), {_sql_str(m['transform_kind'] or 'spec')},
                        {_sql_str(json.dumps(m['transform_spec'], default=str)) if m['transform_spec'] is not None else 'NULL'},
                        {_sql_str(m['transform_sql']) if m['transform_sql'] else 'NULL'},
                        {_sql_str(json.dumps(m['provenance'], default=str))})"""
        )


def decide(pool: ConnectionPool, spec_id: UUID, *, decision: str, checker: str, rationale: str | None, is_admin: bool = False) -> dict[str, Any]:
    """Approve (runs the saga) or reject.

    Enforces maker != checker UNLESS the checker is an administrator — admins
    bypass segregation of duties and may approve their own spec.
    """
    if decision not in ("approved", "rejected"):
        raise GovernanceError("decision must be 'approved' or 'rejected'")

    # Step 1: transition Proposed -> Approving (or Rejected), enforcing SoD.
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SELECT status, owner FROM mapping_factory.mapping_spec WHERE id=%s FOR UPDATE", (spec_id,))
            spec = cur.fetchone()
            if spec is None:
                raise GovernanceError("spec not found")
            if spec["status"] not in ("Proposed", "Approving"):
                raise GovernanceError(f"cannot decide from status {spec['status']}")
            if decision == "approved" and spec["owner"] == checker and not is_admin:
                raise GovernanceError("segregation of duties: the maker cannot approve their own spec")

            if decision == "rejected":
                cur.execute(
                    "UPDATE mapping_factory.mapping_spec SET status='Rejected', updated_at=now() WHERE id=%s RETURNING *",
                    (spec_id,),
                )
                out = cur.fetchone()
                cur.execute(
                    "UPDATE mapping_factory.approval_task SET checker=%s, decision='rejected', rationale=%s, decided_at=now() WHERE spec_id=%s AND decided_at IS NULL",
                    (checker, rationale, spec_id),
                )
                conn.commit()
                return out

            cur.execute("UPDATE mapping_factory.mapping_spec SET status='Approving', updated_at=now() WHERE id=%s", (spec_id,))
            snapshot = _snapshot(cur, spec_id)
        conn.commit()

    if not snapshot["mappings"]:
        raise GovernanceError("no accepted/edited mappings to approve")
    content_hash = _content_hash(snapshot)

    # Step 2: materialize to Delta (idempotent). On failure, spec stays 'Approving'.
    _materialize_to_delta(snapshot, content_hash, checker)

    # Tier-1 self-learning: record approved mappings into retrieval memory + sync
    # the index. Best-effort — a retrieval-memory hiccup must not fail approval.
    try:
        from server import retrieval

        retrieval.record_approved_mappings(snapshot)
        retrieval.sync_index()
    except Exception:  # noqa: BLE001
        pass

    # Explainability: write a human-readable evidence doc for the Knowledge
    # Assistant to ground on, and trigger a re-index. Best-effort.
    try:
        from server import explain

        explain.write_evidence(snapshot, content_hash)
        explain.sync_ka()
    except Exception:  # noqa: BLE001
        pass

    # Step 3: finalize in Lakebase.
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE mapping_factory.mapping_spec SET status='Approved', delta_content_hash=%s, updated_at=now() WHERE id=%s RETURNING *",
                (content_hash, spec_id),
            )
            out = cur.fetchone()
            cur.execute(
                "UPDATE mapping_factory.approval_task SET checker=%s, decision='approved', rationale=%s, decided_at=now() WHERE spec_id=%s AND decided_at IS NULL",
                (checker, rationale, spec_id),
            )
        conn.commit()

    # Metadata Explorer: index the now-published mapping's assets/edges/terms into
    # the catalog. ASYNC (background thread) — the approve request must not wait on
    # it — and best-effort, so an indexing hiccup never fails the approval.
    try:
        from server import metadata_index

        metadata_index.index_spec_async(spec_id)
    except Exception:  # noqa: BLE001
        pass

    # Contribute-back: register the NEW transformations + validation rules this mapping
    # introduced into the reusable libraries (Published), closing the propose→learn loop
    # so the next Suggest/Validate can reuse them. Best-effort; never fails approval.
    try:
        from server import library_contrib

        library_contrib.contribute_from_snapshot(pool, snapshot, actor=checker)
        library_contrib.contribute_validations(pool, str(spec_id), snapshot.get("name") or "", actor=checker)
    except Exception:  # noqa: BLE001
        pass

    out["snapshot"] = snapshot
    out["delta_content_hash"] = content_hash
    return out
