#!/usr/bin/env bash
#
# Mapping Factory — apply all OBO (on-behalf-of-user) grants for the app-users group.
#
# Run this AFTER enabling OBO on the app (Settings → User authorization → add scopes
# sql, serving.serving-endpoints, files). It grants the group everything the app
# touches AS THE USER at request time:
#   1. Unity Catalog: catalog/schema USE + SELECT/MODIFY/CREATE + volume READ/WRITE
#      (via SQL statements on the app's warehouse) — from scripts/obo_grants.sql
#   2. SQL warehouse: CAN_USE           (permissions API)
#   3. Foundation Model endpoint: CAN_QUERY   (permissions API)
#   4. Knowledge Assistant endpoint: CAN_QUERY (permissions API)
#
# The permission API calls are ADDITIVE (update-permissions) — they won't remove the
# service principal's existing access. Requires a profile/identity that can MANAGE
# these objects (workspace admin or object owner).
#
# Usage:
#   GROUP="mapping-factory-users" ./scripts/obo_grants.sh
# (or edit GROUP below; use "account users" to grant everyone)
set -euo pipefail

GROUP="${GROUP:-mapping factory users}"
PROFILE="${DATABRICKS_PROFILE:-fevm-pritam-demo-workspace}"
WAREHOUSE_ID="${MF_WAREHOUSE_ID:-cd54b9f16b2bf7ed}"
CATALOG="${MF_CATALOG:-pritam_demo_workspace_catalog}"
SCHEMA="${MF_SCHEMA:-mapping_factory}"
LLM_ENDPOINT="${MF_LLM_ENDPOINT:-databricks-claude-opus-4-7}"
KA_ENDPOINT="${MF_KA_ENDPOINT:-ka-d2813d51-endpoint}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$GROUP" = "<GROUP>" ]; then
  echo "ERROR: set GROUP first, e.g.  GROUP='mapping-factory-users' $0" >&2
  exit 1
fi
echo "Granting Mapping Factory OBO access to group: $GROUP  (profile: $PROFILE)"

# --- 1. Unity Catalog grants (run each statement in obo_grants.sql on the warehouse) ---
echo "== Unity Catalog grants (via warehouse $WAREHOUSE_ID) =="
# Substitute <GROUP> in the SQL, split on ';', run non-empty non-comment statements.
sed "s/<GROUP>/${GROUP}/g" "$HERE/obo_grants.sql" \
  | sed 's/--.*$//' \
  | tr '\n' ' ' \
  | tr ';' '\n' \
  | while IFS= read -r stmt; do
      stmt="$(echo "$stmt" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
      [ -z "$stmt" ] && continue
      echo "  > $stmt"
      databricks api post /api/2.0/sql/statements --profile "$PROFILE" --json "$(
        printf '{"warehouse_id":"%s","catalog":"%s","schema":"%s","wait_timeout":"30s","statement":%s}' \
          "$WAREHOUSE_ID" "$CATALOG" "$SCHEMA" "$(printf '%s' "$stmt" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')"
      )" >/dev/null && echo "    ok" || echo "    FAILED (needs an owner/admin?) — continuing"
    done

# --- 2. SQL warehouse CAN_USE ---
echo "== Warehouse CAN_USE =="
databricks warehouses update-permissions "$WAREHOUSE_ID" --profile "$PROFILE" \
  --json "{\"access_control_list\":[{\"group_name\":\"${GROUP}\",\"permission_level\":\"CAN_USE\"}]}" \
  >/dev/null && echo "  ok" || echo "  FAILED — needs warehouse MANAGE"

# --- 3 + 4. Serving endpoints CAN_QUERY (Foundation Model + Knowledge Assistant) ---
for EP in "$LLM_ENDPOINT" "$KA_ENDPOINT"; do
  echo "== Serving endpoint CAN_QUERY: $EP =="
  # resolve endpoint id (permissions API is keyed by id)
  EP_ID="$(databricks serving-endpoints get "$EP" --profile "$PROFILE" -o json 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin).get("id",""))' || true)"
  if [ -z "$EP_ID" ]; then echo "  skip: endpoint $EP not found / no access"; continue; fi
  databricks serving-endpoints update-permissions "$EP_ID" --profile "$PROFILE" \
    --json "{\"access_control_list\":[{\"group_name\":\"${GROUP}\",\"permission_level\":\"CAN_QUERY\"}]}" \
    >/dev/null && echo "  ok" || echo "  FAILED — needs endpoint MANAGE"
done

echo "Done. Verify: open the app as a group member → /api/health shows auth:obo_user + your identity, and Suggest/Compile/Run/Upload all work."
