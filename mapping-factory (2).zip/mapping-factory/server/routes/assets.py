"""Asset registration + retrieval (M1/M2)."""
from __future__ import annotations

import io
import posixpath
import uuid as _uuid
from uuid import UUID

from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from server import config, db, docingest, ingest, repo
from server.models import AssetCreate, AssetIngest, AssetOut

router = APIRouter(tags=["assets"])


def _current_user() -> str:
    try:
        return config.get_workspace_client().current_user.me().user_name or "unknown"
    except Exception:
        return "unknown"


@router.post("/assets", response_model=AssetOut)
def create_asset(body: AssetCreate) -> AssetOut:
    asset = repo.create_asset(
        db.pool,
        name=body.name,
        object_type=body.object_type,
        role=body.role,
        created_by=_current_user(),
        system=body.system,
        locator=body.locator,
        fields=[f.model_dump() for f in body.fields],
    )
    return AssetOut(**asset)


@router.post("/assets/ingest", response_model=AssetOut)
def ingest_asset(body: AssetIngest) -> AssetOut:
    """Deterministically infer a schema from a structured source, then register it.

    No LLM: UC-table introspection, DDL parse, or CSV header inference (P1).
    """
    try:
        if body.object_type == "uc_table":
            if not body.locator:
                raise ValueError("locator (catalog.schema.table) required for uc_table")
            fields = ingest.fields_from_uc_table(body.locator)
        elif body.object_type == "ddl":
            fields = ingest.fields_from_ddl(body.content or "")
        elif body.object_type == "uploaded_csv":
            fields = ingest.fields_from_csv(body.content or "")
        else:
            raise ValueError(f"Unsupported ingest object_type: {body.object_type}")
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:  # noqa: BLE001 — surface warehouse/introspection errors
        raise HTTPException(status_code=502, detail=f"ingestion failed: {e}")

    asset = repo.create_asset(
        db.pool,
        name=body.name,
        object_type=body.object_type,
        role=body.role,
        created_by=_current_user(),
        locator=body.locator,
        fields=fields,
    )
    return AssetOut(**asset)


@router.post("/assets/ingest-document", response_model=AssetOut)
def ingest_document(
    file: UploadFile = File(...),
    role: str = Form("source"),
    name: str | None = Form(None),
) -> AssetOut:
    """Extract a schema from an unstructured document (Schema Extraction Agent).

    Upload → UC volume → ai_parse_document → FM schema extraction → DRAFT asset
    (human confirms field types before use). This is a proposal, not truth (P4).
    """
    data = file.file.read()
    if not data:
        raise HTTPException(status_code=422, detail="empty file")

    # Upload to the UC volume via the Files API (unique subpath per upload).
    safe = (file.filename or "document").replace("/", "_")
    vol_path = posixpath.join(docingest.DOC_VOLUME, _uuid.uuid4().hex, safe)
    try:
        config.get_workspace_client().files.upload(vol_path, io.BytesIO(data), overwrite=True)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"upload to volume failed: {e}")

    try:
        fields = docingest.ingest_document(vol_path)
    except Exception as e:  # noqa: BLE001 — surface parse/extract failures
        raise HTTPException(status_code=502, detail=f"document schema extraction failed: {e}")
    if not fields:
        raise HTTPException(status_code=422, detail="no schema fields could be extracted from the document")

    asset = repo.create_asset(
        db.pool,
        name=name or safe.rsplit(".", 1)[0],
        object_type="extracted_schema",
        role=role,
        created_by=_current_user(),
        locator=vol_path,
        fields=fields,
    )
    return AssetOut(**asset)


@router.post("/assets/parse-tables")
def parse_tables(
    file: UploadFile = File(...),
    role: str = Form("source"),
) -> dict:
    """Parse a document into its constituent TABLES (name + fields) WITHOUT creating
    assets. The user then multi-selects which tables to map; assets are created at
    spec-creation time (POST /api/specs/multi). Supports multi-table data models.
    """
    data = file.file.read()
    if not data:
        raise HTTPException(status_code=422, detail="empty file")
    safe = (file.filename or "document").replace("/", "_")
    vol_path = posixpath.join(docingest.DOC_VOLUME, _uuid.uuid4().hex, safe)
    try:
        config.get_workspace_client().files.upload(vol_path, io.BytesIO(data), overwrite=True)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"upload to volume failed: {e}")
    try:
        tables = docingest.parse_document_tables(vol_path)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"document table extraction failed: {e}")
    if not tables:
        raise HTTPException(status_code=422, detail="no tables could be extracted from the document")
    return {"role": role, "source_path": vol_path, "filename": safe, "tables": tables}


@router.get("/assets/{asset_id}", response_model=AssetOut)
def get_asset(asset_id: UUID) -> AssetOut:
    asset = repo.get_asset(db.pool, asset_id)
    if asset is None:
        raise HTTPException(status_code=404, detail="asset not found")
    return AssetOut(**asset)


@router.get("/assets", response_model=list[AssetOut])
def list_assets(role: str | None = None) -> list[AssetOut]:
    return [AssetOut(**a) for a in repo.list_assets(db.pool, role=role)]
