"""Explanation layer via Agent Bricks Knowledge Assistant.

The architecture's Explainability Platform, realized with a managed Knowledge
Assistant (KA) that answers grounded, cited questions over the evidence the
platform produces. On approval we write a human-readable "evidence document"
per spec (business-readable derivation of every target field + its transform
logic and lineage) into a UC volume; KA indexes that volume and answers
questions like "how is balance derived?" with citations back to the evidence.

KA is created/managed via the Databricks SDK (w.knowledge_assistants). A KA
knowledge source over a UC volume ('files') embeds the docs and stands up a
serving endpoint; ALHF examples (create_example) teach it in natural language.
"""
from __future__ import annotations

import io
import json
import os
import posixpath
from typing import Any

from server import config

KA_DISPLAY_NAME = "Mapping Factory Explainer"
EVIDENCE_VOLUME = f"/Volumes/{config.UC_CATALOG}/{config.UC_SCHEMA}/evidence"
# When set, the app queries this KA serving endpoint directly and skips the
# list/create provisioning dance (which needs elevated perms the SP lacks).
KA_ENDPOINT = os.environ.get("MF_KA_ENDPOINT")
KA_NAME = os.environ.get("MF_KA_NAME")


def resolve_endpoint() -> str | None:
    """The KA serving endpoint to query, preferring the configured override."""
    if KA_ENDPOINT:
        return KA_ENDPOINT
    try:
        return get_or_create_ka().get("endpoint_name")
    except Exception:  # noqa: BLE001
        return None


def _ensure_evidence_volume() -> None:
    from server import warehouse

    warehouse.execute(
        f"CREATE VOLUME IF NOT EXISTS {config.UC_CATALOG}.{config.UC_SCHEMA}.evidence"
    )


def evidence_markdown(snapshot: dict[str, Any], content_hash: str) -> str:
    """Business-readable evidence document for an approved spec (what KA grounds on)."""
    lines = [
        f"# Mapping Evidence — {snapshot.get('name', 'spec')}",
        "",
        f"- **Spec id:** {snapshot.get('spec_id')}",
        f"- **Version:** {snapshot.get('version_no')}",
        f"- **Approved content hash:** {content_hash}",
        f"- **Source:** {snapshot.get('source_locator')}",
        f"- **Author (maker):** {snapshot.get('author')}",
        "",
        "## Field derivations",
        "",
    ]
    for m in snapshot.get("mappings", []):
        spec = m.get("transform_spec") or {}
        op = (spec.get("op") if isinstance(spec, dict) else None) or m.get("transform_kind")
        src = ", ".join(m.get("source_fields") or []) or "(none)"
        detail = json.dumps(spec) if isinstance(spec, dict) else str(m.get("transform_sql") or "")
        prov = m.get("provenance") or {}
        origin = prov.get("origin", "?")
        lines += [
            f"### `{m['target_field']}` ({m['target_type']})",
            f"- Derived from source field(s): **{src}**",
            f"- Transform: **{op}** — {detail}",
            f"- Provenance: proposed by **{origin}**"
            + (f", reviewed by {prov.get('reviewed_by')}" if prov.get("reviewed_by") else ""),
            "",
        ]
    return "\n".join(lines)


def write_evidence(snapshot: dict[str, Any], content_hash: str) -> str:
    """Write the evidence doc to the UC volume; return its path."""
    _ensure_evidence_volume()
    md = evidence_markdown(snapshot, content_hash)
    path = posixpath.join(EVIDENCE_VOLUME, f"{snapshot.get('spec_id')}__{content_hash[:12]}.md")
    config.get_workspace_client().files.upload(path, io.BytesIO(md.encode()), overwrite=True)
    return path


def get_or_create_ka() -> dict[str, Any]:
    """Idempotently create the Knowledge Assistant + its volume knowledge source."""
    from databricks.sdk.service import knowledgeassistants as ka

    w = config.get_workspace_client()
    _ensure_evidence_volume()

    def _find() -> Any | None:
        for a in w.knowledge_assistants.list_knowledge_assistants():
            if a.display_name == KA_DISPLAY_NAME:
                return a
        return None

    # Find existing by display name.
    existing = _find()

    if existing is None:
        try:
            existing = w.knowledge_assistants.create_knowledge_assistant(
                knowledge_assistant=ka.KnowledgeAssistant(
                    display_name=KA_DISPLAY_NAME,
                    description="Answers questions about how governed data mappings are derived, with citations to approved evidence.",
                    instructions=(
                        "You explain how target fields are derived from sources in the Mapping Factory. "
                        "Answer using the approved mapping evidence documents. Always cite the specific "
                        "field derivation. If asked about a field not in the evidence, say it is not yet approved."
                    ),
                )
            )
        except Exception as e:  # noqa: BLE001
            # Another identity (e.g. the app SP vs the owner) may have created it,
            # or a list-visibility gap hid it. Recover by re-looking-up.
            if "ALREADY_EXISTS" not in str(e):
                raise
            existing = _find()
            if existing is None:
                raise

    # Ensure a 'files' knowledge source over the evidence volume.
    parent = existing.name
    has_source = any(True for _ in w.knowledge_assistants.list_knowledge_sources(parent))
    if not has_source:
        w.knowledge_assistants.create_knowledge_source(
            parent=parent,
            knowledge_source=ka.KnowledgeSource(
                display_name="Approved mapping evidence",
                description="Human-readable evidence documents for approved mapping specs.",
                source_type="files",
                files=ka.FilesSpec(path=EVIDENCE_VOLUME),
            ),
        )

    return {"name": existing.name, "id": existing.id, "endpoint_name": existing.endpoint_name}


def sync_ka() -> None:
    """Re-index the KA's knowledge sources after new evidence is written."""
    w = config.get_workspace_client()
    try:
        info = get_or_create_ka()
        w.knowledge_assistants.sync_knowledge_sources(name=info["name"])
    except Exception:
        pass  # KA may still be provisioning; a later sync catches up
