"""Admin utilities — seed the demo dataset + manage administrator users."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from server import config, db, demo, repo_admin, seed

router = APIRouter(tags=["admin"])


def _current_user() -> str:
    try:
        return config.get_workspace_client().current_user.me().user_name or "unknown"
    except Exception:
        return "unknown"


def _require_admin() -> str:
    """Return the caller's identity, or 403 if they are not an administrator."""
    user = _current_user()
    if not repo_admin.is_admin(db.pool, user):
        raise HTTPException(status_code=403, detail="administrator access required")
    return user


# --- administration: admin users --------------------------------------------

@router.get("/admin/me")
def admin_me() -> dict:
    """Whether the current user is an administrator (drives the UI)."""
    user = _current_user()
    return {"user": user, "is_admin": repo_admin.is_admin(db.pool, user)}


@router.get("/admin/admins")
def list_admins() -> dict:
    return {"admins": repo_admin.list_admins(db.pool), "me": _current_user()}


class AdminAdd(BaseModel):
    user_name: str


@router.post("/admin/admins")
def add_admin(body: AdminAdd) -> dict:
    added_by = _require_admin()
    if not body.user_name.strip():
        raise HTTPException(status_code=422, detail="user_name is required")
    row = repo_admin.add_admin(db.pool, body.user_name, added_by)
    return {"admin": row}


@router.delete("/admin/admins/{user_name}")
def remove_admin(user_name: str) -> dict:
    me = _require_admin()
    # Guard: never let the last admin remove themselves (would orphan the list).
    if repo_admin._norm(user_name) == repo_admin._norm(me) and repo_admin.count_admins(db.pool) <= 1:
        raise HTTPException(status_code=409, detail="cannot remove the last administrator")
    deleted = repo_admin.remove_admin(db.pool, user_name)
    if not deleted:
        raise HTTPException(status_code=404, detail="admin not found")
    return {"removed": user_name}


@router.post("/admin/seed")
def run_seed() -> dict:
    """Idempotently load the one consistent demo dataset used across all screens."""
    try:
        counts = seed.seed(db.pool)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"seed failed: {e}")
    return {"seeded": counts}


@router.get("/admin/pipeline-status")
def pipeline_status() -> dict:
    """Whether the Agentic-Mapping-Test SDP pipeline has been provisioned."""
    from server import sdp_pipeline

    return sdp_pipeline.status()


@router.post("/admin/provision-pipeline")
def provision_pipeline() -> dict:
    """Idempotently create + deploy the generic serverless SDP test pipeline (app setup)."""
    from server import sdp_pipeline

    try:
        return sdp_pipeline.provision()
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"pipeline provisioning failed: {e}")


@router.post("/admin/complex-demo")
def build_complex_demo() -> dict:
    """Set up the wide Customer-360 scenario (messy source → conformed target).

    Introspects the real UC landing table, creates the conformed target from DDL,
    creates a spec, and seeds ~24 compound `expr` mappings in the accepted state.
    Returns the full spec (with mappings) so the studio can render it immediately.
    """
    try:
        return demo.build_complex_demo(db.pool, owner=_current_user())
    except Exception as e:  # noqa: BLE001 — surface warehouse/DB failures
        raise HTTPException(status_code=502, detail=f"complex demo setup failed: {e}")
