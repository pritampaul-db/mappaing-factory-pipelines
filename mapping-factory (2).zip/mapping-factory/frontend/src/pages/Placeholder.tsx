import { Hammer } from "lucide-react";
import { usePage } from "../AppShell";

// Tasteful placeholder for nav items that don't have a wireframe yet.
export function Placeholder({ title, subtitle }: { title: string; subtitle?: string }) {
  usePage({ title, subtitle }, [title]);
  return (
    <div className="h-full grid place-items-center p-8">
      <div className="text-center max-w-sm">
        <div className="mx-auto w-12 h-12 rounded-xl bg-brand-soft grid place-items-center mb-4">
          <Hammer className="w-6 h-6 text-brand" />
        </div>
        <h2 className="text-lg font-semibold text-gray-800">{title}</h2>
        <p className="text-sm text-gray-500 mt-1">
          This screen is on the roadmap. Once its wireframe is ready it will be built out here.
        </p>
      </div>
    </div>
  );
}
