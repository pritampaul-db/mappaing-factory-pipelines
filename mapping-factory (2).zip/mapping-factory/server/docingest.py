"""Unstructured-document schema extraction (Schema Extraction Agent).

Adds the heterogeneous-document ingestion path from the architecture: a user
uploads a spec/data-dictionary document (PDF/DOCX/etc.); we parse it with Agent
Bricks' ai_parse_document, then extract a candidate *schema* (field definitions)
from the parsed text. The result is a DRAFT asset a human confirms — extraction
is a proposal, never authoritative (P1/P4).

Two Agent Bricks / FM primitives are used:
  * ai_parse_document — binary doc in a UC volume -> structured text (VARIANT).
  * an FM structured-output call — parsed text -> typed field definitions.
"""
from __future__ import annotations

import json
import os
from typing import Any

from server import config, warehouse

# Where uploaded documents land (dedicated UC volume created for this).
DOC_VOLUME = os.environ.get(
    "MF_DOC_VOLUME", f"/Volumes/{config.UC_CATALOG}/{config.UC_SCHEMA}/documents"
)

_FIELD_SCHEMA = {
    "type": "object",
    "properties": {
        "fields": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "datatype": {
                        "type": "string",
                        "description": "Spark SQL type: string, bigint, int, double, decimal, boolean, date, timestamp",
                    },
                    "nullable": {"type": "boolean"},
                    "description": {"type": "string"},
                },
                "required": ["name", "datatype", "nullable", "description"],
            },
        }
    },
    "required": ["fields"],
}

_SYSTEM = """You extract a DATA SCHEMA from a document that describes a data model, table,
or data dictionary. Return the list of fields/columns the document defines, each with a
name, a Spark SQL datatype (string, bigint, int, double, decimal, boolean, date, timestamp),
whether it is nullable, and a one-line description. Only include actual data fields the
document defines — ignore prose, headers, and page furniture. Return ONLY JSON matching
the schema."""


# ai_parse_document handles rich binary docs; plain-text formats it rejects
# ("Unsupported file format"), so we read those directly.
_TEXT_EXTS = (".txt", ".md", ".markdown", ".csv", ".tsv", ".json")


def parse_document(volume_path: str) -> str:
    """Return a document's text content.

    Text-like files are read directly; binary docs (PDF/DOCX/PPTX/images) go
    through Agent Bricks' ai_parse_document. Parse errors are raised, not
    swallowed, so a failed extraction never looks like an empty schema.
    """
    lower = volume_path.lower()
    if lower.endswith(_TEXT_EXTS):
        # format=>'text' with wholeText exposes the content column as `value`.
        rows = warehouse.execute(
            f"SELECT CAST(value AS STRING) FROM READ_FILES('{volume_path}', format => 'text', wholeText => true)"
        )
        if not rows or rows[0][0] is None:
            raise ValueError(f"No text read at {volume_path}")
        return str(rows[0][0])[:20000]

    rows = warehouse.execute(
        f"""SELECT CAST(ai_parse_document(content) AS STRING) AS parsed
            FROM READ_FILES('{volume_path}', format => 'binaryFile')"""
    )
    if not rows:
        raise ValueError(f"No document read at {volume_path}")
    parsed_raw = rows[0][0]
    parsed = json.loads(parsed_raw) if isinstance(parsed_raw, str) else parsed_raw
    # Surface ai_parse_document's own error_status rather than returning empty.
    if isinstance(parsed, dict):
        errs = [e for e in (parsed.get("error_status") or []) if e.get("error_message")]
        text = _extract_text(parsed)
        if errs and not text.strip():
            raise ValueError(f"ai_parse_document could not parse this file: {errs[0]['error_message']}")
        return text
    return _extract_text(parsed)


def _extract_text(parsed: Any) -> str:
    """Best-effort text extraction from ai_parse_document output."""
    if isinstance(parsed, str):
        try:
            parsed = json.loads(parsed)
        except json.JSONDecodeError:
            return parsed  # already plain text
    chunks: list[str] = []

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            # Common keys ai_parse_document emits for textual content.
            for k in ("content", "text", "markdown"):
                v = node.get(k)
                if isinstance(v, str) and v.strip():
                    chunks.append(v)
            for v in node.values():
                if isinstance(v, (dict, list)):
                    walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    walk(parsed)
    text = "\n".join(chunks) if chunks else json.dumps(parsed)
    # Keep the prompt bounded; a data dictionary's schema is near the top anyway.
    return text[:20000]


def extract_schema(parsed_text: str) -> list[dict[str, Any]]:
    """FM structured-output call: parsed document text -> candidate field defs."""
    from openai import OpenAI

    client = OpenAI(
        api_key=config.get_bearer_token(),
        base_url=f"{config.get_workspace_host()}/serving-endpoints",
    )
    resp = client.chat.completions.create(
        model=config.LLM_ENDPOINT,
        messages=[
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": f"Document:\n\n{parsed_text}\n\nExtract the schema."},
        ],
        response_format={
            "type": "json_schema",
            "json_schema": {"name": "schema_fields", "schema": _FIELD_SCHEMA, "strict": True},
        },
        max_tokens=4096,
    )
    data = json.loads(resp.choices[0].message.content or "{}")
    fields = data.get("fields", [])
    for i, f in enumerate(fields):
        f["ordinal"] = i
    return fields


def ingest_document(volume_path: str) -> list[dict[str, Any]]:
    """Full path: parse a document, then extract candidate schema fields."""
    text = parse_document(volume_path)
    return extract_schema(text)


# --- multi-table extraction (a document may describe several tables) ---------

_TABLES_SCHEMA = {
    "type": "object",
    "properties": {
        "tables": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "table_name": {"type": "string"},
                    "description": {"type": "string"},
                    "fields": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "name": {"type": "string"},
                                "datatype": {"type": "string", "description": "Spark SQL type: string, bigint, int, double, decimal, boolean, date, timestamp"},
                                "nullable": {"type": "boolean"},
                                "is_key": {"type": "boolean", "description": "true if this is a primary key or a foreign/reference key"},
                                "description": {"type": "string"},
                            },
                            "required": ["name", "datatype", "nullable", "is_key", "description"],
                        },
                    },
                },
                "required": ["table_name", "description", "fields"],
            },
        }
    },
    "required": ["tables"],
}

_TABLES_SYSTEM = """You extract a DATA MODEL from a document (a data dictionary / dimensional or source
data model) that may describe MULTIPLE tables. Return every distinct TABLE the document defines, each
with its table_name, a one-line description, and its list of fields/columns. For each field give a
name, a Spark SQL datatype (string, bigint, int, double, decimal, boolean, date, timestamp), whether
it is nullable, whether it is a key (`is_key` = true for primary keys AND foreign/reference keys — this
matters for joins across tables), and a one-line description. Keep each table's columns SEPARATE — do
NOT merge columns from different tables. Ignore prose, headers, and page furniture. Return ONLY JSON."""


def extract_tables(parsed_text: str) -> list[dict[str, Any]]:
    """FM structured-output call: parsed document text -> list of {table_name, fields[]}."""
    from openai import OpenAI

    client = OpenAI(api_key=config.get_bearer_token(), base_url=f"{config.get_workspace_host()}/serving-endpoints")
    resp = client.chat.completions.create(
        model=config.LLM_ENDPOINT,
        messages=[
            {"role": "system", "content": _TABLES_SYSTEM},
            {"role": "user", "content": f"Document:\n\n{parsed_text}\n\nExtract every table and its fields."},
        ],
        response_format={"type": "json_schema", "json_schema": {"name": "data_model", "schema": _TABLES_SCHEMA, "strict": True}},
        max_tokens=8192,
    )
    data = json.loads(resp.choices[0].message.content or "{}")
    tables = data.get("tables", [])
    for t in tables:
        for i, f in enumerate(t.get("fields", [])):
            f["ordinal"] = i
    return tables


def parse_document_tables(volume_path: str) -> list[dict[str, Any]]:
    """Full multi-table path: parse a document, then extract all tables + their fields."""
    text = parse_document(volume_path)
    return extract_tables(text)
