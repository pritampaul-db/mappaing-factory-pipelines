"""AI auto-mapping — the "AI proposes" half of P1 (M3).

Calls a Foundation Model (Claude) via the OpenAI-compatible serving endpoint
with a strict JSON schema, so the model returns candidate FieldMappings — never
free text and never runnable code. Candidates are normalized to the compiler's
transform-spec vocabulary and handed back for human review as Draft metadata.

The model proposes; it does not decide. Every candidate carries a confidence and
an evidence rationale, and nothing here writes approved truth or executes.
"""
from __future__ import annotations

import json
from typing import Any

from openai import OpenAI

from server import config

# The transform ops the compiler understands. Kept in lockstep with
# server.compiler._lower_spec_to_sql so a suggestion can always compile. The
# compiler also supports a custom "expr" op, but it is deliberately excluded here
# so the auto-mapper proposes structured, well-typed ops rather than opaque SQL;
# "expr" is reserved for the Optimize action (merging steps into one expression).
_SUPPORTED_OPS = ["rename", "cast", "default", "concat", "arithmetic", "case", "date_format"]

_RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "mappings": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "target_field": {"type": "string"},
                    "source_fields": {"type": "array", "items": {"type": "string"}},
                    "reuse_code": {"type": "string", "description": "code of an existing library transformation to REUSE for this column, or empty string if none fits and you are proposing a new transform"},
                    "transform": {
                        "type": "object",
                        "properties": {
                            "op": {"type": "string", "enum": _SUPPORTED_OPS},
                            "source": {"type": "string"},
                            "sources": {"type": "array", "items": {"type": "string"}},
                            "to": {"type": "string"},
                            "separator": {"type": "string"},
                            "format": {"type": "string"},
                            "value": {"type": "string"},
                            "expr": {"type": "string"},
                        },
                        "required": ["op"],
                    },
                    "confidence": {"type": "number"},
                    "rationale": {"type": "string"},
                },
                "required": ["target_field", "source_fields", "reuse_code", "transform", "confidence", "rationale"],
            },
        }
    },
    "required": ["mappings"],
}

_SYSTEM = """You are a data-mapping assistant for an enterprise transformation platform.
Given a SOURCE schema and a TARGET schema, propose how to derive each target field
from source field(s). You may ONLY use these transform ops: rename, cast, default,
concat, arithmetic, case, date_format. Choose a cast when source and target types
differ. Return one mapping per target field you are confident about; omit a target
field entirely rather than guess wildly. Provide a 0..1 confidence and a short
rationale for each. Return ONLY JSON matching the provided schema."""


def _client() -> OpenAI:
    # Bound each FM call: without an explicit timeout the SDK waits up to 10 min,
    # so one slow/hung generation can freeze a step (e.g. the Dummy Data Agent makes
    # one call per source table). 120s per attempt + 2 retries fails fast + recovers.
    return OpenAI(
        api_key=config.get_bearer_token(),
        base_url=f"{config.get_workspace_host()}/serving-endpoints",
        timeout=120.0,
        max_retries=2,
    )


def _schema_block(label: str, fields: list[dict[str, Any]]) -> str:
    lines = [f"{label} schema:"]
    for f in fields:
        null = "" if f.get("nullable", True) else " NOT NULL"
        lines.append(f"  - {f['name']}: {f['datatype']}{null}")
    return "\n".join(lines)


def _exemplar_block(exemplars: list[dict[str, Any]]) -> str:
    """Format retrieved approved precedents as few-shot guidance (Tier-1 learning)."""
    if not exemplars:
        return ""
    lines = ["Prior APPROVED mappings from this organization (follow these house patterns):"]
    for e in exemplars:
        txt = e.get("memory_text") or ""
        if txt:
            lines.append(f"  - {txt}")
    return "\n".join(lines) + "\n\n"


def _catalog_block(catalog: list[dict[str, Any]], kind: str) -> str:
    """Format the published library as a REUSE-FIRST catalog. The model should prefer
    an existing item (referenced by its `code`) over inventing a new one when it fits."""
    if not catalog:
        return ""
    lines = [
        f"EXISTING {kind} LIBRARY — PREFER REUSING one of these before inventing a new one. "
        f"If an item's logic fits a column, set `reuse_code` to its CODE (and still fill the transform "
        f"with the equivalent op). Only leave reuse_code empty when nothing fits:"
    ]
    for c in catalog:
        logic = (c.get("logic") or "").replace("\n", " ")[:120]
        desc = (c.get("description") or "")[:80]
        lines.append(f"  - [{c['code']}] {c['name']} — {desc} | logic: {logic}")
    return "\n".join(lines) + "\n\n"


def suggest_mappings(
    source_fields: list[dict[str, Any]],
    target_fields: list[dict[str, Any]],
    exemplars: list[dict[str, Any]] | None = None,
    transform_catalog: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Return raw candidate mappings from the model (validated against the schema).

    Each item: {target_field, source_fields[], reuse_code, transform{op,...}, confidence, rationale}.
    `exemplars` (retrieved approved precedents) are injected as few-shot guidance.
    `transform_catalog` (published transformation library) is injected as a REUSE-FIRST
    catalog so the model prefers an existing transformation (via reuse_code) before
    inventing a new one. Raises on transport/parse failure (no silent writes).
    """
    prompt = (
        f"{_exemplar_block(exemplars or [])}"
        f"{_catalog_block(transform_catalog or [], 'TRANSFORMATION')}"
        f"{_schema_block('SOURCE', source_fields)}\n\n"
        f"{_schema_block('TARGET', target_fields)}\n\n"
        "Propose the target-field mappings, reusing library transformations where they fit."
    )
    resp = _client().chat.completions.create(
        model=config.LLM_ENDPOINT,
        messages=[{"role": "system", "content": _SYSTEM}, {"role": "user", "content": prompt}],
        response_format={
            "type": "json_schema",
            "json_schema": {"name": "field_mappings", "schema": _RESPONSE_SCHEMA, "strict": True},
        },
        max_tokens=4096,
    )
    content = resp.choices[0].message.content or "{}"
    data = json.loads(content)
    return data.get("mappings", [])


# --- multi-table suggest (many sources → many targets, with joins) -----------

# Multi-table also allows a raw "expr" op — needed for surrogate/FK KEY generation
# (e.g. xxhash64 of the natural key), which the structured ops can't express.
_MULTI_OPS = _SUPPORTED_OPS + ["expr"]

_MULTI_SCHEMA = {
    "type": "object",
    "properties": {
        "joins": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "left": {"type": "string", "description": "qualified source column table.column"},
                    "right": {"type": "string", "description": "qualified source column table.column"},
                    "confidence": {"type": "number"},
                    "rationale": {"type": "string"},
                },
                "required": ["left", "right", "confidence", "rationale"],
            },
        },
        "mappings": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "target_field": {"type": "string", "description": "qualified target column table.column"},
                    "source_fields": {"type": "array", "items": {"type": "string"}, "description": "qualified source columns table.column"},
                    "reuse_code": {"type": "string", "description": "code of an existing library transformation to REUSE, or empty string if proposing new"},
                    "transform": {
                        "type": "object",
                        "properties": {
                            "op": {"type": "string", "enum": _MULTI_OPS},
                            "source": {"type": "string"},
                            "sources": {"type": "array", "items": {"type": "string"}},
                            "to": {"type": "string"},
                            "separator": {"type": "string"},
                            "format": {"type": "string"},
                            "value": {"type": "string"},
                            "expr": {"type": "string"},
                        },
                        "required": ["op"],
                    },
                    "confidence": {"type": "number"},
                    "rationale": {"type": "string"},
                },
                "required": ["target_field", "source_fields", "reuse_code", "transform", "confidence", "rationale"],
            },
        },
    },
    "required": ["joins", "mappings"],
}

_MULTI_SYSTEM = """You are a data-mapping assistant for an enterprise transformation platform.
You are given MULTIPLE source tables and MULTIPLE target tables. Every column is referenced as a
QUALIFIED name `table.column`. Columns marked [KEY] are primary keys or foreign/reference keys. Do:
  1. JOINS: infer how the source tables relate — foreign/reference keys linking one source table to
     another (e.g. `raw_account.customer_ref` = `raw_customer.cust_id`). Return each as left/right
     qualified columns with a confidence + rationale. Only propose joins you're reasonably sure of.
  2. MAPPINGS: for EVERY target column, propose how to derive it from source column(s). A target
     column MAY draw from a source table OTHER than its "own" — e.g. a dim_account row needs the
     customer name from raw_customer via the join key. `source_fields` and the transform's
     source/sources MUST be qualified `table.column` names. Ops: rename, cast, default, concat,
     arithmetic, case, date_format, expr. Cast when types differ.
  3. KEY COLUMNS — never omit these; they are the whole point of a dimensional model:
     - A SURROGATE primary key (e.g. dim_customer.customer_key, a bigint with no matching source
       column) is DERIVED, not copied: use op "expr" with a deterministic hash of the natural/business
       key, e.g. expr "xxhash64(RAW_CUSTOMER_MASTER.CUSTOMER_ID)"; source_fields = that natural key.
     - A FOREIGN key to another target dim (e.g. dim_address.customer_key → dim_customer's surrogate)
       is derived the SAME way from the SAME natural key on this row's source, so the FK matches the
       parent's surrogate: op "expr", expr "xxhash64(<source natural key on this table>)". Reference
       the join to find the right natural key column.
     - If a business/natural key exists on the source (e.g. CUSTOMER_ID string), map it straight
       through (rename/cast).
     Qualify EVERY column in expr as table.column. Provide 0..1 confidence + short rationale each.
Return ONLY JSON. Prefer a low-confidence proposal with a clear rationale over omitting a column."""


def suggest_mappings_multi(
    source_tables: list[dict[str, Any]],
    target_tables: list[dict[str, Any]],
    exemplars: list[dict[str, Any]] | None = None,
    transform_catalog: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Multi-table suggest. `source_tables`/`target_tables` items: {name, fields:[{name,datatype,nullable,is_key?}]}.

    Returns {joins:[...], mappings:[{target_field,source_fields,reuse_code,transform,confidence,rationale}]}
    with all column refs QUALIFIED as table.column. `transform_catalog` is injected as a
    reuse-first catalog (reuse_code references an existing library transformation).
    """
    def _block(label: str, tables: list[dict]) -> str:
        out = [f"{label} TABLES:"]
        for t in tables:
            out.append(f"  {t['name']}:")
            for f in t.get("fields", []):
                key = " [KEY]" if f.get("is_key") or f.get("semantic_type") == "key" else ""
                null = "" if f.get("nullable", True) else " NOT NULL"
                out.append(f"    - {t['name']}.{f['name']}: {f['datatype']}{null}{key}")
        return "\n".join(out)

    prompt = (
        f"{_exemplar_block(exemplars or [])}"
        f"{_catalog_block(transform_catalog or [], 'TRANSFORMATION')}"
        f"{_block('SOURCE', source_tables)}\n\n"
        f"{_block('TARGET', target_tables)}\n\n"
        "Infer the joins across source tables, then propose the target-column mappings, "
        "reusing library transformations where they fit."
    )
    resp = _client().chat.completions.create(
        model=config.LLM_ENDPOINT,
        messages=[{"role": "system", "content": _MULTI_SYSTEM}, {"role": "user", "content": prompt}],
        response_format={"type": "json_schema", "json_schema": {"name": "multi_mappings", "schema": _MULTI_SCHEMA, "strict": True}},
        max_tokens=16384,
    )
    choice = resp.choices[0]
    content = choice.message.content or "{}"
    try:
        data = json.loads(content)
    except Exception as e:  # noqa: BLE001 — a truncated/length-capped response yields invalid JSON
        raise RuntimeError(
            f"AI returned unparseable JSON (finish_reason={getattr(choice, 'finish_reason', '?')}, "
            f"{len(content)} chars). The schema is likely too large for one response — "
            f"try fewer target tables. ({e})"
        )
    print(
        f"[suggest_multi] finish_reason={getattr(choice, 'finish_reason', '?')} "
        f"joins={len(data.get('joins', []))} mappings={len(data.get('mappings', []))} chars={len(content)}"
    )
    return {"joins": data.get("joins", []), "mappings": data.get("mappings", [])}


# --- library AI generators (Rule / Transformation / Validation wizards) ------

def _generate(system: str, user: str, schema: dict) -> dict:
    """Shared structured-output call for the library 'AI generate' actions."""
    resp = _client().chat.completions.create(
        model=config.LLM_ENDPOINT,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        response_format={"type": "json_schema", "json_schema": {"name": "gen", "schema": schema, "strict": True}},
        max_tokens=2048,
    )
    return json.loads(resp.choices[0].message.content or "{}")


_RULE_SCHEMA = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "description": {"type": "string"},
        "logic_sql": {"type": "string"},
        "logic_preview": {"type": "string"},
        "explanation": {"type": "string"},
        "sample_io": {"type": "array", "items": {"type": "object", "properties": {"input": {"type": "string"}, "output": {"type": "string"}}, "required": ["input", "output"]}},
    },
    "required": ["name", "description", "logic_sql", "logic_preview", "explanation", "sample_io"],
}


def generate_rule(description: str, rule_type: str, data_type: str) -> dict:
    return _generate(
        "You generate a reusable data transformation/validation RULE. Return a short Title-Case `name` "
        "(3-5 words, no quotes), a one-sentence `description`, concise Spark SQL logic, a short logic-preview "
        "template, a one-paragraph explanation, and 2-3 input/output samples. JSON only.",
        f"Rule type: {rule_type}. Data type: {data_type}. Requirement: {description}",
        _RULE_SCHEMA,
    )


_XFORM_SCHEMA = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "description": {"type": "string"},
        "logic_expr": {"type": "string"},
        "logic_sql": {"type": "string"},
        "explanation": {"type": "string"},
        "steps": {"type": "array", "items": {"type": "object", "properties": {"name": {"type": "string"}, "detail": {"type": "string"}}, "required": ["name", "detail"]}},
    },
    "required": ["name", "description", "logic_expr", "logic_sql", "explanation", "steps"],
}


def generate_transformation(description: str) -> dict:
    return _generate(
        "You design a reusable column TRANSFORMATION. Return a short Title-Case `name` (3-5 words, no quotes), "
        "a one-sentence `description` of what it does, a single-line expression, equivalent Spark SQL, a short "
        "explanation, and the ordered component steps. JSON only.",
        f"Requirement: {description}",
        _XFORM_SCHEMA,
    )


# --- per-column REGENERATE from human feedback (Designer detail panel) --------

_REGEN_XFORM_SCHEMA = {
    "type": "object",
    "properties": {
        "expr": {"type": "string", "description": "ONE Spark SQL expression producing the target column, referencing only the given source columns"},
        "rationale": {"type": "string"},
    },
    "required": ["expr", "rationale"],
}


def regenerate_transform(*, target_field: str, target_type: str, source_columns: list[str], current_expr: str | None, feedback: str) -> dict:
    """Regenerate ONE column's transform from human feedback. Returns {expr, rationale}.
    The caller lowers/sqlglot-gates `expr` before persisting (model proposes, code disposes)."""
    cols = ", ".join(source_columns) or "(none)"
    return _generate(
        "You revise ONE column's transformation for a data mapping based on the reviewer's feedback. "
        "Return a SINGLE Spark SQL expression (`expr`) that produces the target column, referencing ONLY the "
        "listed source columns (qualified `Table.Column` names must be kept exactly as given). Do NOT wrap in "
        "SELECT, do NOT alias, do NOT invent columns. Also return a one-line `rationale`. JSON only.",
        f"Target column: {target_field} ({target_type})\nSource columns available: {cols}\n"
        f"Current expression: {current_expr or '(none / direct)'}\n\nReviewer feedback: {feedback}\n\n"
        "Produce the improved expression.",
        _REGEN_XFORM_SCHEMA,
    )


_REGEN_VALID_SCHEMA = {
    "type": "object",
    "properties": {
        "logic": {"type": "string", "description": "a Spark SQL BOOLEAN expression TRUE for a valid row, referencing only the target column(s)"},
        "rationale": {"type": "string"},
    },
    "required": ["logic", "rationale"],
}


def regenerate_validation(*, column: str, current_logic: str | None, feedback: str) -> dict:
    """Regenerate ONE data-quality check's logic from feedback. Returns {logic, rationale}."""
    return _generate(
        "You revise ONE data-quality check based on the reviewer's feedback. Return `logic`: a Spark SQL BOOLEAN "
        "expression that is TRUE for a VALID row, referencing ONLY the given column. Do NOT wrap in SELECT/WHERE/"
        "COUNT, do NOT alias. Also return a one-line `rationale`. JSON only.",
        f"Column: {column}\nCurrent rule logic: {current_logic or '(none)'}\n\nReviewer feedback: {feedback}\n\n"
        "Produce the improved rule logic.",
        _REGEN_VALID_SCHEMA,
    )


_VALID_SCHEMA = {
    "type": "object",
    "properties": {
        "logic": {"type": "string"},
        "explanation": {"type": "string"},
        "checks": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["logic", "explanation", "checks"],
}


def generate_validation(description: str, rule_type: str, column: str) -> dict:
    return _generate(
        "You generate a DATA QUALITY validation rule. Return the rule logic (SQL boolean expression), a short "
        "explanation, and the list of things it checks. JSON only.",
        f"Rule type: {rule_type}. Column: {column}. Requirement: {description}",
        _VALID_SCHEMA,
    )


# --- transformation optimizer (AI Assistant "Optimize transformations") -------

_OPTIMIZE_SCHEMA = {
    "type": "object",
    "properties": {
        "optimizations": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    # The target column this optimization rewrites (must match input).
                    "target_field": {"type": "string"},
                    # Short kind tag for the UI badge.
                    "kind": {
                        "type": "string",
                        "enum": ["merge", "simplify", "cast", "readability", "other"],
                    },
                    "title": {"type": "string"},
                    "rationale": {"type": "string"},
                    # The proposed replacement as ONE Spark SQL expression over source columns.
                    "expr": {"type": "string"},
                    "impact": {"type": "string", "enum": ["high", "medium", "low"]},
                },
                "required": ["target_field", "kind", "title", "rationale", "expr", "impact"],
            },
        }
    },
    "required": ["optimizations"],
}

_OPTIMIZE_SYSTEM = """You are a Spark SQL optimization assistant for a data-mapping platform.
You are given, for each TARGET column, the source column(s) and its CURRENT derivation. A column may
list MORE THAN ONE current step (e.g. a rename AND a CASE) — those are separate transformers applied
to the same target that SHOULD be combined. Your PRIMARY job is to look for chances to merge multiple
transformers into ONE custom transformer, then to simplify. Every proposal must preserve the exact
output semantics. Opportunities, in priority order:
  - MERGE (most important): when a target column is produced by multiple steps/transformers, or a
    single derivation nests several ops, fold the WHOLE chain into ONE Spark SQL expression that
    yields the identical result. Combine chained CASE/rename/cast/concat/regex steps into one.
  - SIMPLIFY: remove redundant CASTs, no-op COALESCE, double functions, unnecessary nesting.
  - CAST/READABILITY: make an implicit cast explicit, or improve clarity without changing results.
For each optimization return the target_field (exactly as given), a kind, a short title, a one-line
rationale, an `impact`, and `expr` — the SINGLE replacement Spark SQL expression referencing ONLY the
listed source columns. When merging multiple steps for a column, `expr` is the one combined expression
that replaces ALL of them. Do NOT alias, do NOT wrap in SELECT, do NOT invent columns. Only include a
column if you can genuinely improve it; return an empty list if nothing is worth changing. Return ONLY JSON."""


def optimize_transformations(columns: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Propose per-column optimizations given each column's current derivation(s).

    `columns` items: {target_field, target_type, source_fields[], current_exprs[]}.
    `current_exprs` is a LIST — usually one expression, but MORE than one when the
    column is produced by several separate transformers (the merge case). The model
    is asked to combine multiple steps into one custom transformer where possible.
    Returns raw proposals: {target_field, kind, title, rationale, expr, impact}.
    The caller MUST deterministically validate each `expr` (parse + source-column
    existence) before surfacing it — the model proposes, it does not decide.
    Raises on transport/parse failure so the caller can surface it.
    """
    lines = ["Columns and their current derivations:"]
    for c in columns:
        srcs = ", ".join(c.get("source_fields") or []) or "(none)"
        exprs = c.get("current_exprs") or ([c["current_expr"]] if c.get("current_expr") else [])
        if len(exprs) > 1:
            steps = "; ".join(f"step {i + 1}: {e}" for i, e in enumerate(exprs))
            lines.append(
                f"  - target `{c['target_field']}` ({c.get('target_type', 'unknown')}) from [{srcs}] "
                f"has {len(exprs)} SEPARATE transformers to MERGE — {steps}"
            )
        else:
            lines.append(
                f"  - target `{c['target_field']}` ({c.get('target_type', 'unknown')}) "
                f"from [{srcs}]: {exprs[0] if exprs else ''}"
            )
    prompt = "\n".join(lines) + "\n\nPropose semantics-preserving optimizations."
    resp = _client().chat.completions.create(
        model=config.LLM_ENDPOINT,
        messages=[{"role": "system", "content": _OPTIMIZE_SYSTEM}, {"role": "user", "content": prompt}],
        response_format={
            "type": "json_schema",
            "json_schema": {"name": "optimizations", "schema": _OPTIMIZE_SCHEMA, "strict": True},
        },
        max_tokens=3072,
    )
    data = json.loads(resp.choices[0].message.content or "{}")
    return data.get("optimizations", [])


# --- mapping validator (AI Assistant "Validate mapping") ----------------------

_VALIDATE_SCHEMA = {
    "type": "object",
    "properties": {
        "validations": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    # The TARGET column this check guards (must match an input column).
                    "target_field": {"type": "string"},
                    "rule_type": {
                        "type": "string",
                        "enum": [
                            "completeness", "validity", "accuracy",
                            "uniqueness", "consistency", "business_rule",
                        ],
                    },
                    "severity": {"type": "string", "enum": ["critical", "high", "medium", "low"]},
                    "name": {"type": "string"},
                    "rationale": {"type": "string"},
                    # A Spark SQL BOOLEAN expression that is TRUE for a VALID row.
                    "logic": {"type": "string"},
                    "reuse_code": {"type": "string", "description": "code of an existing Rule Library rule to REUSE for this check, or empty string if proposing new"},
                },
                "required": ["target_field", "rule_type", "severity", "name", "rationale", "logic", "reuse_code"],
            },
        }
    },
    "required": ["validations"],
}

_VALIDATE_SYSTEM = """You are a data-quality assistant for an enterprise data-mapping platform.
You are given the TARGET columns of a mapping, each with its type and the transformation that
produces it, and a note on which columns already have a validation. Propose data-quality checks to
run on the TARGET data AFTER the transformation, so bad output is caught. Focus on:
  - the transformation's failure modes — a CAST that can yield NULL on bad input, a regex/parse that
    can drop data, a numeric field that should never be negative, a date that must be in range;
  - COMPLETENESS (NOT NULL on required columns), VALIDITY (format/domain, e.g. email regex, allowed
    codes), UNIQUENESS (ids/keys), ACCURACY/CONSISTENCY (ranges, cross-field rules), BUSINESS_RULE;
  - COVERAGE: prioritize columns that have NO validation yet, especially risky transformed ones.
Each check's `logic` MUST be a Spark SQL BOOLEAN expression that is TRUE for a VALID row, referencing
ONLY the given TARGET column name(s). Do NOT wrap in SELECT/WHERE/COUNT, do NOT alias, do NOT invent
columns. Pick a sensible rule_type and severity (critical for keys/ids, lower for cosmetic).
Propose AT MOST ONE check per column — the single most valuable one (NOT NULL on ids/keys and
required fields; a format/range check on transformed columns). Keep each `logic` short. Prefer
proposing a useful check over nothing; only omit a column if truly no meaningful check applies.
Return at most 24 checks total. JSON only."""


def suggest_validations(columns: list[dict[str, Any]], rule_catalog: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Propose post-transformation data-quality checks for a mapping's target columns.

    `columns` items: {target_field, target_type, transform_expr, has_validation(bool)}.
    Returns raw proposals: {target_field, rule_type, severity, name, rationale, logic, reuse_code}.
    `rule_catalog` (published Rule Library) is injected as a reuse-first catalog so the
    model prefers reusing a rule (via reuse_code) over inventing a new one. The caller
    MUST deterministically validate each `logic` before surfacing it.
    """
    lines = ["TARGET columns (name : type — transform — coverage):"]
    for c in columns:
        cov = "HAS a validation" if c.get("has_validation") else "NO validation yet"
        lines.append(
            f"  - {c['target_field']} : {c.get('target_type', 'unknown')} "
            f"— {c.get('transform_expr') or '(direct)'} — {cov}"
        )
    prompt = (
        f"{_catalog_block(rule_catalog or [], 'DATA-QUALITY RULE')}"
        + "\n".join(lines)
        + "\n\nPropose the data-quality checks to run after the transformation, reusing library rules where they fit."
    )
    resp = _client().chat.completions.create(
        model=config.LLM_ENDPOINT,
        messages=[{"role": "system", "content": _VALIDATE_SYSTEM}, {"role": "user", "content": prompt}],
        response_format={
            "type": "json_schema",
            "json_schema": {"name": "validations", "schema": _VALIDATE_SCHEMA, "strict": True},
        },
        # One check per column across ~24 wide columns needs headroom; too small a
        # budget truncates the JSON (finish_reason=length) and strict output returns {}.
        max_tokens=8192,
    )
    data = json.loads(resp.choices[0].message.content or "{}")
    return data.get("validations", [])


# --- dummy source-data generation (Agentic Mapping Validation, step 1) --------

_DUMMY_SCHEMA = {
    "type": "object",
    "properties": {
        "rows": {
            "type": "array",
            "items": {"type": "array", "items": {"type": ["string", "null"]}},
        }
    },
    "required": ["rows"],
}

_DUMMY_SYSTEM = """You generate realistic DUMMY test data for a source data model, to exercise a
data-mapping pipeline. You are given the source columns (name + type) and how many rows to produce.
Return `rows` as a JSON array; each row is an array of string values (or null) in the EXACT column
order given. Make the data realistic AND intentionally messy where the type/name implies raw
landing-zone data — mixed case, stray whitespace, mixed date formats, currency symbols/commas in
amounts, Y/N or 1/0 flags, occasional nulls/blanks, id prefixes — so downstream cleansing
transformations and data-quality checks are actually tested. Every value must be a STRING (or null);
do not emit numbers or booleans as JSON types. Return ONLY JSON matching the schema."""


def generate_dummy_rows(source_fields: list[dict[str, Any]], n: int = 25) -> list[list[str | None]]:
    """Return `n` dummy rows (list of string/null lists) matching the source columns' order."""
    cols = "\n".join(f"  {i + 1}. {f['name']} : {f.get('datatype', 'string')}" for i, f in enumerate(source_fields))
    prompt = f"Source columns (in order):\n{cols}\n\nGenerate {n} realistic, intentionally-messy rows."
    resp = _client().chat.completions.create(
        model=config.LLM_ENDPOINT,
        messages=[{"role": "system", "content": _DUMMY_SYSTEM}, {"role": "user", "content": prompt}],
        response_format={"type": "json_schema", "json_schema": {"name": "dummy", "schema": _DUMMY_SCHEMA, "strict": True}},
        max_tokens=8192,
    )
    data = json.loads(resp.choices[0].message.content or "{}")
    return data.get("rows", [])


# --- documentation narrative (AI Assistant "Generate documentation") ----------
# The doc's FACTS (tables, SQL, lineage, rules) are assembled deterministically by
# the route; the model only writes the PROSE layer around them, so nothing factual
# can be hallucinated.

_DOC_SCHEMA = {
    "type": "object",
    "properties": {
        "summary": {"type": "string"},          # executive-summary paragraph(s)
        "columns": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "target_field": {"type": "string"},
                    "description": {"type": "string"},  # one plain-English sentence
                },
                "required": ["target_field", "description"],
            },
        },
        "open_items": {"type": "array", "items": {"type": "string"}},  # narrative caveats
    },
    "required": ["summary", "columns", "open_items"],
}

_DOC_SYSTEM = """You are a technical writer documenting an enterprise data mapping specification.
You are given the mapping's header, its source→target column derivations (with the exact SQL that
produces each target column), and computed coverage facts. Write the PROSE layer of the spec:
  - `summary`: a concise executive summary (2-4 sentences) — what this mapping does, source→target
    systems, the shape of the transformation work, overall confidence/readiness. Business-readable.
  - `columns`: for EACH given target_field, ONE plain-English sentence describing how it is derived
    (translate the SQL into words a business analyst understands — e.g. "trimmed, title-cased first,
    middle and last names joined by spaces"). Use exactly the target_field names given.
  - `open_items`: short bullet notes on risks/gaps from the coverage facts (unmapped columns,
    low-confidence mappings, columns lacking a data-quality check). Empty list if none.
Do NOT invent columns, values, or SQL — describe only what is given. Keep each column description to
one sentence. Return ONLY JSON matching the schema."""


def generate_doc_narrative(header: dict[str, Any], columns: list[dict[str, Any]], coverage: dict[str, Any]) -> dict:
    """Return {summary, columns:[{target_field, description}], open_items[]} for a spec.

    `columns` items: {target_field, target_type, source_fields[], sql, confidence, has_validation}.
    Prose only — the caller supplies all facts. Raises on transport/parse failure.
    """
    hdr = ", ".join(f"{k}={v}" for k, v in header.items() if v is not None)
    lines = [f"MAPPING: {hdr}", "", "TARGET COLUMNS (name : type ← sources :: SQL):"]
    for c in columns:
        srcs = ", ".join(c.get("source_fields") or []) or "(none)"
        lines.append(f"  - {c['target_field']} : {c.get('target_type','?')} ← {srcs} :: {c.get('sql') or '(direct)'}")
    lines += ["", f"COVERAGE: {json.dumps(coverage)}"]
    prompt = "\n".join(lines) + "\n\nWrite the documentation prose."
    resp = _client().chat.completions.create(
        model=config.LLM_ENDPOINT,
        messages=[{"role": "system", "content": _DOC_SYSTEM}, {"role": "user", "content": prompt}],
        response_format={"type": "json_schema", "json_schema": {"name": "doc", "schema": _DOC_SCHEMA, "strict": True}},
        # One sentence per column across ~24 wide columns + summary needs headroom.
        max_tokens=8192,
    )
    return json.loads(resp.choices[0].message.content or "{}")
