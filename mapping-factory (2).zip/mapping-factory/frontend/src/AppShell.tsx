import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { Outlet } from "react-router-dom";
import { Sidebar } from "./components/Sidebar";
import { TopBar } from "./components/TopBar";
import { api } from "./api";

// Pages call usePage({title, subtitle, actions}) to drive the TopBar.
interface PageMeta {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}
const PageCtx = createContext<{ set: (m: PageMeta) => void; identity?: string; isAdmin?: boolean }>({ set: () => {} });

export function usePage(meta: PageMeta, deps: unknown[] = []) {
  const { set } = useContext(PageCtx);
  useEffect(() => {
    set(meta);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}
export function useIdentity() {
  return useContext(PageCtx).identity;
}
// Whether the current user is an administrator (admins bypass maker-checker).
export function useIsAdmin() {
  return useContext(PageCtx).isAdmin ?? false;
}

export function AppShell() {
  const [collapsed, setCollapsed] = useState(false);
  const [meta, setMeta] = useState<PageMeta>({ title: "Mapping Factory" });
  const [identity, setIdentity] = useState<string | undefined>();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    api.health().then((h) => setIdentity(h.identity)).catch(() => {});
    api.adminMe().then((r) => setIsAdmin(r.is_admin)).catch(() => {});
  }, []);

  return (
    <PageCtx.Provider value={{ set: setMeta, identity, isAdmin }}>
      <div className="h-full flex overflow-hidden">
        <Sidebar collapsed={collapsed} onToggle={() => setCollapsed((c) => !c)} />
        <div className="flex-1 flex flex-col min-w-0">
          <TopBar title={meta.title} subtitle={meta.subtitle} identity={identity} isAdmin={isAdmin} actions={meta.actions} />
          <main className="flex-1 overflow-y-auto bg-[#f6f7f9]">
            <Outlet />
          </main>
        </div>
      </div>
    </PageCtx.Provider>
  );
}
