-- Mapping Factory — operational (hot tier) schema on Lakebase / Postgres.
-- Idempotent: safe to run repeatedly. This is DRAFT/working state only; the
-- governed system-of-record for APPROVED artifacts lives in Unity Catalog/Delta.

CREATE SCHEMA IF NOT EXISTS mapping_factory;
SET search_path TO mapping_factory, public;

-- A source or target data object (both live here; a target may originate from a spec).
CREATE TABLE IF NOT EXISTS physical_asset (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         TEXT NOT NULL,
  system       TEXT,
  locator      TEXT,                              -- e.g. catalog.schema.table
  object_type  TEXT NOT NULL,                     -- uc_table | uploaded_csv | ddl | target_schema
  role         TEXT NOT NULL,                     -- source | target
  created_by   TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS physical_field (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id       UUID NOT NULL REFERENCES physical_asset(id) ON DELETE CASCADE,
  name           TEXT NOT NULL,
  datatype       TEXT NOT NULL,
  nullable       BOOLEAN NOT NULL DEFAULT true,
  ordinal        INT,
  semantic_type  TEXT,
  sample_profile JSONB
);
CREATE INDEX IF NOT EXISTS ix_field_asset ON physical_field(asset_id);

-- A governed unit of work: maps one source asset to one target asset.
CREATE TABLE IF NOT EXISTS mapping_spec (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name               TEXT NOT NULL,
  source_asset_id    UUID REFERENCES physical_asset(id),
  target_asset_id    UUID REFERENCES physical_asset(id),
  status             TEXT NOT NULL DEFAULT 'Draft',  -- Draft|Proposed|Approving|Approved|Rejected
  version_no         INT  NOT NULL DEFAULT 1,
  owner              TEXT NOT NULL,                  -- the maker
  delta_content_hash TEXT,                           -- pointer to Delta snapshot, set on approval
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One target field's derivation.
CREATE TABLE IF NOT EXISTS transform_rule (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  kind            TEXT NOT NULL,                     -- spec | sql_expr
  spec_json       JSONB,                             -- declarative rule (when kind=spec)
  sql_expression  TEXT,                              -- escape hatch (when kind=sql_expr)
  ast_fingerprint TEXT,
  description     TEXT,
  test_cases      JSONB
);

-- Many-to-many: a spec can span MULTIPLE source and target tables (assets). The
-- primary (first) table of each side is still stored on mapping_spec.source/target_asset_id
-- for back-compat with single-table flows; this table holds the full set.
CREATE TABLE IF NOT EXISTS mapping_spec_asset (
  spec_id  UUID NOT NULL REFERENCES mapping_spec(id) ON DELETE CASCADE,
  asset_id UUID NOT NULL REFERENCES physical_asset(id) ON DELETE CASCADE,
  role     TEXT NOT NULL,                    -- source | target
  PRIMARY KEY (spec_id, asset_id)
);
CREATE INDEX IF NOT EXISTS ix_spec_asset ON mapping_spec_asset(spec_id);

CREATE TABLE IF NOT EXISTS field_mapping (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  spec_id           UUID NOT NULL REFERENCES mapping_spec(id) ON DELETE CASCADE,
  target_field_id   UUID NOT NULL REFERENCES physical_field(id),
  source_field_ids  UUID[] NOT NULL DEFAULT '{}',
  transform_rule_id UUID REFERENCES transform_rule(id),
  confidence        REAL,
  provenance        JSONB NOT NULL,                  -- {origin:AI|HUMAN, model_id, model_version, evidence[]}
  state             TEXT NOT NULL DEFAULT 'suggested' -- suggested|accepted|edited|rejected
);
CREATE INDEX IF NOT EXISTS ix_mapping_spec ON field_mapping(spec_id);

-- Maker-checker instances.
CREATE TABLE IF NOT EXISTS approval_task (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  spec_id    UUID NOT NULL REFERENCES mapping_spec(id) ON DELETE CASCADE,
  maker      TEXT NOT NULL,
  checker    TEXT,
  decision   TEXT,                                   -- approved|changes_requested|rejected
  rationale  TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ix_approval_spec ON approval_task(spec_id);

-- Learning signal (seeds later self-learning tiers).
CREATE TABLE IF NOT EXISTS feedback_event (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  field_mapping_id UUID,
  action           TEXT NOT NULL,                    -- accept|edit|reject
  ai_candidate     JSONB,
  human_value      JSONB,
  actor            TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Reviewer/author discussion on a mapping, scoped by section (Mapping /
-- Transformations / Validations / General) so the Comments tab can group them.
CREATE TABLE IF NOT EXISTS mapping_comment (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  spec_id    UUID NOT NULL REFERENCES mapping_spec(id) ON DELETE CASCADE,
  section    TEXT NOT NULL DEFAULT 'General',   -- General|Mapping|Transformations|Validations|Lineage
  author     TEXT NOT NULL,
  body       TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_comment_spec ON mapping_comment(spec_id);

-- Display metadata for the Mapping List/Details screens. Nullable so the real
-- compiler/governance flow (which sets source/target via assets) is unaffected;
-- seeded demo specs populate these for a rich list view.
ALTER TABLE mapping_spec ADD COLUMN IF NOT EXISTS description   TEXT;
ALTER TABLE mapping_spec ADD COLUMN IF NOT EXISTS source_system TEXT;
ALTER TABLE mapping_spec ADD COLUMN IF NOT EXISTS target_system TEXT;
ALTER TABLE mapping_spec ADD COLUMN IF NOT EXISTS mapping_type  TEXT;
ALTER TABLE mapping_spec ADD COLUMN IF NOT EXISTS ai_confidence REAL;
-- AI-proposed join keys across source tables (multi-table mappings).
ALTER TABLE mapping_spec ADD COLUMN IF NOT EXISTS joins JSONB;

-- Visual canvas state ONLY — never domain truth. Keyed by spec.
CREATE TABLE IF NOT EXISTS canvas_layout (
  spec_id  UUID PRIMARY KEY REFERENCES mapping_spec(id) ON DELETE CASCADE,
  nodes    JSONB,
  edges    JSONB,
  viewport JSONB
);

-- ============================================================================
-- UI-revamp domains (Rule Library, Transformations, Validation, Metadata,
-- Execution Monitor, activity feed). Seeded with one consistent dataset.
-- Text ids (code) are used so the seed can cross-reference deterministically.
-- ============================================================================

CREATE TABLE IF NOT EXISTS rule (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  code          TEXT UNIQUE NOT NULL,
  rule_type     TEXT NOT NULL,            -- business|standardization|validation|derivation|custom
  domain        TEXT,
  data_type     TEXT,
  description   TEXT,
  logic_sql     TEXT,
  logic_preview TEXT,
  sample_io     JSONB,                    -- [{input, output}]
  owner         TEXT,
  status        TEXT NOT NULL DEFAULT 'Draft',   -- Draft|Approved|In Review|Published
  version       TEXT DEFAULT '1.0',
  usage_count   INT DEFAULT 0,
  tags          TEXT[] DEFAULT '{}',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS transformation (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  code          TEXT UNIQUE NOT NULL,
  ttype         TEXT NOT NULL,            -- custom|library|ai_assisted
  category      TEXT,                     -- string|date|numeric|conversion|other
  description   TEXT,
  logic_expr    TEXT,
  logic_sql     TEXT,
  test_cases    JSONB,                    -- [{name, input, output, pass}]
  owner         TEXT,
  status        TEXT NOT NULL DEFAULT 'Draft',   -- Draft|Published|Review
  reuse_count   INT DEFAULT 0,
  tags          TEXT[] DEFAULT '{}',
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Maker-checker governance on transformations (Draft→Proposed→Published / Rejected).
-- A SIDECAR table (not ALTER on `transformation`) because the app service principal
-- has DML grants but is not the owner of the pre-existing `transformation` table, so
-- ALTER is denied — whereas a freshly-created table is SP-owned and fully writable.
-- One row per transformation, upserted on submit/decide; joined into list/get.
CREATE TABLE IF NOT EXISTS transformation_governance (
  transformation_id UUID PRIMARY KEY,
  submitted_by      TEXT,
  approved_by       TEXT,
  rationale         TEXT,
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Maker-checker governance on validation rules (Draft→Proposed→Published / Rejected).
-- Sidecar (not ALTER on validation_rule) — same ownership constraint as transformations.
CREATE TABLE IF NOT EXISTS validation_governance (
  validation_id UUID PRIMARY KEY,
  submitted_by  TEXT,
  approved_by   TEXT,
  rationale     TEXT,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Maker-checker governance on Rule Library rules (Draft→Proposed→Published / Rejected).
CREATE TABLE IF NOT EXISTS rule_governance (
  rule_id      UUID PRIMARY KEY,
  submitted_by TEXT,
  approved_by  TEXT,
  rationale    TEXT,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Git credentials for Deploy-as-Pipeline. token_encrypted is Fernet-encrypted (see
-- server/crypto.py); never store the raw PAT. One row per (user, provider) — SP-owned.
CREATE TABLE IF NOT EXISTS git_credential (
  user_name       TEXT NOT NULL,
  provider        TEXT NOT NULL DEFAULT 'github',
  git_username    TEXT,
  token_encrypted TEXT NOT NULL,
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_name, provider)
);

-- Administration: admin users bypass maker-checker (they may approve their own
-- mappings/transformations) and are the only ones who can manage the admin list.
-- SP-owned (freshly created here) so the app can write it without table ownership.
CREATE TABLE IF NOT EXISTS admin_user (
  user_name  TEXT PRIMARY KEY,
  added_by   TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS validation_rule (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name           TEXT NOT NULL,
  code           TEXT UNIQUE NOT NULL,
  rule_type      TEXT NOT NULL,           -- completeness|validity|accuracy|business_rule|consistency|uniqueness|referential
  dataset        TEXT,
  column_name    TEXT,
  severity       TEXT NOT NULL,           -- critical|high|medium|low
  description    TEXT,
  logic          TEXT,
  owner          TEXT,
  status         TEXT NOT NULL DEFAULT 'Active',
  last_run_at    TIMESTAMPTZ,
  last_status    TEXT,                    -- Passed|Failed
  success_rate   REAL,
  failed_records INT DEFAULT 0,
  tags           TEXT[] DEFAULT '{}',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Pipeline DQ routing action: 'fail' => a violating row is quarantined (kept out of the
-- target); 'warn' => the row still lands in the target, the violation is only logged.
-- AI suggests a default per rule_type; a human can change it in the Designer.
-- SP-OWNED SIDECAR (not an ALTER on validation_rule): the app service principal can't
-- ALTER pre-existing tables it doesn't own, so a new column silently fails to apply.
-- LEFT-JOINed into reads; rows without a sidecar row fall back to the rule_type default.
CREATE TABLE IF NOT EXISTS validation_dq (
  validation_id UUID PRIMARY KEY,
  dq_action     TEXT NOT NULL DEFAULT 'warn',   -- warn | fail
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS validation_run (
  id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_name  TEXT NOT NULL,
  cadence   TEXT,                         -- Daily|Hourly|Adhoc
  passed_pct REAL,
  run_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS glossary_term (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name       TEXT NOT NULL,
  definition TEXT,
  term_type  TEXT NOT NULL DEFAULT 'business_term',   -- business_term|business_rule
  domain     TEXT,
  steward    TEXT
);

CREATE TABLE IF NOT EXISTS source_system (
  code        TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  asset_count INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS data_asset (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         TEXT NOT NULL,
  asset_type   TEXT NOT NULL,            -- table|column|report|dashboard|pipeline|data_product|business_term
  system       TEXT,
  domain       TEXT,
  criticality  TEXT,                     -- Critical|High|Medium|Low
  owner        TEXT,
  tags         TEXT[] DEFAULT '{}',
  description  TEXT,
  impact_score INT,
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS metadata_edge (
  id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  src_name  TEXT NOT NULL,
  src_type  TEXT,
  dst_name  TEXT NOT NULL,
  dst_type  TEXT,
  edge_type TEXT
);

-- Provenance for auto-indexed metadata: rows created by publishing a mapping carry
-- its spec_id so re-indexing that spec replaces only its own rows (seeded rows have
-- NULL spec_id and are never touched). Nullable + idempotent.
ALTER TABLE data_asset   ADD COLUMN IF NOT EXISTS spec_id UUID;
ALTER TABLE metadata_edge ADD COLUMN IF NOT EXISTS spec_id UUID;
CREATE INDEX IF NOT EXISTS ix_data_asset_spec ON data_asset(spec_id);
CREATE INDEX IF NOT EXISTS ix_metadata_edge_spec ON metadata_edge(spec_id);

CREATE TABLE IF NOT EXISTS execution (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_name     TEXT NOT NULL,
  status            TEXT NOT NULL,       -- running|succeeded|failed|warning
  duration_sec      INT,
  cost              NUMERIC,
  row_count         BIGINT,
  validation_status TEXT,
  error             TEXT,
  started_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS activity (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor       TEXT,
  action      TEXT NOT NULL,
  target      TEXT,
  target_type TEXT,
  at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
