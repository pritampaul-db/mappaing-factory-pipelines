# Mapping Factory

A metadata-driven transformation platform that turns source → target data mappings
(source PDFs / DDL / Unity Catalog tables into governed target schemas) into runnable,
auditable Spark SQL — following an **AI-proposes, deterministic-code-disposes** pattern.

## Why

Hand-writing and maintaining transformation logic across dozens of tables is slow,
error-prone, and undocumented. Mapping Factory collapses that manual STM/ETL work into
an AI-drafted, human-reviewed flow with built-in lineage, validation, and governance —
where an LLM only ever *proposes*, and a deterministic compiler (no LLM) emits
byte-identical, type-checked SQL so nothing factual can be hallucinated.

## What it does

- **AI mapping suggestions** — proposes field mappings, cross-table joins, transforms,
  and data-quality checks; humans review and approve.
- **Multi-source → multi-target** — many source tables joined into many target tables,
  with AI-proposed join keys. Single-table mappings work unchanged.
- **Deterministic compiler** — approved mappings compile to reproducible, hash-stamped
  Spark SQL with column-level lineage and generated tests.
- **Governance** — maker-checker approval with segregation of duties; an immutable
  Delta system-of-record as the governed truth tier.
- **Agentic validation** — generates dummy data, runs a real SDP test pipeline, and
  validates the joined output end-to-end.
- **Docs & metadata** — auto-generated mapping specification documents and Metadata
  Explorer indexing on publish.

## Stack

- **Backend** — FastAPI (Python), deployed as a Databricks App.
- **Frontend** — React + Vite SPA (built to `app/frontend/dist`).
- **Data** — Lakebase (Postgres) hot tier for drafts; Unity Catalog + Delta governed
  tier for approved artifacts; serverless SQL warehouse for compile/verify.
- **AI** — Databricks Foundation Model endpoints; Knowledge Assistant for explainability.

## Layout

| Path | What |
|------|------|
| `app/` | The Databricks App (backend + frontend + SDP pipeline). |
| `app/server/` | FastAPI backend: compiler, governance, LLM, agentic validation, routes. |
| `app/frontend/` | React SPA. |
| `MappingFactory_Architecture_v1.md` | Architecture design + decisions. |
| `MappingFactory_PRD_v2.md` | Product requirements. |

See [`app/README.md`](app/README.md) for local dev and deployment details.
