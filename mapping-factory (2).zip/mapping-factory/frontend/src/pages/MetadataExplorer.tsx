import { useEffect, useMemo, useState } from "react";
import { ReactFlow, Background, Controls, MarkerType, type Node, type Edge } from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { BookOpen, Database, Table2, Columns3, BarChart3, GitBranch } from "lucide-react";
import { usePage } from "../AppShell";
import { api, type MetadataSummary, type MetaAsset, type GlossaryTerm } from "../api";
import { Card, Tabs } from "../components/primitives";
import { DonutChart, LegendList } from "../components/charts";
import { timeAgo } from "../theme";

const KPI_ICONS = [BookOpen, Database, Table2, Columns3, BarChart3, GitBranch];
// Per-KPI icon color + tint (matches the wireframe's red/purple alternation).
const KPI_COLORS = [
  { color: "#dc2626", tint: "#fef2f2" }, // Business Terms — red
  { color: "#a855f7", tint: "#faf5ff" }, // Data Assets — purple
  { color: "#dc2626", tint: "#fef2f2" }, // Tables — red
  { color: "#a855f7", tint: "#faf5ff" }, // Columns — purple
  { color: "#dc2626", tint: "#fef2f2" }, // Reports & Dashboards — red
  { color: "#ea580c", tint: "#fff7ed" }, // Pipelines — orange
];

// Node color by asset/entity type for the relationship graph.
const TYPE_COLOR: Record<string, string> = {
  business_term: "#16a34a",
  table: "#c9252d",
  mapping: "#d97706",
  pipeline: "#a855f7",
  report: "#2563eb",
  dashboard: "#0891b2",
};

export function MetadataExplorer() {
  const [sum, setSum] = useState<MetadataSummary | null>(null);
  const [assets, setAssets] = useState<MetaAsset[]>([]);
  const [glossary, setGlossary] = useState<GlossaryTerm[]>([]);
  const [graph, setGraph] = useState<{ nodes: { name: string; type: string }[]; edges: { source: string; target: string; type: string }[] }>({ nodes: [], edges: [] });
  const [catalogTab, setCatalogTab] = useState("Recent");

  usePage({ title: "Metadata Explorer", subtitle: "Discover, explore and understand all your data assets" });

  useEffect(() => {
    api.metadataSummary().then(setSum);
    api.metadataAssets().then(setAssets);
    api.metadataGlossary().then(setGlossary);
    api.metadataGraph().then(setGraph);
  }, []);

  // Lay the graph out left→right by dependency depth (BFS from roots).
  const { nodes, edges } = useMemo(() => {
    const depth = new Map<string, number>();
    const incoming = new Map<string, number>();
    graph.nodes.forEach((n) => incoming.set(n.name, 0));
    graph.edges.forEach((e) => incoming.set(e.target, (incoming.get(e.target) ?? 0) + 1));
    const queue = graph.nodes.filter((n) => (incoming.get(n.name) ?? 0) === 0).map((n) => n.name);
    queue.forEach((n) => depth.set(n, 0));
    let guard = 0;
    while (queue.length && guard++ < 500) {
      const cur = queue.shift()!;
      const d = depth.get(cur) ?? 0;
      graph.edges.filter((e) => e.source === cur).forEach((e) => {
        if (!depth.has(e.target) || (depth.get(e.target) ?? 0) < d + 1) {
          depth.set(e.target, d + 1);
          queue.push(e.target);
        }
      });
    }
    const perCol: Record<number, number> = {};
    const rfNodes: Node[] = graph.nodes.map((n) => {
      const d = depth.get(n.name) ?? 0;
      const row = perCol[d] ?? 0;
      perCol[d] = row + 1;
      const color = TYPE_COLOR[n.type] ?? "#6b7280";
      return {
        id: n.name,
        position: { x: d * 220, y: row * 90 },
        data: { label: n.name },
        style: { border: `1px solid ${color}`, borderRadius: 8, background: "#fff", fontSize: 11, padding: 6, width: 170, color: "#1f2937" },
      };
    });
    const rfEdges: Edge[] = graph.edges.map((e, i) => ({
      id: `${e.source}-${e.target}-${i}`,
      source: e.source,
      target: e.target,
      label: e.type,
      style: { stroke: "#cbd5e1" },
      markerEnd: { type: MarkerType.ArrowClosed, color: "#cbd5e1" },
      labelStyle: { fontSize: 9, fill: "#94a3b8" },
    }));
    return { nodes: rfNodes, edges: rfEdges };
  }, [graph]);

  return (
    <div className="p-6 space-y-4">
      <Tabs tabs={["Overview", "Business Glossary", "Data Assets", "Reports & Dashboards", "Pipelines", "Domains"]} active="Overview" onChange={() => {}} />

      {/* Empty state — the catalog is populated by PUBLISHING mappings; nothing yet. */}
      {sum && (sum.kpis.every((k) => !k.value)) && (
        <div className="bg-blue-50/60 border border-blue-100 rounded-xl px-4 py-3 text-sm text-gray-600">
          No published metadata yet. Assets, glossary terms and the relationship graph are indexed automatically when a mapping is <span className="font-medium">published</span>.
        </div>
      )}

      {/* KPI row */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        {sum?.kpis.map((k, i) => {
          const Icon = KPI_ICONS[i % KPI_ICONS.length];
          const c = KPI_COLORS[i % KPI_COLORS.length];
          return (
            <div key={k.label} className="bg-white rounded-xl border border-gray-200 p-3">
              <div className="flex items-center gap-2">
                <span className="w-9 h-9 rounded-lg grid place-items-center shrink-0" style={{ background: c.tint, color: c.color }}><Icon className="w-4 h-4" /></span>
                <div><div className="text-[11px] text-gray-500">{k.label}</div><div className="text-lg font-semibold text-gray-900">{k.value.toLocaleString()}</div></div>
              </div>
              {k.delta && <div className="text-[11px] text-green-600 mt-1">▲ {k.delta}</div>}
            </div>
          );
        })}
      </div>

      {/* 3-column row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card title="Business Domain">
          {sum && (
            <>
              <DonutChart data={sum.domains} totalLabel="Total Assets" />
              <div className="mt-3"><LegendList data={sum.domains} /></div>
            </>
          )}
        </Card>

        <Card title="Asset Catalog">
          <Tabs tabs={["Recent", "Most Viewed", "Recently Updated"]} active={catalogTab} onChange={setCatalogTab} />
          <ul className="mt-2 space-y-2.5">
            {assets.slice(0, 7).map((a) => (
              <li key={a.name} className="flex items-start justify-between">
                <div className="min-w-0">
                  <div className="text-sm text-gray-800 truncate">{a.name}</div>
                  <div className="text-xs text-gray-400 capitalize">{a.asset_type} · {a.system}</div>
                </div>
                <div className="text-right shrink-0 ml-2">
                  {a.criticality && (
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${a.criticality === "Critical" ? "bg-red-100 text-red-700" : a.criticality === "High" ? "bg-orange-100 text-orange-700" : "bg-gray-100 text-gray-600"}`}>{a.criticality}</span>
                  )}
                  <div className="text-[10px] text-gray-400 mt-0.5">{timeAgo(a.updated_at)}</div>
                </div>
              </li>
            ))}
          </ul>
        </Card>

        <div className="space-y-4">
          <Card title="Business Glossary">
            <ul className="space-y-2.5">
              {glossary.slice(0, 5).map((t) => (
                <li key={t.name} className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-sm text-gray-800">{t.name}</div>
                    <div className="text-xs text-gray-400 line-clamp-1">{t.definition}</div>
                  </div>
                  <span className="text-[10px] text-brand shrink-0">{t.term_type === "business_rule" ? "Business Rule" : "Business Term"}</span>
                </li>
              ))}
            </ul>
          </Card>
          <Card title="Data Source Systems">
            <ul className="space-y-2">
              {sum?.systems.map((s) => (
                <li key={s.code} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2"><Database className="w-3.5 h-3.5 text-gray-400" /><span className="text-gray-700">{s.code}</span></div>
                  <span className="text-xs text-gray-400">{s.assets} Assets</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>

      {/* Relationship graph */}
      <Card title="Metadata Relationship Graph">
        <div className="flex flex-wrap gap-3 mb-2 text-xs">
          {Object.entries(TYPE_COLOR).map(([type, color]) => (
            <span key={type} className="flex items-center gap-1 text-gray-600">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: color }} /> {type.replace("_", " ")}
            </span>
          ))}
        </div>
        <div style={{ height: 340 }} className="border border-gray-100 rounded-lg">
          <ReactFlow nodes={nodes} edges={edges} fitView proOptions={{ hideAttribution: true }} nodesDraggable={false}>
            <Background color="#eef2f7" gap={16} />
            <Controls showInteractive={false} />
          </ReactFlow>
        </div>
      </Card>
    </div>
  );
}
