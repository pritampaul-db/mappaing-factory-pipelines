import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Eye, Copy, MoreVertical, Map as MapIcon, FileText, UserCheck, Sparkles, CheckCircle2, Ban, Trash2, X, Rocket } from "lucide-react";
import { usePage, useIdentity } from "../../AppShell";
import { api, type SpecRow } from "../../api";
import { Button, Tabs, StatusBadge, ConfidenceBar, Avatar } from "../../components/primitives";
import { DataTable, LinkCell, type Column } from "../../components/DataTable";
import { DeployPipelineWizard } from "./DeployPipelineWizard";

const TABS = ["All Mappings", "My Mappings", "AI Suggested", "Draft", "Pending Approval", "Published"];

// Governance statuses (Draft→Proposed→Approving→Approved / Rejected) mapped to the
// display buckets the tabs use. "Pending Approval" and "Published" are the display
// names; the real lifecycle uses Proposed/Approving and Approved.
const PENDING_STATUSES = new Set(["Pending Approval", "Proposed", "Approving", "In Review"]);
const PUBLISHED_STATUSES = new Set(["Published", "Approved", "Live"]);
// A mapping is "AI-authored" when its columns are predominantly AI-origin and it's
// confident — the useful reading of the AI Suggested tab.
const isAiSuggested = (r: SpecRow) =>
  r.status === "AI Suggested" ||
  ((r.ai_authored ?? 0) >= 0.6 && (r.ai_confidence ?? 0) >= 0.8 && (r.mapping_count ?? 0) > 0);

export function MappingList() {
  const nav = useNavigate();
  const identity = useIdentity();
  // spec.owner is stored as the RAW identity (email / service-principal id) — the
  // same value health returns — so "My Mappings" matches on that, not the pretty name.
  const me = (identity ?? "").toLowerCase();
  const [rows, setRows] = useState<SpecRow[]>([]);
  const [tab, setTab] = useState(TABS[0]);
  const [err, setErr] = useState<string | null>(null);
  const [menuId, setMenuId] = useState<string | null>(null);   // row whose ⋮ menu is open
  const [confirmDel, setConfirmDel] = useState<SpecRow | null>(null);
  const [deployRow, setDeployRow] = useState<SpecRow | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const reload = () => api.listSpecs().then(setRows).catch((e) => setErr(String(e)));

  const clone = async (r: SpecRow) => {
    setMenuId(null); setBusyId(r.id);
    try {
      const created = await api.cloneSpec(r.id);
      await reload();
      nav(`/mappings/${created.id}/edit`);
    } catch (e) {
      setErr(String(e));
    } finally {
      setBusyId(null);
    }
  };

  const doDelete = async (r: SpecRow) => {
    setConfirmDel(null); setBusyId(r.id);
    try {
      await api.deleteSpec(r.id);
      await reload();
    } catch (e) {
      setErr(String(e));
    } finally {
      setBusyId(null);
    }
  };

  usePage({
    title: "Mapping Studio – Mapping List",
    subtitle: "Create, manage and govern all your mappings",
    actions: (
      <Button onClick={() => nav("/mappings/new")}>
        <Plus className="w-4 h-4" /> New Mapping
      </Button>
    ),
  });

  useEffect(() => { reload(); }, []);
  // Close any open row menu on an outside click.
  useEffect(() => {
    if (!menuId) return;
    const close = () => setMenuId(null);
    window.addEventListener("click", close);
    return () => window.removeEventListener("click", close);
  }, [menuId]);

  const filtered = useMemo(() => {
    switch (tab) {
      case "All Mappings": return rows;
      case "My Mappings": return rows.filter((r) => (r.owner ?? "").toLowerCase() === me);
      case "AI Suggested": return rows.filter(isAiSuggested);
      case "Draft": return rows.filter((r) => r.status === "Draft");
      case "Pending Approval": return rows.filter((r) => PENDING_STATUSES.has(r.status));
      case "Published": return rows.filter((r) => PUBLISHED_STATUSES.has(r.status));
      default: return rows;
    }
  }, [rows, tab, me]);

  const kpis = useMemo(() => {
    const countPending = rows.filter((r) => PENDING_STATUSES.has(r.status)).length;
    const countPublished = rows.filter((r) => PUBLISHED_STATUSES.has(r.status)).length;
    return [
      { icon: MapIcon, label: "Total Mappings", value: rows.length },
      { icon: FileText, label: "Draft", value: rows.filter((r) => r.status === "Draft").length },
      { icon: UserCheck, label: "Pending Approval", value: countPending },
      { icon: Sparkles, label: "AI Suggested", value: rows.filter(isAiSuggested).length },
      { icon: CheckCircle2, label: "Published", value: countPublished },
      { icon: Ban, label: "Deprecated", value: rows.filter((r) => r.status === "Deprecated" || r.status === "Rejected").length },
    ];
  }, [rows]);

  // Draft mappings open in the Studio to keep building; everything else opens the
  // read-only Details view (where a reviewer approves a pending one).
  const openSpec = (r: SpecRow) => nav(r.status === "Draft" ? `/mappings/${r.id}/edit` : `/mappings/${r.id}`);

  const columns: Column<SpecRow>[] = [
    {
      key: "name",
      header: "Mapping Name",
      sortValue: (r) => r.name,
      render: (r) => <LinkCell title={r.name} subtitle={r.description ?? undefined} />,
    },
    {
      key: "source",
      header: "Source System",
      render: (r) => <div className="text-gray-700">{r.source_system ?? "—"}</div>,
      sortValue: (r) => r.source_system ?? "",
    },
    {
      key: "target",
      header: "Target System",
      render: (r) => <div className="text-gray-700">{r.target_system ?? "—"}</div>,
      sortValue: (r) => r.target_system ?? "",
    },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} />, sortValue: (r) => r.status },
    { key: "type", header: "Mapping Type", render: (r) => <span className="text-gray-600">{r.mapping_type ?? "—"}</span> },
    { key: "conf", header: "AI Confidence", width: "150px", render: (r) => <ConfidenceBar value={r.ai_confidence} />, sortValue: (r) => r.ai_confidence ?? 0 },
    {
      key: "updated",
      header: "Updated On",
      sortValue: (r) => r.updated_at ?? "",
      render: (r) => <span className="text-gray-500 text-xs">{r.updated_at ? new Date(r.updated_at).toLocaleDateString() : "—"}</span>,
    },
    { key: "owner", header: "Owner", render: (r) => <Avatar name={r.owner} /> },
    {
      key: "actions",
      header: "Actions",
      render: (r) => (
        <div className="flex items-center gap-2 text-gray-400 relative" onClick={(e) => e.stopPropagation()}>
          <button className="hover:text-gray-700 disabled:opacity-40" title="Open" onClick={() => openSpec(r)} disabled={busyId === r.id}>
            <Eye className="w-4 h-4" />
          </button>
          <button className="hover:text-gray-700 disabled:opacity-40" title="Clone" onClick={() => clone(r)} disabled={busyId === r.id}>
            <Copy className="w-4 h-4" />
          </button>
          <button className="hover:text-gray-700" title="More" onClick={(e) => { e.stopPropagation(); setMenuId(menuId === r.id ? null : r.id); }}>
            <MoreVertical className="w-4 h-4" />
          </button>
          {menuId === r.id && (
            <div className="absolute right-0 top-6 z-20 w-48 bg-white border border-gray-200 rounded-lg shadow-lg py-1 text-sm" onClick={(e) => e.stopPropagation()}>
              {/* Deploy is only for APPROVED mappings — not Draft / Pending. */}
              {PUBLISHED_STATUSES.has(r.status) && (
                <button className="w-full text-left px-3 py-1.5 hover:bg-brand-soft/40 flex items-center gap-2 text-gray-700" onClick={() => { setMenuId(null); setDeployRow(r); }}>
                  <Rocket className="w-3.5 h-3.5 text-brand" /> Deploy as Pipeline
                </button>
              )}
              <button className="w-full text-left px-3 py-1.5 hover:bg-gray-50 flex items-center gap-2 text-gray-700" onClick={() => clone(r)}>
                <Copy className="w-3.5 h-3.5" /> Clone mapping
              </button>
              <button className="w-full text-left px-3 py-1.5 hover:bg-red-50 flex items-center gap-2 text-red-600" onClick={() => { setMenuId(null); setConfirmDel(r); }}>
                <Trash2 className="w-3.5 h-3.5" /> Delete mapping
              </button>
            </div>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="p-6 space-y-4">
      <Tabs tabs={TABS} active={tab} onChange={setTab} />

      {/* KPI strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white rounded-xl border border-gray-200 p-3 flex items-center gap-3">
            <span className="w-9 h-9 rounded-lg grid place-items-center bg-brand-soft text-brand shrink-0">
              <k.icon className="w-4 h-4" />
            </span>
            <div>
              <div className="text-[11px] text-gray-500">{k.label}</div>
              <div className="text-lg font-semibold text-gray-900">{k.value.toLocaleString()}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-4">
        {err ? (
          <div className="text-red-600 text-sm py-8 text-center">Failed to load: {err}</div>
        ) : (
          <DataTable columns={columns} rows={filtered} rowKey={(r) => r.id} onRowClick={openSpec} />
        )}
      </div>

      {confirmDel && (
        <div className="fixed inset-0 bg-black/30 grid place-items-center z-50" onClick={() => setConfirmDel(null)}>
          <div className="bg-white rounded-xl shadow-xl w-[420px] p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-gray-800">Delete mapping</h3>
              <button onClick={() => setConfirmDel(null)} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
            </div>
            <p className="text-sm text-gray-600">
              Permanently delete <span className="font-medium">{confirmDel.name}</span> and its field mappings? This cannot be undone.
            </p>
            <div className="flex gap-2 justify-end mt-4">
              <Button variant="secondary" onClick={() => setConfirmDel(null)}>Cancel</Button>
              <button onClick={() => doDelete(confirmDel)} className="inline-flex items-center gap-1 text-sm px-3 py-1.5 rounded-lg bg-red-600 text-white hover:bg-red-700">
                <Trash2 className="w-4 h-4" /> Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {deployRow && <DeployPipelineWizard spec={deployRow} onClose={() => setDeployRow(null)} />}
    </div>
  );
}
