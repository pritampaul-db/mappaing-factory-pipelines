"""Tier-1 self-learning: retrieval memory over approved mappings.

The system gets smarter by *remembering approved examples*, not by retraining.
Every approved field mapping is written as a "memory" row (a natural-language
description + structured metadata) into a Delta table, which a Vector Search
Delta Sync index embeds with a managed embedding model. At suggestion time we
retrieve the most similar approved precedents and inject them as few-shot
exemplars — so acceptance improves as the approved corpus grows, with zero
model changes. This is the retrieval-first tier of the architecture's
self-learning engine, and the substrate the later Custom LLM graduates from.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

from server import config, warehouse

VS_ENDPOINT = "mapping_factory_vs"
EMBED_MODEL = "databricks-gte-large-en"


def _fqn(table: str) -> str:
    return f"{config.UC_CATALOG}.{config.UC_SCHEMA}.{table}"


MEMORY_TABLE = "mapping_memory"
INDEX_NAME_TABLE = "mapping_memory_index"  # the VS index sits alongside


def ensure_memory_table() -> None:
    """Delta source table for retrieval memory, with Change Data Feed on (VS needs it)."""
    warehouse.execute(
        f"""CREATE TABLE IF NOT EXISTS {_fqn(MEMORY_TABLE)} (
              id STRING,
              memory_text STRING,
              target_field STRING,
              target_type STRING,
              source_fields STRING,
              transform_op STRING,
              transform_detail STRING,
              domain STRING
            ) USING DELTA
            TBLPROPERTIES (delta.enableChangeDataFeed = true)"""
    )


def _sql_str(v: Any) -> str:
    s = v if isinstance(v, str) else json.dumps(v, default=str)
    return "'" + s.replace("'", "''") + "'"


def _memory_text(target_field: str, target_type: str, source_fields: list[str], op: str, detail: str) -> str:
    """The natural-language exemplar that gets embedded + shown back to the model."""
    src = ", ".join(source_fields) or "(none)"
    return (
        f"Target field `{target_field}` ({target_type}) is derived from source field(s) "
        f"[{src}] using a `{op}` transform. {detail}".strip()
    )


def record_approved_mappings(snapshot: dict[str, Any]) -> int:
    """Write one memory row per approved mapping (idempotent by content-derived id)."""
    ensure_memory_table()
    rows = []
    domain = snapshot.get("name", "")
    for m in snapshot.get("mappings", []):
        spec = m.get("transform_spec") or {}
        op = (spec.get("op") if isinstance(spec, dict) else None) or m.get("transform_kind") or "spec"
        detail = json.dumps(spec, default=str) if isinstance(spec, dict) else str(m.get("transform_sql") or "")
        src = m.get("source_fields") or []
        text = _memory_text(m["target_field"], m["target_type"], src, op, detail)
        # Stable id: same approved mapping content => same row (idempotent).
        rid = hashlib.sha256(f"{text}|{domain}".encode()).hexdigest()[:32]
        rows.append((rid, text, m["target_field"], m["target_type"], json.dumps(src), op, detail, domain))

    if not rows:
        return 0
    # MERGE for idempotency.
    values = ", ".join(
        f"({_sql_str(r[0])},{_sql_str(r[1])},{_sql_str(r[2])},{_sql_str(r[3])},{_sql_str(r[4])},{_sql_str(r[5])},{_sql_str(r[6])},{_sql_str(r[7])})"
        for r in rows
    )
    warehouse.execute(
        f"""MERGE INTO {_fqn(MEMORY_TABLE)} t
            USING (SELECT * FROM VALUES {values}
                   AS s(id, memory_text, target_field, target_type, source_fields, transform_op, transform_detail, domain)) s
            ON t.id = s.id
            WHEN NOT MATCHED THEN INSERT *"""
    )
    return len(rows)


def ensure_index() -> str:
    """Create the Delta Sync index over the memory table (managed embeddings). Idempotent."""
    from databricks.sdk import WorkspaceClient

    w = config.get_workspace_client()
    index_fqn = _fqn(INDEX_NAME_TABLE)
    existing = [i.name for i in w.vector_search_indexes.list_indexes(endpoint_name=VS_ENDPOINT)]
    if index_fqn in existing:
        return index_fqn

    from databricks.sdk.service.vectorsearch import (
        DeltaSyncVectorIndexSpecRequest,
        EmbeddingSourceColumn,
        IndexSubtype,
        PipelineType,
        VectorIndexType,
    )

    w.vector_search_indexes.create_index(
        name=index_fqn,
        endpoint_name=VS_ENDPOINT,
        primary_key="id",
        index_type=VectorIndexType.DELTA_SYNC,
        index_subtype=IndexSubtype.HYBRID,
        delta_sync_index_spec=DeltaSyncVectorIndexSpecRequest(
            source_table=_fqn(MEMORY_TABLE),
            pipeline_type=PipelineType.TRIGGERED,
            embedding_source_columns=[
                EmbeddingSourceColumn(name="memory_text", embedding_model_endpoint_name=EMBED_MODEL)
            ],
        ),
    )
    return index_fqn


def sync_index() -> None:
    """Trigger a sync so newly approved memories become searchable."""
    w = config.get_workspace_client()
    try:
        w.vector_search_indexes.sync_index(index_name=_fqn(INDEX_NAME_TABLE))
    except Exception:
        pass  # index may still be provisioning; next sync will catch up


def search_similar(query_text: str, k: int = 5) -> list[dict[str, Any]]:
    """Retrieve the most similar approved mappings as few-shot exemplars."""
    w = config.get_workspace_client()
    try:
        resp = w.vector_search_indexes.query_index(
            index_name=_fqn(INDEX_NAME_TABLE),
            columns=["memory_text", "target_field", "transform_op", "transform_detail"],
            query_text=query_text,
            num_results=k,
        )
    except Exception:
        return []  # no index yet / empty memory — degrade gracefully (cold start)
    out: list[dict[str, Any]] = []
    result = resp.result
    if not result or not result.data_array:
        return out
    cols = [c.name for c in (resp.manifest.columns or [])] if resp.manifest else []
    for row in result.data_array:
        out.append(dict(zip(cols, row)))
    return out
