"""Minimal GitHub REST client for Deploy-as-Pipeline.

Uses a user's PAT over HTTPS — no git binary, works from the Databricks App sandbox.
Covers what the wizard needs: identify the user, list/create repos, create branches,
and commit a set of files in ONE commit via the Git Data API (blobs → tree → commit →
ref update). All calls raise GitHubError with the API message on failure.
"""
from __future__ import annotations

import base64
import time
from typing import Any

import httpx

_API = "https://api.github.com"


class GitHubError(Exception):
    pass


class GitHub:
    def __init__(self, token: str):
        self._h = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        self._c = httpx.Client(base_url=_API, headers=self._h, timeout=30.0)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self._c.close()

    def _req(self, method: str, path: str, **kw) -> Any:
        r = self._c.request(method, path, **kw)
        if r.status_code >= 400:
            try:
                msg = r.json().get("message", r.text)
            except Exception:  # noqa: BLE001
                msg = r.text
            raise GitHubError(f"GitHub {method} {path} → {r.status_code}: {msg}")
        return r.json() if r.content else {}

    # --- identity / discovery ---
    def whoami(self) -> str:
        return self._req("GET", "/user")["login"]

    def list_repos(self, limit: int = 100) -> list[dict[str, Any]]:
        out = self._req("GET", f"/user/repos?per_page={min(limit, 100)}&sort=updated&affiliation=owner,collaborator")
        return [{"full_name": r["full_name"], "default_branch": r.get("default_branch", "main"), "private": r.get("private", True)} for r in out]

    def create_repo(self, name: str, *, private: bool = True, description: str = "") -> dict[str, Any]:
        r = self._req("POST", "/user/repos", json={"name": name, "private": private, "description": description, "auto_init": True})
        return {"full_name": r["full_name"], "default_branch": r.get("default_branch", "main")}

    # --- branches ---
    def get_branch_sha(self, full_name: str, branch: str) -> str | None:
        try:
            ref = self._req("GET", f"/repos/{full_name}/git/ref/heads/{branch}")
            return ref["object"]["sha"]
        except GitHubError:
            return None

    def default_branch(self, full_name: str) -> str:
        return self._req("GET", f"/repos/{full_name}").get("default_branch", "main")

    def _wait_for_branch(self, full_name: str, branch: str, tries: int = 6, delay: float = 0.7) -> str | None:
        """Poll until a branch ref is readable (GitHub's ref API is read-after-write
        eventually-consistent, and a freshly auto_init'd repo's default branch can lag)."""
        for i in range(tries):
            sha = self.get_branch_sha(full_name, branch)
            if sha is not None:
                return sha
            if i < tries - 1:
                time.sleep(delay)
        return None

    def create_branch(self, full_name: str, new_branch: str, from_branch: str) -> str:
        # The base branch may lag right after create_repo(auto_init=True) — wait for it.
        base_sha = self._wait_for_branch(full_name, from_branch)
        if base_sha is None:
            raise GitHubError(f"base branch '{from_branch}' not found in {full_name}")
        if self.get_branch_sha(full_name, new_branch) is not None:
            return new_branch  # already exists
        self._req("POST", f"/repos/{full_name}/git/refs", json={"ref": f"refs/heads/{new_branch}", "sha": base_sha})
        # Confirm the new ref is visible before callers try to commit onto it.
        if self._wait_for_branch(full_name, new_branch) is None:
            raise GitHubError(f"branch '{new_branch}' was created but is not yet visible in {full_name}")
        return new_branch

    # --- commit a set of files in one commit (Git Data API) ---
    def commit_files(self, full_name: str, branch: str, files: dict[str, str], message: str) -> dict[str, Any]:
        """Create ONE commit adding/updating `files` (path → text content) on `branch`.
        Branch must already exist. Returns {commit_sha, html_url}."""
        parent = self._wait_for_branch(full_name, branch)
        if parent is None:
            raise GitHubError(f"branch '{branch}' not found in {full_name}")
        base_commit = self._req("GET", f"/repos/{full_name}/git/commits/{parent}")
        base_tree = base_commit["tree"]["sha"]
        # blob per file
        tree = []
        for path, content in files.items():
            blob = self._req("POST", f"/repos/{full_name}/git/blobs",
                             json={"content": base64.b64encode(content.encode()).decode(), "encoding": "base64"})
            tree.append({"path": path, "mode": "100644", "type": "blob", "sha": blob["sha"]})
        new_tree = self._req("POST", f"/repos/{full_name}/git/trees", json={"base_tree": base_tree, "tree": tree})
        commit = self._req("POST", f"/repos/{full_name}/git/commits",
                           json={"message": message, "tree": new_tree["sha"], "parents": [parent]})
        self._req("PATCH", f"/repos/{full_name}/git/refs/heads/{branch}", json={"sha": commit["sha"]})
        return {"commit_sha": commit["sha"], "html_url": commit.get("html_url", f"https://github.com/{full_name}/commit/{commit['sha']}")}
