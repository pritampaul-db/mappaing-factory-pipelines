"""Deterministic compiler — the P1 "dispose" half.

Turns APPROVED field mappings + transform rules into runnable Spark SQL, with
static type-checking, column-level lineage, and generated tests. There is NO
LLM in this module: given the same approved snapshot + compiler version, it
emits byte-identical SQL. That determinism is what makes the platform
reproducible and auditable.

Transform rules are one of two kinds:
  * "spec"     — a declarative JSON rule (rename/cast/default/concat/arithmetic/
                 case/date_format), lowered here to a SQL expression.
  * "sql_expr" — a raw SQL expression escape hatch.
Both are normalized to a sqlglot AST (dialect=spark) so we can type-check,
extract lineage, and pretty-print in one place.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any

import sqlglot
from sqlglot import exp

COMPILER_VERSION = "0.1.0"
DIALECT = "spark"

# Minimal Spark type lattice for the slice's op set. Enough to catch the
# mismatches that matter (string↔numeric↔date↔boolean) without pretending to
# be a full type system.
_NUMERIC = {"tinyint", "smallint", "int", "integer", "bigint", "float", "double", "decimal"}
_STRING = {"string", "varchar", "char", "text"}
_TEMPORAL = {"date", "timestamp"}
_BOOL = {"boolean", "bool"}


class CompileError(Exception):
    """Raised on any static-validation failure. Fail closed: no SQL is emitted."""


@dataclass
class FieldMappingIR:
    """One target field's derivation, as handed to the compiler from approved metadata."""
    target_field: str
    target_type: str
    source_fields: list[str]
    transform_kind: str          # "spec" | "sql_expr"
    transform: dict[str, Any] | str  # spec dict, or raw sql string
    test_cases: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class CompileResult:
    content_hash: str
    compiler_version: str
    generated_sql: str
    generated_tests: list[dict[str, Any]]
    lineage_edges: list[dict[str, str]]


def _canonical_type(t: str) -> str:
    t = t.strip().lower()
    # normalize decimal(10,2) -> decimal, etc.
    return t.split("(", 1)[0]


def _type_class(t: str) -> str:
    ct = _canonical_type(t)
    if ct in _NUMERIC:
        return "numeric"
    if ct in _STRING:
        return "string"
    if ct in _TEMPORAL:
        return "temporal"
    if ct in _BOOL:
        return "boolean"
    return "unknown"


def _lower_spec_to_sql(spec: dict[str, Any], source_types: dict[str, str]) -> tuple[str, str]:
    """Lower a declarative rule to (sql_expression, inferred_output_type_class).

    Supported ops keep the slice's surface small and well-typed.
    """
    op = spec.get("op")
    if op == "rename":
        src = spec["source"]
        return _q(src), _type_class(source_types.get(src, "unknown"))
    if op == "cast":
        src = spec["source"]
        to = spec["to"]
        return f"CAST({_q(src)} AS {to.upper()})", _type_class(to)
    if op == "default":
        # COALESCE(source, literal)
        src = spec["source"]
        lit = _literal(spec["value"])
        return f"COALESCE({_q(src)}, {lit})", _type_class(source_types.get(src, "unknown"))
    if op == "concat":
        parts = ", ".join(_q(s) for s in spec["sources"])
        sep = spec.get("separator")
        if sep is not None:
            return f"CONCAT_WS({_literal(sep)}, {parts})", "string"
        return f"CONCAT({parts})", "string"
    if op == "arithmetic":
        # {op:arithmetic, expr:"a + b"} — validated by parse + source-column check
        return spec["expr"], "numeric"
    if op == "expr":
        # {op:expr, expr:"..."} — a custom, merged transformation (e.g. several
        # steps for one column folded into one expression by the Optimize action).
        # Output type is unknown so the compiler's type-check defers to parse +
        # source-column validation, exactly like the sql_expr escape hatch.
        return spec["expr"], "unknown"
    if op == "case":
        # Two accepted shapes:
        #  a) {op:case, expr:"CASE WHEN ... END"} — a pre-formed CASE expression (what the
        #     AI often emits); treated like the sql_expr escape hatch (parse + col-check).
        #  b) {op:case, whens:[{when:"x > 0", then:"'pos'"}], else:"'neg'"} — structured.
        if spec.get("expr"):
            return spec["expr"], "unknown"
        whens = " ".join(f"WHEN {w['when']} THEN {w['then']}" for w in spec["whens"])
        els = f" ELSE {spec['else']}" if "else" in spec else ""
        return f"CASE {whens}{els} END", "unknown"
    if op == "date_format":
        src = spec["source"]
        fmt = _literal(spec["format"])
        return f"DATE_FORMAT({_q(src)}, {fmt})", "string"
    raise CompileError(f"Unsupported transform op: {op!r}")


def _q(ident: str) -> str:
    """Quote a column identifier for Spark (backticks).

    Dot-aware: a QUALIFIED reference `Table.Column` (multi-table mappings qualify
    every source ref) is quoted per-segment -> `Table`.`Column`, so it resolves as
    a proper table-qualified column against a joined view. A bare name (the
    single-table case) has no dot and is quoted whole -> `Column` (unchanged)."""
    if "." in ident:
        return ".".join("`" + part.replace("`", "``") + "`" for part in ident.split("."))
    return "`" + ident.replace("`", "``") + "`"


@dataclass
class SourceTable:
    """One physical source table available to a multi-source compile."""
    name: str        # logical table name (the alias transforms qualify against)
    locator: str     # fully-qualified physical locator (catalog.schema.table)


def _normalize_joins(joins: list[dict[str, Any]] | None) -> list[dict[str, str]]:
    """Accept either the spec.joins shape (`{left:'T.c', right:'T.c'}`) or the
    already-split SDP shape (`{left_table,left_col,right_table,right_col}`) and
    return a uniform list of the split shape. Anything unparseable is dropped."""
    out: list[dict[str, str]] = []
    for j in joins or []:
        lt, lc = j.get("left_table"), j.get("left_col")
        rt, rc = j.get("right_table"), j.get("right_col")
        if not (lt and lc and rt and rc):
            lt, _, lc = (j.get("left") or "").partition(".")
            rt, _, rc = (j.get("right") or "").partition(".")
        if lt and lc and rt and rc:
            out.append({"left_table": lt, "left_col": lc, "right_table": rt, "right_col": rc})
    return out


def _build_from_clause(sources: list[SourceTable], joins: list[dict[str, str]]) -> str:
    """Build `FROM <grain> LEFT JOIN <t> ON ...` across the source tables.

    The FIRST source is the grain (row anchor); each subsequent table is LEFT
    JOINed on a configured join key that links it to an already-included table.
    A table with no resolvable join key is dropped (can't be related safely) —
    the same conservative rule the SDP test pipeline uses. Mirroring that logic
    keeps the deterministic compile path consistent with agentic validation."""
    if not sources:
        raise CompileError("no source tables to compile")
    included = [sources[0].name]
    parts = [f"{sources[0].locator} AS {_q(sources[0].name)}"]
    for s in sources[1:]:
        on = None
        for j in joins:
            if s.name == j["right_table"] and j["left_table"] in included:
                on = f"{_q(j['left_table'])}.{_q(j['left_col'])} = {_q(s.name)}.{_q(j['right_col'])}"
                break
            if s.name == j["left_table"] and j["right_table"] in included:
                on = f"{_q(j['right_table'])}.{_q(j['right_col'])} = {_q(s.name)}.{_q(j['left_col'])}"
                break
        if on:
            parts.append(f"LEFT JOIN {s.locator} AS {_q(s.name)} ON {on}")
            included.append(s.name)
    return " ".join(parts)


def _literal(v: Any) -> str:
    if isinstance(v, str):
        return "'" + v.replace("'", "''") + "'"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if v is None:
        return "NULL"
    return str(v)


def compile_spec(
    *,
    spec_id: str,
    source_table: str | None = None,
    source_types: dict[str, str],
    mappings: list[FieldMappingIR],
    sources: list[SourceTable] | None = None,
    joins: list[dict[str, Any]] | None = None,
) -> CompileResult:
    """Compile approved mappings into deterministic Spark SQL + tests + lineage.

    Two shapes, one code path:
      * SINGLE source — pass `source_table` (the physical locator). FROM is that
        one table; transforms use bare column names. (Unchanged behavior.)
      * MULTI source — pass `sources` (>=1 SourceTable) + optional `joins`. FROM
        is a grain-anchored LEFT-JOIN across them; transforms qualify columns as
        `Table.Column`. `source_types` must be POOLED across all tables (bare AND
        qualified) so the reference check and type lowering resolve either form.
    """
    if not mappings:
        raise CompileError("No field mappings to compile.")

    # Resolve the FROM clause from whichever shape was supplied.
    if sources:
        from_clause = _build_from_clause(sources, _normalize_joins(joins))
    elif source_table:
        from_clause = source_table
    else:
        raise CompileError("compile_spec requires either source_table or sources")

    select_items: list[str] = []
    lineage_edges: list[dict[str, str]] = []
    tests: list[dict[str, Any]] = []

    # Deterministic ordering by target field name — same input, same output.
    for m in sorted(mappings, key=lambda x: x.target_field):
        # 1) Resolve to a SQL expression.
        if m.transform_kind == "spec":
            assert isinstance(m.transform, dict)
            sql_expr, out_class = _lower_spec_to_sql(m.transform, source_types)
        elif m.transform_kind == "sql_expr":
            assert isinstance(m.transform, str)
            sql_expr, out_class = m.transform, "unknown"
        else:
            raise CompileError(f"Unknown transform kind: {m.transform_kind!r}")

        # 2) Parse to AST (fail closed on unparseable SQL).
        try:
            expr_ast = sqlglot.parse_one(sql_expr, read=DIALECT)
        except Exception as e:  # noqa: BLE001
            raise CompileError(f"{m.target_field}: cannot parse expression {sql_expr!r}: {e}")

        # 3) Referenced columns must exist in the source. A ref is known if EITHER
        #    its bare name OR its qualified `Table.Column` is in the pooled types
        #    (multi-source pools both; single-source pools bare only). We keep the
        #    most-qualified spelling for lineage so cross-table refs are unambiguous.
        referenced: set[str] = set()
        for c in expr_ast.find_all(exp.Column):
            qualified = f"{c.table}.{c.name}" if c.table else c.name
            referenced.add(qualified if qualified in source_types else c.name)
        unknown = {r for r in referenced if r not in source_types and r.split(".")[-1] not in source_types}
        if unknown:
            raise CompileError(
                f"{m.target_field}: expression references unknown source column(s): {sorted(unknown)}"
            )

        # 4) Type-check declared target type vs inferred output class (skip unknown).
        target_class = _type_class(m.target_type)
        if out_class != "unknown" and target_class != "unknown" and out_class != target_class:
            raise CompileError(
                f"{m.target_field}: type mismatch — transform yields {out_class}, "
                f"target is {m.target_type} ({target_class}). Add an explicit cast."
            )

        # 5) Emit projected column, aliased to the target field.
        projected = expr_ast.sql(dialect=DIALECT)
        select_items.append(f"{projected} AS {_q(m.target_field)}")

        # 6) Column-level lineage.
        for src in referenced:
            lineage_edges.append(
                {"source_field": src, "target_field": m.target_field, "transform_sql": projected}
            )

        # 7) Carry generated tests: null checks + author-supplied sample I/O.
        tests.append(
            {
                "target_field": m.target_field,
                "expects_type": m.target_type,
                "sample_cases": m.test_cases,
            }
        )

    body = ",\n  ".join(select_items)
    raw_sql = f"SELECT\n  {body}\nFROM {from_clause}"
    # Round-trip through sqlglot for canonical, deterministic formatting.
    generated_sql = sqlglot.parse_one(raw_sql, read=DIALECT).sql(dialect=DIALECT, pretty=True)

    content_hash = hashlib.sha256(
        json.dumps(
            {
                "spec_id": spec_id,
                "compiler_version": COMPILER_VERSION,
                "sql": generated_sql,
            },
            sort_keys=True,
        ).encode()
    ).hexdigest()

    return CompileResult(
        content_hash=content_hash,
        compiler_version=COMPILER_VERSION,
        generated_sql=generated_sql,
        generated_tests=tests,
        lineage_edges=lineage_edges,
    )
