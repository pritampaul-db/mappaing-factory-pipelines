"""Unit tests for the deterministic compiler (M6). No workspace needed."""
from __future__ import annotations

import pytest

from server.compiler import CompileError, FieldMappingIR, SourceTable, compile_spec

SOURCE_TABLE = "pritam_demo_workspace_catalog.mapping_factory.src_customers"
SOURCE_TYPES = {
    "cust_id": "bigint",
    "first_nm": "string",
    "last_nm": "string",
    "signup_ts": "timestamp",
    "balance_str": "string",
}


def _golden_mappings() -> list[FieldMappingIR]:
    return [
        # trivial rename
        FieldMappingIR("customer_id", "bigint", ["cust_id"], "spec", {"op": "rename", "source": "cust_id"}),
        # concat with separator
        FieldMappingIR(
            "full_name", "string", ["first_nm", "last_nm"], "spec",
            {"op": "concat", "sources": ["first_nm", "last_nm"], "separator": " "},
        ),
        # cast string -> numeric
        FieldMappingIR("balance", "double", ["balance_str"], "spec", {"op": "cast", "source": "balance_str", "to": "double"}),
        # date_format -> string
        FieldMappingIR(
            "signup_date", "string", ["signup_ts"], "spec",
            {"op": "date_format", "source": "signup_ts", "format": "yyyy-MM-dd"},
        ),
    ]


def test_compiles_golden_path():
    res = compile_spec(
        spec_id="spec-1", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=_golden_mappings()
    )
    assert "SELECT" in res.generated_sql
    assert "`customer_id`" in res.generated_sql
    assert "CONCAT_WS" in res.generated_sql
    assert "CAST" in res.generated_sql
    # lineage covers every source column touched
    srcs = {e["source_field"] for e in res.lineage_edges}
    assert {"cust_id", "first_nm", "last_nm", "balance_str", "signup_ts"} == srcs


def test_determinism_same_hash():
    a = compile_spec(spec_id="spec-1", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=_golden_mappings())
    b = compile_spec(spec_id="spec-1", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=_golden_mappings())
    assert a.content_hash == b.content_hash
    assert a.generated_sql == b.generated_sql


def test_ordering_independent():
    """Input mapping order must not change the output (deterministic sort)."""
    m = _golden_mappings()
    a = compile_spec(spec_id="s", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=m)
    b = compile_spec(spec_id="s", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=list(reversed(m)))
    assert a.content_hash == b.content_hash


def test_type_mismatch_fails_closed():
    """A string->bigint with no cast must be rejected, not silently emitted."""
    bad = [FieldMappingIR("customer_id", "bigint", ["first_nm"], "spec", {"op": "rename", "source": "first_nm"})]
    with pytest.raises(CompileError, match="type mismatch"):
        compile_spec(spec_id="s", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=bad)


def test_unknown_source_column_fails():
    bad = [FieldMappingIR("x", "string", ["nope"], "spec", {"op": "rename", "source": "nope"})]
    with pytest.raises(CompileError, match="unknown source column"):
        compile_spec(spec_id="s", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=bad)


def test_unparseable_sql_expr_fails():
    bad = [FieldMappingIR("x", "string", [], "sql_expr", "SELECT SELECT FROM WHERE ((")]
    with pytest.raises(CompileError):
        compile_spec(spec_id="s", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=bad)


def test_custom_expr_op_merges_steps():
    """The 'expr' op (Optimize action's merged transform) compiles as one expression."""
    m = [
        FieldMappingIR(
            "full_name", "string", ["first_nm", "last_nm"], "spec",
            {"op": "expr", "expr": "CONCAT_WS(' ', TRIM(first_nm), TRIM(last_nm))"},
        )
    ]
    res = compile_spec(spec_id="s", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=m)
    assert "CONCAT_WS" in res.generated_sql and "TRIM" in res.generated_sql
    assert {e["source_field"] for e in res.lineage_edges} == {"first_nm", "last_nm"}


def test_custom_expr_op_checks_columns():
    """A merged expr referencing a non-existent column must still fail closed."""
    bad = [FieldMappingIR("x", "string", [], "spec", {"op": "expr", "expr": "UPPER(nope)"})]
    with pytest.raises(CompileError, match="unknown source column"):
        compile_spec(spec_id="s", source_table=SOURCE_TABLE, source_types=SOURCE_TYPES, mappings=bad)


# --- multi-source (JOIN) compile ---------------------------------------------

CAT = "pritam_demo_workspace_catalog.mapping_factory"
MULTI_SOURCES = [
    SourceTable(name="RAW_CUSTOMER_MASTER", locator=f"{CAT}.raw_customer_master"),
    SourceTable(name="RAW_CUSTOMER_ACCOUNT", locator=f"{CAT}.raw_customer_account"),
]
# Pooled types: bare AND qualified `Table.col`, exactly what _load_approved builds.
MULTI_TYPES = {
    "CUSTOMER_ID": "bigint", "RAW_CUSTOMER_MASTER.CUSTOMER_ID": "bigint",
    "NAME": "string", "RAW_CUSTOMER_MASTER.NAME": "string",
    "ACCOUNT_ID": "bigint", "RAW_CUSTOMER_ACCOUNT.ACCOUNT_ID": "bigint",
    "BALANCE": "double", "RAW_CUSTOMER_ACCOUNT.BALANCE": "double",
}
MULTI_JOINS = [{"left": "RAW_CUSTOMER_MASTER.CUSTOMER_ID", "right": "RAW_CUSTOMER_ACCOUNT.CUSTOMER_ID"}]


def _multi_mappings() -> list[FieldMappingIR]:
    return [
        # straight qualified rename from the grain table
        FieldMappingIR("customer_id", "bigint", ["RAW_CUSTOMER_MASTER.CUSTOMER_ID"], "spec",
                       {"op": "rename", "source": "RAW_CUSTOMER_MASTER.CUSTOMER_ID"}),
        # a column drawn from the JOINED (non-grain) table
        FieldMappingIR("balance", "double", ["RAW_CUSTOMER_ACCOUNT.BALANCE"], "spec",
                       {"op": "rename", "source": "RAW_CUSTOMER_ACCOUNT.BALANCE"}),
    ]


def test_multi_source_emits_left_join():
    res = compile_spec(spec_id="m", sources=MULTI_SOURCES, source_types=MULTI_TYPES,
                       joins=MULTI_JOINS, mappings=_multi_mappings())
    sql = res.generated_sql
    # grain table anchors FROM; the second source is LEFT JOINed on the key
    assert "LEFT JOIN" in sql
    assert "`RAW_CUSTOMER_MASTER`" in sql and "`RAW_CUSTOMER_ACCOUNT`" in sql
    # qualified refs resolve as table-qualified columns
    assert "`RAW_CUSTOMER_ACCOUNT`.`BALANCE`" in sql
    # join predicate present
    assert "`RAW_CUSTOMER_MASTER`.`CUSTOMER_ID` = `RAW_CUSTOMER_ACCOUNT`.`CUSTOMER_ID`" in sql


def test_multi_source_deterministic():
    a = compile_spec(spec_id="m", sources=MULTI_SOURCES, source_types=MULTI_TYPES, joins=MULTI_JOINS, mappings=_multi_mappings())
    b = compile_spec(spec_id="m", sources=MULTI_SOURCES, source_types=MULTI_TYPES, joins=MULTI_JOINS, mappings=_multi_mappings())
    assert a.content_hash == b.content_hash and a.generated_sql == b.generated_sql


def test_multi_source_unknown_qualified_col_fails():
    bad = [FieldMappingIR("x", "string", [], "spec", {"op": "expr", "expr": "RAW_CUSTOMER_MASTER.NOPE"})]
    with pytest.raises(CompileError, match="unknown source column"):
        compile_spec(spec_id="m", sources=MULTI_SOURCES, source_types=MULTI_TYPES, joins=MULTI_JOINS, mappings=bad)


def test_single_source_via_sources_list_no_join():
    """A 1-element sources list is the degenerate case: plain FROM, no JOIN."""
    res = compile_spec(spec_id="s", sources=[MULTI_SOURCES[0]], source_types=MULTI_TYPES,
                       joins=[], mappings=[_multi_mappings()[0]])
    assert "LEFT JOIN" not in res.generated_sql
    assert "`RAW_CUSTOMER_MASTER`" in res.generated_sql


def test_requires_source_or_sources():
    with pytest.raises(CompileError, match="requires either"):
        compile_spec(spec_id="s", source_types=SOURCE_TYPES, mappings=_golden_mappings())
