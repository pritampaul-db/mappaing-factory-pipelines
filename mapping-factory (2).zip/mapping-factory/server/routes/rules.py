"""Rule Library — list, detail, create, AI-generate, governance (submit/decide),
expression validation, and apply-to-dataset."""
from __future__ import annotations

from uuid import UUID

import sqlglot
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from server import config, db, llm, repo_admin, repo_library

router = APIRouter(tags=["rules"])


def _user() -> str:
    try:
        return config.get_workspace_client().current_user.me().user_name or "unknown"
    except Exception:
        return "unknown"


@router.get("/rules")
def list_rules() -> list[dict]:
    return repo_library.list_rules(db.pool)


@router.get("/rules/{rule_id}")
def get_rule(rule_id: UUID) -> dict:
    r = repo_library.get_rule(db.pool, rule_id)
    if r is None:
        raise HTTPException(status_code=404, detail="rule not found")
    return r


class RuleCreate(BaseModel):
    name: str
    code: str | None = None
    rule_type: str = "custom"
    domain: str | None = None
    data_type: str | None = None
    description: str | None = None
    logic_sql: str | None = None
    logic_preview: str | None = None
    sample_io: list[dict] | None = None
    tags: list[str] | None = None
    status: str | None = None  # Draft (default) | Published


@router.post("/rules")
def create_rule(body: RuleCreate) -> dict:
    import uuid as _uuid

    data = body.model_dump()
    if not data.get("code"):
        base = (data["name"].upper().replace(" ", "_"))[:40] or "RULE"
        data["code"] = f"{base}_{_uuid.uuid4().hex[:6].upper()}"
    return repo_library.create_rule(db.pool, data, _user())


@router.post("/rules/{rule_id}/submit")
def submit_rule(rule_id: UUID) -> dict:
    """Draft → Proposed (Pending Approval)."""
    try:
        return repo_library.submit_rule(db.pool, rule_id, _user())
    except repo_library.RuleGovernanceError as e:
        raise HTTPException(status_code=409, detail=str(e))


class RuleDecision(BaseModel):
    decision: str  # approved | rejected
    rationale: str | None = None


@router.post("/rules/{rule_id}/decide")
def decide_rule(rule_id: UUID, body: RuleDecision) -> dict:
    """Approve (→ Published) or reject (→ Rejected). Maker != checker, admins exempt."""
    checker = _user()
    try:
        return repo_library.decide_rule(
            db.pool, rule_id, decision=body.decision, checker=checker, rationale=body.rationale,
            is_admin=repo_admin.is_admin(db.pool, checker),
        )
    except repo_library.RuleGovernanceError as e:
        raise HTTPException(status_code=409, detail=str(e))


class RuleApply(BaseModel):
    dataset: str
    column_name: str | None = None
    severity: str = "medium"


@router.post("/rules/{rule_id}/apply")
def apply_rule(rule_id: UUID, body: RuleApply) -> dict:
    """Apply a published library rule to a dataset — creates a dataset-tagged
    validation instance (the 'use = tag to dataset' step)."""
    try:
        v = repo_library.apply_rule_to_dataset(
            db.pool, rule_id, dataset=body.dataset, column_name=body.column_name,
            severity=body.severity, owner=_user(),
        )
        return {"validation": v}
    except repo_library.RuleGovernanceError as e:
        raise HTTPException(status_code=409, detail=str(e))


class ExprValidate(BaseModel):
    expression: str


@router.post("/rules/validate-expression")
def validate_expression(body: ExprValidate) -> dict:
    """Deterministic expression check via sqlglot."""
    try:
        ast = sqlglot.parse_one(body.expression, read="spark")
        cols = sorted({c.name for c in ast.find_all(sqlglot.exp.Column)})
        return {"valid": True, "normalized": ast.sql(dialect="spark"), "columns": cols}
    except Exception as e:  # noqa: BLE001
        return {"valid": False, "error": str(e)}


class RuleGenerate(BaseModel):
    description: str
    rule_type: str = "standardization"
    data_type: str = "String"


@router.post("/rules/generate")
def generate_rule(body: RuleGenerate) -> dict:
    try:
        return llm.generate_rule(body.description, body.rule_type, body.data_type)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"AI rule generation failed: {e}")
