import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, BookOpen, FileCode, ShieldCheck, GitFork, Clock, X, Search, Check, Database } from "lucide-react";
import { usePage, useIdentity, useIsAdmin } from "../../AppShell";
import { api, type Rule } from "../../api";
import { Button, Tabs, StatusBadge, Avatar, Card } from "../../components/primitives";
import { DataTable, LinkCell, type Column } from "../../components/DataTable";
import { fuzzyFilter } from "../../lib/fuzzy";

const TABS = ["Overview", "Pending Approval", "Business Rules", "Standardization Rules", "Validation Rules", "Derivation Rules", "Custom Rules"];
const TAB_TYPE: Record<string, string> = {
  "Business Rules": "business",
  "Standardization Rules": "standardization",
  "Validation Rules": "validation",
  "Derivation Rules": "derivation",
  "Custom Rules": "custom",
};
const PENDING_STATUSES = new Set(["Proposed", "Pending Approval", "In Review"]);
const PUBLISHED_STATUSES = new Set(["Published", "Approved", "Active", "Live"]);

export function RuleLibrary() {
  const nav = useNavigate();
  const identity = useIdentity();
  const [rules, setRules] = useState<Rule[]>([]);
  const [tab, setTab] = useState(TABS[0]);
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<Rule | null>(null);

  usePage({
    title: "Rule Library",
    subtitle: "Create, approve and reuse dataset-agnostic business and technical rules",
    actions: (
      <Button onClick={() => nav("/rules/new")}>
        <Plus className="w-4 h-4" /> Create Rule
      </Button>
    ),
  });

  const load = () =>
    api.listRules().then((r) => {
      setRules(r);
      setSelected((prev) => (prev ? r.find((x) => x.id === prev.id) ?? null : null));
    });
  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    let out = rules;
    if (tab === "Pending Approval") out = rules.filter((r) => PENDING_STATUSES.has(r.status));
    else if (tab !== "Overview") out = rules.filter((r) => r.rule_type === TAB_TYPE[tab]);
    return fuzzyFilter(out, q, (r) => [r.name, r.description, r.domain, r.logic_preview]);
  }, [rules, tab, q]);

  const pendingCount = rules.filter((r) => PENDING_STATUSES.has(r.status)).length;
  const kpis = [
    { icon: BookOpen, label: "Total Rules", value: rules.length },
    { icon: FileCode, label: "Business", value: rules.filter((r) => r.rule_type === "business").length },
    { icon: ShieldCheck, label: "Published", value: rules.filter((r) => PUBLISHED_STATUSES.has(r.status)).length },
    { icon: GitFork, label: "Derivation", value: rules.filter((r) => r.rule_type === "derivation").length },
    { icon: Clock, label: "Pending Approval", value: pendingCount },
  ];

  const columns: Column<Rule>[] = [
    { key: "name", header: "Rule Name", sortValue: (r) => r.name, render: (r) => <LinkCell title={r.name} subtitle={r.code} /> },
    { key: "type", header: "Rule Type", render: (r) => <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded capitalize">{r.rule_type}</span> },
    { key: "domain", header: "Domain", render: (r) => <span className="text-gray-600">{r.domain ?? "—"}</span>, sortValue: (r) => r.domain ?? "" },
    { key: "desc", header: "Description", render: (r) => <span className="text-gray-500 text-xs line-clamp-1">{r.description}</span> },
    { key: "owner", header: "Owner", render: (r) => <Avatar name={r.owner ?? "—"} /> },
    { key: "usage", header: "Used By", align: "right", sortValue: (r) => r.used_by ?? r.usage_count, render: (r) => <span className="text-gray-700" title="Datasets this rule has been applied to">{r.used_by ?? 0} dataset{(r.used_by ?? 0) === 1 ? "" : "s"}</span> },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <Tabs tabs={TABS} active={tab} onChange={setTab} />
        <div className="relative w-72">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input value={q} onChange={(e) => setQ(e.target.value)} className="w-full bg-white border border-gray-200 rounded-lg pl-9 pr-8 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30" placeholder="Search rules by name or description…" />
          {q && <button onClick={() => setQ("")} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"><X className="w-3.5 h-3.5" /></button>}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white rounded-xl border border-gray-200 p-3 flex items-center gap-3">
            <span className="w-9 h-9 rounded-lg grid place-items-center bg-brand-soft text-brand shrink-0"><k.icon className="w-4 h-4" /></span>
            <div><div className="text-[11px] text-gray-500">{k.label}</div><div className="text-lg font-semibold text-gray-900">{k.value}</div></div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 items-start">
        <div className="xl:col-span-2 bg-white rounded-xl border border-gray-200 p-4">
          {q && <div className="text-[11px] text-gray-400 mb-2">{filtered.length} match{filtered.length === 1 ? "" : "es"} for “{q}”</div>}
          <DataTable columns={columns} rows={filtered} rowKey={(r) => r.id} onRowClick={setSelected} />
        </div>
        {selected && <RuleDetail rule={selected} identity={identity} onClose={() => setSelected(null)} onChanged={load} />}
      </div>
    </div>
  );
}

function RuleDetail({ rule, identity, onClose, onChanged }: { rule: Rule; identity?: string | null; onClose: () => void; onChanged: () => void }) {
  const isAdmin = useIsAdmin();
  const isPending = PENDING_STATUSES.has(rule.status);
  const isPublished = PUBLISHED_STATUSES.has(rule.status);
  const maker = (rule.submitted_by || rule.owner || "").toLowerCase();
  const isMaker = !!maker && maker === (identity ?? "").toLowerCase();
  const [applying, setApplying] = useState(false);

  return (
    <Card className="self-start sticky top-4">
      <div className="flex items-start justify-between mb-2">
        <div><h3 className="font-semibold text-gray-800 leading-tight">{rule.name}</h3><div className="text-[11px] text-gray-400 font-mono mt-0.5">{rule.code}</div></div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        <StatusBadge status={rule.status} />
        <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded capitalize">{rule.rule_type}</span>
      </div>

      {isPending && <ReviewBar rule={rule} isMaker={isMaker} isAdmin={isAdmin} onChanged={onChanged} />}
      {isPublished && rule.approved_by && <p className="text-[11px] text-green-700 bg-green-50 border border-green-100 rounded px-2 py-1.5 mt-3">Approved &amp; published by {rule.approved_by}.</p>}
      {rule.status === "Rejected" && <p className="text-[11px] text-red-700 bg-red-50 border border-red-100 rounded px-2 py-1.5 mt-3">Rejected{rule.rationale ? `: ${rule.rationale}` : "."}</p>}

      {rule.description && <p className="text-xs text-gray-600 mt-3">{rule.description}</p>}
      <dl className="text-sm mt-3 space-y-1.5">
        <Row k="Domain" v={rule.domain ?? "—"} /><Row k="Data Type" v={rule.data_type ?? "—"} /><Row k="Owner" v={rule.owner ?? "—"} /><Row k="Used by" v={`${rule.used_by ?? 0} dataset${(rule.used_by ?? 0) === 1 ? "" : "s"}`} />
      </dl>
      {(rule.logic_sql || rule.logic_preview) && (
        <div className="mt-3">
          <div className="text-xs font-medium text-gray-500 mb-1">Logic</div>
          <pre className="bg-[#0d1117] text-emerald-300 rounded px-2.5 py-2 text-[11px] font-mono overflow-x-auto whitespace-pre-wrap">{rule.logic_sql || rule.logic_preview}</pre>
        </div>
      )}
      {rule.sample_io && rule.sample_io.length > 0 && (
        <div className="mt-3">
          <div className="text-xs font-medium text-gray-500 mb-1">Sample</div>
          <table className="w-full text-xs"><thead><tr className="text-gray-400 text-left"><th className="font-normal">Input</th><th className="font-normal">Output</th></tr></thead>
            <tbody>{rule.sample_io.map((s, i) => <tr key={i}><td className="py-0.5 text-gray-600 font-mono">{s.input}</td><td className="py-0.5 text-gray-800 font-mono">{s.output}</td></tr>)}</tbody></table>
        </div>
      )}
      {rule.tags && rule.tags.length > 0 && <div className="mt-3 flex flex-wrap gap-1">{rule.tags.map((t) => <span key={t} className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{t}</span>)}</div>}

      {isPublished && (
        <Button className="w-full justify-center mt-4" onClick={() => setApplying(true)}><Database className="w-4 h-4" /> Apply to Dataset</Button>
      )}
      {applying && <ApplyModal rule={rule} onClose={() => setApplying(false)} onApplied={onChanged} />}
    </Card>
  );
}

function ReviewBar({ rule, isMaker, isAdmin, onChanged }: { rule: Rule; isMaker: boolean; isAdmin: boolean; onChanged: () => void }) {
  const blockApprove = isMaker && !isAdmin;
  const [decision, setDecision] = useState<null | "approved" | "rejected">(null);
  const [rationale, setRationale] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const confirm = async (d: "approved" | "rejected") => {
    setBusy(true); setErr(null);
    try { await api.decideRule(rule.id, { decision: d, rationale: rationale || undefined }); onChanged(); }
    catch (e) { setErr(e instanceof Error ? e.message : "Failed."); } finally { setBusy(false); }
  };
  return (
    <div className="border border-orange-200 bg-orange-50/50 rounded-lg p-3 mt-3">
      <div className="flex items-center gap-2 text-sm font-semibold text-gray-800"><ShieldCheck className="w-4 h-4 text-orange-600" /> Pending approval</div>
      <p className="text-[11px] text-gray-500 mt-0.5">Submitted by {rule.submitted_by ?? rule.owner ?? "—"}. Review the logic, then approve or reject.</p>
      {isMaker && isAdmin && <p className="text-[11px] text-brand mt-1">You submitted this — as an administrator you may approve your own (SoD bypassed).</p>}
      {isMaker && !isAdmin && <p className="text-[11px] text-amber-700 mt-1">You submitted this — a different reviewer must approve it. You can still reject it.</p>}
      {decision === null ? (
        <div className="flex gap-2 mt-2">
          <Button onClick={() => setDecision("approved")} disabled={blockApprove || busy}><Check className="w-4 h-4" /> Approve &amp; Publish</Button>
          <Button variant="secondary" onClick={() => setDecision("rejected")} disabled={busy}><X className="w-4 h-4" /> Reject</Button>
        </div>
      ) : (
        <div className="mt-2">
          <textarea value={rationale} onChange={(e) => setRationale(e.target.value)} rows={2} placeholder={decision === "approved" ? "Looks correct — approving." : "Why is this being rejected?"} className="w-full border border-gray-300 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand/30" />
          <div className="flex gap-2 mt-1.5">
            <Button onClick={() => confirm(decision)} disabled={busy}>{busy ? "Saving…" : decision === "approved" ? "Confirm approve" : "Confirm reject"}</Button>
            <Button variant="secondary" onClick={() => setDecision(null)} disabled={busy}>Cancel</Button>
          </div>
        </div>
      )}
      {err && <p className="text-[11px] text-red-600 mt-1.5">{err}</p>}
    </div>
  );
}

function ApplyModal({ rule, onClose, onApplied }: { rule: Rule; onClose: () => void; onApplied: () => void }) {
  const [dataset, setDataset] = useState("");
  const [column, setColumn] = useState("");
  const [severity, setSeverity] = useState("medium");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const apply = async () => {
    setErr(null);
    if (!dataset.trim()) { setErr("Dataset is required."); return; }
    setBusy(true);
    try {
      await api.applyRule(rule.id, { dataset: dataset.trim(), column_name: column.trim() || null, severity });
      setDone(true);
      onApplied();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed to apply.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/30 grid place-items-center z-50" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl w-[420px] p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-gray-800">Apply “{rule.name}” to a dataset</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
        </div>
        {done ? (
          <div className="text-sm text-green-700 flex items-center gap-2"><Check className="w-4 h-4" /> Applied — a dataset-tagged validation rule was created. It now appears under Validation.</div>
        ) : (
          <>
            <p className="text-xs text-gray-500 mb-3">This creates a data-quality rule tagged to the dataset (visible under Validation), using this rule's logic.</p>
            <label className="block mb-2"><span className="text-xs text-gray-500 mb-1 block">Dataset / Table *</span><input value={dataset} onChange={(e) => setDataset(e.target.value)} className="inp" placeholder="customer_master" /></label>
            <label className="block mb-2"><span className="text-xs text-gray-500 mb-1 block">Column (optional)</span><input value={column} onChange={(e) => setColumn(e.target.value)} className="inp" placeholder="Email_ID" /></label>
            <label className="block mb-3"><span className="text-xs text-gray-500 mb-1 block">Severity</span><select value={severity} onChange={(e) => setSeverity(e.target.value)} className="inp">{["critical", "high", "medium", "low"].map((s) => <option key={s}>{s}</option>)}</select></label>
            {err && <p className="text-xs text-red-600 mb-2">{err}</p>}
            <div className="flex gap-2 justify-end">
              <Button variant="secondary" onClick={onClose}>Cancel</Button>
              <Button onClick={apply} disabled={busy}>{busy ? "Applying…" : "Apply to Dataset"}</Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between"><dt className="text-gray-500">{k}</dt><dd className="text-gray-800 capitalize">{v}</dd></div>;
}
