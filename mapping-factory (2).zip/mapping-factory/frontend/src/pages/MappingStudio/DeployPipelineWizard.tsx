import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { X, GitBranch, KeyRound, Rocket, CheckCircle2, XCircle, Loader2, FlaskConical, ExternalLink, Circle } from "lucide-react";
import { api, type SpecRow, type DeployRun, type TestRun } from "../../api";
import { Button } from "../../components/primitives";

const STEPS = ["Git access", "Repository", "Pipeline", "Review", "Deploy", "Test"];
const TABLE_TYPES = [
  { v: "streaming_table", label: "Streaming Table", sub: "incremental, append/CDC" },
  { v: "materialized_view", label: "Materialized View", sub: "declarative, fully refreshed" },
  { v: "delta_table", label: "Delta Table", sub: "batch rebuild" },
];

// The Deploy-as-Pipeline wizard: git auth → repo/branch → pipeline config → deploy → test.
export function DeployPipelineWizard({ spec, onClose }: { spec: SpecRow; onClose: () => void }) {
  const nav = useNavigate();
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  // step 0 — git creds
  const [credStored, setCredStored] = useState<boolean | null>(null);
  const [gitUser, setGitUser] = useState("");
  const [token, setToken] = useState("");

  // step 1 — repo/branch
  const [repos, setRepos] = useState<{ full_name: string; default_branch: string }[] | null>(null);
  const [repoMode, setRepoMode] = useState<"existing" | "new">("existing");
  const [repoFull, setRepoFull] = useState("");
  const [newRepoName, setNewRepoName] = useState("");
  const [branchMode, setBranchMode] = useState<"existing" | "new">("new");
  const [branch, setBranch] = useState("");
  const [baseBranch, setBaseBranch] = useState("main");

  // step 2 — pipeline
  const [pipelineName, setPipelineName] = useState(`${slug(spec.name)}_pipeline`);
  const [sourceCatalog, setSourceCatalog] = useState("");
  const [sourceSchema, setSourceSchema] = useState("mapping_factory");
  const [targetCatalog, setTargetCatalog] = useState("");
  const [schema, setSchema] = useState("mapping_factory");
  const [tableType, setTableType] = useState("streaming_table");
  const [schedule, setSchedule] = useState("");

  // deploy run (live commentary) + its final result
  const [deployRun, setDeployRun] = useState<DeployRun | null>(null);
  const result = deployRun?.result ?? null;
  // test run (live commentary for "Test with dummy data")
  const [testRun, setTestRun] = useState<TestRun | null>(null);

  const [defCatalog, setDefCatalog] = useState("the default catalog");

  useEffect(() => {
    api.gitCredential().then((r) => { setCredStored(r.stored); if (r.git_username) setGitUser(r.git_username); });
    api.pipelineDefaults().then((d) => { if (d.catalog) setDefCatalog(d.catalog); }).catch(() => {});
  }, []);

  const saveCred = async () => {
    setBusy("Validating token…"); setErr(null);
    try {
      const r = await api.saveGitCredential({ git_username: gitUser, token });
      setCredStored(true); setGitUser(r.git_username ?? r.github_login ?? gitUser); setToken("");
      await loadRepos(); setStep(1);
    } catch (e) { setErr(msg(e)); } finally { setBusy(null); }
  };

  const loadRepos = async () => {
    try { const r = await api.listGitRepos(); setRepos(r.repos); } catch (e) { setErr(msg(e)); }
  };

  const goRepos = async () => { setErr(null); if (repos === null) await loadRepos(); setStep(1); };

  const ensureRepo = async (): Promise<{ full_name: string; default_branch: string } | null> => {
    if (repoMode === "new") {
      const created = await api.createGitRepo({ name: newRepoName });
      return created;
    }
    const r = repos?.find((x) => x.full_name === repoFull);
    return r ?? (repoFull ? { full_name: repoFull, default_branch: "main" } : null);
  };

  const deploy = async () => {
    setErr(null); setBusy("Starting deploy…"); setDeployRun(null);
    try {
      const r = await ensureRepo();
      if (!r) { setErr("Pick or name a repository."); setBusy(null); return; }
      const targetBranch = branch || r.default_branch;
      const started = await api.deployPipeline(spec.id, {
        repo_full_name: r.full_name,
        branch: targetBranch,
        new_branch_from: branchMode === "new" ? (baseBranch || r.default_branch) : null,
        pipeline_name: pipelineName,
        source_catalog: sourceCatalog.trim() || null,
        source_schema: sourceSchema,
        target_catalog: targetCatalog.trim() || null,
        target_schema: schema,
        table_type: tableType,
        schedule: schedule.trim() || null,
      });
      setStep(4); setBusy(null);
      // Poll the run and stream commentary until it reaches a terminal state.
      const id = started.deploy_id;
      const poll = async () => {
        try {
          const run = await api.deployStatus(id);
          setDeployRun(run);
          if (run.status === "running") setTimeout(poll, 1200);
        } catch (e) { setErr(msg(e)); }
      };
      poll();
    } catch (e) { setErr(msg(e)); setBusy(null); }
  };

  const test = async () => {
    if (!result) return;
    setErr(null); setBusy("Starting test…"); setTestRun(null);
    try {
      const started = await api.testPipeline(spec.id, {
        pipeline_id: result.pipeline_id,
        source_catalog: sourceCatalog.trim() || null,
        source_schema: sourceSchema,
        target_catalog: targetCatalog.trim() || null,
        target_schema: schema,
        table_type: tableType,
      });
      setStep(5); setBusy(null);
      const id = started.test_id;
      const poll = async () => {
        try {
          const run = await api.testStatus(id);
          setTestRun(run);
          if (run.status === "running") setTimeout(poll, 1500);
        } catch (e) { setErr(msg(e)); }
      };
      poll();
    } catch (e) { setErr(msg(e)); setBusy(null); }
  };

  return (
    <div className="fixed inset-0 bg-black/30 grid place-items-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl w-[560px] max-w-full max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        {/* header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <Rocket className="w-4 h-4 text-brand" />
            <h3 className="font-semibold text-gray-800">Deploy as Pipeline — {spec.name}</h3>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
        </div>
        {/* stepper */}
        <div className="flex items-center gap-1 px-5 py-2.5 border-b border-gray-100 text-[11px]">
          {STEPS.map((s, i) => (
            <div key={s} className="flex items-center gap-1">
              <span className={`w-5 h-5 rounded-full grid place-items-center text-[10px] ${i <= step ? "bg-brand text-white" : "bg-gray-100 text-gray-400"}`}>{i + 1}</span>
              <span className={i === step ? "text-gray-800 font-medium" : "text-gray-400"}>{s}</span>
              {i < STEPS.length - 1 && <span className="w-4 h-px bg-gray-200 mx-1" />}
            </div>
          ))}
        </div>

        <div className="px-5 py-4 space-y-3">
          {err && <div className="text-xs text-red-600 bg-red-50 border border-red-100 rounded px-2 py-1.5">{err}</div>}

          {/* Step 0: git access */}
          {step === 0 && (
            <>
              <div className="flex items-center gap-2 text-sm font-medium text-gray-800"><KeyRound className="w-4 h-4 text-brand" /> GitHub access</div>
              {credStored ? (
                <>
                  <p className="text-xs text-green-700 bg-green-50 border border-green-100 rounded px-2 py-1.5">A GitHub token is already stored{gitUser ? ` for ${gitUser}` : ""}. It's encrypted and reused.</p>
                  <div className="flex gap-2">
                    <Button onClick={goRepos} disabled={!!busy}>Continue</Button>
                    <button onClick={() => setCredStored(false)} className="text-xs text-gray-500 hover:text-gray-700 underline">Use a different token</button>
                  </div>
                </>
              ) : (
                <>
                  <p className="text-xs text-gray-500">Enter a GitHub Personal Access Token (repo scope). It's stored <b>encrypted</b> and reused on later deploys.</p>
                  <Labeled label="GitHub username"><input value={gitUser} onChange={(e) => setGitUser(e.target.value)} className="inp" placeholder="octocat" /></Labeled>
                  <Labeled label="Personal Access Token"><input type="password" value={token} onChange={(e) => setToken(e.target.value)} className="inp" placeholder="ghp_…" /></Labeled>
                  <Button onClick={saveCred} disabled={!!busy || !token.trim()}>{busy ? busy : "Save & validate"}</Button>
                </>
              )}
            </>
          )}

          {/* Step 1: repository + branch */}
          {step === 1 && (
            <>
              <div className="flex items-center gap-2 text-sm font-medium text-gray-800"><GitBranch className="w-4 h-4 text-brand" /> Repository & branch</div>
              <div className="flex gap-2 text-xs">
                <Seg on={repoMode === "existing"} onClick={() => setRepoMode("existing")}>Existing repo</Seg>
                <Seg on={repoMode === "new"} onClick={() => setRepoMode("new")}>New repo</Seg>
              </div>
              {repoMode === "existing" ? (
                <Labeled label="Repository">
                  <select value={repoFull} onChange={(e) => setRepoFull(e.target.value)} className="inp">
                    <option value="">{repos === null ? "Loading…" : "Select a repository"}</option>
                    {(repos ?? []).map((r) => <option key={r.full_name} value={r.full_name}>{r.full_name}</option>)}
                  </select>
                </Labeled>
              ) : (
                <Labeled label="New repository name"><input value={newRepoName} onChange={(e) => setNewRepoName(e.target.value)} className="inp" placeholder="my-mapping-pipelines" /></Labeled>
              )}
              <div className="flex gap-2 text-xs">
                <Seg on={branchMode === "new"} onClick={() => setBranchMode("new")}>New branch</Seg>
                <Seg on={branchMode === "existing"} onClick={() => setBranchMode("existing")}>Existing branch</Seg>
              </div>
              <Labeled label={branchMode === "new" ? "New branch name" : "Branch"}><input value={branch} onChange={(e) => setBranch(e.target.value)} className="inp" placeholder={branchMode === "new" ? "feature/finance-pipeline" : "main"} /></Labeled>
              {branchMode === "new" && <Labeled label="Create from"><input value={baseBranch} onChange={(e) => setBaseBranch(e.target.value)} className="inp" placeholder="main" /></Labeled>}
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setStep(0)}>Back</Button>
                <Button onClick={() => setStep(2)} disabled={(repoMode === "existing" && !repoFull) || (repoMode === "new" && !newRepoName.trim()) || !branch.trim()}>Next</Button>
              </div>
            </>
          )}

          {/* Step 2: pipeline config */}
          {step === 2 && (
            <>
              <div className="text-sm font-medium text-gray-800">Pipeline configuration</div>
              <Labeled label="Pipeline name"><input value={pipelineName} onChange={(e) => setPipelineName(e.target.value)} className="inp" /></Labeled>
              <div className="border border-gray-200 rounded-lg p-2.5 space-y-1.5">
                <div className="text-[11px] font-medium text-gray-600">Source — read from</div>
                <div className="grid grid-cols-2 gap-2">
                  <Labeled label="Catalog"><input value={sourceCatalog} onChange={(e) => setSourceCatalog(e.target.value)} className="inp" placeholder={defCatalog} /></Labeled>
                  <Labeled label="Schema"><input value={sourceSchema} onChange={(e) => setSourceSchema(e.target.value)} className="inp" placeholder="raw" /></Labeled>
                </div>
              </div>
              <div className="border border-gray-200 rounded-lg p-2.5 space-y-1.5">
                <div className="text-[11px] font-medium text-gray-600">Target — write to</div>
                <div className="grid grid-cols-2 gap-2">
                  <Labeled label="Catalog"><input value={targetCatalog} onChange={(e) => setTargetCatalog(e.target.value)} className="inp" placeholder={defCatalog} /></Labeled>
                  <Labeled label="Schema"><input value={schema} onChange={(e) => setSchema(e.target.value)} className="inp" placeholder="mapping_factory" /></Labeled>
                </div>
              </div>
              <p className="text-[11px] text-gray-400 -mt-1">Leave a catalog blank to use the default (<code>{defCatalog}</code>). Sources are read from the source catalog/schema; targets are created in the target catalog/schema.</p>
              <div>
                <span className="text-xs text-gray-500 mb-1 block">Target table type</span>
                <div className="grid grid-cols-3 gap-2">
                  {TABLE_TYPES.map((t) => (
                    <button key={t.v} onClick={() => setTableType(t.v)} className={`border rounded-lg p-2 text-left ${tableType === t.v ? "border-brand bg-brand-soft/40" : "border-gray-200 hover:border-brand/40"}`}>
                      <div className="text-xs font-medium text-gray-800">{t.label}</div>
                      <div className="text-[10px] text-gray-400 leading-tight">{t.sub}</div>
                    </button>
                  ))}
                </div>
              </div>
              <Labeled label="Schedule (Quartz cron, optional)"><input value={schedule} onChange={(e) => setSchedule(e.target.value)} className="inp" placeholder="0 0 6 * * ?  (daily 6am UTC)" /></Labeled>
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setStep(1)}>Back</Button>
                <Button onClick={() => setStep(3)} disabled={!pipelineName.trim() || !schema.trim() || !sourceSchema.trim()}>Next</Button>
              </div>
            </>
          )}

          {/* Step 3: review */}
          {step === 3 && (
            <>
              <div className="text-sm font-medium text-gray-800">Review & deploy</div>
              <dl className="text-xs space-y-1.5">
                <Row k="Repository" v={repoMode === "new" ? `${newRepoName} (new)` : repoFull} />
                <Row k="Branch" v={branchMode === "new" ? `${branch} (new, from ${baseBranch})` : branch} />
                <Row k="Pipeline" v={pipelineName} />
                <Row k="Source" v={`${sourceCatalog.trim() || defCatalog}.${sourceSchema}`} />
                <Row k="Target" v={`${targetCatalog.trim() || defCatalog}.${schema} · ${TABLE_TYPES.find((t) => t.v === tableType)?.label}`} />
                <Row k="Schedule" v={schedule.trim() || "manual / triggered"} />
              </dl>
              <p className="text-[11px] text-gray-500">Commits <code>databricks.yml</code>, <code>src/mapping_pipeline.py</code>, and <code>config/mapping_config.json</code> (DAB for CICD), then creates a git-backed pipeline.</p>
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setStep(2)} disabled={!!busy}>Back</Button>
                <Button onClick={deploy} disabled={!!busy}>{busy ? <span className="flex items-center gap-1"><Loader2 className="w-3.5 h-3.5 animate-spin" /> {busy}</span> : <span className="flex items-center gap-1"><Rocket className="w-4 h-4" /> Deploy</span>}</Button>
              </div>
            </>
          )}

          {/* Step 4: live commentary → done / failed */}
          {step === 4 && (
            <>
              <div className="flex items-center gap-2 text-sm font-medium text-gray-800">
                {deployRun?.status === "succeeded" ? <><CheckCircle2 className="w-4 h-4 text-green-600" /> <span className="text-green-700">Pipeline deployed</span></>
                  : deployRun?.status === "failed" ? <><XCircle className="w-4 h-4 text-red-600" /> <span className="text-red-700">Deploy failed</span></>
                  : <><Loader2 className="w-4 h-4 animate-spin text-brand" /> Deploying…</>}
              </div>

              {/* commentary: one row per step */}
              <ol className="space-y-1.5">
                {(deployRun?.steps ?? []).map((s) => (
                  <li key={s.key} className="flex items-start gap-2 text-xs">
                    <span className="mt-0.5">
                      {s.status === "done" ? <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                        : s.status === "running" ? <Loader2 className="w-3.5 h-3.5 animate-spin text-brand" />
                        : s.status === "failed" ? <XCircle className="w-3.5 h-3.5 text-red-600" />
                        : <Circle className="w-3.5 h-3.5 text-gray-300" />}
                    </span>
                    <span className="flex-1">
                      <span className={s.status === "pending" ? "text-gray-400" : "text-gray-800 font-medium"}>{s.label}</span>
                      <span className="text-gray-400"> — {s.description}</span>
                      {s.detail && <span className={`block ${s.status === "failed" ? "text-red-600" : "text-gray-500"} break-all`}>{s.detail}</span>}
                    </span>
                    {s.elapsed_sec != null && <span className="text-[10px] text-gray-400 tabular-nums">{s.elapsed_sec}s</span>}
                  </li>
                ))}
              </ol>

              {deployRun?.status === "failed" && (
                <div className="text-xs text-red-600 bg-red-50 border border-red-100 rounded px-2 py-1.5 space-y-1">
                  <div>{deployRun.error}</div>
                  {deployRun.cleanup && <div className="text-gray-500">Cleanup: {deployRun.cleanup}</div>}
                </div>
              )}

              {deployRun?.status === "succeeded" && result && (
                <>
                  <div className="flex flex-wrap gap-3 text-xs pt-1">
                    <a href={result.commit_url} target="_blank" rel="noreferrer" className="text-brand inline-flex items-center gap-1">View commit <ExternalLink className="w-3 h-3" /></a>
                    <a href={result.pipeline_url} target="_blank" rel="noreferrer" className="text-brand inline-flex items-center gap-1">Open pipeline <ExternalLink className="w-3 h-3" /></a>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <Button onClick={test} disabled={!!busy}>{busy ? busy : <span className="flex items-center gap-1"><FlaskConical className="w-4 h-4" /> Test with dummy data</span>}</Button>
                    <Button variant="secondary" onClick={onClose}>Done</Button>
                  </div>
                  <p className="text-[11px] text-gray-400">Testing seeds dummy source data, then the pipeline + its runs appear in the Execution Monitor.</p>
                </>
              )}

              {deployRun?.status === "failed" && (
                <div className="flex gap-2 pt-1">
                  <Button variant="secondary" onClick={() => setStep(3)}>Back to review</Button>
                  <Button variant="secondary" onClick={onClose}>Close</Button>
                </div>
              )}
            </>
          )}

          {/* Step 5: test-with-dummy-data live commentary */}
          {step === 5 && (
            <>
              <div className="flex items-center gap-2 text-sm font-medium text-gray-800">
                {testRun?.status === "succeeded" ? <><CheckCircle2 className="w-4 h-4 text-green-600" /> <span className="text-green-700">Test run complete</span></>
                  : testRun?.status === "failed" ? <><XCircle className="w-4 h-4 text-red-600" /> <span className="text-red-700">Test run failed</span></>
                  : <><Loader2 className="w-4 h-4 animate-spin text-brand" /> Testing with dummy data…</>}
              </div>

              <ol className="space-y-1.5">
                {(testRun?.steps ?? []).map((s) => (
                  <li key={s.key} className="flex items-start gap-2 text-xs">
                    <span className="mt-0.5">
                      {s.status === "done" ? <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                        : s.status === "running" ? <Loader2 className="w-3.5 h-3.5 animate-spin text-brand" />
                        : s.status === "failed" ? <XCircle className="w-3.5 h-3.5 text-red-600" />
                        : <Circle className="w-3.5 h-3.5 text-gray-300" />}
                    </span>
                    <span className="flex-1">
                      <span className={s.status === "pending" ? "text-gray-400" : "text-gray-800 font-medium"}>{s.label}</span>
                      <span className="text-gray-400"> — {s.description}</span>
                      {s.detail && <span className={`block ${s.status === "failed" ? "text-red-600" : "text-gray-500"} break-all`}>{s.detail}</span>}
                    </span>
                    {s.elapsed_sec != null && <span className="text-[10px] text-gray-400 tabular-nums">{s.elapsed_sec}s</span>}
                  </li>
                ))}
              </ol>

              {testRun?.status === "failed" && (
                <div className="text-xs text-red-600 bg-red-50 border border-red-100 rounded px-2 py-1.5">{testRun.error}</div>
              )}

              {testRun?.status === "succeeded" && testRun.result && (
                <div className="text-xs space-y-1.5">
                  <div className="font-medium text-gray-700">Results per target</div>
                  {testRun.result.targets.map((t) => (
                    <div key={t.target} className="flex justify-between gap-3 border border-gray-100 rounded px-2 py-1">
                      <span className="text-gray-800 break-all">{t.target}</span>
                      <span className="text-gray-500 shrink-0 tabular-nums">
                        {t.rows ?? 0} rows{(t.quarantined ?? 0) > 0 && <span className="text-amber-600"> · {t.quarantined} quarantined</span>}
                      </span>
                    </div>
                  ))}
                  <div className="text-gray-500">{testRun.result.audit_rows} DQ audit row(s) written for quality metrics.</div>
                </div>
              )}

              {testRun && testRun.status !== "running" && (
                <div className="flex gap-2 pt-1">
                  <Button onClick={() => nav("/executions")}>Open Execution Monitor</Button>
                  <Button variant="secondary" onClick={onClose}>Done</Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Labeled({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="block"><span className="text-xs text-gray-500 mb-1 block">{label}</span>{children}</label>;
}
function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between gap-3"><dt className="text-gray-500 shrink-0">{k}</dt><dd className="text-gray-800 text-right break-all">{v}</dd></div>;
}
function Seg({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return <button onClick={onClick} className={`px-2.5 py-1 rounded-lg border ${on ? "border-brand bg-brand-soft/40 text-brand" : "border-gray-200 text-gray-600"}`}>{children}</button>;
}
function slug(s: string) { return s.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "mapping"; }
function msg(e: unknown) { return e instanceof Error ? e.message : String(e); }
