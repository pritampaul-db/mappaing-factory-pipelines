"""Mapping specs + AI auto-mapping (M3)."""
from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, HTTPException

from pydantic import BaseModel

from server import config, compiler, db, governance, llm, repo, repo_library, warehouse
from server.models import LayoutPut, MappingCurate, SpecCreate

router = APIRouter(tags=["specs"])


def _current_user() -> str:
    try:
        return config.get_workspace_client().current_user.me().user_name or "unknown"
    except Exception:
        return "unknown"


@router.post("/specs")
def create_spec(body: SpecCreate) -> dict:
    spec = repo.create_spec(
        db.pool,
        name=body.name,
        source_asset_id=body.source_asset_id,
        target_asset_id=body.target_asset_id,
        owner=_current_user(),
    )
    # Optional source/target SYSTEM names entered in the New Mapping setup.
    if body.source_system or body.target_system:
        repo.set_spec_systems(db.pool, spec["id"], source_system=body.source_system, target_system=body.target_system)
        spec = repo.get_spec(db.pool, spec["id"])
    return spec


class SpecSystems(BaseModel):
    source_system: str | None = None
    target_system: str | None = None


@router.patch("/specs/{spec_id}/systems")
def set_spec_systems(spec_id: UUID, body: SpecSystems) -> dict:
    """Set the source/target system names on a spec (New Mapping setup / details)."""
    if repo.get_spec(db.pool, spec_id) is None:
        raise HTTPException(status_code=404, detail="spec not found")
    repo.set_spec_systems(db.pool, spec_id, source_system=body.source_system, target_system=body.target_system)
    return repo.get_spec(db.pool, spec_id)


@router.delete("/specs/{spec_id}")
def delete_spec(spec_id: UUID) -> dict:
    """Delete a mapping spec and its dependent rows."""
    if not repo.delete_spec(db.pool, spec_id):
        raise HTTPException(status_code=404, detail="spec not found")
    return {"deleted": str(spec_id)}


@router.post("/specs/{spec_id}/clone")
def clone_spec(spec_id: UUID) -> dict:
    """Deep-copy a spec into a new Draft owned by the current user."""
    new = repo.clone_spec(db.pool, spec_id, owner=_current_user())
    if new is None:
        raise HTTPException(status_code=404, detail="spec not found")
    return new


class TablePick(BaseModel):
    table_name: str
    fields: list[dict]  # [{name, datatype, nullable, is_key?, description?, ordinal?}]


class MultiSpecCreate(BaseModel):
    name: str | None = None
    sources: list[TablePick]  # picked source tables
    targets: list[TablePick]  # picked target tables


@router.post("/specs/multi")
def create_spec_multi(body: MultiSpecCreate) -> dict:
    """Create a spec spanning multiple source/target tables (multi-table mapping).

    Each picked table becomes a physical_asset (object_type='extracted_schema');
    the spec links them all via mapping_spec_asset. Returns the full spec.
    """
    if not body.sources or not body.targets:
        raise HTTPException(status_code=422, detail="pick at least one source and one target table")
    owner = _current_user()

    def _mk(t: "TablePick", role: str):
        fields = [
            {
                "name": f["name"],
                "datatype": f.get("datatype", "string"),
                "nullable": f.get("nullable", True),
                "ordinal": f.get("ordinal", i),
                "semantic_type": "key" if f.get("is_key") else None,
            }
            for i, f in enumerate(t.fields)
        ]
        return repo.create_asset(db.pool, name=t.table_name, object_type="extracted_schema", role=role, created_by=owner, fields=fields)

    src_assets = [_mk(t, "source") for t in body.sources]
    tgt_assets = [_mk(t, "target") for t in body.targets]
    name = body.name or f"{src_assets[0]['name']}{'+' if len(src_assets) > 1 else ''} → {tgt_assets[0]['name']}{'+' if len(tgt_assets) > 1 else ''}"
    spec = repo.create_spec_multi(
        db.pool,
        name=name,
        source_asset_ids=[a["id"] for a in src_assets],
        target_asset_ids=[a["id"] for a in tgt_assets],
        owner=owner,
    )
    return repo.get_spec(db.pool, spec["id"])


class SpecRename(BaseModel):
    name: str


@router.patch("/specs/{spec_id}")
def rename_spec(spec_id: UUID, body: SpecRename) -> dict:
    """Rename a mapping spec (the editable name in the designer header)."""
    name = (body.name or "").strip()
    if not name:
        raise HTTPException(status_code=422, detail="name cannot be empty")
    if repo.get_spec(db.pool, spec_id) is None:
        raise HTTPException(status_code=404, detail="spec not found")
    repo.rename_spec(db.pool, spec_id, name)
    return repo.get_spec(db.pool, spec_id)


@router.get("/specs")
def list_specs() -> list[dict]:
    return repo.list_specs(db.pool)


@router.get("/specs/{spec_id}")
def get_spec(spec_id: UUID) -> dict:
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    return spec


def _suggest_multi(spec_id: UUID, spec: dict, sources: list[dict], targets: list[dict]) -> dict:
    """Multi-table suggest: AI proposes joins across source tables + per-target-column
    mappings that may draw from joined tables. Column refs are qualified table.column;
    we resolve them to global field ids across all source/target assets."""
    # Qualified-name → field row, across all assets on each side.
    src_by_qual: dict[str, dict] = {}
    for a in sources:
        for f in a["fields"]:
            src_by_qual[f"{a['name']}.{f['name']}"] = f
    tgt_by_qual: dict[str, dict] = {}
    for a in targets:
        for f in a["fields"]:
            tgt_by_qual[f"{a['name']}.{f['name']}"] = f

    src_tables = [{"name": a["name"], "fields": a["fields"]} for a in sources]
    tgt_tables = [{"name": a["name"], "fields": a["fields"]} for a in targets]

    # Reuse-first: published transformation library, referenced by code.
    try:
        xform_catalog = repo_library.published_transformation_catalog(db.pool)
    except Exception:  # noqa: BLE001
        xform_catalog = []
    xform_by_code = {c["code"]: c for c in xform_catalog}

    try:
        out = llm.suggest_mappings_multi(src_tables, tgt_tables, transform_catalog=xform_catalog)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"AI suggestion failed: {e}")

    # Resolve join keys to ids (kept as spec-level metadata + attached per-mapping).
    joins = []
    for j in out.get("joins", []):
        left, right = src_by_qual.get(j.get("left")), src_by_qual.get(j.get("right"))
        if left and right:
            joins.append({"left": j["left"], "right": j["right"], "left_id": str(left["id"]), "right_id": str(right["id"]),
                          "confidence": j.get("confidence"), "rationale": j.get("rationale")})

    decided = {m["target_field_name"] for m in spec["mappings"] if m["state"] in ("accepted", "edited")}
    candidates: list[dict] = []
    skipped: list[dict] = []
    seen: set[str] = set()
    for m in out.get("mappings", []):
        tf_qual = m.get("target_field")
        tgt = tgt_by_qual.get(tf_qual)
        if tgt is None:
            skipped.append({"reason": "unknown target field", "item": m})
            continue
        # De-dup by target field id (a column name can repeat across target tables).
        key = str(tgt["id"])
        if key in seen or tgt["name"] in decided:
            skipped.append({"reason": "duplicate target field", "item": m})
            continue
        seen.add(key)
        src_ids = [src_by_qual[s]["id"] for s in m.get("source_fields", []) if s in src_by_qual]
        # Which source tables this mapping spans (for join awareness downstream).
        src_tables_used = sorted({s.split(".")[0] for s in m.get("source_fields", []) if s in src_by_qual})
        reuse_code = (m.get("reuse_code") or "").strip()
        reused = xform_by_code.get(reuse_code) if reuse_code else None
        candidates.append({
            "target_field_id": tgt["id"],
            "source_field_ids": src_ids,
            "transform_kind": "spec",
            "transform_spec": m.get("transform", {}),
            "confidence": m.get("confidence"),
            "description": m.get("rationale"),
            "provenance": {
                "origin": "AI",
                "model_id": config.LLM_ENDPOINT,
                "rationale": m.get("rationale"),
                "source_field_names": m.get("source_fields", []),
                "source_tables": src_tables_used,
                "target_table": tf_qual.split(".")[0] if tf_qual else None,
                "reused_transformation_code": reused["code"] if reused else None,
                "reused_transformation_id": str(reused["id"]) if reused else None,
                "reused_transformation_name": reused["name"] if reused else None,
                "is_new_transformation": reused is None,
            },
        })

    mappings = repo.replace_ai_suggestions(db.pool, spec_id, candidates)
    # Persist joins on the spec (reused by the multi-box canvas + Phase-2 compiler).
    try:
        repo.set_spec_joins(db.pool, spec_id, joins)
    except Exception:  # noqa: BLE001
        pass
    return {
        "spec_id": str(spec_id),
        "suggested": len(candidates),
        "skipped": skipped,
        "joins": joins,
        "exemplars_used": 0,
        "mappings": mappings,
    }


@router.post("/specs/{spec_id}/suggest")
def suggest(spec_id: UUID) -> dict:
    """AI proposes field mappings; persisted as Draft with provenance (P1: propose only)."""
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")

    sources = spec.get("sources") or []
    targets = spec.get("targets") or []
    # Multi-table spec (>1 source or >1 target table) → the join-aware path.
    if len(sources) > 1 or len(targets) > 1:
        return _suggest_multi(spec_id, spec, sources, targets)

    source = repo.get_asset(db.pool, spec["source_asset_id"])
    target = repo.get_asset(db.pool, spec["target_asset_id"])
    if not source or not target:
        raise HTTPException(status_code=422, detail="spec is missing source or target asset")

    # Index target/source fields by name for id resolution.
    tgt_by_name = {f["name"]: f for f in target["fields"]}
    src_by_name = {f["name"]: f for f in source["fields"]}

    # Targets a human already decided (accepted/edited) are preserved across a
    # re-suggest, so don't propose a second mapping for the same column.
    decided_targets = {
        m["target_field_name"] for m in spec["mappings"] if m["state"] in ("accepted", "edited")
    }

    # Tier-1 self-learning: retrieve similar APPROVED mappings as few-shot
    # exemplars. A target-schema summary is the query; cold-start returns none.
    from server import retrieval

    query = "; ".join(f"{f['name']} ({f['datatype']})" for f in target["fields"])
    try:
        exemplars = retrieval.search_similar(query, k=6)
    except Exception:  # noqa: BLE001 — retrieval is an enhancement, never a hard dep
        exemplars = []

    # Reuse-first: give the model the published transformation library so it prefers
    # an existing transformation (by code) before inventing a new one.
    try:
        xform_catalog = repo_library.published_transformation_catalog(db.pool)
    except Exception:  # noqa: BLE001
        xform_catalog = []
    xform_by_code = {c["code"]: c for c in xform_catalog}

    try:
        raw = llm.suggest_mappings(source["fields"], target["fields"], exemplars=exemplars, transform_catalog=xform_catalog)
    except Exception as e:  # noqa: BLE001 — surface FM API failures, never write junk
        raise HTTPException(status_code=502, detail=f"AI suggestion failed: {e}")

    candidates: list[dict] = []
    skipped: list[dict] = []
    seen_targets: set[str] = set()
    for m in raw:
        tf = m.get("target_field")
        tgt = tgt_by_name.get(tf)
        if tgt is None:
            skipped.append({"reason": "unknown target field", "item": m})
            continue
        # One mapping per target column. Drop a duplicate the model emitted for the
        # same target, and never shadow a column a human already decided.
        if tf in seen_targets or tf in decided_targets:
            skipped.append({"reason": "duplicate target field", "item": m})
            continue
        seen_targets.add(tf)
        src_ids = [src_by_name[s]["id"] for s in m.get("source_fields", []) if s in src_by_name]
        transform = m.get("transform", {})
        # Reuse-first: did the model reference an existing library transformation?
        reuse_code = (m.get("reuse_code") or "").strip()
        reused = xform_by_code.get(reuse_code) if reuse_code else None
        candidates.append(
            {
                "target_field_id": tgt["id"],
                "source_field_ids": src_ids,
                "transform_kind": "spec",
                "transform_spec": transform,
                "confidence": m.get("confidence"),
                "description": m.get("rationale"),
                "provenance": {
                    "origin": "AI",
                    "model_id": config.LLM_ENDPOINT,
                    "rationale": m.get("rationale"),
                    "source_field_names": m.get("source_fields", []),
                    # Library reuse: link to the reused transformation, or flag as new.
                    "reused_transformation_code": reused["code"] if reused else None,
                    "reused_transformation_id": str(reused["id"]) if reused else None,
                    "reused_transformation_name": reused["name"] if reused else None,
                    "is_new_transformation": reused is None,
                },
            }
        )

    mappings = repo.replace_ai_suggestions(db.pool, spec_id, candidates)
    return {
        "spec_id": str(spec_id),
        "suggested": len(candidates),
        "skipped": skipped,
        "exemplars_used": len(exemplars),
        "mappings": mappings,
    }


@router.post("/specs/{spec_id}/optimize")
def optimize(spec_id: UUID) -> dict:
    """AI reviews the current per-column transforms and proposes optimizations.

    Propose-only (P1): nothing is written. For each active column we deterministically
    lower its transform to SQL (the same lowering the compiler uses), ask the model for
    semantics-preserving rewrites — chiefly merging a multi-step derivation into one
    custom expression — then GATE every proposal through sqlglot (parse + source-column
    existence + must actually differ) before returning it. Invalid proposals are dropped.
    Each surviving proposal carries the mapping_id + a ready-to-apply transform_spec.
    """
    import sqlglot
    from sqlglot import exp

    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    # Source types pooled across ALL source tables (qualified `Table.col` AND bare),
    # so an optimization touching a joined table's column isn't dropped as "unknown".
    sources = spec.get("sources") or ([s] if (s := repo.get_asset(db.pool, spec["source_asset_id"])) else [])
    if not sources:
        raise HTTPException(status_code=422, detail="spec is missing its source asset")
    source_types: dict[str, str] = {}
    for a in sources:
        for f in a["fields"]:
            source_types[f["name"]] = f["datatype"]
            source_types[f"{a['name']}.{f['name']}"] = f["datatype"]
    # Target types pooled across ALL target tables (multi-target specs).
    targets = spec.get("targets") or ([t] if (t := repo.get_asset(db.pool, spec["target_asset_id"])) else [])
    target_types: dict[str, str] = {f["name"]: f["datatype"] for a in targets for f in a["fields"]}

    active = [m for m in spec["mappings"] if m["state"] != "rejected"]
    if not active:
        return {"spec_id": str(spec_id), "optimizations": [], "reviewed": 0, "skipped": []}

    skipped: list[dict] = []

    # Build each TARGET column's current derivation(s) the deterministic way, GROUPED
    # by target — a column may be produced by more than one transformer (e.g. a rename
    # plus a CASE), which is exactly the multi-step merge case Optimize should combine.
    # Columns whose transform can't be lowered (unknown op) are simply not offered.
    def _entry_tables(m: dict) -> list[str]:
        return (m.get("provenance") or {}).get("source_tables") or []

    by_target: dict[str, list[dict]] = {}
    for m in active:
        kind = m.get("transform_kind") or "spec"
        try:
            if kind == "spec" and m.get("transform_spec"):
                current_expr, _ = compiler._lower_spec_to_sql(m["transform_spec"], source_types)
            elif kind == "sql_expr" and m.get("transform_sql"):
                current_expr = m["transform_sql"]
            else:
                continue
        except Exception:  # noqa: BLE001 — unlowerable column is simply not offered
            continue
        by_target.setdefault(m["target_field_name"], []).append({"mapping": m, "expr": current_expr})

    columns: list[dict] = []
    for tf, entries in by_target.items():
        # A "merge" is only valid across steps on the SAME source table. When a target is
        # populated from DIFFERENT source tables (a multi-source resolution — e.g. the same
        # key coming off several joined tables), folding them into a cross-table COALESCE
        # would CHANGE the semantics, so we do not offer Optimize on it at all.
        tables = {t for e in entries for t in _entry_tables(e["mapping"])}
        if len(tables) > 1:
            skipped.append({"reason": "multi-source column — not a merge candidate",
                            "target_field": tf, "source_tables": sorted(tables)})
            continue
        src_names: list[str] = []
        for e in entries:
            for n in (e["mapping"].get("provenance") or {}).get("source_field_names") or []:
                if n not in src_names:
                    src_names.append(n)
        columns.append(
            {
                "target_field": tf,
                "target_type": target_types.get(tf, "unknown"),
                "source_fields": src_names,
                "current_exprs": [e["expr"] for e in entries],
            }
        )

    if not columns:
        return {"spec_id": str(spec_id), "optimizations": [], "reviewed": 0, "skipped": skipped}

    try:
        raw = llm.optimize_transformations(columns)
    except Exception as e:  # noqa: BLE001 — surface FM API failures, never write junk
        raise HTTPException(status_code=502, detail=f"AI optimization failed: {e}")

    def _norm(sql: str) -> str:
        try:
            return sqlglot.parse_one(sql, read=compiler.DIALECT).sql(dialect=compiler.DIALECT)
        except Exception:  # noqa: BLE001
            return sql

    optimizations: list[dict] = []
    for i, o in enumerate(raw):
        tf = o.get("target_field")
        entries = by_target.get(tf)
        expr = (o.get("expr") or "").strip()
        if not entries or not expr:
            skipped.append({"reason": "unknown target or empty expr", "item": o})
            continue
        # Deterministic gate: must parse, reference only real source columns, and
        # actually change the current derivation (no cosmetic no-ops).
        try:
            ast = sqlglot.parse_one(expr, read=compiler.DIALECT)
        except Exception:  # noqa: BLE001
            skipped.append({"reason": "unparseable", "target_field": tf, "expr": expr})
            continue
        # A ref is known if its bare name OR its qualified `Table.col` is pooled
        # (multi-source pools both spellings; single-source pools bare only).
        unknown = set()
        for c in ast.find_all(exp.Column):
            qualified = f"{c.table}.{c.name}" if c.table else c.name
            if qualified not in source_types and c.name not in source_types:
                unknown.add(qualified)
        if unknown:
            skipped.append({"reason": f"unknown columns {sorted(unknown)}", "target_field": tf})
            continue
        normalized = ast.sql(dialect=compiler.DIALECT)
        current_norms = [_norm(e["expr"]) for e in entries]
        is_merge = len(entries) > 1
        # For a single-step column, skip a proposal that changes nothing. For a
        # multi-step column, collapsing N steps into 1 is itself the improvement.
        if not is_merge and normalized == current_norms[0]:
            skipped.append({"reason": "no-op", "target_field": tf})
            continue
        primary = entries[0]["mapping"]
        before_display = (
            "  ▸  ".join(current_norms) if is_merge else current_norms[0]
        )
        optimizations.append(
            {
                "id": f"{primary['id']}:{i}",
                "mapping_id": str(primary["id"]),
                # Other mappings for the same target that this merge absorbs; the UI
                # rejects these when the optimization is applied so only one remains.
                "merged_mapping_ids": [str(e["mapping"]["id"]) for e in entries[1:]],
                "target_field": tf,
                "kind": o.get("kind", "merge" if is_merge else "other"),
                "title": o.get("title") or (f"Merge {len(entries)} transformers for {tf}" if is_merge else f"Optimize {tf}"),
                "rationale": o.get("rationale") or "",
                "impact": o.get("impact", "medium"),
                "before": before_display,
                "after": normalized,
                "transform_spec": {"op": "expr", "expr": normalized},
            }
        )

    return {
        "spec_id": str(spec_id),
        "reviewed": len(columns),
        "optimizations": optimizations,
        "skipped": skipped,
    }


@router.post("/specs/{spec_id}/validate")
def validate_mapping(spec_id: UUID) -> dict:
    """AI proposes post-transformation DATA-QUALITY checks for the target columns.

    Propose-only (P1): nothing is written. We describe each target column + its
    transform + whether it already has a validation (coverage), ask the model for
    DQ checks, then GATE every proposed SQL boolean through sqlglot (parse +
    references only real target columns) before returning it. Invalid ones drop.
    """
    import sqlglot
    from sqlglot import exp

    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    targets = spec.get("targets") or ([t] if (t := repo.get_asset(db.pool, spec["target_asset_id"])) else [])
    if not targets:
        raise HTTPException(status_code=422, detail="spec is missing its target asset")

    # Source column types are pooled across ALL source tables (a transform may draw
    # from any of them via joins), qualified + bare so lowering resolves either form.
    sources = spec.get("sources") or ([s] if (s := repo.get_asset(db.pool, spec["source_asset_id"])) else [])
    source_types: dict[str, str] = {}
    for a in sources:
        for f in a["fields"]:
            source_types[f["name"]] = f["datatype"]
            source_types[f"{a['name']}.{f['name']}"] = f["datatype"]

    # field id → target asset, so each active mapping is bucketed to its own table.
    tgt_asset_by_field: dict[str, dict] = {}
    for a in targets:
        for f in a["fields"]:
            tgt_asset_by_field[str(f["id"])] = a

    # Coverage reflects only THIS spec's saved checks (scoped by spec:<id> tag) — a
    # same-named dataset from another mapping must not count as "already covered".
    spec_tag = f"spec:{spec_id}"
    try:
        all_existing = [v for v in repo_library.list_validations(db.pool) if spec_tag in (v.get("tags") or [])]
    except Exception:  # noqa: BLE001 — coverage is advisory; never block on it
        all_existing = []

    # Reuse-first: published Rule Library, referenced by code so the model reuses an
    # existing rule before inventing a new one.
    try:
        rule_catalog = repo_library.published_rule_catalog(db.pool)
    except Exception:  # noqa: BLE001
        rule_catalog = []
    rule_by_code = {c["code"]: c for c in rule_catalog}

    active = [m for m in spec["mappings"] if m["state"] != "rejected"]
    proposals: list[dict] = []
    skipped: list[dict] = []
    tables_out: list[dict] = []
    total_covered = 0
    total_cols = 0
    # Dedupe proposals: the model sometimes returns the SAME check twice for a column
    # (and re-running compounds it) — a column must never show duplicate checks. Key on
    # (dataset, column, normalized-logic) with whitespace collapsed + case-folded.
    seen_props: set[tuple[str, str, str]] = set()

    def _norm_logic(s: str) -> str:
        return " ".join((s or "").split()).lower()

    # One AI review PER TARGET TABLE — each dataset is validated against its own columns.
    for tgt in targets:
        dataset = tgt["name"]
        target_types = {f["name"]: f["datatype"] for f in tgt["fields"]}
        covered = {v.get("column_name") for v in all_existing if v.get("dataset") == dataset and v.get("column_name")}

        cols_for_tgt = [m for m in active if tgt_asset_by_field.get(str(m["target_field_id"])) is tgt]
        columns: list[dict] = []
        for m in cols_for_tgt:
            tf = m["target_field_name"]
            expr = None
            try:
                if (m.get("transform_kind") or "spec") == "spec" and m.get("transform_spec"):
                    expr, _ = compiler._lower_spec_to_sql(m["transform_spec"], source_types)
                elif m.get("transform_sql"):
                    expr = m["transform_sql"]
            except Exception:  # noqa: BLE001 — a column we can't lower is still worth validating
                expr = None
            columns.append({"target_field": tf, "target_type": target_types.get(tf, "unknown"), "transform_expr": expr, "has_validation": tf in covered})

        total_cols += len(columns)
        total_covered += len(covered & set(target_types))
        if not columns:
            tables_out.append({"target_table": dataset, "dataset": dataset, "proposed": 0, "covered": len(covered), "total": 0})
            continue

        try:
            raw = llm.suggest_validations(columns, rule_catalog=rule_catalog)
        except Exception as e:  # noqa: BLE001 — surface FM API failures, never write junk
            raise HTTPException(status_code=502, detail=f"AI validation review failed for {dataset}: {e}")

        proposed_here = 0
        for i, v in enumerate(raw):
            tf = v.get("target_field")
            logic = (v.get("logic") or "").strip()
            if tf not in target_types or not logic:
                skipped.append({"reason": "unknown target or empty logic", "item": v, "dataset": dataset})
                continue
            try:
                ast = sqlglot.parse_one(logic, read=compiler.DIALECT)
            except Exception:  # noqa: BLE001
                skipped.append({"reason": "unparseable", "target_field": tf, "logic": logic, "dataset": dataset})
                continue
            referenced = {c.name for c in ast.find_all(exp.Column)}
            unknown = referenced - set(target_types)
            if unknown:
                skipped.append({"reason": f"unknown columns {sorted(unknown)}", "target_field": tf, "dataset": dataset})
                continue
            if list(ast.find_all(exp.Window)) or list(ast.find_all(exp.AggFunc)):
                skipped.append({"reason": "not a row-level predicate", "target_field": tf, "logic": logic, "dataset": dataset})
                continue
            normalized_sql = ast.sql(dialect=compiler.DIALECT)
            dkey = (dataset.lower(), tf.lower(), _norm_logic(normalized_sql))
            if dkey in seen_props:
                skipped.append({"reason": "duplicate check", "target_field": tf, "logic": logic, "dataset": dataset})
                continue
            seen_props.add(dkey)
            reuse_code = (v.get("reuse_code") or "").strip()
            reused = rule_by_code.get(reuse_code) if reuse_code else None
            proposals.append({
                "id": f"{spec_id}:{dataset}:{i}",
                "target_field": tf,
                "target_table": dataset,
                "dataset": dataset,
                "rule_type": v.get("rule_type", "validity"),
                "severity": v.get("severity", "medium"),
                "name": v.get("name") or f"{tf} check",
                "rationale": v.get("rationale") or "",
                "logic": normalized_sql,
                "covered": tf in covered,
                # Library reuse: link to the reused rule, or flag as new.
                "reused_rule_code": reused["code"] if reused else None,
                "reused_rule_id": str(reused["id"]) if reused else None,
                "reused_rule_name": reused["name"] if reused else None,
                "is_new_rule": reused is None,
            })
            proposed_here += 1
        tables_out.append({"target_table": dataset, "dataset": dataset, "proposed": proposed_here, "covered": len(covered), "total": len(columns)})

    return {
        "spec_id": str(spec_id),
        # `dataset` kept for back-compat (first target); multi-table clients use `tables`.
        "dataset": targets[0]["name"],
        "coverage": {"covered": total_covered, "total": total_cols},
        "tables": tables_out,
        "validations": proposals,
        "skipped": skipped,
    }


class ValidationApply(BaseModel):
    dataset: str
    items: list[dict]  # each: {target_field, rule_type, severity, name, logic}


@router.post("/specs/{spec_id}/validations/apply")
def apply_validations(spec_id: UUID, body: ValidationApply) -> dict:
    """Persist accepted validation proposals into the DQ Library (validation_rule)."""
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    owner = _current_user()
    created: list[dict] = []
    skipped: list[dict] = []
    duplicates: list[dict] = []
    import uuid as _uuid

    def _norm(s: str | None) -> str:
        # Normalize logic for identity: collapse whitespace + case-fold so trivially
        # different spellings of the same predicate still dedupe.
        return " ".join((s or "").split()).lower()

    # Idempotency: skip a proposal that already exists for THIS spec (same dataset +
    # column + normalized logic). Re-running "Validate mapping" and re-applying used to
    # accumulate identical rows because the code carried a random suffix. Seed the seen
    # set from the spec's already-applied checks, then also dedupe within this batch.
    spec_tag = f"spec:{spec_id}"
    seen: set[tuple[str, str, str]] = set()
    try:
        for v in repo_library.list_validations(db.pool):
            if spec_tag in (v.get("tags") or []):
                seen.add(((v.get("dataset") or "").lower(), (v.get("column_name") or "").lower(), _norm(v.get("logic"))))
    except Exception:  # noqa: BLE001 — if the read fails, fall back to batch-only dedup
        pass

    for it in body.items:
        tf = it.get("target_field") or "col"
        key = ((body.dataset or "").lower(), (tf or "").lower(), _norm(it.get("logic")))
        if key in seen:
            duplicates.append({"target_field": tf, "logic": it.get("logic")})
            continue
        seen.add(key)
        # Unique code: dataset+column+rule_type + a short random suffix so re-applying
        # (or two checks of the same type on a column) never trips the UNIQUE(code).
        base = f"{body.dataset}_{tf}_{it.get('rule_type', 'validity')}".upper().replace(".", "_")[:44]
        code = f"{base}_{_uuid.uuid4().hex[:6].upper()}"
        # Reuse-first provenance carried from the proposal: tag with the reused Rule
        # Library rule (so publish-contribution doesn't re-add it), else mark new-rule.
        reused_rule_id = it.get("reused_rule_id")
        tags = ["mapping-derived", spec["name"], f"spec:{spec_id}"]
        tags.append(f"rule:{reused_rule_id}" if reused_rule_id else "new-rule")
        try:
            row = repo_library.create_validation(
                db.pool,
                {
                    "name": it.get("name") or f"{tf} check",
                    "code": code,
                    "rule_type": it.get("rule_type", "validity"),
                    "dataset": body.dataset,
                    "column_name": tf,
                    "severity": it.get("severity", "medium"),
                    # AI-suggested pipeline DQ routing; falls back to the rule_type default
                    # in create_validation when absent. A human can change it later.
                    "dq_action": it.get("dq_action"),
                    "description": it.get("rationale") or f"Post-transformation check on {tf}.",
                    "logic": it.get("logic"),
                    # Tag with the spec id so the canvas/wizard can scope applied
                    # validations to THIS mapping (dataset name alone isn't unique).
                    "tags": tags,
                },
                owner,
            )
            created.append(row)
        except Exception as e:  # noqa: BLE001 — one bad row shouldn't abort the batch
            skipped.append({"target_field": tf, "error": str(e)})
    return {"created": len(created), "skipped": skipped,
            "duplicates": len(duplicates), "validations": created}


class DqActionIn(BaseModel):
    dq_action: str  # 'warn' | 'fail'


@router.post("/validations/{validation_id}/dq-action")
def set_validation_dq_action(validation_id: UUID, body: DqActionIn) -> dict:
    """Human override of a validation's pipeline DQ routing (warn=log / fail=quarantine)."""
    try:
        row = repo_library.set_validation_dq_action(db.pool, validation_id, dq_action=body.dq_action)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    if row is None:
        raise HTTPException(status_code=404, detail="validation not found")
    return {"id": str(row["id"]), "dq_action": row.get("dq_action")}


def _gate_dq(logic: str) -> str:
    """Parse + sanity-check a DQ boolean predicate; return normalized SQL or raise 422."""
    import sqlglot
    logic = (logic or "").strip()
    if not logic:
        raise HTTPException(status_code=422, detail="empty rule logic")
    try:
        ast = sqlglot.parse_one(logic, read=compiler.DIALECT)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=422, detail=f"rule logic does not parse: {e}")
    if list(ast.find_all(sqlglot.exp.Window)) or list(ast.find_all(sqlglot.exp.AggFunc)):
        raise HTTPException(status_code=422, detail="rule must be a row-level predicate (no window/aggregate)")
    return ast.sql(dialect=compiler.DIALECT)


def _create_scoped_validation(spec: dict, spec_id: UUID, *, dataset: str, column: str, logic: str,
                              name: str, rule_type: str, severity: str, description: str | None,
                              reused_rule_id: str | None, owner: str) -> dict:
    """Create ONE dataset-scoped validation for a spec (dedup-aware). Shared by add-check
    and cross-table propagation. Returns the created row, or a {'duplicate': True} marker."""
    import uuid as _uuid

    def _norm(s: str | None) -> str:
        return " ".join((s or "").split()).lower()

    spec_tag = f"spec:{spec_id}"
    for v in repo_library.list_validations(db.pool):
        if spec_tag in (v.get("tags") or []) and (v.get("dataset") or "").lower() == dataset.lower() \
                and (v.get("column_name") or "").lower() == column.lower() and _norm(v.get("logic")) == _norm(logic):
            return {"duplicate": True, "dataset": dataset}
    base = f"{dataset}_{column}_{rule_type}".upper().replace(".", "_")[:44]
    code = f"{base}_{_uuid.uuid4().hex[:6].upper()}"
    tags = ["mapping-derived", spec["name"], f"spec:{spec_id}"]
    tags.append(f"rule:{reused_rule_id}" if reused_rule_id else "new-rule")
    return repo_library.create_validation(db.pool, {
        "name": name, "code": code, "rule_type": rule_type, "dataset": dataset, "column_name": column,
        "severity": severity, "description": description or f"Post-transformation check on {column}.",
        "logic": logic, "tags": tags,
    }, owner)


class AddCheckIn(BaseModel):
    dataset: str
    column: str
    description: str | None = None   # AI mode: describe the check to generate
    rule_code: str | None = None     # library mode: an existing Rule Library rule code
    also_datasets: list[str] = []    # cross-table: same-named column in these other tables too


@router.post("/specs/{spec_id}/validations/add")
def add_validation_check(spec_id: UUID, body: AddCheckIn) -> dict:
    """Add ONE data-quality check to a field — AI-generated (from `description`) or reused
    from the Rule Library (`rule_code`). Optionally also apply to the SAME column in the
    `also_datasets` target tables (cross-table propagation)."""
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    owner = _current_user()
    if body.rule_code:
        r = repo_library.get_rule_by_code(db.pool, body.rule_code)
        if r is None:
            raise HTTPException(status_code=404, detail="rule not found")
        logic = _gate_dq(r.get("logic_sql") or r.get("logic_preview") or "")
        name, rule_type, severity = r["name"], (r.get("rule_type") or "validity"), (r.get("severity") or "medium")
        description, reused_rule_id = r.get("description"), str(r["id"])
    elif body.description:
        try:
            out = llm.generate_validation(body.description, "validity", body.column)
        except Exception as e:  # noqa: BLE001
            raise HTTPException(status_code=502, detail=f"AI validation generation failed: {e}")
        logic = _gate_dq(out.get("logic") or "")
        name = f"{body.column} check"
        rule_type, severity, description, reused_rule_id = "validity", "medium", body.description, None
    else:
        raise HTTPException(status_code=422, detail="provide either description (AI) or rule_code (library)")

    created, duplicates = [], []
    for ds in [body.dataset, *body.also_datasets]:
        res = _create_scoped_validation(spec, spec_id, dataset=ds, column=body.column, logic=logic,
                                        name=name, rule_type=rule_type, severity=severity,
                                        description=description, reused_rule_id=reused_rule_id, owner=owner)
        (duplicates if res.get("duplicate") else created).append(res)
    return {"created": len(created), "duplicates": len(duplicates), "validations": created}


class PropagateValidationIn(BaseModel):
    also_datasets: list[str]   # target tables to copy this check into (same column name)


@router.post("/specs/{spec_id}/validations/{validation_id}/propagate")
def propagate_validation(spec_id: UUID, validation_id: UUID, body: PropagateValidationIn) -> dict:
    """Copy an existing (just edited/regenerated) validation to the SAME column in other
    target tables. The check's current logic — as it stands after any change — is applied."""
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    v = repo_library.get_validation(db.pool, validation_id)
    if v is None:
        raise HTTPException(status_code=404, detail="validation not found")
    logic = _gate_dq(v.get("logic") or "")
    owner = _current_user()
    created, duplicates = [], []
    for ds in body.also_datasets:
        res = _create_scoped_validation(spec, spec_id, dataset=ds, column=v.get("column_name") or "",
                                        logic=logic, name=v.get("name") or "check",
                                        rule_type=v.get("rule_type") or "validity", severity=v.get("severity") or "medium",
                                        description=v.get("description"), reused_rule_id=None, owner=owner)
        (duplicates if res.get("duplicate") else created).append(res)
    return {"created": len(created), "duplicates": len(duplicates)}


class PropagateTransformIn(BaseModel):
    also_datasets: list[str]   # target tables to apply this transform to (same field name)


@router.post("/specs/{spec_id}/mappings/{mapping_id}/propagate")
def propagate_transformation(spec_id: UUID, mapping_id: UUID, body: PropagateTransformIn) -> dict:
    """Apply a mapping's current transform to the SAME target field name in other target
    tables. Only the mapping(s) for that field in the chosen tables are edited; the
    expression is copied verbatim (gate-checked against each table's source columns)."""
    import sqlglot
    from sqlglot import exp

    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    src = next((m for m in spec["mappings"] if str(m["id"]) == str(mapping_id)), None)
    if src is None:
        raise HTTPException(status_code=404, detail="mapping not found")
    field_name = src["target_field_name"]
    # The transform to copy: prefer the spec's expr, else the compiled sql.
    ts = src.get("transform_spec") or {}
    expr = ts.get("expr") or src.get("compiled_sql")
    if not expr:
        raise HTTPException(status_code=422, detail="mapping has no expression to propagate")

    # Pool source types so the copied expression can be gate-checked per target table.
    sources = spec.get("sources") or ([s] if (s := repo.get_asset(db.pool, spec["source_asset_id"])) else [])
    src_types: dict[str, str] = {}
    for a in sources:
        for f in a["fields"]:
            src_types[f["name"]] = f["datatype"]
            src_types[f"{a['name']}.{f['name']}"] = f["datatype"]
    targets = spec.get("targets") or []
    tgt_asset_by_field = {str(f["id"]): a for a in targets for f in a["fields"]}

    owner, applied, skipped = _current_user(), [], []
    for ds in body.also_datasets:
        # find the active mapping for `field_name` whose target table == ds
        cand = [m for m in spec["mappings"] if m["state"] != "rejected"
                and m["target_field_name"] == field_name
                and (tgt_asset_by_field.get(str(m["target_field_id"])) or {}).get("name") == ds]
        if not cand:
            skipped.append({"dataset": ds, "reason": "no mapping for this field in that table"})
            continue
        for m in cand:
            try:
                ast = sqlglot.parse_one(expr, read=compiler.DIALECT)
            except Exception:  # noqa: BLE001
                skipped.append({"dataset": ds, "reason": "expression does not parse"}); continue
            unknown = {(f"{c.table}.{c.name}" if c.table else c.name) for c in ast.find_all(exp.Column)
                       if (f"{c.table}.{c.name}" if c.table else c.name) not in src_types and c.name not in src_types}
            if unknown:
                skipped.append({"dataset": ds, "reason": f"expression references columns not in {ds}'s sources: {sorted(unknown)}"}); continue
            repo.update_mapping_state(db.pool, mapping_id=m["id"], action="edit",
                                      transform_spec={"op": "expr", "expr": ast.sql(dialect=compiler.DIALECT)}, actor=owner)
            repo.set_mapping_provenance(db.pool, m["id"], {
                "origin": "AI+feedback", "rationale": f"Applied from {field_name} on another table.",
                "reused_transformation_code": None, "reused_transformation_id": None,
                "reused_transformation_name": None, "is_new_transformation": True,
            }, reset_state="suggested")
            applied.append({"dataset": ds, "mapping_id": str(m["id"])})
    return {"applied": len(applied), "skipped": skipped}


# --- documentation (AI Assistant "Generate documentation") -------------------

def _lower_or_none(m: dict, source_types: dict) -> str | None:
    """Deterministically lower a mapping's transform to a SQL expression, or None."""
    try:
        if (m.get("transform_kind") or "spec") == "spec" and m.get("transform_spec"):
            expr, _ = compiler._lower_spec_to_sql(m["transform_spec"], source_types)
            return expr
        if m.get("transform_sql"):
            return m["transform_sql"]
    except Exception:  # noqa: BLE001
        return None
    return None


def _build_doc(spec_id: UUID) -> dict:
    """Assemble the full mapping-specification document from REAL data + AI prose.

    Facts (STM table, per-column SQL, DQ rules, lineage, generated SQL, governance,
    coverage) are deterministic; only the summary/column-descriptions/open-items
    prose comes from the model — so nothing factual can be hallucinated.
    """
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    sources = spec.get("sources") or ([s] if (s := repo.get_asset(db.pool, spec["source_asset_id"])) else [])
    targets = spec.get("targets") or ([t] if (t := repo.get_asset(db.pool, spec["target_asset_id"])) else [])

    # Pooled source types across all source tables (qualified + bare) so multi-table
    # transforms lower for the per-column SQL regardless of which table they draw from.
    source_types: dict[str, str] = {}
    for a in sources:
        for f in a["fields"]:
            source_types[f["name"]] = f["datatype"]
            source_types[f"{a['name']}.{f['name']}"] = f["datatype"]
    primary_source = sources[0] if sources else None

    active = [m for m in spec["mappings"] if m["state"] != "rejected"]
    tgt_asset_by_field = {str(f["id"]): a for a in targets for f in a["fields"]}

    # Only THIS spec's saved validations (scoped by the spec:<id> tag written at apply
    # time) — dataset name alone isn't unique across mappings.
    spec_tag = f"spec:{spec_id}"
    all_vals = []
    try:
        all_vals = [v for v in repo_library.list_validations(db.pool) if spec_tag in (v.get("tags") or [])]
    except Exception:  # noqa: BLE001
        pass

    # Build one SECTION per target table: its columns, coverage, SQL, lineage.
    tables: list[dict] = []
    all_columns: list[dict] = []  # flat list (all tables) — feeds the AI prose layer once
    for tgt in targets:
        dataset = tgt["name"]
        target_fields = tgt["fields"]
        target_types = {f["name"]: f["datatype"] for f in target_fields}
        vals_by_col: dict[str, list[dict]] = {}
        for v in all_vals:
            if v.get("dataset") == dataset and v.get("column_name"):
                vals_by_col.setdefault(v["column_name"], []).append(v)

        maps_here = [m for m in active if tgt_asset_by_field.get(str(m["target_field_id"])) is tgt]
        columns: list[dict] = []
        for m in maps_here:
            tf = m["target_field_name"]
            prov = m.get("provenance") or {}
            columns.append({
                "target_field": tf,
                "target_type": target_types.get(tf, "unknown"),
                "source_fields": prov.get("source_field_names") or [],
                "source_tables": prov.get("source_tables") or [],
                "sql": _lower_or_none(m, source_types),
                "confidence": m.get("confidence"),
                "origin": prov.get("origin"),
                "reviewed_by": prov.get("reviewed_by"),
                "state": m["state"],
                "validations": [
                    {"name": v["name"], "rule_type": v["rule_type"], "severity": v["severity"], "logic": v.get("logic")}
                    for v in vals_by_col.get(tf, [])
                ],
            })
        all_columns.extend(columns)

        mapped_names = {m["target_field_name"] for m in maps_here}
        coverage = {
            "target_columns": len(target_fields),
            "mapped": len(mapped_names),
            "unmapped": [f["name"] for f in target_fields if f["name"] not in mapped_names],
            "validated_columns": sum(1 for c in columns if c["validations"]),
            "low_confidence": [c["target_field"] for c in columns if (c["confidence"] or 1) < 0.6],
            "without_validation": [c["target_field"] for c in columns if not c["validations"]],
        }

        # Per-table generated SQL + lineage (best-effort). The compiler now handles
        # multi-source JOINs, so a table drawing from several sources compiles the
        # grain-anchored JOIN; single-source stays a plain FROM. Only the sources
        # THIS target actually draws from are passed (grain first), so the FROM
        # clause stays minimal per table.
        generated_sql, lineage = None, []
        try:
            irs = []
            used_tables: list[str] = []
            for m in maps_here:
                kind = m.get("transform_kind") or "spec"
                transform = m.get("transform_spec") if kind == "spec" else (m.get("transform_sql") or "")
                if transform:
                    prov = m.get("provenance") or {}
                    irs.append(compiler.FieldMappingIR(
                        target_field=m["target_field_name"],
                        target_type=target_types.get(m["target_field_name"], "string"),
                        source_fields=prov.get("source_field_names") or [],
                        transform_kind=kind, transform=transform,
                    ))
                    for st in prov.get("source_tables") or []:
                        if st not in used_tables:
                            used_tables.append(st)
            # SourceTable list for this target: the tables it draws from (grain first
            # per suggest's ordering), or the single primary when provenance is bare.
            by_name = {a["name"]: a for a in sources}
            tgt_sources = [compiler.SourceTable(name=by_name[t]["name"], locator=by_name[t]["locator"])
                           for t in used_tables if t in by_name and by_name[t].get("locator")]
            if not tgt_sources and primary_source and primary_source.get("locator"):
                tgt_sources = [compiler.SourceTable(name=primary_source["name"], locator=primary_source["locator"])]
            if irs and tgt_sources:
                r = compiler.compile_spec(
                    spec_id=str(spec_id), sources=tgt_sources, source_types=source_types,
                    joins=spec.get("joins") or [], mappings=irs,
                )
                generated_sql, lineage = r.generated_sql, r.lineage_edges
        except Exception:  # noqa: BLE001 — a doc without compiled SQL is still useful
            pass

        tables.append({
            "target_table": dataset,
            "target_system": spec.get("target_system"),
            "columns": columns,
            "coverage": coverage,
            "generated_sql": generated_sql,
            "lineage": lineage,
        })

    # Spec-level roll-up coverage (across all target tables).
    coverage = {
        "target_columns": sum(t["coverage"]["target_columns"] for t in tables),
        "mapped": sum(t["coverage"]["mapped"] for t in tables),
        "unmapped": [f"{t['target_table']}.{u}" for t in tables for u in t["coverage"]["unmapped"]],
        "validated_columns": sum(t["coverage"]["validated_columns"] for t in tables),
        "low_confidence": [f"{t['target_table']}.{c}" for t in tables for c in t["coverage"]["low_confidence"]],
        "without_validation": [f"{t['target_table']}.{c}" for t in tables for c in t["coverage"]["without_validation"]],
    }

    joins = spec.get("joins") or []

    try:
        gov = repo.governance_trail(db.pool, spec_id)
    except Exception:  # noqa: BLE001
        gov = {"approvals": [], "feedback": {}}

    header = {
        "name": spec["name"],
        "source": " + ".join(a["name"] for a in sources) if sources else None,
        "target": " + ".join(t["target_table"] for t in tables) if tables else None,
        "source_system": spec.get("source_system"),
        "target_system": spec.get("target_system"),
        "owner": spec["owner"],
        "version": spec.get("version_no"),
        "status": spec["status"],
        "multi_table": len(sources) > 1 or len(targets) > 1,
        "source_tables": [a["name"] for a in sources],
        "target_tables": [t["target_table"] for t in tables],
    }

    # AI prose layer over the FLAT column list (facts already fixed above).
    narrative = {"summary": "", "columns": [], "open_items": []}
    try:
        narrative = llm.generate_doc_narrative(header, all_columns, coverage)
    except Exception:  # noqa: BLE001 — doc still renders without prose
        pass
    desc_by_col = {c.get("target_field"): c.get("description") for c in narrative.get("columns", [])}
    for t in tables:
        for c in t["columns"]:
            c["description"] = desc_by_col.get(c["target_field"])

    # `columns`/`generated_sql`/`lineage` kept at top level (first table) for
    # back-compat with any single-table client; `tables` is the multi-table view.
    return {
        "spec_id": str(spec_id),
        "header": header,
        "summary": narrative.get("summary", ""),
        "tables": tables,
        "joins": joins,
        "columns": tables[0]["columns"] if tables else [],
        "coverage": coverage,
        "generated_sql": tables[0]["generated_sql"] if tables else None,
        "lineage": tables[0]["lineage"] if tables else [],
        "governance": gov,
        "open_items": narrative.get("open_items", []),
        "generated_at": __import__("datetime").datetime.utcnow().isoformat() + "Z",
    }


def _doc_markdown(doc: dict) -> str:
    """Render the doc model as a portable Markdown string (for Copy + KA feed).

    Multi-table: an executive summary + join section up top, then ONE section per
    target table (its STM grid, column descriptions, DQ rules, SQL, lineage,
    coverage), then spec-wide coverage + governance.
    """
    h = doc["header"]
    tables = doc.get("tables") or []
    L = [f"# Mapping Specification — {h.get('name')}", ""]
    L.append(f"**Source:** {h.get('source')} ({h.get('source_system') or '—'})  ")
    L.append(f"**Target:** {h.get('target')} ({h.get('target_system') or '—'})  ")
    L.append(f"**Owner:** {h.get('owner')}  ·  **Version:** {h.get('version')}  ·  **Status:** {h.get('status')}  ")
    L.append(f"**Generated:** {doc.get('generated_at')}")
    L += ["", "## Executive summary", "", doc.get("summary") or "_(no summary)_", ""]

    # Join keys across source tables (multi-table).
    if doc.get("joins"):
        L += ["## Source table joins", "", "| Left | Right | Confidence | Rationale |", "|---|---|---|---|"]
        for j in doc["joins"]:
            conf = f"{round((j.get('confidence') or 0)*100)}%" if j.get("confidence") is not None else "—"
            L.append(f"| `{j.get('left')}` | `{j.get('right')}` | {conf} | {j.get('rationale') or '—'} |")
        L.append("")

    # Per-target-table sections.
    for idx, t in enumerate(tables, 1):
        L += [f"## Table {idx}: `{t['target_table']}`", ""]
        L += ["| Target | Type | Source field(s) | Transformation | Conf. | Origin | Status |", "|---|---|---|---|---|---|---|"]
        for c in t["columns"]:
            conf = f"{round((c['confidence'] or 0)*100)}%" if c.get("confidence") is not None else "—"
            sql = (c.get("sql") or "—").replace("|", "\\|")
            L.append(f"| `{c['target_field']}` | {c['target_type']} | {', '.join(c['source_fields']) or '—'} | `{sql}` | {conf} | {c.get('origin') or '—'} | {c['state']} |")
        L += ["", "**Column descriptions**", ""]
        for c in t["columns"]:
            L.append(f"- **`{c['target_field']}`** — {c.get('description') or '_(no description)_'}")
        # DQ rules for this table.
        rules = [(c["target_field"], v) for c in t["columns"] for v in c["validations"]]
        L += ["", "**Data-quality rules**", ""]
        if rules:
            for tf, v in rules:
                L.append(f"- `{tf}` — **{v['rule_type']}** ({v['severity']}): `{v.get('logic') or ''}`")
        else:
            L.append("_No data-quality rules defined yet._")
        if t.get("generated_sql"):
            L += ["", "**Generated Spark SQL**", "", "```sql", t["generated_sql"], "```"]
        if t.get("lineage"):
            L += ["", "**Column lineage**", ""]
            for e in t["lineage"]:
                L.append(f"- `{e['source_field']}` → `{e['target_field']}`")
        cov = t["coverage"]
        L += ["", f"_Coverage: {cov['mapped']}/{cov['target_columns']} columns mapped, {cov['validated_columns']} validated._"]
        if cov["unmapped"]:
            L.append(f"_Unmapped: {', '.join(cov['unmapped'])}_")
        L.append("")

    # Spec-wide coverage + governance.
    cov = doc["coverage"]
    L += ["## Coverage & open items", "",
          f"- Target columns: **{cov['target_columns']}**, mapped: **{cov['mapped']}**, validated: **{cov['validated_columns']}**"]
    if cov["unmapped"]:
        L.append(f"- Unmapped: {', '.join(cov['unmapped'])}")
    if cov["low_confidence"]:
        L.append(f"- Low-confidence: {', '.join(cov['low_confidence'])}")
    if cov["without_validation"]:
        L.append(f"- No data-quality check: {', '.join(cov['without_validation'])}")
    for oi in doc.get("open_items", []):
        L.append(f"- {oi}")
    gov = doc["governance"]
    L += ["", "## Governance & approvals", ""]
    if gov.get("approvals"):
        for a in gov["approvals"]:
            L.append(f"- Maker **{a.get('maker')}** · Checker **{a.get('checker') or '—'}** · {a.get('decision') or 'pending'}")
    else:
        L.append("- Not yet submitted for approval.")
    if gov.get("feedback"):
        L.append(f"- Feedback events: {', '.join(f'{k}={v}' for k,v in gov['feedback'].items())}")
    return "\n".join(L)


@router.post("/specs/{spec_id}/documentation")
def documentation(spec_id: UUID) -> dict:
    """Generate the full mapping-specification document (deterministic facts + AI prose)."""
    doc = _build_doc(spec_id)
    doc["markdown"] = _doc_markdown(doc)
    return doc


class DocPublish(BaseModel):
    markdown: str | None = None


@router.post("/specs/{spec_id}/documentation/publish")
def publish_documentation(spec_id: UUID, body: DocPublish) -> dict:
    """Feed the generated doc to the Knowledge Assistant (writes to evidence volume + syncs)."""
    from server import explain
    import io as _io
    import posixpath as _pp

    md = body.markdown
    if not md:
        doc = _build_doc(spec_id)
        md = _doc_markdown(doc)
    try:
        explain._ensure_evidence_volume()
        path = _pp.join(explain.EVIDENCE_VOLUME, f"doc__{spec_id}.md")
        config.get_workspace_client().files.upload(path, _io.BytesIO(md.encode()), overwrite=True)
        explain.sync_ka()
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"publish to Knowledge Assistant failed: {e}")
    return {"published": True, "path": path}


@router.post("/specs/{spec_id}/documentation/pdf")
def documentation_pdf(spec_id: UUID):
    """Generate the mapping-spec document and return it as a downloadable PDF file."""
    from fastapi import Response
    from server import pdf as pdfgen

    doc = _build_doc(spec_id)
    try:
        data = pdfgen.render_doc_pdf(doc)
    except Exception as e:  # noqa: BLE001 — surface rendering failures
        raise HTTPException(status_code=500, detail=f"PDF generation failed: {e}")
    target = (doc.get("header", {}).get("target") or "mapping").replace(" ", "_")
    filename = f"mapping_spec_{target}.pdf"
    return Response(
        content=data,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/specs/{spec_id}/similar")
def similar_mappings(spec_id: UUID) -> dict:
    """Find mappings similar to this one by table + column metadata.

    Deterministic scoring (no LLM): source/target SYSTEM match + Jaccard overlap of
    source column-name sets + target column-name sets. Returns ranked matches with a
    short 'why' so a reviewer can reuse an existing, proven mapping.
    """
    all_specs = repo.specs_with_metadata(db.pool)
    me = next((s for s in all_specs if str(s["id"]) == str(spec_id)), None)
    if me is None:
        raise HTTPException(status_code=404, detail="spec not found")

    def _set(v) -> set[str]:
        return {str(x).lower() for x in (v or [])}

    my_src, my_tgt = _set(me["source_cols"]), _set(me["target_cols"])

    def _jac(a: set, b: set) -> float:
        if not a or not b:
            return 0.0
        return len(a & b) / len(a | b)

    ranked: list[dict] = []
    for s in all_specs:
        if str(s["id"]) == str(spec_id):
            continue
        s_src, s_tgt = _set(s["source_cols"]), _set(s["target_cols"])
        src_j, tgt_j = _jac(my_src, s_src), _jac(my_tgt, s_tgt)
        sys_src = bool(me["source_system"]) and me["source_system"] == s["source_system"]
        sys_tgt = bool(me["target_system"]) and me["target_system"] == s["target_system"]
        # Weighted blend: column overlap dominates, system match is a bonus.
        score = 0.4 * src_j + 0.4 * tgt_j + 0.1 * sys_src + 0.1 * sys_tgt
        if score <= 0:
            continue
        shared_tgt = sorted((my_tgt & s_tgt))[:8]
        shared_src = sorted((my_src & s_src))[:8]
        reasons = []
        if shared_tgt:
            reasons.append(f"{len(my_tgt & s_tgt)} shared target column(s)")
        if shared_src:
            reasons.append(f"{len(my_src & s_src)} shared source column(s)")
        if sys_src or sys_tgt:
            reasons.append("same " + " & ".join([w for w, ok in [("source system", sys_src), ("target system", sys_tgt)] if ok]))
        # Note when the candidate is itself a multi-table mapping.
        n_src, n_tgt = int(s.get("n_sources") or 0), int(s.get("n_targets") or 0)
        if n_src > 1 or n_tgt > 1:
            reasons.append(f"multi-table ({max(n_src,1)}→{max(n_tgt,1)})")
        ranked.append({
            "id": str(s["id"]),
            "name": s["name"],
            "status": s["status"],
            "owner": s["owner"],
            "source_system": s["source_system"],
            "target_system": s["target_system"],
            "score": round(score, 3),
            "shared_target_columns": shared_tgt,
            "shared_source_columns": shared_src,
            "why": "; ".join(reasons) or "metadata overlap",
        })
    ranked.sort(key=lambda r: -r["score"])
    return {"spec_id": str(spec_id), "matches": ranked[:8]}


@router.post("/specs/{spec_id}/validate-run")
def start_validate_run(spec_id: UUID) -> dict:
    """Kick off an Agentic Mapping Validation run (dummy data → SDP pipeline → validate)."""
    from server import agentic_validate, sdp_pipeline

    if not sdp_pipeline.get_pipeline_id():
        raise HTTPException(status_code=409, detail="Test pipeline not provisioned — run Setup first.")
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    return agentic_validate.start(spec_id)


@router.get("/specs/{spec_id}/validate-run/{run_id}")
def get_validate_run(spec_id: UUID, run_id: str) -> dict:
    """Poll the status/progress of an Agentic Mapping Validation run."""
    from server import agentic_validate

    run = agentic_validate.get_run(run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="run not found")
    return run


@router.patch("/specs/{spec_id}/mappings/{mapping_id}")
def curate_mapping(spec_id: UUID, mapping_id: UUID, body: MappingCurate) -> dict:
    """Human accept/edit/reject of an AI suggestion (records a FeedbackEvent)."""
    if body.action == "edit" and body.transform_spec is None:
        raise HTTPException(status_code=422, detail="edit requires transform_spec")
    try:
        return repo.update_mapping_state(
            db.pool,
            mapping_id=mapping_id,
            action=body.action,
            actor=_current_user(),
            transform_spec=body.transform_spec,
            source_field_ids=body.source_field_ids,
        )
    except KeyError:
        raise HTTPException(status_code=404, detail="mapping not found")


def _mapping_ctx(spec_id: UUID, mapping_id: UUID) -> tuple[dict, dict, dict]:
    """Resolve (spec, the one mapping, pooled source_types) for per-item feedback ops."""
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    m = next((x for x in spec["mappings"] if str(x["id"]) == str(mapping_id)), None)
    if m is None:
        raise HTTPException(status_code=404, detail="mapping not found")
    sources = spec.get("sources") or ([s] if (s := repo.get_asset(db.pool, spec["source_asset_id"])) else [])
    src_types: dict[str, str] = {}
    for a in sources:
        for f in a["fields"]:
            src_types[f["name"]] = f["datatype"]
            src_types[f"{a['name']}.{f['name']}"] = f["datatype"]
    return spec, m, src_types


class RegenBody(BaseModel):
    feedback: str


@router.post("/specs/{spec_id}/mappings/{mapping_id}/regenerate")
def regenerate_mapping(spec_id: UUID, mapping_id: UUID, body: RegenBody) -> dict:
    """Regenerate ONE column's transform from human feedback; replace in place, stays pending."""
    import sqlglot
    from sqlglot import exp

    if not (body.feedback or "").strip():
        raise HTTPException(status_code=422, detail="feedback is required")
    _spec, m, src_types = _mapping_ctx(spec_id, mapping_id)
    prov = m.get("provenance") or {}
    current = m.get("compiled_sql") or (m.get("transform_spec") or {}).get("expr")
    try:
        out = llm.regenerate_transform(
            target_field=m["target_field_name"],
            target_type=(m.get("transform_spec") or {}).get("to") or "unknown",
            source_columns=prov.get("source_field_names") or [],
            current_expr=current,
            feedback=body.feedback,
        )
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"AI regeneration failed: {e}")
    expr = (out.get("expr") or "").strip()
    if not expr:
        raise HTTPException(status_code=502, detail="AI returned an empty expression")
    # Deterministic gate: must parse + reference only real source columns.
    try:
        ast = sqlglot.parse_one(expr, read=compiler.DIALECT)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=422, detail=f"regenerated expression does not parse: {e}")
    unknown = set()
    for c in ast.find_all(exp.Column):
        qualified = f"{c.table}.{c.name}" if c.table else c.name
        if qualified not in src_types and c.name not in src_types:
            unknown.add(qualified)
    if unknown:
        raise HTTPException(status_code=422, detail=f"regenerated expression references unknown columns: {sorted(unknown)}")
    # Replace in place as an `expr` transform; stays pending (state 'edited'), provenance carries the feedback.
    repo.update_mapping_state(db.pool, mapping_id=mapping_id, action="edit",
                              transform_spec={"op": "expr", "expr": ast.sql(dialect=compiler.DIALECT)},
                              actor=_current_user())
    repo.set_mapping_provenance(db.pool, mapping_id, {
        "regenerated_from_feedback": body.feedback,
        "rationale": out.get("rationale") or body.feedback,
        "origin": "AI+feedback",
        # Regeneration DIVERGES from the library transform — clear the reuse stamp so
        # the UI no longer shows "Reused library transformation" for a now-custom expr.
        "reused_transformation_code": None,
        "reused_transformation_id": None,
        "reused_transformation_name": None,
        "is_new_transformation": True,
    }, reset_state="suggested")
    return repo.get_spec(db.pool, spec_id)


class UseTransformBody(BaseModel):
    code: str


@router.post("/specs/{spec_id}/mappings/{mapping_id}/use-transformation")
def use_transformation(spec_id: UUID, mapping_id: UUID, body: UseTransformBody) -> dict:
    """Swap a column's transform to an existing PUBLISHED library transformation (reuse)."""
    _spec, m, _src_types = _mapping_ctx(spec_id, mapping_id)
    t = repo_library.get_transformation_by_code(db.pool, body.code)
    if t is None:
        raise HTTPException(status_code=404, detail="transformation not found")
    logic = t.get("logic_expr") or t.get("logic_sql")
    if not logic:
        raise HTTPException(status_code=422, detail="that library transformation has no logic to apply")
    repo.update_mapping_state(db.pool, mapping_id=mapping_id, action="edit",
                              transform_spec={"op": "expr", "expr": logic}, actor=_current_user())
    repo.set_mapping_provenance(db.pool, mapping_id, {
        "reused_transformation_code": t["code"],
        "reused_transformation_id": str(t["id"]),
        "reused_transformation_name": t["name"],
        "is_new_transformation": False,
        "rationale": f"Reused library transformation “{t['name']}”.",
    }, reset_state="suggested")
    return repo.get_spec(db.pool, spec_id)


@router.get("/specs/{spec_id}/layout")
def get_layout(spec_id: UUID) -> dict:
    """Canvas VISUAL state (node positions). Separate from the domain mapping model."""
    return repo.get_layout(db.pool, spec_id) or {"spec_id": str(spec_id), "nodes": None, "edges": None, "viewport": None}


@router.put("/specs/{spec_id}/layout")
def put_layout(spec_id: UUID, body: LayoutPut) -> dict:
    repo.put_layout(db.pool, spec_id, nodes=body.nodes, edges=body.edges, viewport=body.viewport)
    return {"ok": True}


# --- audit log + comments (Mapping Details: History / Comments tabs) ---------

@router.get("/specs/{spec_id}/audit")
def audit(spec_id: UUID) -> dict:
    """Chronological work log: creation, submissions, approve/reject, per-column curation."""
    return {"spec_id": str(spec_id), "events": repo.audit_log(db.pool, spec_id)}


class CommentCreate(BaseModel):
    body: str
    section: str = "General"


@router.get("/specs/{spec_id}/comments")
def list_comments(spec_id: UUID) -> dict:
    return {"spec_id": str(spec_id), "comments": repo.list_comments(db.pool, spec_id)}


@router.post("/specs/{spec_id}/comments")
def add_comment(spec_id: UUID, body: CommentCreate) -> dict:
    text = (body.body or "").strip()
    if not text:
        raise HTTPException(status_code=422, detail="comment cannot be empty")
    return repo.add_comment(db.pool, spec_id, section=body.section or "General", author=_current_user(), body=text)


# --- governance (M5) ---------------------------------------------------------

class Decision(BaseModel):
    decision: str  # approved | rejected
    rationale: str | None = None


@router.post("/specs/{spec_id}/submit")
def submit(spec_id: UUID) -> dict:
    try:
        return governance.submit_for_approval(db.pool, spec_id)
    except governance.GovernanceError as e:
        raise HTTPException(status_code=409, detail=str(e))


@router.post("/specs/{spec_id}/decide")
def decide(spec_id: UUID, body: Decision) -> dict:
    from server import repo_admin

    checker = _current_user()
    try:
        return governance.decide(
            db.pool, spec_id, decision=body.decision, checker=checker, rationale=body.rationale,
            is_admin=repo_admin.is_admin(db.pool, checker),
        )
    except governance.GovernanceError as e:
        raise HTTPException(status_code=409, detail=str(e))
    except Exception as e:  # noqa: BLE001 — surface Delta materialization failures
        raise HTTPException(status_code=502, detail=f"approval saga failed: {e}")


# --- compile + verify (M6/M7) ------------------------------------------------

def _load_approved(spec_id: UUID) -> tuple[dict, list[compiler.FieldMappingIR]]:
    """Read the approved snapshot from Delta and build compiler IR.

    Returns a ctx carrying everything the compiler needs for BOTH shapes:
      * `sources`       — list of compiler.SourceTable (1 for single-table specs).
      * `source_types`  — pooled datatypes, keyed BARE and (for multi-source) also
                          QUALIFIED `Table.col`, so references resolve either form.
      * `joins`         — spec.joins (empty for single-table).
      * `source`        — the primary source asset (back-compat for callers).
    """
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None:
        raise HTTPException(status_code=404, detail="spec not found")
    if spec["status"] != "Approved" or not spec["delta_content_hash"]:
        raise HTTPException(status_code=409, detail="spec is not approved; compile requires an approved version")

    ch = spec["delta_content_hash"]
    cat, sch = config.UC_CATALOG, config.UC_SCHEMA
    rows = warehouse.execute(
        f"""SELECT target_field, target_type, source_fields, transform_kind, transform_spec, transform_sql
            FROM {cat}.{sch}.approved_field_mapping WHERE content_hash = '{ch}'"""
    )

    # Source tables: the full multi-table set (get_spec attaches `sources`, falling
    # back to the primary for single-table specs). Pool types bare + qualified.
    src_assets = spec.get("sources") or ([a] if (a := repo.get_asset(db.pool, spec["source_asset_id"])) else [])
    source_types: dict[str, str] = {}
    for a in src_assets:
        for f in a["fields"]:
            source_types[f["name"]] = f["datatype"]
            source_types[f"{a['name']}.{f['name']}"] = f["datatype"]
    source_tables = [compiler.SourceTable(name=a["name"], locator=a["locator"]) for a in src_assets if a.get("locator")]

    mappings = []
    import json as _json

    for r in rows:
        kind = r[3] or "spec"
        transform: object = _json.loads(r[4]) if kind == "spec" and r[4] else (r[5] or "")
        mappings.append(
            compiler.FieldMappingIR(
                target_field=r[0],
                target_type=r[1],
                source_fields=list(r[2]) if r[2] else [],
                transform_kind=kind,
                transform=transform,
            )
        )
    return {
        "spec": spec,
        "source": src_assets[0] if src_assets else None,
        "sources": source_tables,
        "source_types": source_types,
        "joins": spec.get("joins") or [],
        "content_hash": ch,
    }, mappings


@router.post("/specs/{spec_id}/compile")
def compile_spec(spec_id: UUID) -> dict:
    ctx, mappings = _load_approved(spec_id)
    try:
        result = compiler.compile_spec(
            spec_id=str(spec_id),
            sources=ctx["sources"],
            source_types=ctx["source_types"],
            joins=ctx["joins"],
            mappings=mappings,
        )
    except compiler.CompileError as e:
        raise HTTPException(status_code=422, detail=f"compile error: {e}")

    # Persist compiled artifact + lineage to Delta, keyed by the APPROVAL hash
    # (the one the spec stores as delta_content_hash) so they can be looked up
    # from the spec. The compiler's own fingerprint is returned for determinism
    # checks. Idempotent: delete-then-insert for this approved version.
    cat, sch = config.UC_CATALOG, config.UC_SCHEMA
    from server.governance import _sql_str

    key = ctx["content_hash"]
    warehouse.execute(f"DELETE FROM {cat}.{sch}.compiled_artifact WHERE content_hash={_sql_str(key)}")
    warehouse.execute(
        f"""INSERT INTO {cat}.{sch}.compiled_artifact (content_hash, spec_id, compiler_version, generated_sql, generated_tests, compiled_at)
            VALUES ({_sql_str(key)}, {_sql_str(str(spec_id))}, {_sql_str(result.compiler_version)},
                    {_sql_str(result.generated_sql)}, {_sql_str(__import__('json').dumps(result.generated_tests))}, current_timestamp())"""
    )
    warehouse.execute(f"DELETE FROM {cat}.{sch}.lineage_edge WHERE content_hash={_sql_str(key)}")
    for e in result.lineage_edges:
        warehouse.execute(
            f"""INSERT INTO {cat}.{sch}.lineage_edge (content_hash, source_field, target_field, transform_sql)
                VALUES ({_sql_str(key)}, {_sql_str(e['source_field'])}, {_sql_str(e['target_field'])}, {_sql_str(e['transform_sql'])})"""
        )
    return {
        "content_hash": key,
        "compiler_fingerprint": result.content_hash,
        "compiler_version": result.compiler_version,
        "generated_sql": result.generated_sql,
        "lineage": result.lineage_edges,
        "tests": result.generated_tests,
    }


@router.get("/specs/{spec_id}/lineage")
def lineage(spec_id: UUID) -> dict:
    spec = repo.get_spec(db.pool, spec_id)
    if spec is None or not spec.get("delta_content_hash"):
        raise HTTPException(status_code=404, detail="no approved/compiled version")
    cat, sch = config.UC_CATALOG, config.UC_SCHEMA
    rows = warehouse.execute(
        f"SELECT source_field, target_field, transform_sql FROM {cat}.{sch}.lineage_edge WHERE content_hash='{spec['delta_content_hash']}'"
    )
    return {"edges": [{"source_field": r[0], "target_field": r[1], "transform_sql": r[2]} for r in rows]}


@router.post("/specs/{spec_id}/run")
def run(spec_id: UUID) -> dict:
    """Execute the generated SQL on the warehouse — the execution-verify step (M7)."""
    ctx, mappings = _load_approved(spec_id)
    result = compiler.compile_spec(
        spec_id=str(spec_id), sources=ctx["sources"], source_types=ctx["source_types"],
        joins=ctx["joins"], mappings=mappings,
    )
    rows = warehouse.execute(result.generated_sql)
    columns = sorted({e["target_field"] for e in result.lineage_edges} | {m.target_field for m in mappings})
    return {"columns": columns, "rows": rows[:50]}
