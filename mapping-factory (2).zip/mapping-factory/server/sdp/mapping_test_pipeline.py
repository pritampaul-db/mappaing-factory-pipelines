# Databricks notebook source
# MAGIC %md
# MAGIC # Mapping Factory — Agentic Mapping Test Pipeline (generic, config-driven)
# MAGIC
# MAGIC A single reusable **Spark Declarative Pipeline** that tests any mapping without
# MAGIC being redeployed. Each test run:
# MAGIC   1. writes one config row to `mapping_factory.mf_test_config` (keyed by `run_id`)
# MAGIC   2. starts an update of THIS pipeline with the `run_id` parameter
# MAGIC
# MAGIC **Config v2 (multi-table):** the config carries MANY source (dummy) tables, the
# MAGIC AI-proposed JOINS across them, and a list of TARGETS — each with its per-column
# MAGIC transform SQL (deterministically compiled) and its data-quality rules. For every
# MAGIC target the pipeline builds:
# MAGIC   - `<target>_target`  — the transformed target rows (from the joined sources)
# MAGIC   - `<target>_dq`      — target rows + a `_dq` struct (per-rule pass + all_passed)
# MAGIC
# MAGIC v1 configs (single `input_table` + top-level `columns`/`validations`) are still
# MAGIC accepted so older runs keep working. No dataset names are hardcoded.

# COMMAND ----------

import json

import pyspark.pipelines as dlt
from pyspark.sql import functions as F

# The run_id parameter selects which config row to build. Passed via the pipeline
# update's configuration (spark conf `mf.run_id`), defaulting to the latest row.
try:
    RUN_ID = spark.conf.get("mf.run_id")  # noqa: F821 — spark is provided by the runtime
except Exception:
    RUN_ID = None

CATALOG = "pritam_demo_workspace_catalog"
SCHEMA = "mapping_factory"
CONFIG_TABLE = f"{CATALOG}.{SCHEMA}.mf_test_config"


def _load_config():
    """Read the config row for this run (or the most recent one).

    `config_json` is base64-encoded to survive the SQL-literal round-trip
    (transform SQL contains single quotes + backslashes that otherwise get
    mangled going app -> INSERT -> table -> here).
    """
    import base64

    df = spark.read.table(CONFIG_TABLE)  # noqa: F821
    if RUN_ID:
        df = df.filter(F.col("run_id") == RUN_ID)
    row = df.orderBy(F.col("created_at").desc()).limit(1).collect()
    if not row:
        raise ValueError(f"No mapping-test config found (run_id={RUN_ID}) in {CONFIG_TABLE}")
    raw = row[0]["config_json"]
    try:
        decoded = base64.b64decode(raw).decode()
        return json.loads(decoded)
    except Exception:
        # Backward-compat: plain JSON if not base64.
        return json.loads(raw)


_CFG = _load_config()


# --- normalize v1 -> v2 so the build logic is uniform ------------------------
def _normalize(cfg: dict) -> dict:
    """Return a v2-shaped config: {inputs:{name:{table,columns}}, joins:[], targets:[...]}"""
    if cfg.get("version") == 2 or "targets" in cfg:
        cfg.setdefault("inputs", {})
        cfg.setdefault("joins", [])
        cfg.setdefault("targets", [])
        return cfg
    # v1: single input_table + top-level target_name/columns/validations.
    name = cfg.get("target_name") or "target"
    return {
        "version": 2,
        "run_id": cfg.get("run_id"),
        "inputs": {"_v1_input": {"table": cfg["input_table"], "columns": []}},
        "joins": [],
        "targets": [{
            "target_name": name,
            "columns": cfg.get("columns", []),
            "validations": cfg.get("validations", []),
            "source_tables": ["_v1_input"],
        }],
        "_v1_single_view": True,
    }


_CFG = _normalize(_CFG)
_INPUTS = _CFG["inputs"]          # {source_table_name: {table (fqn), columns[]}}
_JOINS = _CFG.get("joins", [])    # [{left_table,left_col,right_table,right_col}]
_TARGETS = _CFG["targets"]        # [{target_name, columns[], validations[], source_tables[]}]

print(f"[MappingTest] run_id={RUN_ID} inputs={list(_INPUTS)} joins={len(_JOINS)} targets={[t['target_name'] for t in _TARGETS]}")


def _view_name(src_table_name: str) -> str:
    """A per-source temp view name (safe identifier)."""
    import re
    return "mfsrc_" + re.sub(r"[^0-9a-zA-Z]+", "_", str(src_table_name).lower()).strip("_")


def _register_source_views():
    """Register one temp view per source (dummy) table, keyed by its LOGICAL name.

    Called at EXECUTION time (inside each target's build fn) — in SDP the table
    functions run lazily, so views registered only at module load may not be
    visible then. Re-registering per build is cheap and guarantees availability.
    """
    for logical_name, meta in _INPUTS.items():
        spark.read.table(meta["table"]).createOrReplaceTempView(_view_name(logical_name))  # noqa: F821


def _joined_from_clause(target_source_tables: list[str]) -> str:
    """Build a FROM ... LEFT JOIN ... clause across the target's source tables.

    The FIRST table is the grain (the row anchor); the rest are LEFT JOINed on any
    configured join key that connects them to an already-included table. Every
    source column is exposed BARE (col) and QUALIFIED (`Table.col`) via a wrapping
    projection so transform SQL resolves either spelling and there's no ambiguity.
    """
    tables = [t for t in target_source_tables if t in _INPUTS] or list(_INPUTS)
    if not tables:
        raise ValueError("no source tables for target")

    # Alias each source table by its logical name (so `Table.col` in transforms works).
    included = [tables[0]]
    parts = [f"{_view_name(tables[0])} AS `{tables[0]}`"]
    for tbl in tables[1:]:
        # Find a join key linking `tbl` to any already-included table.
        on = None
        for j in _JOINS:
            lt, rt = j.get("left_table"), j.get("right_table")
            if tbl == rt and lt in included:
                on = f"`{lt}`.`{j['left_col']}` = `{tbl}`.`{j['right_col']}`"
                break
            if tbl == lt and rt in included:
                on = f"`{rt}`.`{j['right_col']}` = `{tbl}`.`{j['left_col']}`"
                break
        if on:
            parts.append(f"LEFT JOIN {_view_name(tbl)} AS `{tbl}` ON {on}")
            included.append(tbl)
        # If no join key is found, skip the table (can't relate it safely).
    return " ".join(parts), included


def _build_one_target(cfg_t: dict):
    """Register the `<target>_target` and `<target>_dq` tables for one target."""
    target = cfg_t["target_name"]
    columns = cfg_t.get("columns", [])
    validations = cfg_t.get("validations", [])
    src_tables = cfg_t.get("source_tables") or list(_INPUTS)
    target_tbl = f"{target}_target"
    dq_tbl = f"{target}_dq"

    @dlt.table(
        name=target_tbl,
        comment=f"Transformed target for mapping test (run {RUN_ID}, target {target})",
        table_properties={"quality": "silver", "mapping_target": target},
    )
    def build_target(_cols=columns, _srcs=src_tables):
        _register_source_views()  # execution-time: ensure the source views exist now
        from_clause, _ = _joined_from_clause(_srcs)
        select_items = [f"{c['sql']} AS `{c['target_field']}`" for c in _cols if c.get("sql")]
        if not select_items:
            select_items = ["1 AS `_empty`"]
        return spark.sql(f"SELECT {', '.join(select_items)} FROM {from_clause}")  # noqa: F821

    @dlt.table(
        name=dq_tbl,
        comment=f"Target rows + per-rule DQ results for mapping test (run {RUN_ID}, target {target})",
        table_properties={"quality": "silver", "mapping_target": target},
    )
    def build_dq(_target_tbl=target_tbl, _vals=validations):
        # dlt.read + expression compilation happen HERE (execution time). Each rule
        # is checked individually so one malformed predicate (LLM-generated) is
        # skipped, never fatal.
        df = dlt.read(_target_tbl)
        checks = []
        all_passed = None
        for i, v in enumerate(_vals):
            logic = v.get("logic")
            if not logic:
                continue
            name = v.get("name") or f"rule_{i}"
            try:
                cond = F.coalesce(F.expr(logic), F.lit(False))  # NULL predicate -> fail
                df.select(cond.alias("_probe")).limit(0).collect()  # force resolution now
            except Exception as ex:  # noqa: BLE001
                print(f"[MappingTest] {target}: skipping unparseable rule '{name}': {str(ex)[:160]}")
                continue
            checks.append(cond.alias(name))
            all_passed = cond if all_passed is None else (all_passed & cond)
        if not checks:
            return df.withColumn("_dq", F.struct(F.lit(True).alias("all_passed")))
        return df.withColumn("_dq", F.struct(*checks)).withColumn("_dq_all_passed", all_passed)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Build every target from the joined source views

# COMMAND ----------

for _t in _TARGETS:
    _build_one_target(_t)
