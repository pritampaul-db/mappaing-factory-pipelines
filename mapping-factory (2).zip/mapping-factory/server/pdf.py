"""Render a mapping-specification document (the `_build_doc` model) to a real PDF.

Pure-Python via fpdf2 — no system libraries, so it installs and runs cleanly in a
Databricks App container. Produces a presentable, multi-page, selectable-text PDF
suitable for distributing to governance / audit / data teams: title block, an
executive summary, the source→target table (with wrapping cells + page breaks),
column descriptions, data-quality rules, generated SQL, coverage, and governance —
with a running footer (title + page numbers).
"""
from __future__ import annotations

from typing import Any

from fpdf import FPDF

# Brand palette (RGB).
BRAND = (201, 37, 45)
INK = (31, 41, 55)
MUTE = (107, 114, 128)
LINE = (229, 231, 235)
ZEBRA = (249, 250, 251)
CODE_BG = (245, 246, 248)


class _Doc(FPDF):
    def __init__(self, title: str):
        super().__init__(orientation="P", unit="mm", format="A4")
        self._title = title
        self.set_auto_page_break(auto=True, margin=18)
        self.set_margins(15, 15, 15)

    def footer(self) -> None:  # noqa: D401 — fpdf2 hook
        self.set_y(-14)
        self.set_font("Helvetica", "", 7)
        self.set_text_color(*MUTE)
        safe = _txt(self, self._title[:90])
        self.cell(0, 5, safe, align="L")
        self.cell(0, 5, f"Page {self.page_no()}/{{nb}}", align="R")


# Common Unicode punctuation → ASCII, so the latin-1 core fonts render it cleanly
# (an arrow/dash/smart-quote would otherwise become "?").
_UNI = {
    "→": "->", "←": "<-", "↔": "<->",
    "‘": "'", "’": "'", "“": '"', "”": '"',
    "–": "-", "—": "-", "…": "...", " ": " ", "•": "-",
}


def _txt(pdf: FPDF, s: Any) -> str:
    """fpdf2 core fonts are latin-1; normalize common punctuation, then replace any
    remaining unencodable chars so rendering never raises."""
    out = str(s if s is not None else "")
    for k, v in _UNI.items():
        out = out.replace(k, v)
    return out.encode("latin-1", "replace").decode("latin-1")


def _para(pdf: _Doc, h: float, text: str) -> None:
    """Full-width wrapped text. Resets X to the left margin first so the auto width
    is always the full usable page width (avoids fpdf2's 'not enough space' when the
    cursor was left mid-row by a prior cell)."""
    pdf.set_x(pdf.l_margin)
    pdf.multi_cell(pdf.epw, h, _txt(pdf, text), new_x="LMARGIN", new_y="NEXT")


def _h2(pdf: _Doc, n: int, title: str) -> None:
    if pdf.get_y() > 250:
        pdf.add_page()
    pdf.ln(3)
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(*BRAND)
    pdf.cell(0, 7, _txt(pdf, f"{n}. {title}"), new_x="LMARGIN", new_y="NEXT")
    pdf.set_draw_color(*LINE)
    pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
    pdf.ln(2)


def _table(pdf: _Doc, headers: list[str], widths: list[float], rows: list[list[str]]) -> None:
    """A table with wrapping cells, zebra striping, header repeat across page breaks."""
    line_h = 4.6

    def _header() -> None:
        pdf.set_font("Helvetica", "B", 7.5)
        pdf.set_fill_color(*INK)
        pdf.set_text_color(255, 255, 255)
        for h, w in zip(headers, widths):
            pdf.cell(w, 6, _txt(pdf, h), border=0, align="L", fill=True)
        pdf.ln(6)

    _header()
    pdf.set_font("Helvetica", "", 7)
    zebra = False
    for row in rows:
        # Compute the row height from the tallest wrapped cell.
        heights = []
        for text, w in zip(row, widths):
            lines = pdf.multi_cell(w, line_h, _txt(pdf, text), dry_run=True, output="LINES")
            heights.append(max(1, len(lines)) * line_h)
        rh = max(heights) + 1.5
        # Page break with header repeat.
        if pdf.get_y() + rh > pdf.h - pdf.b_margin:
            pdf.add_page()
            _header()
            pdf.set_font("Helvetica", "", 7)
        x0, y0 = pdf.get_x(), pdf.get_y()
        if zebra:
            pdf.set_fill_color(*ZEBRA)
            pdf.rect(x0, y0, sum(widths), rh, style="F")
        zebra = not zebra
        pdf.set_text_color(*INK)
        x = x0
        for text, w in zip(row, widths):
            pdf.set_xy(x, y0)
            pdf.multi_cell(w, line_h, _txt(pdf, text), border=0, align="L", max_line_height=line_h)
            x += w
        pdf.set_xy(x0, y0 + rh)
        pdf.set_draw_color(*LINE)
        pdf.line(x0, y0 + rh, x0 + sum(widths), y0 + rh)


def _pct(c: Any) -> str:
    if c is None:
        return "-"
    v = c * 100 if c <= 1 else c
    return f"{round(v)}%"


def render_doc_pdf(doc: dict) -> bytes:
    """Build the PDF and return its bytes."""
    h = doc.get("header", {})
    title = f"Mapping Specification - {h.get('name', 'mapping')}"
    pdf = _Doc(title)
    pdf.alias_nb_pages()
    pdf.add_page()

    # --- Title block ---
    pdf.set_font("Helvetica", "B", 20)
    pdf.set_text_color(*INK)
    pdf.cell(0, 10, "Mapping Specification", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 11)
    pdf.set_text_color(*MUTE)
    pdf.cell(0, 6, _txt(pdf, h.get("name", "")), new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

    # Metadata grid (2 columns of key/value).
    meta = [
        ("Source", f"{h.get('source') or '-'}" + (f"  ({h.get('source_system')})" if h.get("source_system") else "")),
        ("Target", f"{h.get('target') or '-'}" + (f"  ({h.get('target_system')})" if h.get("target_system") else "")),
        ("Owner", h.get("owner") or "-"),
        ("Version / Status", f"v{h.get('version', 1)}  -  {h.get('status', '-')}"),
        ("Generated", doc.get("generated_at", "")),
    ]
    pdf.set_font("Helvetica", "", 9)
    for k, v in meta:
        pdf.set_text_color(*MUTE)
        pdf.cell(38, 5.5, _txt(pdf, k))
        pdf.set_text_color(*INK)
        pdf.cell(0, 5.5, _txt(pdf, v), new_x="LMARGIN", new_y="NEXT")

    # --- 1. Executive summary ---
    _h2(pdf, 1, "Executive summary")
    pdf.set_font("Helvetica", "", 9.5)
    pdf.set_text_color(*INK)
    _para(pdf, 5, doc.get("summary") or "No summary.")

    n = 2
    # --- Source table joins (multi-table) ---
    if doc.get("joins"):
        _h2(pdf, n, "Source table joins")
        n += 1
        jrows = [[j.get("left", ""), j.get("right", ""), _pct(j.get("confidence")), j.get("rationale") or "-"] for j in doc["joins"]]
        _table(pdf, ["Left", "Right", "Conf.", "Rationale"], [40, 40, 14, 86], jrows)

    # --- One section per TARGET TABLE (falls back to the flat column list) ---
    tables = doc.get("tables")
    if not tables:
        tables = [{"target_table": doc.get("header", {}).get("target") or "Target", "columns": doc.get("columns", []), "generated_sql": doc.get("generated_sql")}]
    for t in tables:
        _h2(pdf, n, f"Target table: {t.get('target_table')}")
        n += 1
        cols = t.get("columns", [])
        widths = [30, 16, 34, 66, 12, 22]  # sums to 180 (A4 usable width)
        rows = [
            [
                c.get("target_field", ""),
                c.get("target_type", ""),
                ", ".join(c.get("source_fields") or []) or "-",
                c.get("sql") or "-",
                _pct(c.get("confidence")),
                c.get("origin") or "-",
            ]
            for c in cols
        ]
        _table(pdf, ["Target", "Type", "Source field(s)", "Transformation", "Conf.", "Origin"], widths, rows)

        # Column descriptions.
        pdf.ln(2)
        pdf.set_font("Helvetica", "B", 9)
        pdf.set_text_color(*INK)
        _para(pdf, 5, "Column descriptions")
        for c in cols:
            pdf.set_font("Helvetica", "B", 8.5)
            pdf.set_text_color(*INK)
            _para(pdf, 4.6, c.get("target_field", ""))
            pdf.set_font("Helvetica", "", 8.5)
            pdf.set_text_color(*MUTE)
            _para(pdf, 4.6, c.get("description") or "(no description)")
            pdf.ln(1)

        # Data-quality rules for this table.
        dq_rows = [
            [c.get("target_field", ""), v.get("rule_type", ""), v.get("severity", ""), v.get("logic") or ""]
            for c in cols
            for v in (c.get("validations") or [])
        ]
        pdf.ln(1)
        pdf.set_font("Helvetica", "B", 9)
        pdf.set_text_color(*INK)
        _para(pdf, 5, "Data-quality rules")
        if dq_rows:
            _table(pdf, ["Column", "Rule type", "Severity", "Logic"], [30, 26, 20, 104], dq_rows)
        else:
            pdf.set_font("Helvetica", "I", 9)
            pdf.set_text_color(*MUTE)
            _para(pdf, 5, "No data-quality rules defined yet.")

        # Generated SQL for this table (if any).
        if t.get("generated_sql"):
            pdf.ln(1)
            pdf.set_font("Helvetica", "B", 9)
            pdf.set_text_color(*INK)
            _para(pdf, 5, "Generated Spark SQL")
            pdf.set_font("Courier", "", 7.5)
            pdf.set_text_color(*INK)
            pdf.set_fill_color(*CODE_BG)
            pdf.set_x(pdf.l_margin)
            pdf.multi_cell(pdf.epw, 4, _txt(pdf, t["generated_sql"]), border=0, fill=True, new_x="LMARGIN", new_y="NEXT")

    # --- Coverage & open items ---
    _h2(pdf, n, "Coverage & open items")
    n += 1
    cov = doc.get("coverage", {})
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(*INK)
    _para(pdf, 5, f"Target columns: {cov.get('target_columns', 0)}   |   Mapped: {cov.get('mapped', 0)}   |   Validated: {cov.get('validated_columns', 0)}")
    pdf.set_text_color(*MUTE)
    pdf.set_font("Helvetica", "", 8.5)
    for label, key in [("Unmapped", "unmapped"), ("Low-confidence", "low_confidence"), ("No data-quality check", "without_validation")]:
        vals = cov.get(key) or []
        if vals:
            _para(pdf, 4.6, f"- {label}: {', '.join(vals)}")
    for oi in doc.get("open_items") or []:
        _para(pdf, 4.6, f"- {oi}")

    # --- Governance & approvals ---
    _h2(pdf, n, "Governance & approvals")
    gov = doc.get("governance", {})
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(*INK)
    approvals = gov.get("approvals") or []
    if approvals:
        for a in approvals:
            _para(pdf, 4.6, f"- Maker {a.get('maker')}  |  Checker {a.get('checker') or '-'}  |  {a.get('decision') or 'pending'}")
    else:
        pdf.set_text_color(*MUTE)
        _para(pdf, 5, "Not yet submitted for approval.")
    fb = gov.get("feedback") or {}
    if fb:
        pdf.set_text_color(*MUTE)
        _para(pdf, 4.6, "Feedback events: " + ", ".join(f"{k}={v}" for k, v in fb.items()))

    pdf.ln(4)
    pdf.set_font("Helvetica", "I", 7)
    pdf.set_text_color(*MUTE)
    _para(pdf, 4, "Generated by Mapping Factory. Facts (tables, SQL, lineage) are deterministic; the summary and column descriptions are AI-generated - review before distribution.")

    out = pdf.output()
    return bytes(out)
