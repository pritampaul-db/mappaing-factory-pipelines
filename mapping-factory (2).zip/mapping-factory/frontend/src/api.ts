// Thin typed client for the Mapping Factory API. Same-origin in production
// (FastAPI serves the SPA); proxied to :8000 in dev via vite.config.ts.

export interface Health {
  status: string;
  mode: "databricks_app" | "local";
  lakebase_configured: boolean;
  identity?: string;
  workspace_host?: string;
  identity_error?: string;
}

export interface Field {
  id: string;
  name: string;
  datatype: string;
  nullable: boolean;
  ordinal?: number | null;
  semantic_type?: string | null;   // "key" for PK/FK columns (drives key badges)
}

export interface Asset {
  id: string;
  name: string;
  object_type: string;
  role: string;
  locator?: string | null;
  fields: Field[];
}

export interface TransformSpec {
  op?: string;
  source?: string;
  sources?: string[];
  to?: string;
  separator?: string;
  format?: string;
  value?: string;
  expr?: string;
}

export interface Mapping {
  id: string;
  spec_id: string;
  target_field_id: string;
  target_field_name: string;
  source_field_ids: string[];
  confidence?: number | null;
  provenance: {
    origin: string; source_field_names?: string[]; rationale?: string;
    reused_transformation_code?: string | null; reused_transformation_name?: string | null;
    is_new_transformation?: boolean;
  };
  state: "suggested" | "accepted" | "edited" | "rejected";
  transform_kind?: string;
  transform_spec?: TransformSpec | null;
  transform_description?: string | null;
  compiled_sql?: string | null;   // deterministically lowered SQL (Details code snippet)
}

// One AI-proposed, sqlglot-validated optimization for a target column's transform.
export interface Optimization {
  id: string;
  mapping_id: string;
  // Other mappings for the same target that this proposal MERGES in — rejected on apply.
  merged_mapping_ids: string[];
  target_field: string;
  kind: "merge" | "simplify" | "cast" | "readability" | "other";
  title: string;
  rationale: string;
  impact: "high" | "medium" | "low";
  before: string;
  after: string;
  transform_spec: TransformSpec;
}

// One AI-proposed, sqlglot-validated data-quality check for a target column.
export interface ValidationProposal {
  id: string;
  target_field: string;
  target_table?: string;    // multi-table: the target table this check guards
  dataset?: string;         // dataset the check saves under (= target table name)
  rule_type: "completeness" | "validity" | "accuracy" | "uniqueness" | "consistency" | "business_rule";
  severity: "critical" | "high" | "medium" | "low";
  name: string;
  rationale: string;
  logic: string;
  covered: boolean;
  reused_rule_code?: string | null;
  reused_rule_name?: string | null;
  reused_rule_id?: string | null;
  is_new_rule?: boolean;
}

// Agentic Mapping Validation run — a 6-agent workflow (dummy data → SDP pipeline → validate).
export interface ValidateStep {
  key: string;
  agent: string;                 // e.g. "Metadata Agent"
  description: string;           // e.g. "Analyze models & metadata"
  status: "pending" | "running" | "done" | "failed";
  detail?: string | null;
  elapsed_sec?: number | null;   // per-agent duration (live while running)
}
export interface ValidateRun {
  run_id: string;
  spec_id: string;
  status: "running" | "succeeded" | "failed";
  steps: ValidateStep[];
  pipeline?: {
    name: string;
    pipeline_id?: string;
    update_id?: string;
    run_url?: string;
    pipeline_url?: string;
    environment?: string;
    compute?: string;
    target?: string;
  } | null;
  config?: {
    // v2 (multi-table): inputs + joins + targets[]. v1 fields kept optional for old runs.
    version?: number;
    run_id: string;
    input_table?: string;
    target_name?: string;
    inputs?: Record<string, { table: string; columns: string[] }>;
    joins?: { left_table: string; left_col: string; right_table: string; right_col: string }[];
    targets?: { target_name: string; columns: { target_field: string; sql: string }[]; validations: { name: string; column: string; logic: string }[]; source_tables?: string[] }[];
    columns?: { target_field: string; sql: string }[];
    validations?: { name: string; column: string; logic: string }[];
  } | null;
  error?: string | null;
  result?: {
    overall: string;
    summary: string;
    target_table?: string;
    dq_table?: string;
    row_count?: number;
    checks: { name: string; passed: boolean; detail: string }[];
    dq: { rule: string; column: string; target_table?: string; pass_rate: number | null; passed?: number; total?: number }[];
    tables?: { target_table: string; row_count: number; checks: { name: string; passed: boolean; detail: string }[]; dq: { rule: string; column: string; pass_rate: number | null; passed?: number; total?: number }[] }[];
    analysis?: { headline: string; recommendations: string[]; clean_rules: number; weak_rules: number; verdict: string };
  } | null;
}

export interface DeployStep {
  key: string;
  label: string;                 // e.g. "Commit"
  description: string;
  status: "pending" | "running" | "done" | "failed";
  detail?: string | null;
  elapsed_sec?: number | null;
}
export interface DeployRun {
  deploy_id: string;
  spec_id: string;
  status: "running" | "succeeded" | "failed";
  steps: DeployStep[];
  error?: string | null;
  cleanup?: string | null;       // rollback note when a failure triggered cleanup
  result?: {
    repo: string; branch: string; commit_sha: string; commit_url: string; files: string[];
    pipeline_id: string; pipeline_url: string; git_folder: string; reused: boolean;
    source_catalog: string; source_schema: string; target_catalog: string; target_schema: string;
  } | null;
}

export interface TestRun {
  test_id: string;
  spec_id: string;
  status: "running" | "succeeded" | "failed";
  steps: DeployStep[];   // seed → config → start → run → audit
  error?: string | null;
  result?: {
    pipeline_id: string; update_id?: string; pipeline_state: string;
    targets: { target: string; rows: number | null; quarantined: number | null }[];
    audit_rows: number; audit_table?: string;
  } | null;
}

// A mapping found to be similar by table + column metadata.
export interface SimilarMapping {
  id: string;
  name: string;
  status: string;
  owner?: string | null;
  source_system?: string | null;
  target_system?: string | null;
  score: number;
  shared_target_columns: string[];
  shared_source_columns: string[];
  why: string;
}

// The generated mapping-specification document (deterministic facts + AI prose).
export interface DocColumn {
  target_field: string;
  target_type: string;
  source_fields: string[];
  sql?: string | null;
  confidence?: number | null;
  origin?: string | null;
  reviewed_by?: string | null;
  state: string;
  description?: string | null;
  validations: { name: string; rule_type: string; severity: string; logic?: string | null }[];
}
export interface DocCoverage {
  target_columns: number; mapped: number; unmapped: string[];
  validated_columns: number; low_confidence: string[]; without_validation: string[];
}
// One target table's section of a (possibly multi-table) mapping document.
export interface DocTable {
  target_table: string;
  target_system?: string | null;
  columns: DocColumn[];
  coverage: DocCoverage;
  generated_sql?: string | null;
  lineage: { source_field: string; target_field: string; transform_sql?: string }[];
}
export interface MappingDoc {
  spec_id: string;
  header: {
    name: string; source?: string | null; target?: string | null;
    source_system?: string | null; target_system?: string | null;
    owner: string; version?: number | null; status: string;
    multi_table?: boolean; source_tables?: string[]; target_tables?: string[];
  };
  summary: string;
  // Multi-table: one section per target table. Single-table docs still populate
  // `columns`/`generated_sql`/`lineage` (= the first table) for back-compat.
  tables?: DocTable[];
  joins?: { left: string; right: string; confidence?: number; rationale?: string }[];
  columns: DocColumn[];
  coverage: DocCoverage;
  generated_sql?: string | null;
  lineage: { source_field: string; target_field: string; transform_sql?: string }[];
  governance: { approvals: { maker?: string; checker?: string; decision?: string; rationale?: string }[]; feedback: Record<string, number> };
  open_items: string[];
  generated_at: string;
  markdown: string;
}

export interface Spec {
  id: string;
  name: string;
  source_asset_id: string | null;
  target_asset_id: string | null;
  status: string;
  version_no: number;
  owner: string;
  delta_content_hash?: string | null;
  description?: string | null;
  source_system?: string | null;
  target_system?: string | null;
  mapping_type?: string | null;
  ai_confidence?: number | null;
  mappings: Mapping[];
  // Multi-table: full source/target asset sets (present when >1 table per side;
  // for single-table specs these hold the one primary asset).
  sources?: Asset[];
  targets?: Asset[];
  joins?: { left: string; right: string; left_id?: string; right_id?: string; confidence?: number; rationale?: string }[] | null;
}

// Multi-table: a table parsed out of a document (before any asset is created).
export interface ParsedField {
  name: string;
  datatype: string;
  nullable: boolean;
  is_key?: boolean;
  description?: string | null;
}
export interface ParsedTable {
  table_name: string;
  description?: string | null;
  fields: ParsedField[];
}
export interface ParseTablesResult {
  role: "source" | "target";
  source_path: string;
  filename: string;
  tables: ParsedTable[];
}

async function req<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) {
    let detail = `${res.status}`;
    try {
      detail = (await res.json()).detail ?? detail;
    } catch {
      /* ignore */
    }
    throw new Error(`${path} → ${detail}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  health: () => req<Health>("GET", "/api/health"),

  adminMe: () => req<{ user: string; is_admin: boolean }>("GET", "/api/admin/me"),
  listAdmins: () => req<{ admins: AdminUser[]; me: string }>("GET", "/api/admin/admins"),
  addAdmin: (user_name: string) => req<{ admin: AdminUser }>("POST", "/api/admin/admins", { user_name }),
  removeAdmin: (user_name: string) => req<{ removed: string }>("DELETE", `/api/admin/admins/${encodeURIComponent(user_name)}`),

  ingestAsset: (b: {
    name: string;
    object_type: "uc_table" | "ddl" | "uploaded_csv";
    role: "source" | "target";
    locator?: string;
    content?: string;
  }) => req<Asset>("POST", "/api/assets/ingest", b),

  ingestDocument: async (file: File, role: "source" | "target"): Promise<Asset> => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("role", role);
    const res = await fetch("/api/assets/ingest-document", { method: "POST", body: fd });
    if (!res.ok) {
      let detail = `${res.status}`;
      try {
        detail = (await res.json()).detail ?? detail;
      } catch {
        /* ignore */
      }
      throw new Error(`document ingestion → ${detail}`);
    }
    return res.json() as Promise<Asset>;
  },
  getAsset: (id: string) => req<Asset>("GET", `/api/assets/${id}`),
  listAssets: (role?: string) =>
    req<Asset[]>("GET", `/api/assets${role ? `?role=${role}` : ""}`),

  // Multi-table: parse a document into its constituent tables WITHOUT creating
  // assets. The user then multi-selects tables and creates a spec via createSpecMulti.
  parseTables: async (file: File, role: "source" | "target"): Promise<ParseTablesResult> => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("role", role);
    const res = await fetch("/api/assets/parse-tables", { method: "POST", body: fd });
    if (!res.ok) {
      let detail = `${res.status}`;
      try {
        detail = (await res.json()).detail ?? detail;
      } catch {
        /* ignore */
      }
      throw new Error(`table extraction → ${detail}`);
    }
    return res.json() as Promise<ParseTablesResult>;
  },

  createSpec: (b: { name: string; source_asset_id: string; target_asset_id: string; source_system?: string | null; target_system?: string | null }) =>
    req<Spec>("POST", "/api/specs", b),
  // Create a spec spanning multiple source/target tables (each becomes an asset).
  createSpecMulti: (b: { name?: string; sources: ParsedTable[]; targets: ParsedTable[] }) =>
    req<Spec>("POST", "/api/specs/multi", b),
  getSpec: (id: string) => req<Spec>("GET", `/api/specs/${id}`),
  renameSpec: (id: string, name: string) => req<Spec>("PATCH", `/api/specs/${id}`, { name }),
  setSpecSystems: (id: string, b: { source_system?: string | null; target_system?: string | null }) =>
    req<Spec>("PATCH", `/api/specs/${id}/systems`, b),
  deleteSpec: (id: string) => req<{ deleted: string }>("DELETE", `/api/specs/${id}`),
  cloneSpec: (id: string) => req<Spec>("POST", `/api/specs/${id}/clone`, {}),

  // --- Deploy-as-Pipeline (git → DAB → SDP) ---
  gitCredential: () => req<{ stored: boolean; git_username?: string | null }>("GET", "/api/git/credential"),
  saveGitCredential: (b: { git_username: string; token: string }) =>
    req<{ stored: boolean; git_username?: string; github_login?: string }>("POST", "/api/git/credential", b),
  listGitRepos: () => req<{ repos: { full_name: string; default_branch: string; private: boolean }[] }>("GET", "/api/git/repos"),
  createGitRepo: (b: { name: string; private?: boolean; description?: string }) =>
    req<{ full_name: string; default_branch: string }>("POST", "/api/git/repos", b),
  gitBranches: (repo: string) => req<{ default_branch: string }>("GET", `/api/git/branches?repo=${encodeURIComponent(repo)}`),
  pipelineDefaults: () => req<{ catalog: string; schema: string }>("GET", "/api/pipeline/defaults"),
  deployPipeline: (specId: string, b: {
    repo_full_name: string; branch: string; new_branch_from?: string | null;
    pipeline_name: string;
    source_catalog?: string | null; source_schema: string;
    target_catalog?: string | null; target_schema: string;
    table_type: string; schedule?: string | null; commit_message?: string | null;
  }) => req<{ deploy_id: string; status: string; steps: DeployStep[] }>("POST", `/api/specs/${specId}/deploy-pipeline`, b),
  deployStatus: (deployId: string) => req<DeployRun>("GET", `/api/pipeline/deploy/${deployId}`),
  runPipeline: (pid: string) => req<{ update_id?: string; pipeline_id: string }>("POST", `/api/pipelines/${pid}/run`, {}),
  testPipeline: (specId: string, b: {
    pipeline_id: string; source_catalog?: string | null; source_schema: string;
    target_catalog?: string | null; target_schema: string; table_type: string;
  }) => req<{ test_id: string; status: string; steps: DeployStep[] }>("POST", `/api/specs/${specId}/pipelines/test`, b),
  testStatus: (testId: string) => req<TestRun>("GET", `/api/pipeline/test/${testId}`),
  setValidationDqAction: (validationId: string, dq_action: "warn" | "fail") =>
    req<{ id: string; dq_action: string }>("POST", `/api/validations/${validationId}/dq-action`, { dq_action }),
  auditLog: (id: string) => req<{ spec_id: string; events: AuditEvent[] }>("GET", `/api/specs/${id}/audit`),
  listComments: (id: string) => req<{ spec_id: string; comments: Comment[] }>("GET", `/api/specs/${id}/comments`),
  addComment: (id: string, b: { body: string; section: string }) => req<Comment>("POST", `/api/specs/${id}/comments`, b),
  suggest: (id: string) =>
    req<{ suggested: number; skipped: unknown[]; mappings: Mapping[] }>(
      "POST",
      `/api/specs/${id}/suggest`,
    ),
  optimize: (id: string) =>
    req<{ spec_id: string; reviewed: number; optimizations: Optimization[]; skipped: unknown[] }>(
      "POST",
      `/api/specs/${id}/optimize`,
    ),
  validateMapping: (id: string) =>
    req<{ spec_id: string; dataset: string; coverage: { covered: number; total: number }; tables?: { target_table: string; dataset: string; proposed: number; covered: number; total: number }[]; validations: ValidationProposal[]; skipped: unknown[] }>(
      "POST",
      `/api/specs/${id}/validate`,
    ),
  applyValidations: (id: string, b: { dataset: string; items: ValidationProposal[] }) =>
    req<{ created: number; skipped: unknown[]; validations: Validation[] }>(
      "POST",
      `/api/specs/${id}/validations/apply`,
      b,
    ),
  pipelineStatus: () => req<{ provisioned: boolean; pipeline_id?: string | null; name: string }>("GET", "/api/admin/pipeline-status"),
  provisionPipeline: () => req<{ provisioned: boolean; pipeline_id: string; reused?: boolean }>("POST", "/api/admin/provision-pipeline", {}),
  startValidateRun: (id: string) => req<ValidateRun>("POST", `/api/specs/${id}/validate-run`, {}),
  getValidateRun: (id: string, runId: string) => req<ValidateRun>("GET", `/api/specs/${id}/validate-run/${runId}`),
  similarMappings: (id: string) => req<{ spec_id: string; matches: SimilarMapping[] }>("GET", `/api/specs/${id}/similar`),

  generateDocumentation: (id: string) => req<MappingDoc>("POST", `/api/specs/${id}/documentation`, {}),
  publishDocumentation: (id: string, markdown: string) =>
    req<{ published: boolean; path: string }>("POST", `/api/specs/${id}/documentation/publish`, { markdown }),
  // Fetch the server-generated PDF and trigger a browser download of the real file.
  downloadDocumentationPdf: async (id: string): Promise<void> => {
    const res = await fetch(`/api/specs/${id}/documentation/pdf`, { method: "POST" });
    if (!res.ok) {
      let detail = `${res.status}`;
      try {
        detail = (await res.json()).detail ?? detail;
      } catch {
        /* ignore */
      }
      throw new Error(`PDF download → ${detail}`);
    }
    const blob = await res.blob();
    const cd = res.headers.get("Content-Disposition") || "";
    const m = cd.match(/filename="?([^"]+)"?/);
    const filename = m ? m[1] : "mapping_spec.pdf";
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  },
  curate: (
    specId: string,
    mappingId: string,
    b: { action: "accept" | "edit" | "reject"; transform_spec?: TransformSpec; source_field_ids?: string[] },
  ) => req<Mapping>("PATCH", `/api/specs/${specId}/mappings/${mappingId}`, b),
  // Per-column feedback loops (Designer detail panel).
  regenerateMapping: (specId: string, mappingId: string, feedback: string) =>
    req<Spec>("POST", `/api/specs/${specId}/mappings/${mappingId}/regenerate`, { feedback }),
  useTransformation: (specId: string, mappingId: string, code: string) =>
    req<Spec>("POST", `/api/specs/${specId}/mappings/${mappingId}/use-transformation`, { code }),
  propagateTransformation: (specId: string, mappingId: string, also_datasets: string[]) =>
    req<{ applied: number; skipped: { dataset: string; reason: string }[] }>("POST", `/api/specs/${specId}/mappings/${mappingId}/propagate`, { also_datasets }),
  addValidation: (specId: string, b: { dataset: string; column: string; description?: string; rule_code?: string; also_datasets?: string[] }) =>
    req<{ created: number; duplicates: number; validations: Validation[] }>("POST", `/api/specs/${specId}/validations/add`, b),
  propagateValidation: (specId: string, validationId: string, also_datasets: string[]) =>
    req<{ created: number; duplicates: number }>("POST", `/api/specs/${specId}/validations/${validationId}/propagate`, { also_datasets }),

  submit: (id: string) => req<Spec>("POST", `/api/specs/${id}/submit`, {}),
  decide: (id: string, b: { decision: "approved" | "rejected"; rationale?: string }) =>
    req<Spec>("POST", `/api/specs/${id}/decide`, b),
  compile: (id: string) =>
    req<{ content_hash: string; generated_sql: string; lineage: unknown[] }>(
      "POST",
      `/api/specs/${id}/compile`,
      {},
    ),
  run: (id: string) =>
    req<{ columns: string[]; rows: unknown[][] }>("POST", `/api/specs/${id}/run`, {}),
  lineage: (id: string) => req<{ edges: { source_field: string; target_field: string }[] }>("GET", `/api/specs/${id}/lineage`),

  explainStatus: () => req<{ ready: boolean; endpoint_name?: string }>("GET", "/api/explain/status"),
  explain: (question: string) => req<{ answer: string; endpoint: string }>("POST", "/api/explain", { question }),

  dashboard: () => req<DashboardSummary>("GET", "/api/dashboard/summary"),
  listSpecs: () => req<SpecRow[]>("GET", "/api/specs"),
  seed: () => req<{ seeded: Record<string, number> }>("POST", "/api/admin/seed", {}),
  complexDemo: () => req<{ source: Asset; target: Asset; spec: Spec }>("POST", "/api/admin/complex-demo", {}),

  listRules: () => req<Rule[]>("GET", "/api/rules"),
  getRule: (id: string) => req<Rule>("GET", `/api/rules/${id}`),
  generateRule: (b: { description: string; rule_type: string; data_type: string }) =>
    req<{ name: string; description: string; logic_sql: string; logic_preview: string; explanation: string; sample_io: { input: string; output: string }[] }>("POST", "/api/rules/generate", b),
  createRule: (b: {
    name: string; rule_type?: string; domain?: string | null; data_type?: string | null;
    description?: string | null; logic_sql?: string | null; logic_preview?: string | null;
    sample_io?: { input: string; output: string }[] | null; tags?: string[] | null; status?: string;
  }) => req<Rule>("POST", "/api/rules", b),
  validateRuleLogicExpression: (expression: string) =>
    req<{ valid: boolean; normalized?: string; columns?: string[]; error?: string }>("POST", "/api/rules/validate-expression", { expression }),
  submitRule: (id: string) => req<Rule>("POST", `/api/rules/${id}/submit`, {}),
  decideRule: (id: string, b: { decision: "approved" | "rejected"; rationale?: string }) =>
    req<Rule>("POST", `/api/rules/${id}/decide`, b),
  applyRule: (id: string, b: { dataset: string; column_name?: string | null; severity?: string }) =>
    req<{ validation: Validation }>("POST", `/api/rules/${id}/apply`, b),

  listTransformations: () => req<Transformation[]>("GET", "/api/transformations"),
  getTransformation: (id: string) => req<Transformation>("GET", `/api/transformations/${id}`),
  createTransformation: (b: {
    name: string; description?: string | null; ttype?: string; category?: string | null;
    logic_expr?: string | null; logic_sql?: string | null;
    test_cases?: { name: string; input?: unknown; output?: unknown }[] | null;
    tags?: string[] | null; status?: string;
  }) => req<Transformation>("POST", "/api/transformations", b),
  generateTransformation: (b: { description: string }) =>
    req<{ name: string; description: string; logic_expr: string; logic_sql: string; explanation: string; steps: { name: string; detail: string }[] }>("POST", "/api/transformations/generate", b),
  validateExpression: (expression: string) =>
    req<{ valid: boolean; normalized?: string; columns?: string[]; error?: string }>("POST", "/api/transformations/validate-expression", { expression }),
  submitTransformation: (id: string) => req<Transformation>("POST", `/api/transformations/${id}/submit`, {}),
  decideTransformation: (id: string, b: { decision: "approved" | "rejected"; rationale?: string }) =>
    req<Transformation>("POST", `/api/transformations/${id}/decide`, b),

  listValidations: () => req<Validation[]>("GET", "/api/validations"),
  getValidation: (id: string) => req<Validation>("GET", `/api/validations/${id}`),
  regenerateValidation: (vid: string, feedback: string) =>
    req<Validation>("POST", `/api/validations/${vid}/regenerate`, { feedback }),
  useRuleForValidation: (vid: string, code: string) =>
    req<Validation>("POST", `/api/validations/${vid}/use-rule`, { code }),
  validationsSummary: () => req<ValidationsSummary>("GET", "/api/validations/summary"),
  pipelineDqMetrics: () => req<PipelineDqMetrics>("GET", "/api/validations/pipeline-metrics"),
  generateValidation: (b: { description: string; rule_type: string; column_name: string }) =>
    req<{ logic: string; explanation: string; checks: string[] }>("POST", "/api/validations/generate", b),
  createValidation: (b: {
    name: string; rule_type?: string; dataset?: string | null; column_name?: string | null;
    severity?: string; description?: string | null; logic?: string | null; tags?: string[] | null; status?: string;
  }) => req<Validation>("POST", "/api/validations", b),
  validateRuleExpression: (expression: string) =>
    req<{ valid: boolean; normalized?: string; columns?: string[]; error?: string }>("POST", "/api/validations/validate-expression", { expression }),
  submitValidation: (id: string) => req<Validation>("POST", `/api/validations/${id}/submit`, {}),
  decideValidation: (id: string, b: { decision: "approved" | "rejected"; rationale?: string }) =>
    req<Validation>("POST", `/api/validations/${id}/decide`, b),

  metadataSummary: () => req<MetadataSummary>("GET", "/api/metadata/summary"),
  metadataAssets: () => req<MetaAsset[]>("GET", "/api/metadata/assets"),
  metadataGlossary: () => req<GlossaryTerm[]>("GET", "/api/metadata/glossary"),
  metadataGraph: () => req<{ nodes: { name: string; type: string }[]; edges: { source: string; target: string; type: string }[] }>("GET", "/api/metadata/graph"),

  listExecutions: () => req<Execution[]>("GET", "/api/executions"),
  executionsSummary: () => req<ExecutionsSummary>("GET", "/api/executions/summary"),
};

export interface MetadataSummary {
  kpis: { label: string; value: number; delta?: string }[];
  domains: { name: string; value: number; color: string }[];
  systems: { code: string; name: string; assets: number }[];
}
export interface MetaAsset {
  name: string;
  asset_type: string;
  system?: string | null;
  domain?: string | null;
  criticality?: string | null;
  owner?: string | null;
  updated_at?: string | null;
}
export interface GlossaryTerm {
  name: string;
  definition?: string | null;
  term_type: string;
  domain?: string | null;
  steward?: string | null;
}
export interface Execution {
  pipeline_name: string;
  status: string;
  duration_sec?: number | null;
  cost?: number | null;
  row_count?: number | null;
  validation_status?: string | null;
  error?: string | null;
  started_at?: string | null;
}
export interface ExecutionsSummary {
  total: number;
  by_status: { name: string; value: number }[];
  running: number;
  succeeded: number;
  failed: number;
  warning: number;
  total_cost: number;
  avg_duration_sec: number;
  total_rows: number;
  success_rate: number;
}

export interface Rule {
  id: string;
  name: string;
  code: string;
  rule_type: string;
  domain?: string | null;
  data_type?: string | null;
  description?: string | null;
  logic_preview?: string | null;
  sample_io?: { input: string; output: string }[] | null;
  owner?: string | null;
  status: string;
  version?: string | null;
  usage_count: number;
  used_by?: number;
  tags?: string[] | null;
  logic_sql?: string | null;
  submitted_by?: string | null;
  approved_by?: string | null;
  rationale?: string | null;
  updated_at?: string | null;
}
export interface AdminUser {
  user_name: string;
  added_by?: string | null;
  created_at?: string | null;
}
export interface Transformation {
  id: string;
  name: string;
  code: string;
  ttype: string;
  category?: string | null;
  description?: string | null;
  logic_expr?: string | null;
  logic_sql?: string | null;
  test_cases?: { name: string; input?: unknown; output?: unknown; pass?: boolean }[] | null;
  owner?: string | null;
  status: string;
  reuse_count: number;
  used_by?: number;
  tags?: string[] | null;
  submitted_by?: string | null;
  approved_by?: string | null;
  rationale?: string | null;
  updated_at?: string | null;
}
export interface Validation {
  id: string;
  name: string;
  code: string;
  rule_type: string;
  dataset?: string | null;
  column_name?: string | null;
  severity: string;
  dq_action?: string | null;   // pipeline DQ routing: 'warn' (log) | 'fail' (quarantine)
  description?: string | null;
  logic?: string | null;
  owner?: string | null;
  status: string;
  last_status?: string | null;
  success_rate?: number | null;
  failed_records?: number | null;
  last_run_at?: string | null;
  tags?: string[] | null;
  submitted_by?: string | null;
  approved_by?: string | null;
  rationale?: string | null;
}
export interface ValidationsSummary {
  total: number;
  active: number;
  passed_pct: number;
  failed_pct: number;
  critical_failures: number;
  by_type: { name: string; value: number }[];
  by_severity: { name: string; value: number }[];
  top_failed: { name: string; failed_records: number; rule_type: string }[];
  recent_runs: { run_name: string; cadence: string; passed_pct: number; run_at: string | null }[];
}

export interface PipelineDqMetrics {
  available: boolean;
  reason?: string;
  locations?: string[];
  summary: {
    checks?: number; failing_checks?: number; overall_pass_rate?: number | null;
    quarantined_rows?: number; audited_runs?: number;
  };
  by_rule: {
    run_ts?: string | null; pipeline_name?: string; target?: string; rule?: string; column_name?: string;
    severity?: string; action?: string; failed_rows?: number | null; total_rows?: number | null; pass_rate?: number | null;
  }[];
  by_target: { target: string; checks: number; failing: number; failed_rows: number; total_rows: number; quarantined?: number }[];
  quarantine: { target: string; table: string; rows: number; catalog?: string; schema?: string }[];
  recent_runs: { run_id: string; pipeline_name?: string; run_ts?: string | null; checks: number; failed_rows: number; total_rows: number; pass_rate?: number | null }[];
}

export interface DashboardKpi {
  label: string;
  value: number;
  delta: string;
  spark: number[];
}
export interface DashboardSummary {
  kpis: DashboardKpi[];
  pipeline_health: { running: number; succeeded: number; failed: number; warning: number };
  mappings_by_status: { name: string; value: number }[];
  pending_approvals: { label: string; count: number; type: string }[];
  recent_activity: { actor: string; action: string; target: string; type: string; at: string | null }[];
  top_impacted: { name: string; type: string; criticality: string; impact: number }[];
  executions_7d: { day: string; successful: number; failed: number; warning: number }[];
}
// One entry in a mapping's audit work-log (History tab).
export interface AuditEvent {
  at: string | null;
  actor: string;
  action: string;   // created | submitted | approved | rejected | accepted | edited | rejected
  detail: string;
  kind: "lifecycle" | "governance" | "curation";
}
// A reviewer/author comment on a mapping (Comments tab), scoped by section.
export interface Comment {
  id: string;
  section: string;
  author: string;
  body: string;
  created_at: string;
}

export interface SpecRow {
  id: string;
  name: string;
  description?: string | null;
  source_system?: string | null;
  target_system?: string | null;
  status: string;
  mapping_type?: string | null;
  ai_confidence?: number | null;
  owner: string;
  updated_at?: string | null;
  // List-tab signals computed from the live field mappings.
  mapping_count?: number;
  pending_count?: number;
  ai_authored?: number;   // fraction (0..1) of active mappings with AI provenance
}
