"""Thin wrapper over Databricks SQL statement execution.

A Databricks App is serving compute, not a Spark cluster, so all reads/writes
against Unity Catalog / Delta and all schema introspection go through the
serverless SQL warehouse via the Statement Execution API. Used by ingestion
(M2, information_schema), the governance saga (M5, Delta MERGE) and execution
verification (M7).
"""
from __future__ import annotations

from typing import Any

from databricks.sdk.service.sql import StatementState

from server import config


def execute(sql: str, *, catalog: str | None = None, schema: str | None = None) -> list[list[Any]]:
    """Run a SQL statement synchronously and return result rows (list of lists).

    Raises on non-SUCCESS terminal states so callers fail closed.
    """
    w = config.get_workspace_client()
    resp = w.statement_execution.execute_statement(
        warehouse_id=config.WAREHOUSE_ID,
        statement=sql,
        catalog=catalog,
        schema=schema,
        wait_timeout="50s",
    )
    state = resp.status.state if resp.status else None
    if state != StatementState.SUCCEEDED:
        msg = ""
        if resp.status and resp.status.error:
            msg = resp.status.error.message or ""
        raise RuntimeError(f"SQL failed ({state}): {msg}\n---\n{sql}")
    if resp.result and resp.result.data_array:
        return resp.result.data_array
    return []
