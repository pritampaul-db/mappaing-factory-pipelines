import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Line,
  LineChart,
  Legend,
  CartesianGrid,
} from "recharts";
import { chartPalette } from "../theme";

export interface Slice {
  name: string;
  value: number;
  color?: string;
}

export function DonutChart({ data, total, totalLabel }: { data: Slice[]; total?: number; totalLabel?: string }) {
  const sum = total ?? data.reduce((a, d) => a + d.value, 0);
  // Only render non-zero slices: a zero-value slice contributes no arc but still
  // gets a paddingAngle gap, which shows up as a notch in the ring. Dropping them
  // means a single non-zero category renders as a clean, complete ring.
  const slices = data.filter((d) => d.value > 0);
  return (
    <div className="relative" style={{ width: "100%", height: 200 }}>
      <ResponsiveContainer>
        <PieChart>
          {/* Percentage radii so the ring scales to fit ANY container width — a
              fixed px radius gets clipped left/right in a narrow box. Full-circle
              grey track keeps the ring looking complete even at one/zero slices. */}
          <Pie data={[{ name: "track", value: 1 }]} dataKey="value" innerRadius="62%" outerRadius="90%" isAnimationActive={false} fill="#eef2f7" stroke="none" />
          <Pie data={slices} dataKey="value" nameKey="name" innerRadius="62%" outerRadius="90%" paddingAngle={slices.length > 1 ? 2 : 0} strokeWidth={0}>
            {slices.map((d, i) => (
              <Cell key={i} fill={d.color ?? chartPalette[i % chartPalette.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
      <div className="absolute inset-0 grid place-items-center pointer-events-none">
        <div className="text-center">
          <div className="text-2xl font-semibold text-gray-900">{sum.toLocaleString()}</div>
          {totalLabel && <div className="text-xs text-gray-500">{totalLabel}</div>}
        </div>
      </div>
    </div>
  );
}

// Legend rows next to a donut (label • value • pct).
export function LegendList({ data }: { data: Slice[] }) {
  const sum = data.reduce((a, d) => a + d.value, 0) || 1;
  return (
    <ul className="space-y-1.5">
      {data.map((d, i) => (
        <li key={i} className="flex items-center gap-2 text-sm">
          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: d.color ?? chartPalette[i % chartPalette.length] }} />
          <span className="text-gray-700 flex-1">{d.name}</span>
          <span className="text-gray-900 font-medium">{d.value.toLocaleString()}</span>
          <span className="text-gray-400 w-12 text-right">{Math.round((d.value / sum) * 100)}%</span>
        </li>
      ))}
    </ul>
  );
}

export interface DayBar {
  day: string;
  successful: number;
  failed: number;
  warning: number;
  successRate?: number;
}

export function ExecutionsBarChart({ data }: { data: DayBar[] }) {
  return (
    <div style={{ width: "100%", height: 240 }}>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
          <XAxis dataKey="day" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
          <Tooltip />
          <Legend wrapperStyle={{ fontSize: 11 }} />
          <Bar dataKey="successful" stackId="a" fill="#16a34a" radius={[0, 0, 0, 0]} />
          <Bar dataKey="warning" stackId="a" fill="#d97706" />
          <Bar dataKey="failed" stackId="a" fill="#dc2626" radius={[3, 3, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// Tiny inline sparkline for KPI cards.
export function Sparkline({ points, color = "#c9252d" }: { points: number[]; color?: string }) {
  const data = points.map((y, x) => ({ x, y }));
  return (
    <div style={{ width: 64, height: 24 }}>
      <ResponsiveContainer>
        <LineChart data={data}>
          <Line type="monotone" dataKey="y" stroke={color} dot={false} strokeWidth={1.5} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// Horizontal labelled progress bars (category breakdowns, "rules by severity").
export function BreakdownBars({ data }: { data: { label: string; value: number; color?: string; pct?: number }[] }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <ul className="space-y-2">
      {data.map((d, i) => (
        <li key={i} className="flex items-center gap-3 text-sm">
          <span className="w-28 text-gray-600 truncate">{d.label}</span>
          <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full rounded-full" style={{ width: `${(d.value / max) * 100}%`, background: d.color ?? chartPalette[i % chartPalette.length] }} />
          </div>
          <span className="text-gray-500 w-20 text-right">
            {d.value.toLocaleString()}
            {d.pct != null && <span className="text-gray-400"> ({d.pct}%)</span>}
          </span>
        </li>
      ))}
    </ul>
  );
}
