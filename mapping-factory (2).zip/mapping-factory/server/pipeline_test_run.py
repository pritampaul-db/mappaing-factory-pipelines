"""Background 'Test with dummy data' runner with live commentary.

The wizard's Test button used to fire-and-navigate. This runs the test on a background
thread as named steps the UI polls, mirroring the deploy runner:
  seed  → write fresh config row → start update → wait to terminal → roll up DQ audit

On success it reports per-target row counts + how many rows were quarantined, and writes
one audit row per (rule, run) to mf_dq_audit for quality metrics over time.
"""
from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from server import config, pipeline_config, pipeline_config_store, pipeline_deploy, repo, repo_library

_RUNS: dict[str, dict[str, Any]] = {}
_LOCK = threading.Lock()

_STEP_DEFS = [
    ("seed", "Seed data", "Create + populate dummy source tables"),
    ("config", "Config", "Write the mapping config for this run"),
    ("start", "Start run", "Trigger the pipeline update"),
    ("wait", "Run", "Wait for the pipeline to finish"),
    ("audit", "Audit", "Roll up DQ results into the audit table"),
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_run(spec_id: str) -> dict[str, Any]:
    test_id = uuid.uuid4().hex[:12]
    run = {
        "test_id": test_id,
        "spec_id": spec_id,
        "status": "running",
        "started_at": _now(),
        "steps": [
            {"key": k, "label": lbl, "description": d, "status": "pending", "detail": None, "elapsed_sec": None}
            for k, lbl, d in _STEP_DEFS
        ],
        "result": None,   # {pipeline_id, update_id, pipeline_state, targets:[{target,rows,quarantined}], audit_rows}
        "error": None,
    }
    with _LOCK:
        _RUNS[test_id] = run
    return run


def get_run(test_id: str) -> dict[str, Any] | None:
    import time as _t

    with _LOCK:
        r = _RUNS.get(test_id)
        if not r:
            return None
        for s in r["steps"]:
            if s["status"] == "running" and s.get("_started_mono") is not None:
                s["elapsed_sec"] = round(_t.monotonic() - s["_started_mono"], 1)
        snap = json.loads(json.dumps(r))
    for s in snap["steps"]:
        s.pop("_started_mono", None)
    return snap


def _set_step(run: dict, key: str, status: str, detail: str | None = None) -> None:
    import time as _t

    with _LOCK:
        for s in run["steps"]:
            if s["key"] == key:
                if status == "running" and s.get("_started_mono") is None:
                    s["_started_mono"] = _t.monotonic()
                if s.get("_started_mono") is not None:
                    s["elapsed_sec"] = round(_t.monotonic() - s["_started_mono"], 1)
                s["status"] = status
                if detail is not None:
                    s["detail"] = detail
                break


def start_test(spec_id: UUID, *, pipeline_id: str, source_catalog: str | None,
               source_schema: str, target_catalog: str | None, target_schema: str,
               table_type: str) -> dict[str, Any]:
    run = _new_run(str(spec_id))
    args = (str(spec_id), pipeline_id, source_catalog, source_schema,
            target_catalog, target_schema, table_type, run)
    threading.Thread(target=_execute, args=args, daemon=True).start()
    return run


def _execute(spec_id, pipeline_id, source_catalog, source_schema,
             target_catalog, target_schema, table_type, run) -> None:
    try:
        spec = repo.get_spec(config_pool(), UUID(spec_id))
        if spec is None:
            raise ValueError("spec not found")
        source_catalog = source_catalog or config.UC_CATALOG
        target_catalog = target_catalog or config.UC_CATALOG
        pipeline_name = spec_pipeline_name(spec, pipeline_id)

        # applied validations (dataset-scoped) so audit + config carry severity/action
        spec_tag = f"spec:{spec_id}"
        try:
            vals = [v for v in repo_library.list_validations(config_pool()) if spec_tag in (v.get("tags") or [])]
        except Exception:  # noqa: BLE001
            vals = []
        cfg = pipeline_config.build_mapping_config(spec, vals, catalog=source_catalog, source_schema=source_schema)
        full_config = {**cfg, "catalog": target_catalog, "schema": target_schema,
                       "source_catalog": source_catalog, "source_schema": source_schema,
                       "table_type": table_type, "spec_name": spec.get("name"), "pipeline_name": pipeline_name}

        # --- seed ------------------------------------------------------------
        _set_step(run, "seed", "running")
        seed = pipeline_deploy.seed_dummy_sources(spec, cfg.get("inputs", {}))
        _set_step(run, "seed", "done",
                  ", ".join(f"{s['asset']}: {s['rows']} rows" for s in seed.get("seeded", [])) or "no sources")

        # --- config (fresh row so the run picks up the latest mapping) -------
        _set_step(run, "config", "running")
        rid = uuid.uuid4().hex[:12]
        pipeline_config_store.write_config(full_config, catalog=target_catalog, schema=target_schema,
                                           pipeline_name=pipeline_name, run_id=rid)
        _set_step(run, "config", "done", f"run_id={rid}")

        # --- start -----------------------------------------------------------
        _set_step(run, "start", "running")
        started = pipeline_deploy.run_pipeline(pipeline_id, full_refresh=True)
        update_id = started.get("update_id")
        _set_step(run, "start", "done", f"update {update_id}")

        # --- wait (live state commentary) -----------------------------------
        _set_step(run, "wait", "running", "queued…")
        state = pipeline_deploy.wait_for_update(
            pipeline_id, update_id, on_state=lambda st: _set_step(run, "wait", "running", st))
        if state != "COMPLETED":
            errs = pipeline_deploy.recent_error_events(pipeline_id)
            _set_step(run, "wait", "failed", state)
            raise RuntimeError(f"pipeline run {state}" + (f": {errs[0][:300]}" if errs else ""))
        _set_step(run, "wait", "done", "COMPLETED")

        # --- audit rollup ----------------------------------------------------
        _set_step(run, "audit", "running")
        audit = pipeline_config_store.rollup_audit(full_config, catalog=target_catalog,
                                                   schema=target_schema, pipeline_name=pipeline_name, run_id=rid)
        targets = _target_counts(full_config, target_catalog, target_schema)
        _set_step(run, "audit", "done", f"{audit.get('audit_rows_written', 0)} audit row(s)")

        with _LOCK:
            run["status"] = "succeeded"
            run["result"] = {
                "pipeline_id": pipeline_id, "update_id": update_id, "pipeline_state": state,
                "targets": targets, "audit_rows": audit.get("audit_rows_written", 0),
                "audit_table": audit.get("audit_table"),
            }
    except Exception as e:  # noqa: BLE001
        with _LOCK:
            for s in run["steps"]:
                if s["status"] == "running":
                    s["status"] = "failed"
                    s["detail"] = str(e)[:300]
                    break
            run["status"] = "failed"
            run["error"] = str(e)


def _target_counts(full_config: dict, catalog: str, schema: str) -> list[dict]:
    """Row counts per target + how many rows were quarantined (best-effort)."""
    out = []
    w = config.get_sp_client()
    for tgt in full_config.get("targets", []):
        name = tgt["target_name"]
        rows = _count(w, f"{catalog}.{schema}.{name}")
        quar = _count(w, f"{catalog}.{schema}.{name}_quarantine")
        out.append({"target": name, "rows": rows, "quarantined": quar})
    return out


def _count(w, fqn: str) -> int | None:
    from databricks.sdk.service.sql import StatementState

    try:
        resp = w.statement_execution.execute_statement(
            warehouse_id=config.WAREHOUSE_ID, statement=f"SELECT count(*) FROM {fqn}", wait_timeout="30s")
        if resp.status and resp.status.state == StatementState.SUCCEEDED and resp.result and resp.result.data_array:
            return int(resp.result.data_array[0][0])
    except Exception:  # noqa: BLE001 — table may not exist (no FAIL rules → no quarantine table)
        return None
    return None


def config_pool():
    from server import db
    return db.pool


def spec_pipeline_name(spec: dict, pipeline_id: str) -> str:
    """Resolve the pipeline's name (config_key) from its id, best-effort."""
    try:
        w = config.get_sp_client()
        return w.pipelines.get(pipeline_id=pipeline_id).name or pipeline_id
    except Exception:  # noqa: BLE001
        return pipeline_id
