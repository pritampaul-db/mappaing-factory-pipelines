"""Execution Monitor — pipeline runs list + summary."""
from __future__ import annotations

from fastapi import APIRouter
from psycopg.rows import dict_row

from server import db

router = APIRouter(tags=["executions"])


@router.get("/executions")
def list_executions() -> list[dict]:
    with db.pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                """SELECT pipeline_name, status, duration_sec, cost, row_count,
                          validation_status, error, started_at
                   FROM mapping_factory.execution ORDER BY started_at DESC"""
            )
            return [
                {
                    "pipeline_name": r["pipeline_name"], "status": r["status"], "duration_sec": r["duration_sec"],
                    "cost": float(r["cost"]) if r["cost"] is not None else None, "row_count": r["row_count"],
                    "validation_status": r["validation_status"], "error": r["error"],
                    "started_at": r["started_at"].isoformat() if r["started_at"] else None,
                }
                for r in cur.fetchall()
            ]


@router.get("/executions/summary")
def summary() -> dict:
    with db.pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SET search_path TO mapping_factory, public")
            cur.execute("SELECT status, COUNT(*) AS c FROM execution GROUP BY status")
            by_status = {r["status"]: r["c"] for r in cur.fetchall()}
            cur.execute("SELECT COALESCE(SUM(cost),0) AS cost, COALESCE(AVG(duration_sec),0) AS dur, COALESCE(SUM(row_count),0) AS rows FROM execution WHERE status <> 'running'")
            agg = cur.fetchone()
    total = sum(by_status.values())
    return {
        "total": total,
        "by_status": [{"name": k, "value": v} for k, v in by_status.items()],
        "running": by_status.get("running", 0),
        "succeeded": by_status.get("succeeded", 0),
        "failed": by_status.get("failed", 0),
        "warning": by_status.get("warning", 0),
        "total_cost": round(float(agg["cost"]), 2),
        "avg_duration_sec": round(float(agg["dur"]), 1),
        "total_rows": int(agg["rows"]),
        "success_rate": round((by_status.get("succeeded", 0) / total), 3) if total else 0,
    }
