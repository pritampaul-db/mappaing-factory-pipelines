import { Search, Bell, HelpCircle, ChevronDown, ShieldCheck } from "lucide-react";
import { initials, avatarColor, displayName } from "../theme";

// Page-level title/subtitle + global search + notifications + user chip.
export function TopBar({
  title,
  subtitle,
  identity,
  isAdmin,
  actions,
}: {
  title: string;
  subtitle?: string;
  identity?: string;
  isAdmin?: boolean;
  actions?: React.ReactNode;
}) {
  const name = displayName(identity);
  return (
    <header className="shrink-0 bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-6">
      <div className="min-w-0">
        <h1 className="text-xl font-semibold text-gray-900 truncate">{title}</h1>
        {subtitle && <p className="text-xs text-gray-500 truncate">{subtitle}</p>}
      </div>

      <div className="flex-1 max-w-xl mx-auto hidden md:block">
        <div className="relative">
          <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-9 pr-10 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"
            placeholder="Search mappings, rules, tables, reports…"
          />
          <kbd className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-gray-400 border border-gray-200 rounded px-1">
            ⌘/
          </kbd>
        </div>
      </div>

      <div className="flex items-center gap-4 ml-auto">
        {actions}
        <button className="relative text-gray-500 hover:text-gray-700">
          <Bell className="w-5 h-5" />
          <span className="absolute -top-1.5 -right-1.5 bg-brand text-white text-[10px] rounded-full w-4 h-4 grid place-items-center">
            12
          </span>
        </button>
        <button className="text-gray-500 hover:text-gray-700">
          <HelpCircle className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2">
          <span
            className="w-8 h-8 rounded-full grid place-items-center text-white text-xs font-medium"
            style={{ background: avatarColor(name) }}
          >
            {initials(name)}
          </span>
          <div className="hidden lg:block leading-tight">
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-medium text-gray-800">{name}</span>
              {isAdmin && (
                <span className="inline-flex items-center gap-1 text-[10px] font-medium bg-brand-soft text-brand px-1.5 py-0.5 rounded" title="Administrator — bypasses maker-checker">
                  <ShieldCheck className="w-3 h-3" /> Admin
                </span>
              )}
            </div>
            <div className="text-[11px] text-gray-500">{isAdmin ? "Administrator" : "Data Engineer"}</div>
          </div>
          <ChevronDown className="w-4 h-4 text-gray-400" />
        </div>
      </div>
    </header>
  );
}
