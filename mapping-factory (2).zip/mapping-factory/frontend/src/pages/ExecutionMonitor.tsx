import { useEffect, useState } from "react";
import { Play, CheckCircle2, XCircle, AlertTriangle, DollarSign, Clock, Info } from "lucide-react";
import { usePage } from "../AppShell";
import { api, type Execution, type ExecutionsSummary } from "../api";
import { Card, StatusBadge } from "../components/primitives";
import { DonutChart, LegendList } from "../components/charts";
import { timeAgo } from "../theme";

const STATUS_COLOR: Record<string, string> = { succeeded: "#16a34a", running: "#2563eb", warning: "#d97706", failed: "#dc2626" };

function fmtDur(s?: number | null) {
  if (s == null) return "—";
  return s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${s % 60}s`;
}

export function ExecutionMonitor() {
  const [rows, setRows] = useState<Execution[]>([]);
  const [sum, setSum] = useState<ExecutionsSummary | null>(null);

  usePage({ title: "Execution Monitor", subtitle: "Runtime status, validation, duration, cost and row counts" });

  useEffect(() => {
    api.listExecutions().then(setRows);
    api.executionsSummary().then(setSum);
  }, []);

  const kpis = [
    { icon: Play, label: "Running", value: sum?.running ?? 0, tint: "#dbeafe", color: "#2563eb" },
    { icon: CheckCircle2, label: "Succeeded", value: sum?.succeeded ?? 0, tint: "#dcfce7", color: "#16a34a" },
    { icon: XCircle, label: "Failed", value: sum?.failed ?? 0, tint: "#fee2e2", color: "#dc2626" },
    { icon: AlertTriangle, label: "Warning", value: sum?.warning ?? 0, tint: "#fef3c7", color: "#d97706" },
    { icon: DollarSign, label: "Total Cost (DBU)", value: sum ? `$${sum.total_cost}` : "—", tint: "#fdecec", color: "#c9252d" },
    { icon: Clock, label: "Avg Duration", value: sum ? fmtDur(Math.round(sum.avg_duration_sec)) : "—", tint: "#ede9fe", color: "#a855f7" },
  ];

  return (
    <div className="p-6 space-y-4">
      {/* Provisional banner — this screen was built from the vision doc (no wireframe yet). */}
      <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-800 text-xs rounded-lg px-3 py-2">
        <Info className="w-4 h-4 shrink-0" />
        Provisional layout — Execution Monitor isn't wireframed yet, so this is a first-pass built from the UI vision. It will be refined once a wireframe is ready.
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white rounded-xl border border-gray-200 p-3 flex items-center gap-3">
            <span className="w-9 h-9 rounded-lg grid place-items-center shrink-0" style={{ background: k.tint, color: k.color }}><k.icon className="w-4 h-4" /></span>
            <div><div className="text-[11px] text-gray-500">{k.label}</div><div className="text-lg font-semibold text-gray-900">{k.value}</div></div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2 bg-white rounded-xl border border-gray-200 p-4">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">Pipeline Runs</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-200 text-left text-gray-500">
                  <th className="py-2 pr-3 font-medium">Pipeline</th>
                  <th className="py-2 pr-3 font-medium">Status</th>
                  <th className="py-2 pr-3 font-medium">Validation</th>
                  <th className="py-2 pr-3 font-medium text-right">Duration</th>
                  <th className="py-2 pr-3 font-medium text-right">Cost</th>
                  <th className="py-2 pr-3 font-medium text-right">Rows</th>
                  <th className="py-2 pr-3 font-medium">Started</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i} className="border-b border-gray-100">
                    <td className="py-2.5 pr-3">
                      <div className="font-medium text-gray-800">{r.pipeline_name}</div>
                      {r.error && <div className="text-xs text-red-500">{r.error}</div>}
                    </td>
                    <td className="py-2.5 pr-3"><StatusBadge status={r.status.charAt(0).toUpperCase() + r.status.slice(1)} /></td>
                    <td className="py-2.5 pr-3">
                      {r.validation_status && <StatusBadge status={r.validation_status} />}
                    </td>
                    <td className="py-2.5 pr-3 text-right text-gray-600">{fmtDur(r.duration_sec)}</td>
                    <td className="py-2.5 pr-3 text-right text-gray-600">{r.cost != null ? `$${r.cost.toFixed(2)}` : "—"}</td>
                    <td className="py-2.5 pr-3 text-right text-gray-600">{r.row_count != null ? r.row_count.toLocaleString() : "—"}</td>
                    <td className="py-2.5 pr-3 text-xs text-gray-400">{timeAgo(r.started_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <Card title="Runs by Status">
          {sum && (
            <>
              <DonutChart data={sum.by_status.map((s) => ({ name: s.name, value: s.value, color: STATUS_COLOR[s.name] }))} totalLabel="Total Runs" />
              <div className="mt-3"><LegendList data={sum.by_status.map((s) => ({ name: s.name, value: s.value, color: STATUS_COLOR[s.name] }))} /></div>
              <div className="mt-3 pt-3 border-t border-gray-100 text-sm flex justify-between">
                <span className="text-gray-500">Success rate</span>
                <span className="font-semibold text-gray-900">{Math.round(sum.success_rate * 100)}%</span>
              </div>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
