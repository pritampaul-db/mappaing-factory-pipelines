"""Validation / Data Quality — list (+ summary/insights), detail, create, AI-generate,
governance (submit/decide), and expression validation."""
from __future__ import annotations

from uuid import UUID

import sqlglot
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from server import config, db, llm, pipeline_config_store, repo_admin, repo_library

router = APIRouter(tags=["validations"])


def _user() -> str:
    try:
        return config.get_workspace_client().current_user.me().user_name or "unknown"
    except Exception:
        return "unknown"


@router.get("/validations")
def list_validations() -> list[dict]:
    return repo_library.list_validations(db.pool)


@router.get("/validations/summary")
def validations_summary() -> dict:
    rows = repo_library.list_validations(db.pool)
    runs = repo_library.list_validation_runs(db.pool)
    total = len(rows)
    # 'status' is now the governance lifecycle status; live rules = Published/Approved/Active.
    active = sum(1 for r in rows if r["status"] in ("Published", "Approved", "Active", "Live"))
    passed = sum(1 for r in rows if r.get("last_status") == "Passed")
    failed = sum(1 for r in rows if r.get("last_status") == "Failed")
    critical_fail = sum(1 for r in rows if r.get("last_status") == "Failed" and r.get("severity") == "critical")

    # distributions
    by_type: dict[str, int] = {}
    by_sev: dict[str, int] = {}
    for r in rows:
        by_type[r["rule_type"]] = by_type.get(r["rule_type"], 0) + 1
        by_sev[r["severity"]] = by_sev.get(r["severity"], 0) + 1

    # top failed (by failed_records)
    top_failed = sorted([r for r in rows if r.get("failed_records")], key=lambda r: -(r["failed_records"] or 0))[:5]

    return {
        "total": total,
        "active": active,
        "passed_pct": round(passed / total, 3) if total else 0,
        "failed_pct": round(failed / total, 3) if total else 0,
        "critical_failures": critical_fail,
        "by_type": [{"name": k, "value": v} for k, v in by_type.items()],
        "by_severity": [{"name": k, "value": v} for k, v in by_sev.items()],
        "top_failed": [{"name": r["name"], "failed_records": r["failed_records"], "rule_type": r["rule_type"]} for r in top_failed],
        "recent_runs": [{"run_name": r["run_name"], "cadence": r["cadence"], "passed_pct": r["passed_pct"], "run_at": r["run_at"].isoformat() if r["run_at"] else None} for r in runs],
    }


@router.get("/validations/pipeline-metrics")
def pipeline_dq_metrics() -> dict:
    """Live data-quality metrics from DEPLOYED pipelines: the mf_dq_audit history (one row
    per rule per run) + current quarantine row counts. Aggregated across every schema that
    holds an audit table. Powers the Data Quality screen's 'Pipeline DQ' section."""
    try:
        w = config.get_sp_client()
        locations = pipeline_config_store.discover_locations(w)
    except Exception as e:  # noqa: BLE001 — no SP/warehouse access: return an empty, non-fatal result
        return {"available": False, "reason": str(e), "audit": [], "quarantine": [],
                "summary": {}, "by_rule": [], "by_target": [], "recent_runs": []}

    audit: list[dict] = []
    quarantine: list[dict] = []
    for cat, sch in locations:
        try:
            for a in pipeline_config_store.read_audit(catalog=cat, schema=sch, w=w):
                a["catalog"], a["schema"] = cat, sch
                audit.append(a)
            for q in pipeline_config_store.read_quarantine_counts(catalog=cat, schema=sch, w=w):
                q["catalog"], q["schema"] = cat, sch
                quarantine.append(q)
        except Exception:  # noqa: BLE001 — one bad schema shouldn't sink the whole view
            continue

    # LATEST run per (pipeline, target, rule) for the "current state" rollup.
    latest: dict[tuple, dict] = {}
    for a in audit:  # audit is newest-first per location, but merge across → key on ts
        key = (a.get("pipeline_name"), a.get("target"), a.get("rule"))
        cur = latest.get(key)
        if cur is None or (a.get("run_ts") or "") > (cur.get("run_ts") or ""):
            latest[key] = a
    latest_rows = list(latest.values())

    total_checks = len(latest_rows)
    failing = [r for r in latest_rows if (r.get("failed_rows") or 0) > 0]
    total_failed_rows = sum(r.get("failed_rows") or 0 for r in latest_rows)
    total_rows = sum(r.get("total_rows") or 0 for r in latest_rows)
    quarantined_rows = sum(q.get("rows") or 0 for q in quarantine)
    # weighted overall pass-rate across the latest run of every rule
    overall_pass = (round((total_rows - total_failed_rows) / total_rows, 4) if total_rows else None)

    by_rule = sorted(latest_rows, key=lambda r: (r.get("pass_rate") if r.get("pass_rate") is not None else 1.0))
    by_target: dict[str, dict] = {}
    for r in latest_rows:
        t = r.get("target") or "—"
        b = by_target.setdefault(t, {"target": t, "checks": 0, "failing": 0, "failed_rows": 0, "total_rows": 0})
        b["checks"] += 1
        b["failing"] += 1 if (r.get("failed_rows") or 0) > 0 else 0
        b["failed_rows"] += r.get("failed_rows") or 0
        b["total_rows"] = max(b["total_rows"], r.get("total_rows") or 0)
    for q in quarantine:
        b = by_target.setdefault(q["target"], {"target": q["target"], "checks": 0, "failing": 0, "failed_rows": 0, "total_rows": 0})
        b["quarantined"] = q.get("rows") or 0

    # recent runs (distinct run_id, newest first) with an aggregate pass-rate
    runs: dict[str, dict] = {}
    for a in audit:
        rid = a.get("run_id")
        if not rid:
            continue
        b = runs.setdefault(rid, {"run_id": rid, "pipeline_name": a.get("pipeline_name"),
                                  "run_ts": a.get("run_ts"), "checks": 0, "failed_rows": 0, "total_rows": 0})
        b["checks"] += 1
        b["failed_rows"] += a.get("failed_rows") or 0
        b["total_rows"] = max(b["total_rows"], a.get("total_rows") or 0)
    recent_runs = sorted(runs.values(), key=lambda r: r.get("run_ts") or "", reverse=True)[:15]
    for r in recent_runs:
        r["pass_rate"] = (round((r["total_rows"] - r["failed_rows"]) / r["total_rows"], 4) if r["total_rows"] else None)

    return {
        "available": True,
        "locations": [f"{c}.{s}" for c, s in locations],
        "summary": {
            "checks": total_checks,
            "failing_checks": len(failing),
            "overall_pass_rate": overall_pass,
            "quarantined_rows": quarantined_rows,
            "audited_runs": len(runs),
        },
        "by_rule": by_rule[:50],
        "by_target": sorted(by_target.values(), key=lambda b: -(b.get("quarantined") or 0)),
        "quarantine": quarantine,
        "recent_runs": recent_runs,
    }


@router.get("/validations/{vid}")
def get_validation(vid: UUID) -> dict:
    v = repo_library.get_validation(db.pool, vid)
    if v is None:
        raise HTTPException(status_code=404, detail="validation not found")
    return v


class ValidationCreate(BaseModel):
    name: str
    code: str | None = None
    rule_type: str = "validity"
    dataset: str | None = None
    column_name: str | None = None
    severity: str = "medium"
    description: str | None = None
    logic: str | None = None
    tags: list[str] | None = None
    status: str | None = None  # Draft (default) | Published


@router.post("/validations")
def create_validation(body: ValidationCreate) -> dict:
    import uuid as _uuid

    data = body.model_dump()
    # Unique code when none given — name isn't unique across user-created rules.
    if not data.get("code"):
        base = (data["name"].upper().replace(" ", "_"))[:40] or "DQ_RULE"
        data["code"] = f"{base}_{_uuid.uuid4().hex[:6].upper()}"
    return repo_library.create_validation(db.pool, data, _user())


@router.post("/validations/{vid}/submit")
def submit_validation(vid: UUID) -> dict:
    """Draft → Proposed (Pending Approval)."""
    try:
        return repo_library.submit_validation(db.pool, vid, _user())
    except repo_library.ValidationGovernanceError as e:
        raise HTTPException(status_code=409, detail=str(e))


class ValidationDecision(BaseModel):
    decision: str  # approved | rejected
    rationale: str | None = None


@router.post("/validations/{vid}/decide")
def decide_validation(vid: UUID, body: ValidationDecision) -> dict:
    """Approve (→ Published) or reject (→ Rejected). Maker != checker, admins exempt."""
    checker = _user()
    try:
        return repo_library.decide_validation(
            db.pool, vid, decision=body.decision, checker=checker, rationale=body.rationale,
            is_admin=repo_admin.is_admin(db.pool, checker),
        )
    except repo_library.ValidationGovernanceError as e:
        raise HTTPException(status_code=409, detail=str(e))


class ExprValidate(BaseModel):
    expression: str


@router.post("/validations/validate-expression")
def validate_expression(body: ExprValidate) -> dict:
    """Deterministic boolean-expression check via sqlglot (Custom SQL / Expression Builder)."""
    try:
        ast = sqlglot.parse_one(body.expression, read="spark")
        cols = sorted({c.name for c in ast.find_all(sqlglot.exp.Column)})
        return {"valid": True, "normalized": ast.sql(dialect="spark"), "columns": cols}
    except Exception as e:  # noqa: BLE001
        return {"valid": False, "error": str(e)}


class ValidationGenerate(BaseModel):
    description: str
    rule_type: str = "validity"
    column_name: str = ""


@router.post("/validations/generate")
def generate_validation(body: ValidationGenerate) -> dict:
    try:
        return llm.generate_validation(body.description, body.rule_type, body.column_name)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"AI validation generation failed: {e}")


# --- per-check feedback loops (Designer detail panel) ------------------------

def _gate_dq_logic(logic: str, column: str | None) -> str:
    """Parse + sanity-check a DQ boolean predicate; return the normalized SQL or raise 422."""
    logic = (logic or "").strip()
    if not logic:
        raise HTTPException(status_code=422, detail="empty rule logic")
    try:
        ast = sqlglot.parse_one(logic, read="spark")
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=422, detail=f"rule logic does not parse: {e}")
    if list(ast.find_all(sqlglot.exp.Window)) or list(ast.find_all(sqlglot.exp.AggFunc)):
        raise HTTPException(status_code=422, detail="rule must be a row-level predicate (no window/aggregate)")
    return ast.sql(dialect="spark")


class ValidationRegen(BaseModel):
    feedback: str


@router.post("/validations/{vid}/regenerate")
def regenerate_validation(vid: UUID, body: ValidationRegen) -> dict:
    """Regenerate a saved check's logic from human feedback; replace in place."""
    if not (body.feedback or "").strip():
        raise HTTPException(status_code=422, detail="feedback is required")
    v = repo_library.get_validation(db.pool, vid)
    if v is None:
        raise HTTPException(status_code=404, detail="validation not found")
    try:
        out = llm.regenerate_validation(column=v.get("column_name") or "col", current_logic=v.get("logic"), feedback=body.feedback)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"AI regeneration failed: {e}")
    logic = _gate_dq_logic(out.get("logic", ""), v.get("column_name"))
    row = repo_library.update_validation_logic(db.pool, vid, logic=logic, description=out.get("rationale") or v.get("description"))
    return row or {}


class ValidationUseRule(BaseModel):
    code: str


@router.post("/validations/{vid}/use-rule")
def use_rule(vid: UUID, body: ValidationUseRule) -> dict:
    """Swap a saved check's logic to an existing PUBLISHED Rule Library rule (reuse)."""
    v = repo_library.get_validation(db.pool, vid)
    if v is None:
        raise HTTPException(status_code=404, detail="validation not found")
    r = repo_library.get_rule_by_code(db.pool, body.code)
    if r is None:
        raise HTTPException(status_code=404, detail="rule not found")
    logic = r.get("logic_sql") or r.get("logic_preview")
    if not logic:
        raise HTTPException(status_code=422, detail="that library rule has no logic to apply")
    logic = _gate_dq_logic(logic, v.get("column_name"))
    row = repo_library.update_validation_logic(
        db.pool, vid, logic=logic, name=f"{r['name']} — {v.get('dataset') or v.get('column_name') or ''}".strip(" —"),
        description=r.get("description"), reused_rule_id=str(r["id"]),
    )
    return row or {}
