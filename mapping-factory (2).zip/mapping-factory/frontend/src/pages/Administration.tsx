import { useEffect, useState } from "react";
import { ShieldCheck, UserPlus, Trash2, ShieldAlert, Loader2 } from "lucide-react";
import { usePage } from "../AppShell";
import { api, type AdminUser } from "../api";
import { Button, Card, Avatar } from "../components/primitives";
import { displayName } from "../theme";

export function Administration() {
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [me, setMe] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newUser, setNewUser] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  usePage({ title: "Administration", subtitle: "Manage administrator users and governance privileges" });

  const load = async () => {
    setLoading(true);
    try {
      const [meRes, listRes] = await Promise.all([api.adminMe(), api.listAdmins()]);
      setMe(meRes.user);
      setIsAdmin(meRes.is_admin);
      setAdmins(listRes.admins);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const add = async () => {
    setErr(null);
    const u = newUser.trim();
    if (!u) { setErr("Enter a user name (email or service-principal id)."); return; }
    setBusy(true);
    try {
      await api.addAdmin(u);
      setNewUser("");
      await load();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed to add admin.");
    } finally {
      setBusy(false);
    }
  };

  const remove = async (u: string) => {
    setErr(null);
    setBusy(true);
    try {
      await api.removeAdmin(u);
      await load();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed to remove admin.");
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return <div className="p-6 flex items-center gap-2 text-gray-500 text-sm"><Loader2 className="w-4 h-4 animate-spin" /> Loading administration…</div>;
  }

  return (
    <div className="p-6 space-y-4 max-w-4xl">
      {/* privilege explainer */}
      <div className="bg-white rounded-xl border border-gray-200 p-4 flex items-start gap-3">
        <span className="w-10 h-10 rounded-lg grid place-items-center bg-brand-soft text-brand shrink-0"><ShieldCheck className="w-5 h-5" /></span>
        <div>
          <h3 className="text-sm font-semibold text-gray-800">Administrator privileges</h3>
          <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">
            Administrators bypass maker-checker segregation of duties — they can approve their own mappings and
            transformations — and are the only users who can add or remove other administrators.
          </p>
        </div>
      </div>

      {!isAdmin && (
        <div className="flex items-center gap-2 text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
          <ShieldAlert className="w-4 h-4 shrink-0" /> You are not an administrator — this list is read-only. Ask an existing admin to add you.
        </div>
      )}

      <Card title="Administrators" action={<span className="text-xs text-gray-400">{admins.length} total</span>}>
        {isAdmin && (
          <div className="flex gap-2 mb-4">
            <input
              value={newUser}
              onChange={(e) => setNewUser(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") add(); }}
              className="inp flex-1"
              placeholder="user@databricks.com or service-principal id"
            />
            <Button onClick={add} disabled={busy}><UserPlus className="w-4 h-4" /> Add Admin</Button>
          </div>
        )}
        {err && <p className="text-xs text-red-600 mb-3">{err}</p>}

        <ul className="divide-y divide-gray-100">
          {admins.map((a) => {
            const isMe = a.user_name.toLowerCase() === me.toLowerCase();
            return (
              <li key={a.user_name} className="flex items-center justify-between py-2.5">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar name={displayName(a.user_name)} showName={false} />
                  <div className="min-w-0">
                    <div className="text-sm text-gray-800 truncate">
                      {a.user_name}
                      {isMe && <span className="ml-2 text-[10px] bg-brand-soft text-brand px-1.5 py-0.5 rounded">You</span>}
                    </div>
                    <div className="text-[11px] text-gray-400">
                      {a.added_by === "bootstrap" ? "Bootstrapped" : a.added_by ? `Added by ${displayName(a.added_by)}` : "—"}
                      {a.created_at ? ` · ${new Date(a.created_at).toLocaleDateString()}` : ""}
                    </div>
                  </div>
                </div>
                {isAdmin && (
                  <button
                    onClick={() => remove(a.user_name)}
                    disabled={busy}
                    title="Remove admin"
                    className="text-gray-400 hover:text-red-600 disabled:opacity-40 p-1.5"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </li>
            );
          })}
          {admins.length === 0 && <li className="py-6 text-center text-sm text-gray-400">No administrators yet.</li>}
        </ul>
      </Card>
    </div>
  );
}
