import type { ReactNode } from "react";
import { TrendingUp } from "lucide-react";
import { STATUS_STYLES, SEVERITY_STYLES, avatarColor, initials } from "../theme";

// --- Card: the white rounded container used everywhere -----------------------
export function Card({ title, action, children, className = "" }: { title?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`bg-white rounded-xl border border-gray-200 ${className}`}>
      {(title || action) && (
        <div className="flex items-center justify-between px-5 pt-4 pb-2">
          {title && <h3 className="text-sm font-semibold text-gray-800">{title}</h3>}
          {action}
        </div>
      )}
      <div className={title || action ? "px-5 pb-5" : "p-5"}>{children}</div>
    </section>
  );
}

// --- StatusBadge -------------------------------------------------------------
export function StatusBadge({ status }: { status: string }) {
  const cls = STATUS_STYLES[status] ?? "bg-gray-100 text-gray-600";
  return <span className={`inline-block text-xs font-medium px-2 py-0.5 rounded ${cls}`}>{status}</span>;
}

export function SeverityBadge({ severity }: { severity: string }) {
  const cls = SEVERITY_STYLES[severity?.toLowerCase()] ?? "bg-gray-100 text-gray-600";
  return <span className={`inline-block text-xs font-medium px-2 py-0.5 rounded capitalize ${cls}`}>{severity}</span>;
}

// --- ConfidenceBar -----------------------------------------------------------
export function ConfidenceBar({ value }: { value?: number | null }) {
  const pct = value == null ? 0 : value <= 1 ? value * 100 : value;
  const color = pct >= 90 ? "#16a34a" : pct >= 60 ? "#d97706" : "#dc2626";
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-700 w-9">{pct ? `${Math.round(pct)}%` : "—"}</span>
      <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden min-w-[48px]">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

// --- Avatar chip -------------------------------------------------------------
export function Avatar({ name, showName = true }: { name: string; showName?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span className="w-6 h-6 rounded-full grid place-items-center text-white text-[10px] font-medium shrink-0" style={{ background: avatarColor(name) }}>
        {initials(name)}
      </span>
      {showName && <span className="text-sm text-gray-700">{name}</span>}
    </span>
  );
}

// --- KpiCard -----------------------------------------------------------------
export function KpiCard({
  icon: Icon,
  label,
  value,
  delta,
  tint = "#fdecec",
  iconColor = "#c9252d",
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string | number;
  delta?: string;
  tint?: string;
  iconColor?: string;
}) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-4">
      <div className="flex items-start gap-3">
        <span className="w-10 h-10 rounded-lg grid place-items-center shrink-0" style={{ background: tint, color: iconColor }}>
          <Icon className="w-5 h-5" />
        </span>
        <div className="min-w-0">
          <div className="text-xs text-gray-500 truncate">{label}</div>
          <div className="text-2xl font-semibold text-gray-900 leading-tight">{value}</div>
        </div>
      </div>
      {delta && (
        <div className="flex items-center gap-1 mt-2 text-xs text-green-600">
          <TrendingUp className="w-3 h-3" />
          {delta}
        </div>
      )}
    </div>
  );
}

// --- Tabs (underline style) --------------------------------------------------
export function Tabs({ tabs, active, onChange }: { tabs: string[]; active: string; onChange: (t: string) => void }) {
  return (
    <div className="flex items-center gap-6 border-b border-gray-200">
      {tabs.map((t) => (
        <button
          key={t}
          onClick={() => onChange(t)}
          className={`relative pb-2 text-sm transition-colors ${
            active === t ? "text-brand font-medium" : "text-gray-500 hover:text-gray-700"
          }`}
        >
          {t}
          {active === t && <span className="absolute -bottom-px left-0 right-0 h-0.5 bg-brand rounded-full" />}
        </button>
      ))}
    </div>
  );
}

// --- Breadcrumbs -------------------------------------------------------------
export function Breadcrumbs({ items }: { items: { label: string; to?: string }[] }) {
  return (
    <nav className="flex items-center gap-2 text-sm text-gray-500">
      {items.map((it, i) => (
        <span key={i} className="flex items-center gap-2">
          {i > 0 && <span className="text-gray-300">/</span>}
          <span className={i === items.length - 1 ? "text-gray-800 font-medium" : ""}>{it.label}</span>
        </span>
      ))}
    </nav>
  );
}

// --- Primary / secondary buttons --------------------------------------------
export function Button({
  children,
  variant = "primary",
  onClick,
  disabled,
  className = "",
}: {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost";
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}) {
  const base = "inline-flex items-center gap-1.5 text-sm font-medium rounded-lg px-3.5 py-2 transition-colors disabled:opacity-40";
  const styles = {
    primary: "bg-brand text-white hover:bg-brand-hover",
    secondary: "bg-white border border-gray-300 text-gray-700 hover:bg-gray-50",
    ghost: "text-gray-600 hover:bg-gray-100",
  }[variant];
  return (
    <button onClick={onClick} disabled={disabled} className={`${base} ${styles} ${className}`}>
      {children}
    </button>
  );
}
