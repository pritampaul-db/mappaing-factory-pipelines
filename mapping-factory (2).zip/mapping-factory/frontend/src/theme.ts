// Shared design tokens + tiny formatting helpers used across all screens.

// Status → tailwind classes for StatusBadge (covers mapping, rule, run states).
export const STATUS_STYLES: Record<string, string> = {
  Published: "bg-green-100 text-green-700",
  Approved: "bg-green-100 text-green-700",
  Passed: "bg-green-100 text-green-700",
  Succeeded: "bg-green-100 text-green-700",
  Live: "bg-green-100 text-green-700",
  Draft: "bg-amber-100 text-amber-700",
  "Pending Approval": "bg-orange-100 text-orange-700",
  Proposed: "bg-orange-100 text-orange-700",
  "In Review": "bg-blue-100 text-blue-700",
  Review: "bg-blue-100 text-blue-700",
  "AI Suggested": "bg-purple-100 text-purple-700",
  Running: "bg-blue-100 text-blue-700",
  Warning: "bg-amber-100 text-amber-700",
  Failed: "bg-red-100 text-red-700",
  Rejected: "bg-red-100 text-red-700",
  Deprecated: "bg-gray-100 text-gray-500",
  Archived: "bg-gray-100 text-gray-500",
};

// Severity → classes (validation rules).
export const SEVERITY_STYLES: Record<string, string> = {
  critical: "bg-red-100 text-red-700",
  high: "bg-orange-100 text-orange-700",
  medium: "bg-amber-100 text-amber-700",
  low: "bg-gray-100 text-gray-600",
};

// Deterministic avatar color from a name (for user chips in tables).
const AVATAR_COLORS = ["#c9252d", "#2563eb", "#16a34a", "#a855f7", "#d97706", "#0891b2"];
export function avatarColor(name: string): string {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) & 0xffff;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}
export function initials(name: string): string {
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "")).toUpperCase() || "?";
}

// Turn a login identity (email/username) into a friendly display name:
// "pritam.paul@databricks.com" → "Pritam Paul". Falls back to "User".
export function displayName(identity?: string | null): string {
  const local = identity?.split("@")[0]?.trim();
  if (!local) return "User";
  return local.replace(/[._-]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

// Just the first name, for greetings ("Hi Pritam!").
export function firstName(identity?: string | null): string {
  return displayName(identity).split(/\s+/)[0] || "there";
}

export function confColorHex(c?: number | null): string {
  if (c == null) return "#9ca3af";
  if (c >= 0.9) return "#16a34a";
  if (c >= 0.6) return "#d97706";
  return "#dc2626";
}

export const chartPalette = ["#c9252d", "#16a34a", "#d97706", "#a855f7", "#2563eb", "#0891b2", "#9ca3af"];

// Compact number (2,340 → "2,340"; 1842 → "1,842").
export function fmtNum(n: number | null | undefined): string {
  if (n == null) return "—";
  return n.toLocaleString("en-US");
}

export function fmtPct(n: number | null | undefined, digits = 0): string {
  if (n == null) return "—";
  return `${(n * (n <= 1 ? 100 : 1)).toFixed(digits)}%`;
}

export function timeAgo(iso: string | null | undefined): string {
  if (!iso) return "—";
  const then = new Date(iso).getTime();
  const s = Math.max(0, Math.floor((Date.now() - then) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hour${h > 1 ? "s" : ""} ago`;
  const d = Math.floor(h / 24);
  return `${d} day${d > 1 ? "s" : ""} ago`;
}
