"""Contribute-back-on-publish: when a mapping is approved, add the NEW transformations
and NEW validation rules it introduced into the reusable libraries (as Published), so
the next Suggest/Validate can reuse them (the propose→dispose→learn loop).

Reuse-first already runs at suggest/validate time (the model prefers an existing
library item by code). This module closes the loop for the items that were genuinely
NEW: it registers them as Published library entries, deduped by logic so re-approving
the same spec — or two specs sharing a transform — never creates duplicates.

Best-effort and idempotent: a failure here must never fail the approval.
"""
from __future__ import annotations

import json
import re
from typing import Any

from psycopg_pool import ConnectionPool

from server import repo_library


def _norm_logic(s: str | None) -> str:
    """Whitespace/case-insensitive key for dedup by logic."""
    return re.sub(r"\s+", " ", (s or "").strip()).lower()


def _transform_logic(m: dict[str, Any]) -> str:
    """Best-effort SQL-ish text for a mapping's transform (dedup key + library logic)."""
    if m.get("transform_sql"):
        return str(m["transform_sql"])
    spec = m.get("transform_spec")
    if isinstance(spec, str):
        try:
            spec = json.loads(spec)
        except Exception:  # noqa: BLE001
            return spec
    if isinstance(spec, dict):
        if spec.get("expr"):
            return str(spec["expr"])
        return json.dumps(spec, sort_keys=True)
    return ""


def contribute_from_snapshot(pool: ConnectionPool, snapshot: dict[str, Any], *, actor: str) -> dict[str, int]:
    """Register NEW transformations from an approved snapshot into the transformation
    library (Published). Returns {transformations: n}. Deduped by normalized logic
    against the existing published catalog."""
    added_x = 0
    try:
        existing = {_norm_logic(c.get("logic")): c for c in repo_library.published_transformation_catalog(pool)}
    except Exception:  # noqa: BLE001
        existing = {}

    seen: set[str] = set()
    for m in snapshot.get("mappings", []):
        prov = m.get("provenance")
        if isinstance(prov, str):
            try:
                prov = json.loads(prov)
            except Exception:  # noqa: BLE001
                prov = {}
        prov = prov or {}
        # Only contribute genuinely-new transforms (not ones that reused a library item).
        if prov.get("reused_transformation_id"):
            continue
        if prov.get("is_new_transformation") is False:
            continue
        logic = _transform_logic(m)
        key = _norm_logic(logic)
        if not key or key in existing or key in seen:
            continue
        seen.add(key)
        tf = m.get("target_field") or "field"
        name = f"{tf} transform"
        try:
            created = repo_library.create_transformation(
                pool,
                {
                    "name": name,
                    "ttype": "ai_assisted",
                    "category": "mapping",
                    "description": (prov.get("rationale") or f"Contributed from mapping {snapshot.get('name')}.")[:400],
                    "logic_expr": logic,
                    "logic_sql": logic,
                    "status": "Published",  # parent mapping was already approved → auto-published
                    "tags": ["contributed", f"spec:{snapshot.get('spec_id')}"],
                },
                actor or "System",
            )
            existing[key] = created  # so a second mapping with the same logic reuses (dedup)
            added_x += 1
            # Back-link the originating field_mapping to the new library item so the
            # library's "used by N" count reflects this mapping (is_new → now reuses it).
            mid = m.get("mapping_id")
            if mid and created and created.get("id"):
                _link_transform_usage(pool, mid, str(created["id"]), created.get("code"), name)
        except Exception:  # noqa: BLE001 — one bad row shouldn't abort the batch
            continue
    return {"transformations": added_x}


def _link_transform_usage(pool: ConnectionPool, mapping_id: str, transform_id: str, code, name) -> None:
    """Stamp the originating field_mapping's provenance with the contributed transform id,
    so transformation_usage() (which counts provenance.reused_transformation_id) includes it."""
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """UPDATE mapping_factory.field_mapping
                       SET provenance = provenance
                           || jsonb_build_object(
                                'reused_transformation_id', %s::text,
                                'reused_transformation_code', %s::text,
                                'reused_transformation_name', %s::text,
                                'is_new_transformation', false,
                                'contributed_to_library', true)
                       WHERE id = %s""",
                    (transform_id, code, name, mapping_id),
                )
            conn.commit()
    except Exception:  # noqa: BLE001
        pass


def contribute_validations(pool: ConnectionPool, spec_id: str, spec_name: str, *, actor: str) -> dict[str, int]:
    """Register NEW validation rules (applied to this spec, tagged 'new-rule') into the
    Rule Library (Published, dataset-agnostic). Deduped by normalized logic. Returns
    {rules: n}."""
    added_r = 0
    spec_tag = f"spec:{spec_id}"
    try:
        applied = [v for v in repo_library.list_validations(pool) if spec_tag in (v.get("tags") or [])]
    except Exception:  # noqa: BLE001
        return {"rules": 0}
    try:
        existing = {_norm_logic(c.get("logic")): c for c in repo_library.published_rule_catalog(pool)}
    except Exception:  # noqa: BLE001
        existing = {}

    seen: set[str] = set()
    for v in applied:
        tags = v.get("tags") or []
        # Only NEW rules (the apply step tagged reused ones as rule:<id>).
        if "new-rule" not in tags:
            continue
        logic = v.get("logic")
        key = _norm_logic(logic)
        if not key or key in existing or key in seen:
            continue
        seen.add(key)
        try:
            created = repo_library.create_rule(
                pool,
                {
                    "name": (v.get("name") or "Contributed rule").split(" — ")[0],
                    "rule_type": "validation",
                    "domain": v.get("dataset") or "General",
                    "data_type": "String",
                    "description": (v.get("description") or f"Contributed from mapping {spec_name}.")[:400],
                    "logic_sql": logic,
                    "logic_preview": logic,
                    "status": "Published",
                    "tags": ["contributed", spec_tag],
                },
                actor or "System",
            )
            existing[key] = created
            added_r += 1
            # Re-tag the originating applied validation from 'new-rule' → 'rule:<newid>'
            # so rule_usage() (which counts the rule:<id> tag) reflects this application.
            if created and created.get("id") and v.get("id"):
                _retag_validation(pool, str(v["id"]), str(created["id"]))
        except Exception:  # noqa: BLE001
            continue
    return {"rules": added_r}


def _retag_validation(pool: ConnectionPool, validation_id: str, rule_id: str) -> None:
    """Swap the 'new-rule' tag on an applied validation for 'rule:<id>' pointing at the
    contributed Rule Library rule, so the library's 'used by N datasets' count includes it."""
    try:
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """UPDATE mapping_factory.validation_rule
                       SET tags = array_append(array_remove(tags, 'new-rule'), %s)
                       WHERE id = %s AND NOT (%s = ANY(tags))""",
                    (f"rule:{rule_id}", validation_id, f"rule:{rule_id}"),
                )
            conn.commit()
    except Exception:  # noqa: BLE001
        pass
