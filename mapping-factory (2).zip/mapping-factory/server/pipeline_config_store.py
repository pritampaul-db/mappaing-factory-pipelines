"""Pipeline config lives in a Unity Catalog table, not inlined in the generated code.

The generated `src/mapping_pipeline.py` is generic and identical for every mapping; it
reads its config at runtime from `mf_pipeline_config` (keyed by `config_key`, newest row
wins, or pinned by `run_id`). This module writes those rows as the app service principal.

Also owns `mf_dq_audit` — the append-only quality-metrics table the app rolls up after a
run from each target's `<target>_dq` table (one row per rule per run).
"""
from __future__ import annotations

import base64
import json
import time
import uuid
from typing import Any

from server import config

CONFIG_TABLE_NAME = "mf_pipeline_config"
AUDIT_TABLE_NAME = "mf_dq_audit"


def config_table(catalog: str, schema: str) -> str:
    return f"{catalog}.{schema}.{CONFIG_TABLE_NAME}"


def audit_table(catalog: str, schema: str) -> str:
    return f"{catalog}.{schema}.{AUDIT_TABLE_NAME}"


def config_key_for(pipeline_name: str) -> str:
    return pipeline_name


def _sql(w, stmt: str) -> list[list[Any]]:
    from databricks.sdk.service.sql import StatementState

    resp = w.statement_execution.execute_statement(
        warehouse_id=config.WAREHOUSE_ID, statement=stmt, wait_timeout="50s")
    state = resp.status.state if resp.status else None
    while state in (StatementState.PENDING, StatementState.RUNNING):
        time.sleep(2)
        resp = w.statement_execution.get_statement(resp.statement_id)
        state = resp.status.state if resp.status else None
    if state != StatementState.SUCCEEDED:
        msg = resp.status.error.message if resp.status and resp.status.error else ""
        raise RuntimeError(f"config-store SQL failed ({state}): {msg}\n---\n{stmt[:200]}")
    if resp.result and resp.result.data_array:
        return resp.result.data_array
    return []


def ensure_tables(catalog: str, schema: str, *, w=None) -> None:
    """Idempotently create the config + audit tables in the TARGET catalog/schema."""
    w = w or config.get_sp_client()
    _sql(w, f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
    _sql(w, f"""CREATE TABLE IF NOT EXISTS {config_table(catalog, schema)} (
                  config_key STRING, run_id STRING, pipeline_name STRING,
                  config_json STRING, created_at TIMESTAMP)""")
    _sql(w, f"""CREATE TABLE IF NOT EXISTS {audit_table(catalog, schema)} (
                  run_ts TIMESTAMP, run_id STRING, pipeline_name STRING, target STRING,
                  rule STRING, column_name STRING, severity STRING, action STRING,
                  failed_rows BIGINT, total_rows BIGINT, pass_rate DOUBLE)""")


def write_config(full_config: dict, *, catalog: str, schema: str, pipeline_name: str,
                 run_id: str | None = None, w=None) -> dict[str, str]:
    """Insert one config row (base64 JSON) for this pipeline. Returns {config_key, run_id}.

    base64 so the transform SQL's quotes/backslashes survive the SQL-literal round-trip."""
    w = w or config.get_sp_client()
    ensure_tables(catalog, schema, w=w)
    key = config_key_for(pipeline_name)
    rid = run_id or uuid.uuid4().hex[:12]
    encoded = base64.b64encode(json.dumps(full_config).encode()).decode()
    _sql(w, f"""INSERT INTO {config_table(catalog, schema)}
                  (config_key, run_id, pipeline_name, config_json, created_at)
                VALUES ('{_esc(key)}', '{_esc(rid)}', '{_esc(pipeline_name)}',
                        '{encoded}', current_timestamp())""")
    return {"config_key": key, "run_id": rid}


def rollup_audit(full_config: dict, *, catalog: str, schema: str, pipeline_name: str,
                 run_id: str, w=None) -> dict[str, Any]:
    """After a run, read each target's `<target>_dq` table and APPEND one audit row per
    (rule, run) to mf_dq_audit — failed_rows, total_rows, pass_rate. Best-effort per rule."""
    import re

    w = w or config.get_sp_client()
    ensure_tables(catalog, schema, w=w)
    written = 0
    for tgt in full_config.get("targets", []):
        target = tgt["target_name"]
        dq_fqn = f"{catalog}.{schema}.{target}_dq"
        try:
            total = int(_sql(w, f"SELECT count(*) FROM {dq_fqn}")[0][0])
        except Exception:  # noqa: BLE001 — dq table may not exist if the run failed early
            continue
        for v in tgt.get("validations", []):
            rule = v.get("name")
            if not rule:
                continue
            safe = "r_" + re.sub(r"[^0-9A-Za-z]+", "_", str(rule)).strip("_")
            action = "fail" if (v.get("action") or "warn").lower() == "fail" else "warn"
            sev = v.get("severity") or ""
            col = v.get("column") or ""
            try:
                failed = int(_sql(w, f"SELECT count(*) FROM {dq_fqn} WHERE NOT `_rule_{safe}`")[0][0])
            except Exception:  # noqa: BLE001 — rule column absent (rule was skipped as unparseable)
                continue
            pass_rate = 0.0 if total == 0 else round((total - failed) / total, 6)
            _sql(w, f"""INSERT INTO {audit_table(catalog, schema)}
                          (run_ts, run_id, pipeline_name, target, rule, column_name,
                           severity, action, failed_rows, total_rows, pass_rate)
                        VALUES (current_timestamp(), '{_esc(run_id)}', '{_esc(pipeline_name)}',
                                '{_esc(target)}', '{_esc(rule)}', '{_esc(col)}',
                                '{_esc(sev)}', '{action}', {failed}, {total}, {pass_rate})""")
            written += 1
    return {"audit_rows_written": written, "audit_table": audit_table(catalog, schema)}


def _esc(s: str) -> str:
    return str(s).replace("'", "''")


def _table_exists(w, fqn: str) -> bool:
    from databricks.sdk.service.sql import StatementState

    cat, sch, tbl = fqn.split(".")
    try:
        resp = w.statement_execution.execute_statement(
            warehouse_id=config.WAREHOUSE_ID, wait_timeout="30s",
            statement=f"SELECT 1 FROM {cat}.information_schema.tables "
                      f"WHERE table_schema='{_esc(sch)}' AND table_name='{_esc(tbl)}' LIMIT 1")
        return bool(resp.status and resp.status.state == StatementState.SUCCEEDED
                    and resp.result and resp.result.data_array)
    except Exception:  # noqa: BLE001
        return False


def discover_locations(w=None) -> list[tuple[str, str]]:
    """Discover (catalog, schema) pairs that hold an mf_dq_audit table, so the Data
    Quality screen shows metrics regardless of which schema a pipeline deployed to.
    Always includes the default UC catalog/schema. Scans information_schema per catalog."""
    from databricks.sdk.service.sql import StatementState

    w = w or config.get_sp_client()
    found: set[tuple[str, str]] = {(config.UC_CATALOG, config.UC_SCHEMA)}
    try:
        cats = _sql(w, "SELECT catalog_name FROM system.information_schema.catalogs")
        # 'system' + 'samples' are platform catalogs, not user data — skip them.
        catalogs = [c[0] for c in cats if c[0] not in ("system", "samples", "__databricks_internal")]
    except Exception:  # noqa: BLE001 — fall back to the default catalog only
        catalogs = [config.UC_CATALOG]
    for cat in catalogs:
        try:
            resp = w.statement_execution.execute_statement(
                warehouse_id=config.WAREHOUSE_ID, wait_timeout="30s",
                statement=f"SELECT table_schema FROM {cat}.information_schema.tables "
                          f"WHERE table_name='{AUDIT_TABLE_NAME}'")
            if resp.status and resp.status.state == StatementState.SUCCEEDED and resp.result and resp.result.data_array:
                for row in resp.result.data_array:
                    found.add((cat, row[0]))
        except Exception:  # noqa: BLE001 — no access to this catalog's info schema; skip
            continue
    return sorted(found)


def read_audit(*, catalog: str, schema: str, w=None, limit: int = 2000) -> list[dict[str, Any]]:
    """Return recent mf_dq_audit rows for one catalog.schema (newest first), or [] if the
    table doesn't exist there yet. Powers the Data Quality screen's pipeline metrics."""
    w = w or config.get_sp_client()
    fqn = audit_table(catalog, schema)
    if not _table_exists(w, fqn):
        return []
    rows = _sql(w, f"""SELECT run_ts, run_id, pipeline_name, target, rule, column_name,
                              severity, action, failed_rows, total_rows, pass_rate
                       FROM {fqn} ORDER BY run_ts DESC LIMIT {int(limit)}""")
    out = []
    for r in rows:
        out.append({
            "run_ts": str(r[0]) if r[0] is not None else None, "run_id": r[1],
            "pipeline_name": r[2], "target": r[3], "rule": r[4], "column_name": r[5],
            "severity": r[6], "action": r[7],
            "failed_rows": int(r[8]) if r[8] is not None else None,
            "total_rows": int(r[9]) if r[9] is not None else None,
            "pass_rate": float(r[10]) if r[10] is not None else None,
        })
    return out


def read_quarantine_counts(*, catalog: str, schema: str, w=None) -> list[dict[str, Any]]:
    """Row count of each *_quarantine table in one catalog.schema (best-effort)."""
    from databricks.sdk.service.sql import StatementState

    w = w or config.get_sp_client()
    out: list[dict[str, Any]] = []
    try:
        resp = w.statement_execution.execute_statement(
            warehouse_id=config.WAREHOUSE_ID, wait_timeout="30s",
            statement=f"SELECT table_name FROM {catalog}.information_schema.tables "
                      f"WHERE table_schema='{_esc(schema)}' AND table_name LIKE '%_quarantine'")
        if not (resp.status and resp.status.state == StatementState.SUCCEEDED and resp.result and resp.result.data_array):
            return out
        # Skip SDP's internal materialization tables (__materialization_..._quarantine_N).
        names = [row[0] for row in resp.result.data_array
                 if not row[0].startswith("__materialization") and row[0].endswith("_quarantine")]
    except Exception:  # noqa: BLE001
        return out
    for name in names:
        try:
            cnt = _sql(w, f"SELECT count(*) FROM {catalog}.{schema}.{name}")[0][0]
            out.append({"target": name[: -len("_quarantine")], "table": f"{catalog}.{schema}.{name}",
                        "rows": int(cnt)})
        except Exception:  # noqa: BLE001
            continue
    return out
