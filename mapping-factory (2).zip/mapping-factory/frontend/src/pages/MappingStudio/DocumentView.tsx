import { useState } from "react";
import { X, Copy, Check, Printer, BookOpen, RefreshCw, FileText } from "lucide-react";
import { useStore } from "../../store";
import { Button } from "../../components/primitives";
import { SEVERITY_STYLES } from "../../theme";

// Full-screen view of the generated mapping-specification document.
// Facts are deterministic (assembled server-side); the summary/column
// descriptions/open-items are the AI prose layer. Actions: Copy (markdown),
// Download PDF (a real server-generated .pdf file), Publish to the Knowledge
// Assistant, Regenerate, Close.
export function DocumentView() {
  const { doc, busy, docPublished, generateDoc, publishDoc, downloadDocPdf, clearDoc } = useStore();
  const [copied, setCopied] = useState(false);
  if (!doc) return null;

  const h = doc.header;
  const publishing = busy === "Publishing to Knowledge Assistant…";
  const regenerating = busy === "Generating documentation…";
  const downloading = busy === "Preparing PDF…";

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(doc.markdown);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard may be blocked; ignore */
    }
  };

  const pct = (c?: number | null) => (c == null ? "—" : `${Math.round((c <= 1 ? c * 100 : c))}%`);

  return (
    <div className="fixed inset-0 z-50 bg-black/30 flex items-start justify-center overflow-y-auto">
      <div id="doc-print" className="bg-white w-full max-w-4xl my-6 rounded-xl shadow-xl">
        {/* Toolbar (hidden when printing) */}
        <div className="doc-no-print sticky top-0 z-10 bg-white/95 backdrop-blur border-b border-gray-200 rounded-t-xl px-6 py-3 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-brand" />
          <span className="text-sm font-semibold text-gray-800">Mapping Documentation</span>
          <div className="ml-auto flex items-center gap-2">
            <Button variant="secondary" onClick={() => generateDoc()} disabled={!!busy}>
              <RefreshCw className={`w-3.5 h-3.5 ${regenerating ? "animate-spin" : ""}`} /> Regenerate
            </Button>
            <Button variant="secondary" onClick={copy} disabled={!!busy}>
              {copied ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />} {copied ? "Copied" : "Copy"}
            </Button>
            <Button variant="secondary" onClick={() => downloadDocPdf()} disabled={!!busy}>
              <Printer className="w-3.5 h-3.5" /> {downloading ? "Preparing…" : "Download PDF"}
            </Button>
            <Button onClick={() => publishDoc()} disabled={!!busy}>
              {docPublished ? <Check className="w-3.5 h-3.5" /> : <BookOpen className="w-3.5 h-3.5" />}
              {publishing ? "Publishing…" : docPublished ? "Published" : "Publish to KA"}
            </Button>
            <button onClick={clearDoc} className="p-1.5 text-gray-400 hover:text-gray-700"><X className="w-4 h-4" /></button>
          </div>
        </div>

        {/* Document body */}
        <article className="px-8 py-6 text-gray-800">
          {/* Title block */}
          <div className="flex items-start gap-3 mb-1">
            <FileText className="w-6 h-6 text-brand mt-0.5 shrink-0" />
            <div>
              <h1 className="text-2xl font-semibold text-gray-900 leading-tight">Mapping Specification</h1>
              <div className="text-sm text-gray-500">{h.name}</div>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-1 text-xs text-gray-600 mt-3 mb-6 border-y border-gray-100 py-3">
            <Meta k="Source" v={`${h.source ?? "—"}${h.source_system ? ` · ${h.source_system}` : ""}`} />
            <Meta k="Target" v={`${h.target ?? "—"}${h.target_system ? ` · ${h.target_system}` : ""}`} />
            <Meta k="Owner" v={h.owner} />
            <Meta k="Version" v={`v${h.version ?? 1} · ${h.status}`} />
          </div>

          <Section n={1} title="Executive summary">
            <p className="text-sm leading-relaxed text-gray-700">{doc.summary || <span className="text-gray-400">No summary generated.</span>}</p>
          </Section>

          {(() => {
            // One section per target table; single-table docs fall back to the flat `columns`.
            const tables = doc.tables && doc.tables.length
              ? doc.tables
              : [{ target_table: h.target ?? "Target", columns: doc.columns, generated_sql: doc.generated_sql, coverage: doc.coverage, lineage: doc.lineage }];
            let n = 2;
            const joinsSection = doc.joins && doc.joins.length ? (
              <Section key="joins" n={n++} title="Source table joins">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-left text-gray-500 border-b border-gray-200">
                        <th className="py-1.5 pr-3 font-medium">Left</th>
                        <th className="py-1.5 pr-3 font-medium">Right</th>
                        <th className="py-1.5 pr-3 font-medium text-right">Conf.</th>
                        <th className="py-1.5 pr-3 font-medium">Rationale</th>
                      </tr>
                    </thead>
                    <tbody>
                      {doc.joins.map((j, i) => (
                        <tr key={i} className="border-b border-gray-100 align-top">
                          <td className="py-1.5 pr-3 font-mono text-gray-800">{j.left}</td>
                          <td className="py-1.5 pr-3 font-mono text-gray-800">{j.right}</td>
                          <td className="py-1.5 pr-3 text-right text-gray-600">{pct(j.confidence)}</td>
                          <td className="py-1.5 pr-3 text-gray-600">{j.rationale || "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Section>
            ) : null;
            const multi = tables.length > 1;
            return (
              <>
                {joinsSection}
                {tables.map((t) => (
                  <Section key={t.target_table} n={n++} title={multi ? `Target table — ${t.target_table}` : "Source → Target mapping"}>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="text-left text-gray-500 border-b border-gray-200">
                            <th className="py-1.5 pr-3 font-medium">Target</th>
                            <th className="py-1.5 pr-3 font-medium">Type</th>
                            <th className="py-1.5 pr-3 font-medium">Source field(s)</th>
                            <th className="py-1.5 pr-3 font-medium">Transformation</th>
                            <th className="py-1.5 pr-3 font-medium text-right">Conf.</th>
                            <th className="py-1.5 pr-3 font-medium">Origin</th>
                          </tr>
                        </thead>
                        <tbody>
                          {t.columns.map((c) => (
                            <tr key={c.target_field} className="border-b border-gray-100 align-top">
                              <td className="py-1.5 pr-3 font-mono text-gray-800">{c.target_field}</td>
                              <td className="py-1.5 pr-3 text-gray-500">{c.target_type}</td>
                              <td className="py-1.5 pr-3 text-gray-600">{c.source_fields.join(", ") || "—"}</td>
                              <td className="py-1.5 pr-3 font-mono text-[11px] text-gray-700 break-all max-w-[280px]">{c.sql || "—"}</td>
                              <td className="py-1.5 pr-3 text-right text-gray-600">{pct(c.confidence)}</td>
                              <td className="py-1.5 pr-3 text-gray-500">{c.origin || "—"}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Column descriptions */}
                    <div className="text-xs font-semibold text-gray-700 mt-3 mb-1">Column descriptions</div>
                    <ul className="space-y-1 text-sm">
                      {t.columns.map((c) => (
                        <li key={c.target_field} className="text-gray-700">
                          <span className="font-mono text-xs text-gray-900">{c.target_field}</span>
                          {" — "}
                          {c.description || <span className="text-gray-400">no description</span>}
                        </li>
                      ))}
                    </ul>

                    {/* Data-quality rules for this table */}
                    <div className="text-xs font-semibold text-gray-700 mt-3 mb-1">Data-quality rules</div>
                    {t.columns.some((c) => c.validations.length) ? (
                      <ul className="space-y-1.5 text-xs">
                        {t.columns.flatMap((c) =>
                          c.validations.map((v, i) => (
                            <li key={`${c.target_field}-${i}`} className="flex items-start gap-2">
                              <span className="font-mono text-gray-900 shrink-0">{c.target_field}</span>
                              <span className={`px-1.5 py-0.5 rounded capitalize shrink-0 ${SEVERITY_STYLES[v.severity] ?? "bg-gray-100 text-gray-600"}`}>{v.rule_type.replace("_", " ")}</span>
                              <span className="font-mono text-[11px] text-gray-600 break-all">{v.logic}</span>
                            </li>
                          )),
                        )}
                      </ul>
                    ) : (
                      <p className="text-sm text-gray-400">No data-quality rules defined yet — use “Validate mapping”.</p>
                    )}

                    {t.generated_sql && (
                      <>
                        <div className="text-xs font-semibold text-gray-700 mt-3 mb-1">Generated Spark SQL</div>
                        <pre className="bg-gray-50 border border-gray-100 rounded-lg p-3 text-[11px] font-mono text-gray-800 overflow-x-auto whitespace-pre-wrap">{t.generated_sql}</pre>
                      </>
                    )}
                  </Section>
                ))}
              </>
            );
          })()}

          <Section n={99} title="Coverage & open items">
            <div className="flex flex-wrap gap-4 text-xs mb-2">
              <Stat label="Target columns" v={doc.coverage.target_columns} />
              <Stat label="Mapped" v={doc.coverage.mapped} />
              <Stat label="Validated" v={doc.coverage.validated_columns} />
            </div>
            <ul className="text-xs text-gray-600 space-y-1 list-disc pl-4">
              {doc.coverage.unmapped.length > 0 && <li>Unmapped: {doc.coverage.unmapped.join(", ")}</li>}
              {doc.coverage.low_confidence.length > 0 && <li>Low-confidence: {doc.coverage.low_confidence.join(", ")}</li>}
              {doc.coverage.without_validation.length > 0 && <li>No data-quality check: {doc.coverage.without_validation.join(", ")}</li>}
              {doc.open_items.map((oi, i) => <li key={i}>{oi}</li>)}
              {doc.coverage.unmapped.length === 0 && doc.coverage.low_confidence.length === 0 && doc.coverage.without_validation.length === 0 && doc.open_items.length === 0 && (
                <li className="list-none text-gray-400">No open items — the mapping looks complete.</li>
              )}
            </ul>
          </Section>

          <Section n={100} title="Governance & approvals">
            {doc.governance.approvals.length > 0 ? (
              <ul className="text-xs text-gray-600 space-y-1">
                {doc.governance.approvals.map((a, i) => (
                  <li key={i}>Maker <b>{a.maker}</b> · Checker <b>{a.checker ?? "—"}</b> · {a.decision ?? "pending"}</li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-400">Not yet submitted for approval.</p>
            )}
            {Object.keys(doc.governance.feedback).length > 0 && (
              <p className="text-xs text-gray-500 mt-1">Feedback events: {Object.entries(doc.governance.feedback).map(([k, v]) => `${k}=${v}`).join(", ")}</p>
            )}
          </Section>

          <div className="text-[10px] text-gray-400 mt-6 pt-3 border-t border-gray-100">
            Generated by Mapping Factory · {new Date(doc.generated_at).toLocaleString()} · Facts are deterministic; summary and descriptions are AI-generated — review before distribution.
          </div>
        </article>
      </div>
    </div>
  );
}

function Section({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <section className="mb-6">
      <h2 className="text-sm font-semibold text-gray-900 mb-2">{n > 0 && n < 90 ? `${n}. ` : ""}{title}</h2>
      {children}
    </section>
  );
}
function Meta({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wide text-gray-400">{k}</div>
      <div className="text-gray-700">{v}</div>
    </div>
  );
}
function Stat({ label, v }: { label: string; v: number }) {
  return (
    <div className="text-center">
      <div className="text-lg font-semibold text-gray-900">{v}</div>
      <div className="text-[10px] text-gray-500">{label}</div>
    </div>
  );
}
