"""Metadata Explorer — catalog summary, assets, glossary, systems, graph."""
from __future__ import annotations

from fastapi import APIRouter
from psycopg.rows import dict_row

from server import db

router = APIRouter(tags=["metadata"])

# Domain → color for the Business Domain donut (stable across renders).
_DOMAIN_COLORS = {
    "Customer Management": "#c9252d",
    "Finance": "#d97706",
    "Risk & Compliance": "#a855f7",
    "Reference Data": "#16a34a",
    "Operations": "#2563eb",
}


# All four endpoints show ONLY real, published-mapping metadata — the rows the
# publish-time indexer wrote (they carry a spec_id). Seeded demo rows (spec_id
# NULL) are excluded. Counts are actual COUNTs (no synthesized deltas/estimates).
_PUBLISHED = "spec_id IS NOT NULL"


@router.get("/metadata/summary")
def summary() -> dict:
    with db.pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SET search_path TO mapping_factory, public")

            def n(sql: str) -> int:
                cur.execute(sql)
                r = cur.fetchone()
                return list(r.values())[0] if r else 0

            assets = n(f"SELECT COUNT(*) FROM data_asset WHERE {_PUBLISHED}")
            tables = n(f"SELECT COUNT(*) FROM data_asset WHERE {_PUBLISHED} AND asset_type='table'")
            columns = n(f"SELECT COUNT(*) FROM data_asset WHERE {_PUBLISHED} AND asset_type='column'")
            mappings = n(f"SELECT COUNT(*) FROM data_asset WHERE {_PUBLISHED} AND asset_type='data_product'")
            # Glossary terms tied to a published mapping's target table (by name).
            terms = n(
                f"SELECT COUNT(*) FROM glossary_term g WHERE EXISTS "
                f"(SELECT 1 FROM data_asset d WHERE d.{_PUBLISHED} AND d.asset_type='table' AND d.name = g.name)"
            )

            # Business domain breakdown (published assets only).
            cur.execute(f"SELECT domain, COUNT(*) AS c FROM data_asset WHERE {_PUBLISHED} GROUP BY domain ORDER BY c DESC")
            domains = [{"name": r["domain"] or "Others", "value": r["c"], "color": _DOMAIN_COLORS.get(r["domain"] or "", "#9ca3af")} for r in cur.fetchall()]

            # Source systems computed from the real published assets (not the seeded
            # source_system table), so counts reflect only what's actually indexed.
            cur.execute(
                f"SELECT system AS code, COUNT(*) AS c FROM data_asset "
                f"WHERE {_PUBLISHED} AND system IS NOT NULL GROUP BY system ORDER BY c DESC"
            )
            systems = [{"code": r["code"], "name": r["code"], "assets": r["c"]} for r in cur.fetchall()]

    # KPI tiles — all real counts, no synthesized deltas.
    return {
        "kpis": [
            {"label": "Data Assets", "value": assets},
            {"label": "Mappings", "value": mappings},
            {"label": "Tables", "value": tables},
            {"label": "Columns", "value": columns},
            {"label": "Business Terms", "value": terms},
            {"label": "Source Systems", "value": len(systems)},
        ],
        "domains": domains,
        "systems": systems,
    }


@router.get("/metadata/assets")
def assets() -> list[dict]:
    with db.pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                f"""SELECT name, asset_type, system, domain, criticality, owner, updated_at
                   FROM mapping_factory.data_asset WHERE {_PUBLISHED} ORDER BY updated_at DESC"""
            )
            return [
                {
                    "name": r["name"], "asset_type": r["asset_type"], "system": r["system"],
                    "domain": r["domain"], "criticality": r["criticality"], "owner": r["owner"],
                    "updated_at": r["updated_at"].isoformat() if r["updated_at"] else None,
                }
                for r in cur.fetchall()
            ]


@router.get("/metadata/glossary")
def glossary() -> list[dict]:
    """Only glossary terms produced by a published mapping (match a published
    target-table asset by name) — seeded terms are excluded."""
    with db.pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                f"""SELECT g.name, g.definition, g.term_type, g.domain, g.steward
                   FROM mapping_factory.glossary_term g
                   WHERE EXISTS (SELECT 1 FROM mapping_factory.data_asset d
                                 WHERE d.{_PUBLISHED} AND d.name = g.name)
                   ORDER BY g.name"""
            )
            return cur.fetchall()


@router.get("/metadata/graph")
def graph() -> dict:
    """Nodes + edges for the relationship graph — ONLY published-mapping edges, and
    LIMITED TO TABLES + mappings (column nodes/edges excluded so the graph stays
    readable). Source → mapping → target, plus source↔source joins."""
    with db.pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute(
                f"""SELECT src_name, src_type, dst_name, dst_type, edge_type
                   FROM mapping_factory.metadata_edge
                   WHERE {_PUBLISHED} AND src_type <> 'column' AND dst_type <> 'column'"""
            )
            edges = cur.fetchall()

    nodes: dict[str, str] = {}
    for e in edges:
        nodes[e["src_name"]] = e["src_type"]
        nodes[e["dst_name"]] = e["dst_type"]
    return {
        "nodes": [{"name": name, "type": ntype} for name, ntype in nodes.items()],
        "edges": [{"source": e["src_name"], "target": e["dst_name"], "type": e["edge_type"]} for e in edges],
    }
