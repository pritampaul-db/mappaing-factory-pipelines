"""Symmetric encryption for at-rest secrets (git PATs for Deploy-as-Pipeline).

Fernet (AES-128-CBC + HMAC). The key comes from the `MF_CRED_KEY` env var — a
url-safe base64 32-byte Fernet key. If it's unset we derive a STABLE key from the
workspace host + a fixed salt so the feature still works in dev/demo, but that is
weaker (anyone who can read the host can derive it) — set MF_CRED_KEY in the
deployed app for real isolation.
"""
from __future__ import annotations

import base64
import functools
import hashlib
import os

from cryptography.fernet import Fernet, InvalidToken


@functools.lru_cache(maxsize=1)
def _fernet() -> Fernet:
    key = os.environ.get("MF_CRED_KEY")
    if key:
        return Fernet(key.encode() if isinstance(key, str) else key)
    # Fallback: derive a deterministic 32-byte key. Weaker than a real secret, but
    # keeps stored tokens non-plaintext and stable across restarts for the demo.
    from server import config

    seed = f"mapping-factory::{config.get_workspace_host()}::cred-v1".encode()
    derived = base64.urlsafe_b64encode(hashlib.sha256(seed).digest())
    return Fernet(derived)


def encrypt(plaintext: str) -> str:
    """Encrypt a secret → url-safe token string (safe to store in a TEXT column)."""
    return _fernet().encrypt(plaintext.encode()).decode()


def decrypt(token: str) -> str:
    """Decrypt a token produced by encrypt(). Raises on tamper/wrong-key."""
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken as e:  # noqa: F841
        raise ValueError("could not decrypt stored credential (key changed or data tampered)")


def new_key() -> str:
    """Generate a fresh Fernet key (for operators setting MF_CRED_KEY)."""
    return Fernet.generate_key().decode()
