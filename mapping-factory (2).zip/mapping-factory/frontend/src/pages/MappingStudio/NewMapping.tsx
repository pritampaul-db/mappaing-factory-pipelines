import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  Database,
  FileText,
  Globe,
  Upload,
  Sparkles,
  CheckCircle2,
  Wand2,
  FileCheck,
  Search,
  FlaskConical,
  Undo2,
  Redo2,
  ArrowLeft,
  Check,
  X,
  RefreshCw,
  ArrowRight,
  ShieldCheck,
  Clock,
  ExternalLink,
  FileJson,
  FileSpreadsheet,
  Table2,
  Braces,
  Code2,
  KeyRound,
  Layers,
  Pencil,
  Shuffle,
  Rocket,
  AlertTriangle,
} from "lucide-react";
import { usePage, useIdentity } from "../../AppShell";
import { useStore } from "../../store";
import { Canvas, transformSummary } from "../../Canvas";
import { DocumentView } from "./DocumentView";
import { DatabricksIcon } from "../../components/DatabricksIcon";
import { WizardStepper } from "../../components/WizardStepper";
import { Button, Tabs, StatusBadge } from "../../components/primitives";
import { DonutChart } from "../../components/charts";
import { displayName, firstName } from "../../theme";
import type { Asset, Spec, Mapping, Optimization, ValidationProposal, ValidateRun, ValidateStep, ParseTablesResult, ParsedTable } from "../../api";

const STEPS = ["Design", "Transformations", "Validations", "Preview & Publish"];

// Severity → hex, for the Validations review step's icons/labels.
const SEV_HEX: Record<string, string> = { critical: "#dc2626", high: "#ea580c", medium: "#d97706", low: "#9ca3af" };

export function NewMapping() {
  const nav = useNavigate();
  const { id: editId } = useParams();
  const [step, setStep] = useState(0);
  const [rail, setRail] = useState("Properties");
  const [approvalGate, setApprovalGate] = useState(false); // "approve pending first?" prompt
  const store = useStore();
  const { source, target, spec, busy, error, doc, valRun, valRunError, parsedSources, parsedTargets, reset, loadSpec, setFromDDL, setFromUcTable, parseTablesFor, clearParsed, createMultiSpec, suggest, submit, generateDoc, startAgenticValidation, clearValidationRun, curateBulk, renameSpec } = store;
  const identity = useIdentity();

  usePage({ title: editId ? "Edit Mapping" : "New Mapping", subtitle: "Design → Transformations → Validations → Publish" });

  // New Mapping starts blank; the /mappings/:id/edit route instead LOADS that spec
  // into the studio (open a Draft to keep building). The store is a global singleton,
  // so both paths must run on mount to avoid a stale demo/spec lingering.
  useEffect(() => {
    setStep(0);
    setRail("Properties");
    if (editId) loadSpec(editId);
    else reset();
  }, [editId, reset, loadSpec]);

  const suggested = spec?.mappings?.filter((m) => m.state === "suggested") ?? [];
  // "Total" = the live mappings (suggested + accepted/edited); rejected ones are
  // dropped from the picture, not counted. "Mapped" = the ones a human has locked in.
  const active = spec?.mappings?.filter((m) => m.state !== "rejected") ?? [];
  const total = active.length;
  const mapped = active.filter((m) => m.state === "accepted" || m.state === "edited").length;
  const pendingIds = suggested.map((m) => m.id);

  // Next: from the Designer, gate on pending approvals before advancing.
  const goNext = () => {
    if (step === 0 && pendingIds.length > 0) {
      setApprovalGate(true);
      return;
    }
    if (step < STEPS.length - 1) setStep(step + 1);
    else submit().then(() => nav("/mappings"));
  };
  const approveAllThenNext = async () => {
    await curateBulk(pendingIds, "accept");
    setApprovalGate(false);
    setStep(1);
  };

  const onDesigner = step === 0;

  return (
    <div className="flex flex-col h-full">
      {/* Full-screen generated-documentation view (overlay). */}
      {doc && <DocumentView />}

      {/* Multi-table picker: shown once a document has been parsed into tables. */}
      {(parsedSources || parsedTargets) && !spec && (
        <TablePickerModal
          parsedSources={parsedSources}
          parsedTargets={parsedTargets}
          busy={busy}
          onUpload={parseTablesFor}
          onClearSide={clearParsed}
          onCreate={createMultiSpec}
        />
      )}

      {/* Approval gate: clicking Next in the Designer with pending suggestions. */}
      {approvalGate && (
        <ApprovalGateModal
          pending={pendingIds.length}
          busy={busy}
          onApproveAll={approveAllThenNext}
          onCancel={() => setApprovalGate(false)}
        />
      )}

      {/* Wizard header — editable mapping name + stepper + actions */}
      <div className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="flex items-center justify-between">
          <MappingNameEditor name={spec?.name} disabled={!spec} onRename={renameSpec} />
          <div className="flex items-center gap-2">
            <button className="p-2 text-gray-400 hover:text-gray-600"><Undo2 className="w-4 h-4" /></button>
            <button className="p-2 text-gray-400 hover:text-gray-600"><Redo2 className="w-4 h-4" /></button>
            <Button variant="secondary">Save as Draft</Button>
            <Button onClick={goNext} disabled={!!busy || !spec}>
              {step < STEPS.length - 1 ? "Next" : "Publish"}
            </Button>
          </div>
        </div>
        <div className="mt-3">
          <WizardStepper steps={STEPS} current={step} />
        </div>
      </div>

      {error && <div className="bg-red-50 text-red-700 text-sm px-6 py-2 border-b border-red-100">{error}</div>}

      {/* 3-column workspace. The left palette + right rail are the DESIGNER work
          surface; steps 2–4 take over the center with review/summary content. */}
      <div className="flex-1 flex min-h-0">
        {/* Left: unified setup panel (Designer step only) */}
        {onDesigner && (
          <div className="w-72 border-r border-gray-200 bg-white overflow-y-auto p-4 shrink-0">
            <SetupPanel
              source={source}
              target={target}
              sourcesCount={spec?.sources?.length}
              targetsCount={spec?.targets?.length}
              busy={busy}
              parseTablesFor={parseTablesFor}
              setFromDDL={setFromDDL}
              setFromUcTable={setFromUcTable}
            />
          </div>
        )}

        {/* Center: canvas (Designer) OR the step's review/summary content */}
        <div className="flex-1 min-w-0 flex flex-col">
          <div className="flex-1 min-h-0 bg-[#fafafa] overflow-y-auto">
            {step === 1 ? (
              <TransformationsStep spec={spec} onBackToDesigner={() => setStep(0)} />
            ) : step === 2 ? (
              <ValidationsStep spec={spec} onBackToDesigner={() => setStep(0)} />
            ) : step === 3 ? (
              <PreviewStep spec={spec} onGenerateDoc={generateDoc} busy={busy} />
            ) : source ? (
              <Canvas />
            ) : (
              <div className="h-full grid place-items-center">
                <div className="text-center max-w-md">
                  <p className="text-sm text-gray-500 mb-1">Add a source & target to begin.</p>
                  <p className="text-xs text-gray-400 mb-4">Upload a data dictionary, paste DDL, or point at a Unity Catalog table — for both sides — using the panel on the left.</p>
                </div>
              </div>
            )}
          </div>
          {/* Bottom panel (Designer only): agentic-validation progress or overview strip. */}
          {onDesigner && spec && (valRun || valRunError) ? (
            <AgenticValidationPanel run={valRun} error={valRunError} onClose={clearValidationRun} onRetry={startAgenticValidation} />
          ) : onDesigner && spec ? (
            <div className="border-t border-gray-200 bg-white px-5 py-3 flex items-center gap-8">
              <Stat label="Total Mappings" value={total} />
              <Stat label="Approved" value={mapped} />
              <Stat label="Pending Review" value={Math.max(0, total - mapped)} />
              <div className="w-28">
                <DonutChart
                  data={[
                    { name: "Approved", value: mapped, color: "#16a34a" },
                    { name: "Pending", value: Math.max(0, total - mapped), color: "#d97706" },
                  ]}
                  total={total}
                  totalLabel="mappings"
                />
              </div>
            </div>
          ) : null}
        </div>

        {/* Right rail: Designer only (Properties ⇄ AI Assistant ⇄ sub-views) */}
        {onDesigner && (
          <div className="w-96 border-l border-gray-200 bg-white overflow-y-auto shrink-0 flex flex-col">
            {rail === "Optimize" ? (
              <OptimizePanel onBack={() => setRail("AI Assistant")} />
            ) : rail === "Validate" ? (
              <ValidatePanel onBack={() => setRail("AI Assistant")} />
            ) : rail === "Similar" ? (
              <SimilarPanel onBack={() => setRail("AI Assistant")} />
            ) : (
              <>
                <div className="px-4 pt-3">
                  <Tabs tabs={["Properties", "AI Assistant"]} active={rail} onChange={setRail} />
                </div>
                <div className="p-4">
                  {rail === "Properties" ? (
                    <PropertiesPanel spec={spec} owner={displayName(identity)} />
                  ) : (
                    <AiAssistantPanel
                      onSuggest={suggest}
                      onOptimize={() => setRail("Optimize")}
                      onValidate={() => setRail("Validate")}
                      onDocument={generateDoc}
                      onAgenticValidate={startAgenticValidation}
                      onFindSimilar={() => setRail("Similar")}
                      busy={busy}
                      suggestedCount={suggested.length}
                      sourceName={source?.name}
                      targetName={target?.name}
                      greetingName={firstName(identity)}
                    />
                  )}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Inline-editable mapping name in the wizard header. Click the pencil (or the
// name) to edit; Enter/blur saves, Esc cancels.
function MappingNameEditor({ name, disabled, onRename }: { name?: string; disabled?: boolean; onRename: (n: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(name ?? "");
  useEffect(() => { setDraft(name ?? ""); }, [name]);
  if (editing && !disabled) {
    const commit = () => { onRename(draft); setEditing(false); };
    return (
      <input
        autoFocus
        value={draft}
        onFocus={(e) => e.target.select()}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => { if (e.key === "Enter") commit(); if (e.key === "Escape") { setDraft(name ?? ""); setEditing(false); } }}
        className="text-lg font-semibold text-gray-900 border-b-2 border-brand focus:outline-none bg-transparent min-w-[240px]"
      />
    );
  }
  return (
    <button
      onClick={() => !disabled && setEditing(true)}
      disabled={disabled}
      className="group flex items-center gap-2 text-left disabled:cursor-default"
      title={disabled ? "Set up the mapping first" : "Rename mapping"}
    >
      <span className="text-lg font-semibold text-gray-900 truncate max-w-[420px]">{name || "New Mapping"}</span>
      {!disabled && <Pencil className="w-3.5 h-3.5 text-gray-300 group-hover:text-brand shrink-0" />}
    </button>
  );
}

// Confirm-to-proceed when the Designer still has AI suggestions awaiting review.
function ApprovalGateModal({ pending, busy, onApproveAll, onCancel }: { pending: number; busy: string | null; onApproveAll: () => void; onCancel: () => void }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/40 grid place-items-center p-4" onClick={onCancel}>
      <div className="bg-white rounded-2xl shadow-2xl w-[440px] max-w-[92vw] p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start gap-3">
          <span className="w-9 h-9 rounded-lg bg-amber-50 text-amber-600 grid place-items-center shrink-0"><AlertTriangle className="w-5 h-5" /></span>
          <div>
            <h3 className="text-base font-semibold text-gray-800">Approve pending transformations?</h3>
            <p className="text-sm text-gray-500 mt-1">
              {pending} transformation{pending === 1 ? "" : "s"} {pending === 1 ? "is" : "are"} still awaiting review. Approve all of them to continue to the Transformations step, or go back and review them individually on the canvas.
            </p>
          </div>
        </div>
        <div className="flex justify-end gap-2 mt-4">
          <Button variant="secondary" onClick={onCancel} disabled={!!busy}>Back to review</Button>
          <Button onClick={onApproveAll} disabled={!!busy}>
            {busy ? "Approving…" : `Approve all ${pending} & continue`}
          </Button>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="text-2xl font-semibold text-gray-900">{value}</div>
      <div className="text-xs text-gray-500">{label}</div>
    </div>
  );
}

// Unified setup panel — ONE section (merges the old decorative palette + the
// Set-up-mapping rows). A grid of big source-type tiles; clicking one asks which
// side (source/target) then runs the right action: Upload/Excel/CSV/JSON/XML →
// parse a document into tables; DDL/SQL → paste a CREATE TABLE; Database/UC table
// → a UC locator. A compact status shows what's registered for each side.
type SetupKind = "upload" | "ddl" | "uc";
type IconType = React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
const SETUP_TILES: { icon: IconType; label: string; color: string; tint: string; kind: SetupKind }[] = [
  { icon: Upload, label: "Upload File", color: "#c9252d", tint: "#fef2f2", kind: "upload" },
  { icon: FileSpreadsheet, label: "Excel", color: "#16a34a", tint: "#f0fdf4", kind: "upload" },
  { icon: Table2, label: "CSV", color: "#0891b2", tint: "#ecfeff", kind: "upload" },
  { icon: Braces, label: "JSON", color: "#a855f7", tint: "#faf5ff", kind: "upload" },
  { icon: Code2, label: "XML", color: "#ea580c", tint: "#fff7ed", kind: "upload" },
  { icon: Code2, label: "DDL / SQL", color: "#dc2626", tint: "#fef2f2", kind: "ddl" },
  { icon: Database, label: "Database", color: "#dc2626", tint: "#fef2f2", kind: "uc" },
  { icon: DatabricksIcon, label: "UC Table", color: "#FF3621", tint: "#fff1ee", kind: "uc" },
  { icon: Globe, label: "API / Service", color: "#a855f7", tint: "#faf5ff", kind: "uc" },
];

function SetupPanel({
  source, target, sourcesCount, targetsCount, busy, parseTablesFor, setFromDDL, setFromUcTable,
}: {
  source: Asset | null;
  target: Asset | null;
  sourcesCount?: number;
  targetsCount?: number;
  busy: string | null;
  parseTablesFor: (f: File, r: "source" | "target") => void;
  setFromDDL: (ddl: string, r: "source" | "target", name?: string) => void;
  setFromUcTable: (loc: string, r: "source" | "target") => void;
}) {
  const { sourceSystem, targetSystem, setSystem } = useStore();
  // Pending action: a tile was clicked; ask which side, then act. For "upload" we
  // need a hidden file input tied to the chosen side.
  const [pending, setPending] = useState<{ kind: SetupKind; label: string } | null>(null);
  const [role, setRole] = useState<"source" | "target" | null>(null);
  const [text, setText] = useState("");
  const uploadRef = useRef<HTMLInputElement | null>(null);

  const startTile = (kind: SetupKind, label: string) => { setPending({ kind, label }); setRole(null); setText(""); };
  const chooseRole = (r: "source" | "target") => {
    setRole(r);
    if (pending?.kind === "upload") {
      setTimeout(() => uploadRef.current?.click(), 0); // open the file picker for this side
    }
  };
  const reset = () => { setPending(null); setRole(null); setText(""); };

  return (
    <>
      <h3 className="text-sm font-semibold text-gray-800 mb-1">Set up mapping</h3>
      <p className="text-xs text-gray-500 mb-3">Add your source and target — from a data dictionary, DDL, or a Unity Catalog table.</p>

      {/* Current source/target status + system-name entry */}
      <div className="space-y-1.5 mb-4">
        <SetupStatus role="source" asset={source} count={sourcesCount} system={sourceSystem} onSystem={(v) => setSystem("source", v)} />
        <SetupStatus role="target" asset={target} count={targetsCount} system={targetSystem} onSystem={(v) => setSystem("target", v)} />
      </div>

      {/* Big functional tiles */}
      <div className="grid grid-cols-3 gap-2">
        {SETUP_TILES.map((t) => (
          <button
            key={t.label}
            disabled={!!busy}
            onClick={() => startTile(t.kind, t.label)}
            className="border border-gray-200 rounded-lg p-2 text-center hover:border-brand/40 hover:shadow-sm transition-shadow disabled:opacity-40"
          >
            <span className="w-8 h-8 mx-auto mb-1 rounded-lg grid place-items-center" style={{ background: t.tint }}>
              <t.icon className="w-4 h-4" style={{ color: t.color }} />
            </span>
            <span className="text-[10px] text-gray-600 leading-tight block">{t.label}</span>
          </button>
        ))}
      </div>
      {busy && <p className="text-[11px] text-brand mt-3">{busy}</p>}

      {/* Hidden upload input, wired to the chosen side. */}
      <input
        ref={uploadRef}
        type="file"
        className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f && role) parseTablesFor(f, role); e.target.value = ""; reset(); }}
      />

      {/* Step 1: pick which side this tile sets. */}
      {pending && !role && (
        <div className="fixed inset-0 z-50 bg-black/30 grid place-items-center" onClick={reset}>
          <div className="bg-white rounded-xl shadow-xl w-[380px] max-w-[90vw] p-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-semibold text-gray-800">{pending.label} — which side?</h4>
              <button onClick={reset} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button onClick={() => chooseRole("source")} className="border border-gray-200 rounded-lg p-4 text-center hover:border-emerald-300 hover:bg-emerald-50/40">
                <FileText className="w-6 h-6 mx-auto mb-1.5 text-emerald-600" />
                <div className="text-sm font-medium text-gray-800">Source</div>
                <div className="text-[10px] text-gray-500">the data you map FROM</div>
              </button>
              <button onClick={() => chooseRole("target")} className="border border-gray-200 rounded-lg p-4 text-center hover:border-purple-300 hover:bg-purple-50/40">
                <Table2 className="w-6 h-6 mx-auto mb-1.5 text-purple-600" />
                <div className="text-sm font-medium text-gray-800">Target</div>
                <div className="text-[10px] text-gray-500">the schema you map TO</div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 2: DDL / UC-locator input (upload is handled by the hidden input). */}
      {pending && role && pending.kind !== "upload" && (
        <div className="fixed inset-0 z-50 bg-black/30 grid place-items-center" onClick={reset}>
          <div className="bg-white rounded-xl shadow-xl w-[460px] max-w-[90vw] p-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-semibold text-gray-800">{pending.kind === "ddl" ? `Paste ${role} DDL` : `${role} — Unity Catalog table`}</h4>
              <button onClick={reset} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
            </div>
            {pending.kind === "ddl" ? (
              <textarea value={text} onChange={(e) => setText(e.target.value)} rows={6} placeholder="CREATE TABLE dim_customer (customer_id BIGINT NOT NULL, full_name STRING, ...)" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-brand/30" />
            ) : (
              <input value={text} onChange={(e) => setText(e.target.value)} placeholder="catalog.schema.table" className="inp font-mono text-xs" />
            )}
            <div className="flex justify-end gap-2 mt-3">
              <Button variant="secondary" onClick={reset}>Cancel</Button>
              <Button
                onClick={() => {
                  const v = text.trim();
                  if (!v || !role) return;
                  if (pending.kind === "ddl") setFromDDL(v, role);
                  else setFromUcTable(v, role);
                  reset();
                }}
              >
                Register {role}
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function SetupStatus({ role, asset, count, system, onSystem }: { role: "source" | "target"; asset: Asset | null; count?: number; system: string; onSystem: (v: string) => void }) {
  const isSource = role === "source";
  const multi = (count ?? 0) > 1;
  return (
    <div className="border border-gray-200 rounded-lg px-2.5 py-2">
      <div className="flex items-center gap-2">
        <span className={`w-6 h-6 rounded grid place-items-center shrink-0 ${isSource ? "bg-emerald-50 text-emerald-700" : "bg-purple-50 text-purple-700"}`}>
          {isSource ? <FileText className="w-3.5 h-3.5" /> : <Table2 className="w-3.5 h-3.5" />}
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[10px] uppercase tracking-wide text-gray-400">{role}</div>
          <div className={`text-xs truncate ${asset ? "text-gray-800 font-medium" : "text-gray-400"}`}>
            {asset ? asset.name : "not set"}{multi && <span className="text-gray-400 font-normal"> +{(count ?? 1) - 1} more</span>}
          </div>
        </div>
        {asset && <Check className="w-3.5 h-3.5 text-green-600 shrink-0" />}
      </div>
      {/* Source/target SYSTEM name — the owning system this side belongs to. */}
      <input
        value={system}
        onChange={(e) => onSystem(e.target.value)}
        placeholder={isSource ? "Source system (e.g. BU_RETAIL)" : "Target system (e.g. CORP_EDW)"}
        className="mt-1.5 w-full text-[11px] border border-gray-200 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-brand/30"
      />
    </div>
  );
}

// --- Multi-table picker ------------------------------------------------------
// After a document is parsed into tables, the user multi-selects which source and
// target tables to map. Each side is its own upload; a mapping is created once at
// least one table is picked from BOTH sides. Reference/foreign keys are flagged so
// the user can see which columns will drive cross-table joins.
function TablePickerModal({
  parsedSources, parsedTargets, busy, onUpload, onClearSide, onCreate,
}: {
  parsedSources: ParseTablesResult | null;
  parsedTargets: ParseTablesResult | null;
  busy: string | null;
  onUpload: (f: File, r: "source" | "target") => void;
  onClearSide: (r: "source" | "target") => void;
  onCreate: (sources: ParsedTable[], targets: ParsedTable[], name?: string) => void;
}) {
  // Selection is keyed by table_name within each side.
  const [srcSel, setSrcSel] = useState<Set<string>>(new Set());
  const [tgtSel, setTgtSel] = useState<Set<string>>(new Set());

  // Default to selecting ALL tables the first time a side's parse arrives.
  useEffect(() => {
    if (parsedSources) setSrcSel(new Set(parsedSources.tables.map((t) => t.table_name)));
  }, [parsedSources]);
  useEffect(() => {
    if (parsedTargets) setTgtSel(new Set(parsedTargets.tables.map((t) => t.table_name)));
  }, [parsedTargets]);

  const pickedSources = (parsedSources?.tables ?? []).filter((t) => srcSel.has(t.table_name));
  const pickedTargets = (parsedTargets?.tables ?? []).filter((t) => tgtSel.has(t.table_name));
  const canCreate = pickedSources.length > 0 && pickedTargets.length > 0 && !busy;

  return (
    <div className="fixed inset-0 z-50 bg-black/40 grid place-items-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-[860px] max-w-[95vw] max-h-[88vh] flex flex-col overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-200 flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-gray-800 flex items-center gap-2"><Layers className="w-4 h-4 text-brand" /> Select tables to map</h3>
            <p className="text-xs text-gray-500 mt-0.5">Choose the source and target tables. Multiple sources can feed one target through AI-proposed joins.</p>
          </div>
          {busy && <span className="text-xs text-brand">{busy}</span>}
        </div>

        <div className="flex-1 min-h-0 grid grid-cols-2 divide-x divide-gray-100 overflow-hidden">
          <TablePickColumn
            role="source"
            parsed={parsedSources}
            selected={srcSel}
            onToggle={(name) => setSrcSel((s) => toggle(s, name))}
            onUpload={onUpload}
            onClear={() => onClearSide("source")}
            busy={busy}
          />
          <TablePickColumn
            role="target"
            parsed={parsedTargets}
            selected={tgtSel}
            onToggle={(name) => setTgtSel((s) => toggle(s, name))}
            onUpload={onUpload}
            onClear={() => onClearSide("target")}
            busy={busy}
          />
        </div>

        <div className="px-5 py-3 border-t border-gray-200 flex items-center justify-between">
          <p className="text-xs text-gray-500">
            {pickedSources.length} source{pickedSources.length === 1 ? "" : "s"} · {pickedTargets.length} target{pickedTargets.length === 1 ? "" : "s"} selected
            {!parsedTargets && <span className="text-amber-600"> — upload a target document to continue</span>}
          </p>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => { onClearSide("source"); onClearSide("target"); }} disabled={!!busy}>Cancel</Button>
            <Button onClick={() => onCreate(pickedSources, pickedTargets)} disabled={!canCreate}>
              <ArrowRight className="w-4 h-4" /> Create mapping
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function toggle(set: Set<string>, name: string): Set<string> {
  const next = new Set(set);
  if (next.has(name)) next.delete(name); else next.add(name);
  return next;
}

function TablePickColumn({
  role, parsed, selected, onToggle, onUpload, onClear, busy,
}: {
  role: "source" | "target";
  parsed: ParseTablesResult | null;
  selected: Set<string>;
  onToggle: (name: string) => void;
  onUpload: (f: File, r: "source" | "target") => void;
  onClear: () => void;
  busy: string | null;
}) {
  const isSource = role === "source";
  return (
    <div className="flex flex-col min-h-0">
      <div className="px-4 py-2.5 flex items-center justify-between shrink-0">
        <span className={`text-xs font-semibold uppercase tracking-wide flex items-center gap-1.5 ${isSource ? "text-emerald-700" : "text-purple-700"}`}>
          {isSource ? <FileText className="w-3.5 h-3.5" /> : <Table2 className="w-3.5 h-3.5" />} {role}
          {parsed && <span className="text-gray-400 font-normal normal-case">· {parsed.tables.length} tables</span>}
        </span>
        {parsed && (
          <button onClick={onClear} className="text-[11px] text-gray-400 hover:text-gray-600 flex items-center gap-1"><X className="w-3 h-3" /> clear</button>
        )}
      </div>

      {!parsed ? (
        <div className="flex-1 grid place-items-center p-6">
          <label className={`text-center border-2 border-dashed border-gray-200 rounded-xl px-6 py-8 cursor-pointer hover:border-brand/40 ${busy ? "opacity-40 pointer-events-none" : ""}`}>
            <Upload className="w-6 h-6 mx-auto mb-2 text-brand" />
            <span className="text-xs text-gray-600 block font-medium">Upload {role} document</span>
            <span className="text-[10px] text-gray-400 block mt-0.5">PDF, Excel, CSV, JSON, DDL — all tables extracted</span>
            <input type="file" className="hidden" disabled={!!busy} onChange={(e) => { const f = e.target.files?.[0]; if (f) onUpload(f, role); e.target.value = ""; }} />
          </label>
        </div>
      ) : (
        <div className="flex-1 min-h-0 overflow-y-auto px-4 pb-4 space-y-2">
          {parsed.tables.map((t) => {
            const on = selected.has(t.table_name);
            const keys = t.fields.filter((f) => f.is_key);
            return (
              <button
                key={t.table_name}
                onClick={() => onToggle(t.table_name)}
                className={`w-full text-left border rounded-lg p-3 transition-colors ${on ? (isSource ? "border-emerald-300 bg-emerald-50/40" : "border-purple-300 bg-purple-50/40") : "border-gray-200 hover:border-gray-300"}`}
              >
                <div className="flex items-start gap-2">
                  <span className={`mt-0.5 w-4 h-4 rounded grid place-items-center shrink-0 ${on ? (isSource ? "bg-emerald-600" : "bg-purple-600") : "bg-gray-200"}`}>
                    {on && <Check className="w-3 h-3 text-white" />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium text-gray-800 truncate">{t.table_name}</div>
                    {t.description && <div className="text-[11px] text-gray-500 truncate">{t.description}</div>}
                    <div className="text-[10px] text-gray-400 mt-1 flex items-center gap-2 flex-wrap">
                      <span>{t.fields.length} columns</span>
                      {keys.length > 0 && (
                        <span className="inline-flex items-center gap-0.5 text-amber-600"><KeyRound className="w-2.5 h-2.5" /> {keys.map((k) => k.name).join(", ")}</span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

// Agent Workflow panel — six named agents working together to validate the mapping,
// shown as a row of numbered agent cards with per-agent status + timer, a pipeline
// info bar, and the analysis/result once complete. (Matches the Agent Workflow design.)
// Download the run's compiled config (transforms + validations) as a JSON artifact.
function downloadConfigJson(run: ValidateRun) {
  if (!run.config) return;
  const name = (run.config.targets?.map((t) => t.target_name).join("-") || run.config.target_name || "mapping").replace(/\s+/g, "_");
  const blob = new Blob([JSON.stringify(run.config, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `mapping_config_${name}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function fmtElapsed(sec?: number | null): string {
  if (sec == null) return "--:--:--";
  const s = Math.floor(sec);
  const hh = String(Math.floor(s / 3600)).padStart(2, "0");
  const mm = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
}

function AgenticValidationPanel({ run, error, onClose, onRetry }: { run: ValidateRun | null; error: string | null; onClose: () => void; onRetry: () => void }) {
  const running = run?.status === "running";
  const steps = run?.steps ?? [];
  return (
    <div className="border-t border-gray-200 bg-[#fafbfc] px-5 py-3 max-h-[46%] overflow-y-auto">
      {/* Header */}
      <div className="flex items-center gap-2 mb-0.5">
        <FlaskConical className="w-4 h-4 text-brand" />
        <span className="text-sm font-semibold text-gray-800">Agent Workflow</span>
        {run && (
          <span className={`text-[10px] px-1.5 py-0.5 rounded ${run.status === "succeeded" ? "bg-green-100 text-green-700" : run.status === "failed" ? "bg-red-100 text-red-700" : "bg-blue-100 text-blue-700"}`}>
            {run.status === "running" ? "running…" : run.status}
          </span>
        )}
        <div className="ml-auto flex items-center gap-3">
          {run?.config && (
            <button onClick={() => downloadConfigJson(run)} className="text-xs text-gray-500 hover:text-brand inline-flex items-center gap-1">
              <FileJson className="w-3 h-3" /> Download config
            </button>
          )}
          {!running && <button onClick={onRetry} className="text-xs text-gray-500 hover:text-brand inline-flex items-center gap-1"><RefreshCw className="w-3 h-3" /> Run again</button>}
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
        </div>
      </div>
      <p className="text-xs text-gray-500 mb-3">AI agents working together to validate your mapping</p>

      {error && (
        error.startsWith("Reconnecting")
          ? <div className="text-xs text-amber-700 bg-amber-50 rounded px-2 py-1.5 mb-2 flex items-center gap-1.5"><RefreshCw className="w-3 h-3 animate-spin" /> {error}</div>
          : <div className="text-xs text-red-600 bg-red-50 rounded px-2 py-1.5 mb-2">{error}</div>
      )}

      {/* Agent cards row */}
      <div className="flex items-stretch gap-2 overflow-x-auto pb-1">
        {steps.map((s, i) => (
          <div key={s.key} className="flex items-center gap-2 shrink-0">
            <AgentCard step={s} index={i + 1} />
            {i < steps.length - 1 && <ArrowRight className="w-4 h-4 text-gray-300 shrink-0" />}
          </div>
        ))}
      </div>

      {/* Pipeline info bar */}
      {run?.pipeline && (
        <div className="mt-3 bg-white border border-gray-200 rounded-lg px-4 py-2.5 flex items-center gap-8 text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-8 h-8 rounded-lg bg-brand-soft text-brand grid place-items-center shrink-0"><FlaskConical className="w-4 h-4" /></span>
            <div className="min-w-0">
              <div className="font-medium text-gray-800">Pipeline</div>
              <div className="text-gray-500 truncate">Configurable SDP Pipeline: <span className="font-mono">{run.pipeline.name}</span></div>
              {(run.pipeline.run_url || run.pipeline.pipeline_url) && (
                <a href={run.pipeline.run_url || run.pipeline.pipeline_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-brand hover:underline mt-0.5">
                  <ExternalLink className="w-3 h-3" /> View pipeline run
                </a>
              )}
            </div>
          </div>
          <PipeMeta k="Environment" v={run.pipeline.environment} />
          <PipeMeta k="Compute" v={run.pipeline.compute} />
          <PipeMeta k="Target" v={run.pipeline.target} mono />
        </div>
      )}

      {/* Result summary — metadata checks + DQ pass-rate breakdown + recommendations */}
      {run?.result && (
        <div className="mt-3 bg-white border border-gray-200 rounded-lg px-4 py-2.5">
          <div className="flex items-center gap-2 mb-2">
            <span className={`text-xs font-medium ${run.result.analysis?.verdict === "ready" || run.result.overall === "passed" ? "text-green-700" : "text-amber-700"}`}>
              {run.result.analysis?.verdict === "ready" || run.result.overall === "passed" ? "✓ Validation passed" : "⚠ Review recommended"}
            </span>
            <span className="text-[11px] text-gray-500">{run.result.analysis?.headline || run.result.summary}</span>
            {run.result.row_count != null && <span className="text-[11px] text-gray-400">· {run.result.row_count} rows tested</span>}
          </div>

          {/* Metadata checks */}
          {run.result.checks?.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-1 mb-2">
              {run.result.checks.map((c) => (
                <div key={c.name} className="flex items-center gap-1.5 text-[11px]">
                  {c.passed ? <Check className="w-3 h-3 text-green-600 shrink-0" /> : <X className="w-3 h-3 text-red-600 shrink-0" />}
                  <span className="text-gray-700">{c.name}</span>
                  <span className="text-gray-400 truncate">{c.detail}</span>
                </div>
              ))}
            </div>
          )}

          {/* DQ pass-rate breakdown */}
          {run.result.dq?.length > 0 && (
            <div className="border-t border-gray-100 pt-2 mb-2">
              <div className="text-[11px] text-gray-500 mb-1">Data-quality rules — {run.result.dq.filter((d) => d.pass_rate === 1).length}/{run.result.dq.length} at 100% pass</div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-0.5">
                {[...run.result.dq].sort((a, b) => (a.pass_rate ?? 1) - (b.pass_rate ?? 1)).map((d, i) => {
                  const pr = d.pass_rate;
                  const color = pr == null ? "text-gray-400" : pr === 1 ? "text-green-600" : pr >= 0.8 ? "text-amber-600" : "text-red-600";
                  return (
                    <div key={`${d.rule}-${i}`} className="flex items-center justify-between gap-2 text-[11px]">
                      <span className="text-gray-600 font-mono truncate">{d.target_table ? <span className="text-gray-400">{d.target_table}.</span> : null}{d.column}</span>
                      <span className={`shrink-0 ${color}`}>{pr == null ? "—" : `${Math.round(pr * 100)}%`}{d.total != null ? ` (${d.passed}/${d.total})` : ""}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Recommendations */}
          {run.result.analysis?.recommendations?.length ? (
            <div className="border-t border-gray-100 pt-2">
              <div className="text-[11px] font-medium text-gray-600 mb-0.5">Recommendations</div>
              <ul className="text-[11px] text-gray-600 space-y-0.5 list-disc pl-4">
                {run.result.analysis.recommendations.map((r, i) => <li key={i}>{r}</li>)}
              </ul>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}

function AgentCard({ step, index }: { step: ValidateStep; index: number }) {
  const active = step.status === "running";
  const done = step.status === "done";
  const failed = step.status === "failed";
  const border = active ? "border-brand ring-1 ring-brand/30" : failed ? "border-red-200" : "border-gray-200";
  const numCls = done ? "border-green-500 text-green-600" : active ? "border-brand text-brand" : failed ? "border-red-400 text-red-500" : "border-gray-300 text-gray-400";
  return (
    <div className={`w-[150px] shrink-0 bg-white rounded-xl border ${border} p-2.5 flex flex-col`} title={step.detail ?? ""}>
      <span className={`w-6 h-6 rounded-full border grid place-items-center text-[11px] font-semibold mb-1.5 ${numCls}`}>{index}</span>
      <div className="text-xs font-semibold text-gray-800 leading-tight">{step.agent}</div>
      <div className="text-[10px] text-gray-500 leading-tight mt-0.5 mb-2 min-h-[26px]">{step.description}</div>
      <div className="mt-auto">
        <StatusChip status={step.status} />
        {/* Live substate (e.g. the SDP pipeline's waiting_for_resources / running). */}
        {active && step.detail && <div className="text-[10px] text-brand mt-0.5 leading-tight truncate" title={step.detail}>{step.detail}</div>}
        <div className="text-[10px] text-gray-400 font-mono mt-1">{fmtElapsed(step.elapsed_sec)}</div>
      </div>
      {active && <div className="h-0.5 bg-brand/20 rounded-full mt-1 overflow-hidden"><div className="h-full w-1/2 bg-brand animate-pulse" /></div>}
    </div>
  );
}

function StatusChip({ status }: { status: string }) {
  if (status === "done") return <span className="inline-flex items-center gap-1 text-[10px] text-green-600"><Check className="w-3 h-3" /> Completed</span>;
  if (status === "running") return <span className="inline-flex items-center gap-1 text-[10px] text-brand"><RefreshCw className="w-3 h-3 animate-spin" /> Running</span>;
  if (status === "failed") return <span className="inline-flex items-center gap-1 text-[10px] text-red-600"><X className="w-3 h-3" /> Failed</span>;
  return <span className="inline-flex items-center gap-1 text-[10px] text-gray-400"><Clock className="w-3 h-3" /> Waiting</span>;
}

function PipeMeta({ k, v, mono }: { k: string; v?: string | null; mono?: boolean }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wide text-gray-400">{k}</div>
      <div className={`text-gray-700 ${mono ? "font-mono text-[11px]" : ""}`}>{v ?? "—"}</div>
    </div>
  );
}

// --- Wizard steps 2–4: review + summary (read-only; edit back in the Designer) --

// Group a spec's active (non-rejected) mappings by their target TABLE, using the
// field-id → target-asset lookup. Returns [{table, mappings[]}] in target order.
function groupMappingsByTable(spec: Spec | null): { table: string; mappings: Mapping[] }[] {
  if (!spec) return [];
  const targets = spec.targets?.length ? spec.targets : [];
  const active = (spec.mappings ?? []).filter((m) => m.state !== "rejected");
  if (!targets.length) return active.length ? [{ table: "Target", mappings: active }] : [];
  const fieldToTable = new Map<string, string>();
  for (const a of targets) for (const f of a.fields) fieldToTable.set(f.id, a.name);
  const byTable = new Map<string, Mapping[]>();
  for (const a of targets) byTable.set(a.name, []);
  for (const m of active) {
    const t = fieldToTable.get(m.target_field_id);
    if (t) byTable.get(t)!.push(m);
  }
  return [...byTable.entries()].map(([table, mappings]) => ({ table, mappings }));
}

const STATE_STYLE: Record<string, string> = {
  accepted: "bg-green-100 text-green-700",
  edited: "bg-blue-100 text-blue-700",
  suggested: "bg-purple-100 text-purple-700",
};

// Step 2 — Transformations: every transformation in the mapping, grouped by target
// table, with description + metadata. Read-only; edits happen back in the Designer.
function TransformationsStep({ spec, onBackToDesigner }: { spec: Spec | null; onBackToDesigner: () => void }) {
  const groups = useMemo(() => groupMappingsByTable(spec), [spec]);
  const totalCount = groups.reduce((a, g) => a + g.mappings.length, 0);
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <StepHeader
        icon={Shuffle}
        title="Transformations"
        subtitle={`${totalCount} transformation${totalCount === 1 ? "" : "s"} across ${groups.length} target table${groups.length === 1 ? "" : "s"}`}
        onBackToDesigner={onBackToDesigner}
      />
      {totalCount === 0 && (
        <div className="text-center py-16 text-gray-400 text-sm">No transformations yet — go back to the Designer and run “Suggest mappings”.</div>
      )}
      {groups.map((g) => (
        <div key={g.table} className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Table2 className="w-4 h-4 text-purple-500" />
            <h3 className="text-sm font-semibold text-gray-800">{g.table}</h3>
            <span className="text-xs text-gray-400">· {g.mappings.length} column{g.mappings.length === 1 ? "" : "s"}</span>
          </div>
          <div className="border border-gray-200 rounded-xl overflow-x-auto bg-white">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-left text-gray-500 bg-gray-50 border-b border-gray-200">
                  <th className="py-2 px-3 font-medium">Target column</th>
                  <th className="py-2 px-3 font-medium">Source field(s)</th>
                  <th className="py-2 px-3 font-medium">Transformation</th>
                  <th className="py-2 px-3 font-medium text-right whitespace-nowrap">Conf.</th>
                  <th className="py-2 px-3 font-medium">Origin</th>
                  <th className="py-2 px-3 font-medium pr-4">Status</th>
                </tr>
              </thead>
              <tbody>
                {g.mappings.map((m) => (
                  <tr key={m.id} className="border-b border-gray-100 last:border-0 align-top">
                    <td className="py-2 px-3 font-mono text-gray-800">{m.target_field_name}</td>
                    <td className="py-2 px-3 text-gray-600">{(m.provenance?.source_field_names ?? []).join(", ") || "—"}</td>
                    <td className="py-2 px-3">
                      <div className="font-medium text-gray-700 flex items-center gap-1.5">
                        {transformSummary(m)}
                        {m.provenance?.reused_transformation_code ? (
                          <span className="text-[10px] bg-blue-50 text-blue-700 border border-blue-100 px-1.5 py-0.5 rounded whitespace-nowrap" title={`Reused library transformation: ${m.provenance.reused_transformation_name ?? m.provenance.reused_transformation_code}`}>↻ Reused</span>
                        ) : m.provenance?.is_new_transformation ? (
                          <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-100 px-1.5 py-0.5 rounded whitespace-nowrap">✦ New</span>
                        ) : null}
                      </div>
                      {(m.transform_description || m.provenance?.rationale) && (
                        <div className="text-[11px] text-gray-400 mt-0.5">{m.transform_description || m.provenance?.rationale}</div>
                      )}
                    </td>
                    <td className="py-2 px-3 text-right text-gray-600 whitespace-nowrap">{m.confidence == null ? "—" : `${Math.round((m.confidence <= 1 ? m.confidence * 100 : m.confidence))}%`}</td>
                    <td className="py-2 px-3 text-gray-500">{m.provenance?.origin ?? "—"}</td>
                    <td className="py-2 px-3 pr-4"><span className={`inline-block whitespace-nowrap px-1.5 py-0.5 rounded capitalize ${STATE_STYLE[m.state] ?? "bg-gray-100 text-gray-600"}`}>{m.state}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  );
}

// Step 3 — Validations: the DQ checks that will guard the target(s), grouped by
// target table. Loaded from the DQ library for each target dataset.
function ValidationsStep({ spec, onBackToDesigner }: { spec: Spec | null; onBackToDesigner: () => void }) {
  const { appliedValidations, loadAppliedValidations } = useStore();
  useEffect(() => { loadAppliedValidations(); }, [loadAppliedValidations]);
  const datasets = spec?.targets?.length ? spec.targets.map((t) => t.name) : [];
  const groups = datasets.map((ds) => ({ table: ds, vals: appliedValidations.filter((v) => v.dataset === ds) }));
  const total = groups.reduce((a, g) => a + g.vals.length, 0);
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <StepHeader
        icon={ShieldCheck}
        title="Validations"
        subtitle={`${total} data-quality check${total === 1 ? "" : "s"} across ${groups.length} target table${groups.length === 1 ? "" : "s"}`}
        onBackToDesigner={onBackToDesigner}
      />
      {total === 0 && (
        <div className="text-center py-16 text-gray-400 text-sm">No validations yet — go back to the Designer and run “Validate mapping”.</div>
      )}
      {groups.filter((g) => g.vals.length).map((g) => (
        <div key={g.table} className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Table2 className="w-4 h-4 text-rose-500" />
            <h3 className="text-sm font-semibold text-gray-800">{g.table}</h3>
            <span className="text-xs text-gray-400">· {g.vals.length} check{g.vals.length === 1 ? "" : "s"}</span>
          </div>
          <div className="space-y-2">
            {g.vals.map((v) => (
              <div key={v.id} className="border border-gray-200 rounded-lg p-3 bg-white">
                <div className="flex items-center gap-2 mb-1">
                  <ShieldCheck className="w-3.5 h-3.5 shrink-0" style={{ color: SEV_HEX[v.severity] ?? "#9ca3af" }} />
                  <span className="text-sm font-medium text-gray-800 truncate flex-1">{v.name}</span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded capitalize ${VAL_KIND_STYLE[v.rule_type] ?? "bg-gray-100 text-gray-600"}`}>{(v.rule_type ?? "").replace("_", " ")}</span>
                  <span className="text-[10px] capitalize" style={{ color: SEV_HEX[v.severity] ?? "#6b7280" }}>{v.severity}</span>
                </div>
                {v.column_name && <div className="text-[11px] text-gray-400 mb-1">column: <span className="font-mono">{v.column_name}</span></div>}
                {v.logic && <div className="font-mono text-[11px] text-gray-700 bg-gray-50 border border-gray-100 rounded p-1.5 break-all">{v.logic}</div>}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// Step 4 — Preview & Publish: a whole-mapping summary (tables, coverage, joins,
// transforms, validations) + a shortcut to the full generated documentation.
function PreviewStep({ spec, onGenerateDoc, busy }: { spec: Spec | null; onGenerateDoc: () => void; busy: string | null }) {
  const { appliedValidations, loadAppliedValidations } = useStore();
  useEffect(() => { loadAppliedValidations(); }, [loadAppliedValidations]);
  const groups = useMemo(() => groupMappingsByTable(spec), [spec]);
  const active = (spec?.mappings ?? []).filter((m) => m.state !== "rejected");
  const approved = active.filter((m) => m.state === "accepted" || m.state === "edited").length;
  const datasets = new Set(spec?.targets?.map((t) => t.name) ?? []);
  const valCount = appliedValidations.filter((v) => v.dataset && datasets.has(v.dataset)).length;
  const nSrc = spec?.sources?.length ?? 0;
  const nTgt = spec?.targets?.length ?? 0;
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-2 mb-1">
        <Rocket className="w-5 h-5 text-brand" />
        <h2 className="text-lg font-semibold text-gray-900">Preview &amp; Publish</h2>
      </div>
      <p className="text-sm text-gray-500 mb-5">Review the complete mapping before publishing it for approval.</p>

      {/* Summary KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        <SummaryCard label="Source tables" value={nSrc} icon={FileText} />
        <SummaryCard label="Target tables" value={nTgt} icon={Table2} />
        <SummaryCard label="Transformations" value={active.length} icon={Shuffle} />
        <SummaryCard label="Approved" value={approved} icon={Check} accent={approved === active.length && active.length > 0 ? "green" : "amber"} />
        <SummaryCard label="Validations" value={valCount} icon={ShieldCheck} />
      </div>

      {/* Joins */}
      {spec?.joins?.length ? (
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-800 mb-2">Source joins</h3>
          <div className="border border-gray-200 rounded-lg bg-white divide-y divide-gray-100">
            {spec.joins.map((j, i) => (
              <div key={i} className="flex items-center gap-2 px-3 py-2 text-xs">
                <KeyRound className="w-3 h-3 text-amber-500 shrink-0" />
                <span className="font-mono text-gray-700">{j.left}</span>
                <span className="text-gray-400">=</span>
                <span className="font-mono text-gray-700">{j.right}</span>
                {j.confidence != null && <span className="ml-auto text-gray-400">{Math.round(j.confidence * 100)}%</span>}
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {/* Per-table roll-up */}
      <div className="mb-6">
        <h3 className="text-sm font-semibold text-gray-800 mb-2">Per-table summary</h3>
        <div className="border border-gray-200 rounded-xl overflow-hidden bg-white">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-left text-gray-500 bg-gray-50 border-b border-gray-200">
                <th className="py-2 px-3 font-medium">Target table</th>
                <th className="py-2 px-3 font-medium text-right">Columns mapped</th>
                <th className="py-2 px-3 font-medium text-right">Approved</th>
                <th className="py-2 px-3 font-medium text-right">Validations</th>
              </tr>
            </thead>
            <tbody>
              {groups.map((g) => {
                const appr = g.mappings.filter((m) => m.state === "accepted" || m.state === "edited").length;
                const vc = appliedValidations.filter((v) => v.dataset === g.table).length;
                return (
                  <tr key={g.table} className="border-b border-gray-100 last:border-0">
                    <td className="py-2 px-3 font-medium text-gray-800">{g.table}</td>
                    <td className="py-2 px-3 text-right text-gray-600">{g.mappings.length}</td>
                    <td className="py-2 px-3 text-right text-gray-600">{appr}/{g.mappings.length}</td>
                    <td className="py-2 px-3 text-right text-gray-600">{vc}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Button variant="secondary" onClick={onGenerateDoc} disabled={!!busy}>
          <FileText className="w-4 h-4" /> {busy === "Generating documentation…" ? "Generating…" : "View full documentation"}
        </Button>
        <span className="text-xs text-gray-400">Click <b>Publish</b> (top-right) to submit this mapping for maker-checker approval.</span>
      </div>
    </div>
  );
}

function StepHeader({ icon: Icon, title, subtitle, onBackToDesigner }: { icon: typeof Shuffle; title: string; subtitle: string; onBackToDesigner: () => void }) {
  return (
    <div className="flex items-start justify-between mb-5">
      <div className="flex items-center gap-2">
        <Icon className="w-5 h-5 text-brand" />
        <div>
          <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
          <p className="text-xs text-gray-500">{subtitle}</p>
        </div>
      </div>
      <Button variant="secondary" onClick={onBackToDesigner}>
        <ArrowLeft className="w-4 h-4" /> Back to Designer
      </Button>
    </div>
  );
}

function SummaryCard({ label, value, icon: Icon, accent }: { label: string; value: number; icon: typeof Shuffle; accent?: "green" | "amber" }) {
  const tint = accent === "green" ? "bg-green-50 text-green-600" : accent === "amber" ? "bg-amber-50 text-amber-600" : "bg-brand-soft text-brand";
  return (
    <div className="border border-gray-200 rounded-xl p-3 bg-white">
      <span className={`w-8 h-8 rounded-lg grid place-items-center mb-2 ${tint}`}><Icon className="w-4 h-4" /></span>
      <div className="text-2xl font-semibold text-gray-900 leading-none">{value}</div>
      <div className="text-[11px] text-gray-500 mt-1">{label}</div>
    </div>
  );
}

function PropertiesPanel({ spec, owner }: { spec: Spec | null; owner: string }) {
  const nSrc = spec?.sources?.length ?? (spec?.source_asset_id ? 1 : 0);
  const nTgt = spec?.targets?.length ?? (spec?.target_asset_id ? 1 : 0);
  return (
    <div className="space-y-3 text-sm">
      <h3 className="font-semibold text-gray-800">Mapping Properties</h3>
      <Field label="Mapping Name" value={spec?.name ?? "New Mapping"} />
      <Field label="Status" value={spec?.status ?? "Draft"} />
      <Field label="Source tables" value={nSrc ? `${nSrc} table${nSrc > 1 ? "s" : ""}` : "—"} />
      <Field label="Target tables" value={nTgt ? `${nTgt} table${nTgt > 1 ? "s" : ""}` : "—"} />
      {spec?.joins?.length ? <Field label="Joins" value={`${spec.joins.length} proposed`} /> : null}
      <Field label="Owner" value={owner} />
      <Field label="Version" value={`${spec?.version_no ?? 1}.0 (${spec?.status ?? "Draft"})`} />
    </div>
  );
}
function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-xs text-gray-500">{label}</div>
      <div className="text-gray-800">{value}</div>
    </div>
  );
}

// AI Assistant rail (matches MF_Mapping_Studio_AI_Assistant wireframe).
function AiAssistantPanel({
  onSuggest,
  onOptimize,
  onValidate,
  onDocument,
  onAgenticValidate,
  onFindSimilar,
  busy,
  suggestedCount,
  sourceName,
  targetName,
  greetingName,
}: {
  onSuggest: () => void;
  onOptimize: () => void;
  onValidate: () => void;
  onDocument: () => void;
  onAgenticValidate: () => void;
  onFindSimilar: () => void;
  busy: string | null;
  suggestedCount: number;
  sourceName?: string;
  targetName?: string;
  greetingName: string;
}) {
  const actions = [
    { icon: Sparkles, title: "Suggest mappings", sub: "Recommend mappings for unmapped columns", onClick: onSuggest },
    { icon: Wand2, title: "Optimize transformations", sub: "Review and optimize transformation logic", onClick: onOptimize },
    { icon: CheckCircle2, title: "Validate mapping", sub: "Check for data quality and rule coverage", onClick: onValidate },
    { icon: FileCheck, title: "Generate documentation", sub: "Create mapping documentation", onClick: onDocument },
    { icon: FlaskConical, title: "Agentic Mapping Validation", sub: "Test the mapping end-to-end on a real pipeline", onClick: onAgenticValidate },
    { icon: Search, title: "Find similar mappings", sub: "Search by table & column metadata", onClick: onFindSimilar },
  ];
  return (
    <div>
      <div className="flex items-center gap-2 mb-1">
        <Sparkles className="w-4 h-4 text-brand" />
        <span className="font-semibold text-gray-800">AI Assistant</span>
        <span className="text-[10px] bg-purple-100 text-purple-700 px-1.5 rounded">BETA</span>
      </div>
      <p className="text-sm text-gray-600 mb-3">Hi {greetingName}! 👋 How can I help you with this mapping?</p>
      {suggestedCount > 0 && (
        <div className="text-xs text-green-700 bg-green-50 rounded px-2 py-1 mb-3">{suggestedCount} suggestions ready — review on the canvas.</div>
      )}
      <div className="space-y-2">
        {actions.map((a) => (
          <button
            key={a.title}
            onClick={a.onClick}
            disabled={!!busy}
            className="w-full text-left border border-gray-200 rounded-lg px-3 py-2 hover:border-brand/40 hover:bg-brand-soft/30 disabled:opacity-50"
          >
            <div className="flex items-center gap-2">
              <a.icon className="w-4 h-4 text-brand shrink-0" />
              <span className="text-sm font-medium text-gray-800">{a.title}</span>
            </div>
            <div className="text-xs text-gray-500 ml-6">{a.sub}</div>
          </button>
        ))}
      </div>

      <div className="mt-4 border-t border-gray-100 pt-3">
        <div className="text-xs font-medium text-gray-500 mb-2">Context</div>
        <Field label="Source" value={sourceName ?? "—"} />
        <Field label="Target" value={targetName ?? "—"} />
      </div>

      <div className="mt-3 relative">
        <input className="w-full border border-gray-200 rounded-lg pl-3 pr-9 py-2 text-sm" placeholder="Ask anything about this mapping…" />
      </div>
      {busy && <p className="text-xs text-gray-400 mt-2">{busy}</p>}
      <p className="text-[11px] text-gray-400 mt-2">AI responses may be inaccurate. Please review before applying.</p>
    </div>
  );
}

// --- Optimize Transformations sub-view --------------------------------------
// Lists AI-proposed, sqlglot-validated optimizations. Apply stages the rewrite
// on the canvas immediately (optimistic); Undo reverts until saved; Save
// persists every applied edit through the maker-checker curate(edit) path.
const KIND_STYLE: Record<string, string> = {
  merge: "bg-purple-100 text-purple-700",
  simplify: "bg-blue-100 text-blue-700",
  cast: "bg-amber-100 text-amber-700",
  readability: "bg-emerald-100 text-emerald-700",
  other: "bg-gray-100 text-gray-600",
};
const IMPACT_STYLE: Record<string, string> = {
  high: "text-red-600",
  medium: "text-amber-600",
  low: "text-gray-400",
};

function OptimizePanel({ onBack }: { onBack: () => void }) {
  const { spec, busy, optimizations, appliedOpts, optDirty, optSavedCount, optimize, clearOptimizations, applyOptimization, rejectOptimization, undoOptimization, saveOptimizations } = useStore();
  const appliedIds = new Set(appliedOpts.map((e) => e.optId));

  // Auto-run the review the first time the panel is opened for this spec.
  useEffect(() => {
    if (spec && optimizations === null && !busy) optimize();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spec?.id]);

  const list = optimizations ?? [];
  const running = busy === "Reviewing transformations…";
  const saving = busy === "Saving optimizations…";

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-200 flex items-center gap-2">
        <button onClick={onBack} className="p-1 -ml-1 text-gray-400 hover:text-gray-600"><ArrowLeft className="w-4 h-4" /></button>
        <Wand2 className="w-4 h-4 text-brand" />
        <span className="font-semibold text-gray-800 text-sm">Optimize Transformations</span>
        <button onClick={() => optimize()} disabled={!!busy} title="Re-review" className="ml-auto p-1 text-gray-400 hover:text-brand disabled:opacity-40">
          <RefreshCw className={`w-4 h-4 ${running ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <p className="text-xs text-gray-500">
          The assistant reviewed this mapping's transformations. Each suggestion below is validated to preserve output semantics — apply the ones you want, then Save.
        </p>

        {running && <div className="text-sm text-gray-400 py-6 text-center">Reviewing transformations…</div>}

        {!running && list.length === 0 && (
          <div className="text-center py-8">
            <CheckCircle2 className="w-8 h-8 text-green-500 mx-auto mb-2" />
            {optSavedCount > 0 ? (
              <>
                <p className="text-sm text-gray-600">Saved {optSavedCount} optimization{optSavedCount > 1 ? "s" : ""}.</p>
                <p className="text-xs text-gray-400 mt-1">Applied to the mapping. Re-review for more, or click Done.</p>
              </>
            ) : (
              <>
                <p className="text-sm text-gray-600">No optimizations found.</p>
                <p className="text-xs text-gray-400 mt-1">The current transformations already look clean.</p>
              </>
            )}
          </div>
        )}

        {!running && list.map((o) => (
          <OptCard
            key={o.id}
            o={o}
            applied={appliedIds.has(o.id)}
            busy={!!busy}
            onApply={() => applyOptimization(o)}
            onReject={() => rejectOptimization(o.id)}
          />
        ))}
      </div>

      {/* Footer: Undo / Save */}
      <div className="border-t border-gray-200 p-3 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="text-gray-500">{appliedOpts.length} applied{optDirty ? " · unsaved" : ""}</span>
          <button onClick={undoOptimization} disabled={!appliedOpts.length || !!busy} className="inline-flex items-center gap-1 text-gray-600 hover:text-gray-900 disabled:opacity-30">
            <Undo2 className="w-3.5 h-3.5" /> Undo
          </button>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => { clearOptimizations(); onBack(); }} className="flex-1 justify-center">Done</Button>
          <Button onClick={saveOptimizations} disabled={!optDirty || !!busy} className="flex-1 justify-center">
            {saving ? "Saving…" : `Save${appliedOpts.length ? ` (${appliedOpts.length})` : ""}`}
          </Button>
        </div>
      </div>
    </div>
  );
}

function OptCard({ o, applied, busy, onApply, onReject }: { o: Optimization; applied: boolean; busy: boolean; onApply: () => void; onReject: () => void }) {
  const mergeCount = (o.merged_mapping_ids?.length ?? 0) + 1;
  const isMerge = (o.merged_mapping_ids?.length ?? 0) > 0;
  return (
    <div className={`border rounded-lg p-3 ${applied ? "border-green-300 bg-green-50/40" : "border-gray-200"}`}>
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <div className="min-w-0">
          <div className="text-sm font-medium text-gray-800 truncate">{o.title}</div>
          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
            <span className={`text-[10px] px-1.5 py-0.5 rounded capitalize ${KIND_STYLE[o.kind] ?? KIND_STYLE.other}`}>{o.kind}</span>
            {isMerge && <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-100 text-purple-700 font-medium">{mergeCount} → 1</span>}
            <span className="text-[10px] text-gray-400">on <span className="font-mono text-gray-600">{o.target_field}</span></span>
            <span className={`text-[10px] font-medium capitalize ${IMPACT_STYLE[o.impact] ?? ""}`}>{o.impact} impact</span>
          </div>
        </div>
      </div>
      {o.rationale && <p className="text-xs text-gray-500 mb-2">{o.rationale}</p>}
      <div className="space-y-1 mb-2">
        <div className="font-mono text-[10px] text-gray-500 bg-gray-50 border border-gray-100 rounded p-1.5 break-all line-through decoration-gray-300">{o.before}</div>
        <div className="flex items-center gap-1 text-gray-300"><ArrowRight className="w-3 h-3 rotate-90" /></div>
        <div className="font-mono text-[10px] text-gray-800 bg-emerald-50 border border-emerald-100 rounded p-1.5 break-all">{o.after}</div>
      </div>
      {applied ? (
        <div className="flex items-center gap-1 text-xs text-green-700"><Check className="w-3.5 h-3.5" /> Applied — visible on the canvas</div>
      ) : (
        <div className="flex gap-2">
          <button onClick={onApply} disabled={busy} className="flex-1 inline-flex items-center justify-center gap-1 text-xs px-2 py-1.5 rounded bg-brand text-white hover:bg-brand-hover disabled:opacity-40">
            <Check className="w-3 h-3" /> Apply
          </button>
          <button onClick={onReject} disabled={busy} className="flex-1 inline-flex items-center justify-center gap-1 text-xs px-2 py-1.5 rounded bg-white border border-gray-300 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
            <X className="w-3 h-3" /> Reject
          </button>
        </div>
      )}
    </div>
  );
}

// --- Validate Mapping sub-view ----------------------------------------------
// AI proposes post-transformation data-quality checks for the target columns,
// each sqlglot-validated. Shows rule coverage, lets you pick which to keep, and
// Save persists the selected checks into the DQ Library (Validation screen).
const VAL_KIND_STYLE: Record<string, string> = {
  completeness: "bg-blue-100 text-blue-700",
  validity: "bg-emerald-100 text-emerald-700",
  accuracy: "bg-amber-100 text-amber-700",
  uniqueness: "bg-purple-100 text-purple-700",
  consistency: "bg-cyan-100 text-cyan-700",
  business_rule: "bg-rose-100 text-rose-700",
};
const VAL_SEV_STYLE: Record<string, string> = {
  critical: "text-red-600",
  high: "text-orange-600",
  medium: "text-amber-600",
  low: "text-gray-400",
};

// Group validation proposals by their target table, preserving first-seen order.
function groupByTable(list: ValidationProposal[]): [string, ValidationProposal[]][] {
  const m = new Map<string, ValidationProposal[]>();
  for (const v of list) {
    const t = v.target_table || v.dataset || "target";
    (m.get(t) ?? m.set(t, []).get(t)!).push(v);
  }
  return [...m.entries()];
}

function ValidatePanel({ onBack }: { onBack: () => void }) {
  const { spec, busy, validations, valCoverage, valSelected, valSavedCount, validate, clearValidations, toggleValidation, rejectValidation, saveValidations } = useStore();

  // Auto-run the review the first time the panel opens for this spec.
  useEffect(() => {
    if (spec && validations === null && !busy) validate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spec?.id]);

  const list = validations ?? [];
  const running = busy === "Reviewing data quality…";
  const saving = busy === "Saving validations…";
  const cov = valCoverage;
  const pct = cov && cov.total ? Math.round((cov.covered / cov.total) * 100) : 0;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-200 flex items-center gap-2">
        <button onClick={onBack} className="p-1 -ml-1 text-gray-400 hover:text-gray-600"><ArrowLeft className="w-4 h-4" /></button>
        <ShieldCheck className="w-4 h-4 text-brand" />
        <span className="font-semibold text-gray-800 text-sm">Validate Mapping</span>
        <button onClick={() => validate()} disabled={!!busy} title="Re-review" className="ml-auto p-1 text-gray-400 hover:text-brand disabled:opacity-40">
          <RefreshCw className={`w-4 h-4 ${running ? "animate-spin" : ""}`} />
        </button>
      </div>

      {/* Coverage bar */}
      {cov && (
        <div className="px-4 py-2.5 border-b border-gray-100">
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="text-gray-500">Rule coverage</span>
            <span className="text-gray-700 font-medium">{cov.covered} of {cov.total} target columns</span>
          </div>
          <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full rounded-full" style={{ width: `${pct}%`, background: pct >= 80 ? "#16a34a" : pct >= 40 ? "#d97706" : "#dc2626" }} />
          </div>
        </div>
      )}

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <p className="text-xs text-gray-500">
          Suggested data-quality checks to run on the target <span className="font-medium">after</span> the transformation. Pick the ones to keep — Save adds them to the Validation library.
        </p>

        {running && <div className="text-sm text-gray-400 py-6 text-center">Reviewing data quality…</div>}

        {!running && list.length === 0 && (
          <div className="text-center py-8">
            <ShieldCheck className="w-8 h-8 text-green-500 mx-auto mb-2" />
            {valSavedCount > 0 ? (
              <>
                <p className="text-sm text-gray-600">Saved {valSavedCount} validation{valSavedCount > 1 ? "s" : ""}.</p>
                <p className="text-xs text-gray-400 mt-1">Added to the DQ library — see the Validation screen. Re-review for more, or click Done.</p>
              </>
            ) : (
              <>
                <p className="text-sm text-gray-600">No checks proposed.</p>
                <p className="text-xs text-gray-400 mt-1">The target columns already look well-covered.</p>
              </>
            )}
          </div>
        )}

        {!running && groupByTable(list).map(([table, items]) => (
          <div key={table} className="space-y-2">
            {groupByTable(list).length > 1 && (
              <div className="flex items-center gap-1.5 pt-1">
                <Table2 className="w-3 h-3 text-purple-500" />
                <span className="text-[11px] font-semibold text-gray-600 uppercase tracking-wide">{table}</span>
                <span className="text-[10px] text-gray-400">· {items.length}</span>
              </div>
            )}
            {items.map((v) => (
              <ValidationCard
                key={v.id}
                v={v}
                selected={valSelected.includes(v.id)}
                busy={!!busy}
                onToggle={() => toggleValidation(v.id)}
                onReject={() => rejectValidation(v.id)}
              />
            ))}
          </div>
        ))}
      </div>

      {/* Footer: Save selected */}
      <div className="border-t border-gray-200 p-3 space-y-2">
        <div className="text-xs text-gray-500">{valSelected.length} selected to save</div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => { clearValidations(); onBack(); }} className="flex-1 justify-center">Done</Button>
          <Button onClick={saveValidations} disabled={!valSelected.length || !!busy} className="flex-1 justify-center">
            {saving ? "Saving…" : `Save${valSelected.length ? ` (${valSelected.length})` : ""}`}
          </Button>
        </div>
      </div>
    </div>
  );
}

function ValidationCard({ v, selected, busy, onToggle, onReject }: { v: ValidationProposal; selected: boolean; busy: boolean; onToggle: () => void; onReject: () => void }) {
  return (
    <div className={`border rounded-lg p-3 ${selected ? "border-brand/40 bg-brand-soft/20" : "border-gray-200"}`}>
      <div className="flex items-start gap-2 mb-1.5">
        <input type="checkbox" checked={selected} onChange={onToggle} disabled={busy} className="mt-0.5 accent-brand" />
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium text-gray-800 truncate">{v.name}</div>
          <div className="flex items-center gap-2 mt-0.5 flex-wrap">
            <span className={`text-[10px] px-1.5 py-0.5 rounded capitalize ${VAL_KIND_STYLE[v.rule_type] ?? "bg-gray-100 text-gray-600"}`}>{v.rule_type.replace("_", " ")}</span>
            <span className={`text-[10px] font-medium capitalize ${VAL_SEV_STYLE[v.severity] ?? ""}`}>{v.severity}</span>
            <span className="text-[10px] text-gray-400">on <span className="font-mono text-gray-600">{v.target_field}</span></span>
            {v.reused_rule_code ? (
              <span className="text-[10px] bg-blue-50 text-blue-700 border border-blue-100 px-1.5 py-0.5 rounded" title={`Reused Rule Library rule: ${v.reused_rule_name ?? v.reused_rule_code}`}>↻ Reused</span>
            ) : v.is_new_rule ? (
              <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-100 px-1.5 py-0.5 rounded">✦ New</span>
            ) : null}
            {v.covered && <span className="text-[10px] text-gray-400">· already has a rule</span>}
          </div>
        </div>
        <button onClick={onReject} disabled={busy} title="Dismiss" className="text-gray-300 hover:text-gray-500 shrink-0"><X className="w-3.5 h-3.5" /></button>
      </div>
      {v.rationale && <p className="text-xs text-gray-500 mb-2 ml-6">{v.rationale}</p>}
      <div className="ml-6 font-mono text-[10px] text-gray-800 bg-gray-50 border border-gray-100 rounded p-1.5 break-all">{v.logic}</div>
    </div>
  );
}

// --- Find Similar Mappings sub-view -----------------------------------------
// Ranks existing mappings by table + column metadata overlap with the current one.
function SimilarPanel({ onBack }: { onBack: () => void }) {
  const nav = useNavigate();
  const { spec, similar, similarBusy, findSimilar, clearSimilar } = useStore();

  useEffect(() => {
    if (spec && similar === null && !similarBusy) findSimilar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spec?.id]);

  const list = similar ?? [];
  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-gray-200 flex items-center gap-2">
        <button onClick={onBack} className="p-1 -ml-1 text-gray-400 hover:text-gray-600"><ArrowLeft className="w-4 h-4" /></button>
        <Search className="w-4 h-4 text-brand" />
        <span className="font-semibold text-gray-800 text-sm">Similar Mappings</span>
        <button onClick={() => findSimilar()} disabled={similarBusy} title="Re-search" className="ml-auto p-1 text-gray-400 hover:text-brand disabled:opacity-40">
          <RefreshCw className={`w-4 h-4 ${similarBusy ? "animate-spin" : ""}`} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        <p className="text-xs text-gray-500">Existing mappings ranked by shared table & column metadata — reuse a proven mapping instead of starting over.</p>

        {similarBusy && <div className="text-sm text-gray-400 py-6 text-center">Searching by metadata…</div>}

        {!similarBusy && list.length === 0 && (
          <div className="text-center py-8">
            <Search className="w-8 h-8 text-gray-300 mx-auto mb-2" />
            <p className="text-sm text-gray-600">No similar mappings found.</p>
            <p className="text-xs text-gray-400 mt-1">Nothing else shares this mapping's columns or systems yet.</p>
          </div>
        )}

        {!similarBusy && list.map((m) => (
          <button
            key={m.id}
            onClick={() => { clearSimilar(); nav(`/mappings/${m.id}`); }}
            className="w-full text-left border border-gray-200 rounded-lg p-3 hover:border-brand/40 hover:bg-brand-soft/20"
          >
            <div className="flex items-center justify-between gap-2 mb-1">
              <span className="text-sm font-medium text-gray-800 truncate">{m.name}</span>
              <span className="text-[10px] text-gray-400 shrink-0">{Math.round(m.score * 100)}% match</span>
            </div>
            <div className="h-1 bg-gray-100 rounded-full overflow-hidden mb-1.5">
              <div className="h-full rounded-full bg-brand" style={{ width: `${Math.min(100, Math.round(m.score * 100))}%` }} />
            </div>
            <div className="flex items-center gap-2 mb-1">
              <StatusBadge status={m.status} />
              {m.source_system && <span className="text-[10px] text-gray-400">{m.source_system} → {m.target_system}</span>}
            </div>
            <p className="text-[11px] text-gray-500">{m.why}</p>
            {m.shared_target_columns.length > 0 && (
              <div className="mt-1 flex flex-wrap gap-1">
                {m.shared_target_columns.slice(0, 6).map((c) => (
                  <span key={c} className="text-[10px] font-mono bg-gray-100 text-gray-600 rounded px-1">{c}</span>
                ))}
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
