# Databricks notebook source
# MAGIC %md
# MAGIC # Mapping Factory — Agentic Mapping Test Pipeline (generic, config-driven)
# MAGIC
# MAGIC A single reusable **Spark Declarative Pipeline** that tests any mapping without
# MAGIC being redeployed. Each test run:
# MAGIC   1. writes one config row to `mapping_factory.mf_test_config` (keyed by `run_id`)
# MAGIC   2. starts an update of THIS pipeline with the `run_id` parameter
# MAGIC
# MAGIC The config carries the input (dummy-source) table, the per-target-column
# MAGIC transform SQL (the deterministically-compiled expressions), and the
# MAGIC data-quality rules (SQL booleans, TRUE = row passes). The pipeline builds:
# MAGIC   - `<target>_target`     — the transformed target rows
# MAGIC   - `<target>_dq`         — target rows + a `_dq` struct (per-rule pass + all_passed)
# MAGIC
# MAGIC No dataset names are hardcoded; everything comes from the config row.

# COMMAND ----------

import json

import pyspark.pipelines as dlt
from pyspark.sql import functions as F

# The run_id parameter selects which config row to build. Passed via the pipeline
# update's configuration (spark conf `mf.run_id`), defaulting to the latest row.
try:
    RUN_ID = spark.conf.get("mf.run_id")  # noqa: F821 — spark is provided by the runtime
except Exception:
    RUN_ID = None

CATALOG = "pritam_demo_workspace_catalog"
SCHEMA = "mapping_factory"
CONFIG_TABLE = f"{CATALOG}.{SCHEMA}.mf_test_config"


def _load_config():
    """Read the config row for this run (or the most recent one).

    `config_json` is base64-encoded to survive the SQL-literal round-trip
    (transform SQL contains single quotes + backslashes that otherwise get
    mangled going app → INSERT → table → here).
    """
    import base64

    df = spark.read.table(CONFIG_TABLE)  # noqa: F821
    if RUN_ID:
        df = df.filter(F.col("run_id") == RUN_ID)
    row = df.orderBy(F.col("created_at").desc()).limit(1).collect()
    if not row:
        raise ValueError(f"No mapping-test config found (run_id={RUN_ID}) in {CONFIG_TABLE}")
    raw = row[0]["config_json"]
    try:
        decoded = base64.b64decode(raw).decode()
        return json.loads(decoded)
    except Exception:
        # Backward-compat: plain JSON if not base64.
        return json.loads(raw)


_CFG = _load_config()
_INPUT_TABLE = _CFG["input_table"]                 # fully-qualified dummy source table
_TARGET = _CFG["target_name"]                       # e.g. dim_customer_360
_COLUMNS = _CFG["columns"]                           # [{target_field, sql}]
_VALIDATIONS = _CFG.get("validations", [])           # [{name, column, logic}] TRUE = pass

_target_tbl = f"{_TARGET}_target"
_dq_tbl = f"{_TARGET}_dq"

print(f"[MappingTest] run_id={RUN_ID} input={_INPUT_TABLE} target={_TARGET} "
      f"cols={len(_COLUMNS)} rules={len(_VALIDATIONS)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Target table — apply the compiled transform expressions

# COMMAND ----------


@dlt.table(
    name=_target_tbl,
    comment=f"Transformed target for mapping test (run {RUN_ID})",
    table_properties={"quality": "silver", "mapping_target": _TARGET},
)
def build_target():
    src = spark.read.table(_INPUT_TABLE)  # noqa: F821
    src.createOrReplaceTempView("mf_input")
    select_items = [f"{c['sql']} AS `{c['target_field']}`" for c in _COLUMNS if c.get("sql")]
    return spark.sql(f"SELECT {', '.join(select_items)} FROM mf_input")  # noqa: F821


# COMMAND ----------

# MAGIC %md
# MAGIC ## DQ table — attach per-rule pass/fail as a `_dq` struct
# MAGIC Also declares SDP expectations so the pipeline's own data-quality metrics
# MAGIC reflect the mapping's validation rules.

# COMMAND ----------

@dlt.table(
    name=_dq_tbl,
    comment=f"Target rows + per-rule DQ results for mapping test (run {RUN_ID})",
    table_properties={"quality": "silver", "mapping_target": _TARGET},
)
def build_dq():
    # NOTE: dlt.read + expression compilation must happen HERE (execution time),
    # not at module top level — at graph-definition time the target table does
    # not yet exist. Each rule is checked individually so one malformed predicate
    # (the config is machine/LLM-generated) is skipped, never fatal.
    df = dlt.read(_target_tbl)
    checks = []
    all_passed = None
    for i, v in enumerate(_VALIDATIONS):
        logic = v.get("logic")
        if not logic:
            continue
        name = v.get("name") or f"rule_{i}"
        try:
            cond = F.coalesce(F.expr(logic), F.lit(False))  # NULL predicate -> fail, not NULL
            # Force resolution now so a bad rule raises here and is skipped.
            df.select(cond.alias("_probe")).limit(0).collect()
        except Exception as ex:  # noqa: BLE001
            print(f"[MappingTest] skipping unparseable rule '{name}': {str(ex)[:160]}")
            continue
        checks.append(cond.alias(name))
        all_passed = cond if all_passed is None else (all_passed & cond)
    if not checks:
        return df.withColumn("_dq", F.struct(F.lit(True).alias("all_passed")))
    return df.withColumn("_dq", F.struct(*checks)).withColumn("_dq_all_passed", all_passed)
