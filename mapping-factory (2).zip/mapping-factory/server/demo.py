"""Complex demo scenario — a wide, messy Customer-360 mapping.

A realistic banking landing-zone table (`src_customer_raw`, ~24 all-string dirty
columns) mapped onto a conformed dimension (`dim_customer_360`, ~24 typed columns).
Unlike the 4-column golden path, most target columns need COMPOUND, multi-operation
derivations — trim+initcap+concat for names, regex+cast for ids/phones, cast+case
for bands/flags — so the canvas shows real complexity and the "Optimize
transformations" action has genuine merges/simplifications to propose.

Everything stays REAL: the source is a live UC table (introspected, not mocked), and
every expression here has been verified to both run on the warehouse and pass the
deterministic compiler's parse + source-column + type checks. Mappings are seeded as
`{"op": "expr", ...}` transforms (the custom-merged op) in the AI-SUGGESTED state, so
the demo opens fresh and the reviewer drives the per-transformation approve/reject flow.
"""
from __future__ import annotations

from typing import Any
from uuid import UUID

import sqlglot
from sqlglot import exp
from psycopg.types.json import Json
from psycopg_pool import ConnectionPool

from server import config, ingest, repo

# Real UC landing-zone table (created + populated with dirty sample rows).
SOURCE_FQN = f"{config.UC_CATALOG}.{config.UC_SCHEMA}.src_customer_raw"
SOURCE_NAME = "src_customer_raw"

TARGET_NAME = "dim_customer_360"
# Conformed dimension the messy source is standardized into.
TARGET_DDL = """CREATE TABLE dim_customer_360 (
  customer_id BIGINT NOT NULL,
  full_name STRING,
  email_address STRING,
  email_domain STRING,
  phone_e164 STRING,
  birth_date DATE,
  signup_date DATE,
  balance_amount DOUBLE,
  credit_score INT,
  account_status STRING,
  is_active BOOLEAN,
  country_code STRING,
  full_address STRING,
  city STRING,
  postal_code STRING,
  annual_income DOUBLE,
  income_band STRING,
  is_high_risk BOOLEAN,
  customer_segment STRING,
  num_products INT,
  marketing_opt_in BOOLEAN,
  currency_code STRING,
  source_system STRING,
  record_hash STRING
)"""

# target_field -> compound Spark SQL expression over source columns. Deliberately
# messy/nested (redundant COALESCE, double casts, un-merged steps) so the Optimizer
# has real material. Verified on the warehouse + through the compiler.
MAPPINGS: dict[str, str] = {
    "customer_id": "CAST(REGEXP_REPLACE(TRIM(customer_ref), '[^0-9]', '') AS BIGINT)",
    "full_name": (
        "TRIM(REGEXP_REPLACE(CONCAT_WS(' ', INITCAP(TRIM(first_name)), "
        "INITCAP(TRIM(COALESCE(middle_name, ''))), INITCAP(TRIM(last_name))), '\\\\s+', ' '))"
    ),
    "email_address": "LOWER(TRIM(email))",
    "email_domain": "LOWER(SUBSTRING(TRIM(email), INSTR(TRIM(email), '@') + 1))",
    "phone_e164": "CONCAT('+', REGEXP_REPLACE(REGEXP_REPLACE(TRIM(phone), '[^0-9]', ''), '^00', ''))",
    "birth_date": (
        "COALESCE(TRY_TO_DATE(REGEXP_REPLACE(TRIM(date_of_birth), '[/.]', '-'), 'yyyy-MM-dd'), "
        "TRY_TO_DATE(TRIM(date_of_birth)))"
    ),
    "signup_date": "TO_DATE(TRIM(signup_timestamp), 'yyyy-MM-dd HH:mm:ss')",
    "balance_amount": "CAST(REGEXP_REPLACE(TRIM(account_balance), '[^0-9.]', '') AS DOUBLE)",
    "credit_score": "CAST(NULLIF(TRIM(credit_score), '') AS INT)",
    "account_status": "UPPER(TRIM(account_status))",
    "is_active": "CASE WHEN UPPER(TRIM(account_status)) = 'ACTIVE' THEN TRUE ELSE FALSE END",
    "country_code": "UPPER(TRIM(country_code))",
    "full_address": (
        "CONCAT_WS(', ', TRIM(address_line1), NULLIF(TRIM(COALESCE(address_line2, '')), ''), "
        "INITCAP(TRIM(city)), UPPER(TRIM(COALESCE(state_province, ''))))"
    ),
    "city": "INITCAP(TRIM(city))",
    "postal_code": "UPPER(REGEXP_REPLACE(TRIM(postal_code), '\\\\s+', ''))",
    "annual_income": "CAST(TRIM(annual_income) AS DOUBLE)",
    "income_band": (
        "CASE WHEN CAST(TRIM(annual_income) AS DOUBLE) >= 100000 THEN 'HIGH' "
        "WHEN CAST(TRIM(annual_income) AS DOUBLE) >= 75000 THEN 'MID' ELSE 'STANDARD' END"
    ),
    "is_high_risk": "CASE WHEN LOWER(TRIM(risk_indicator)) IN ('y','yes','1','true') THEN TRUE ELSE FALSE END",
    "customer_segment": "UPPER(TRIM(customer_segment))",
    "num_products": "COALESCE(CAST(NULLIF(TRIM(num_products), '') AS INT), 0)",
    "marketing_opt_in": "CASE WHEN LOWER(TRIM(marketing_consent)) IN ('y','yes','1','true') THEN TRUE ELSE FALSE END",
    "currency_code": "UPPER(TRIM(currency))",
    "source_system": "UPPER(TRIM(source_system))",
    "record_hash": "MD5(CONCAT_WS('|', TRIM(customer_ref), LOWER(TRIM(email))))",
}

# Per-column confidence, so the wide canvas isn't a flat wall of one number.
_CONF: dict[str, float] = {
    "customer_id": 0.97, "full_name": 0.88, "email_address": 0.99, "email_domain": 0.82,
    "phone_e164": 0.79, "birth_date": 0.74, "signup_date": 0.95, "balance_amount": 0.9,
    "credit_score": 0.93, "account_status": 0.98, "is_active": 0.91, "country_code": 0.99,
    "full_address": 0.72, "city": 0.94, "postal_code": 0.85, "annual_income": 0.9,
    "income_band": 0.8, "is_high_risk": 0.83, "customer_segment": 0.96, "num_products": 0.89,
    "marketing_opt_in": 0.87, "currency_code": 0.98, "source_system": 0.99, "record_hash": 0.76,
}


def _source_columns(expr_sql: str) -> list[str]:
    """Deterministically extract referenced source columns from an expression."""
    ast = sqlglot.parse_one(expr_sql, read="spark")
    # Preserve first-seen order for stable provenance display.
    seen: list[str] = []
    for c in ast.find_all(exp.Column):
        if c.name not in seen:
            seen.append(c.name)
    return seen


def build_complex_demo(pool: ConnectionPool, *, owner: str) -> dict[str, Any]:
    """Register the real source + conformed target, create a spec, and seed the
    compound mappings as AI-suggested `expr` transforms. Returns {source, target, spec}.

    Deterministic + real: the source is introspected from the live UC table; each
    expression's source columns are resolved via sqlglot. Idempotent enough for a
    demo (creates fresh assets + spec on each call).
    """
    # 1) Source — introspect the real UC landing table (no LLM, no mock).
    src_fields = ingest.fields_from_uc_table(SOURCE_FQN)
    source = repo.create_asset(
        pool,
        name=SOURCE_NAME,
        object_type="uc_table",
        role="source",
        created_by=owner,
        locator=SOURCE_FQN,
        fields=src_fields,
    )

    # 2) Target — parse the conformed DDL.
    tgt_fields = ingest.fields_from_ddl(TARGET_DDL)
    target = repo.create_asset(
        pool,
        name=TARGET_NAME,
        object_type="ddl",
        role="target",
        created_by=owner,
        fields=tgt_fields,
    )

    # 3) Spec.
    spec = repo.create_spec(
        pool,
        name="src_customer_raw → dim_customer_360",
        source_asset_id=source["id"],
        target_asset_id=target["id"],
        owner=owner,
    )

    # 4) Seed the compound mappings directly as AI suggestions, joining by name.
    src_by_name = {f["name"]: f for f in source["fields"]}
    tgt_by_name = {f["name"]: f for f in target["fields"]}
    _seed_mappings(pool, spec["id"], src_by_name, tgt_by_name)

    return {"source": source, "target": target, "spec": repo.get_spec(pool, spec["id"])}


def _seed_mappings(
    pool: ConnectionPool,
    spec_id: UUID,
    src_by_name: dict[str, dict],
    tgt_by_name: dict[str, dict],
) -> None:
    """Insert transform_rule + field_mapping rows as AI suggestions (fresh, unreviewed)."""
    from psycopg.rows import dict_row

    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            for target_field, expr_sql in MAPPINGS.items():
                tgt = tgt_by_name.get(target_field)
                if tgt is None:
                    continue
                src_names = [n for n in _source_columns(expr_sql) if n in src_by_name]
                src_ids = [src_by_name[n]["id"] for n in src_names]
                transform_spec = {"op": "expr", "expr": expr_sql}
                # Seed as AI SUGGESTIONS (not accepted) so the demo starts fresh —
                # the reviewer drives the per-transformation approve/reject flow.
                provenance = {
                    "origin": "AI",
                    "model_id": config.LLM_ENDPOINT,
                    "rationale": "Seeded complex-demo mapping (standardize landing-zone field).",
                    "source_field_names": src_names,
                }
                cur.execute(
                    """INSERT INTO mapping_factory.transform_rule (kind, spec_json, description)
                       VALUES ('spec', %s, %s) RETURNING id""",
                    (Json(transform_spec), f"Standardize {target_field}"),
                )
                rule_id = cur.fetchone()["id"]
                cur.execute(
                    """INSERT INTO mapping_factory.field_mapping
                       (spec_id, target_field_id, source_field_ids, transform_rule_id,
                        confidence, provenance, state)
                       VALUES (%s,%s,%s,%s,%s,%s,'suggested')""",
                    (
                        spec_id,
                        tgt["id"],
                        src_ids,
                        rule_id,
                        _CONF.get(target_field, 0.85),
                        Json(provenance),
                    ),
                )
        conn.commit()
