"""Environment + auth configuration.

Tri-mode auth: when running inside a Databricks App the runtime injects a service
principal (SP); when a USER hits the app, the runtime also forwards that user's
access token in the `x-forwarded-access-token` header (on-behalf-of / OBO); locally
we authenticate via a Databricks CLI profile.

HYBRID OBO model (this is deliberate — a blanket OBO switch would break shared
infrastructure that has no user context):
  * Request-time workspace/warehouse/Foundation-Model calls run AS THE LOGGED-IN
    USER when a forwarded token is present — so Unity Catalog / warehouse
    permissions are the user's, not the app SP's.
  * Infrastructure with no per-user context keeps the SP: the shared Lakebase
    connection pool, background threads (agentic validation, metadata indexing),
    and app startup (schema bootstrap).

The per-request user token is stashed in a contextvar by the app's middleware so
deep call sites (warehouse.execute, llm._client, …) transparently pick it up
without threading it through every signature. Empty contextvar (background thread,
startup, local) → SP/profile client. This is the one place that knows the mode.
"""
from __future__ import annotations

import functools
import os
from contextvars import ContextVar

from databricks.sdk import WorkspaceClient

# The Databricks Apps runtime sets DATABRICKS_APP_NAME; locally it is absent.
IS_DATABRICKS_APP: bool = bool(os.environ.get("DATABRICKS_APP_NAME"))

# Local dev profile (matches the workspace chosen in the plan).
LOCAL_PROFILE: str = os.environ.get("DATABRICKS_PROFILE", "fevm-pritam-demo-workspace")

# Per-request forwarded user token (OBO). Set by app middleware; empty elsewhere.
_USER_TOKEN: ContextVar[str | None] = ContextVar("mf_user_token", default=None)


def set_user_token(token: str | None) -> object:
    """Bind the current request's forwarded user token; returns a reset handle."""
    return _USER_TOKEN.set(token or None)


def reset_user_token(handle: object) -> None:
    try:
        _USER_TOKEN.reset(handle)  # type: ignore[arg-type]
    except Exception:  # noqa: BLE001 — best-effort reset across threads
        _USER_TOKEN.set(None)


def current_user_token() -> str | None:
    """The forwarded user token for the current request, or None (infra/local)."""
    return _USER_TOKEN.get()

# --- Slice configuration (overridable via env / app.yaml) --------------------
# Governed system-of-record (Unity Catalog + Delta).
UC_CATALOG: str = os.environ.get("MF_CATALOG", "pritam_demo_workspace_catalog")
UC_SCHEMA: str = os.environ.get("MF_SCHEMA", "mapping_factory")
# Serverless SQL warehouse used for all Delta reads/writes and SQL verification.
WAREHOUSE_ID: str = os.environ.get("MF_WAREHOUSE_ID", "cd54b9f16b2bf7ed")
# Foundation Model endpoint for AI auto-mapping (M3).
LLM_ENDPOINT: str = os.environ.get("MF_LLM_ENDPOINT", "databricks-claude-opus-4-7")


@functools.lru_cache(maxsize=1)
def get_sp_client() -> WorkspaceClient:
    """The APP's own client — service principal when deployed, CLI profile locally.

    Cached for the process lifetime. Use this for INFRASTRUCTURE that has no
    per-user context: the Lakebase pool, background threads, startup bootstrap.
    """
    if IS_DATABRICKS_APP:
        return WorkspaceClient()  # auto-injected service principal
    return WorkspaceClient(profile=LOCAL_PROFILE)


@functools.lru_cache(maxsize=32)
def _user_client(token: str) -> WorkspaceClient:
    """A WorkspaceClient authenticated as the USER (OBO). Cached per token so we
    don't rebuild it for every call within a request. host from the app env."""
    return WorkspaceClient(host=_raw_host(), token=token, auth_type="pat")


def get_workspace_client() -> WorkspaceClient:
    """The client to use for the CURRENT operation.

    Request-time with a forwarded user token (deployed) → a USER-scoped client
    (OBO). Otherwise (background thread, startup, local dev) → the app SP/profile
    client. So the same downstream code runs as the user when there's a user, and
    as the app when there isn't.
    """
    token = current_user_token()
    if token and IS_DATABRICKS_APP:
        return _user_client(token)
    return get_sp_client()


def _raw_host() -> str:
    """Workspace host URL with https:// (Apps injects a bare hostname → normalize)."""
    if IS_DATABRICKS_APP:
        host = os.environ.get("DATABRICKS_HOST", "")
        if host and not host.startswith("http"):
            host = f"https://{host}"
        if host:
            return host
    return get_sp_client().config.host


def get_workspace_host() -> str:
    """Workspace host URL, always with an https:// scheme."""
    return _raw_host()


def get_bearer_token() -> str:
    """A bearer token for OpenAI-compatible / REST calls (Foundation Model, KA).

    Prefers the forwarded USER token (OBO) when present so FM/serving calls run as
    the user; otherwise falls back to the app SP/profile credential. Works for both
    OAuth (local U2M, token is None → authenticate()) and injected-SP auth.
    """
    token = current_user_token()
    if token and IS_DATABRICKS_APP:
        return token
    if IS_DATABRICKS_APP:
        env_token = os.environ.get("DATABRICKS_TOKEN")
        if env_token:
            return env_token
    auth_headers = get_sp_client().config.authenticate()
    if auth_headers and "Authorization" in auth_headers:
        return auth_headers["Authorization"].replace("Bearer ", "")
    raise RuntimeError("Could not obtain a bearer token from the Databricks SDK config.")
