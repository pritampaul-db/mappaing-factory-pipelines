"""Mapping Factory — FastAPI entry point.

Serves the React SPA (built to frontend/dist) and the /api surface. The
Lakebase connection pool is opened in the lifespan hook when configured;
until M1 provisions Lakebase, the app still boots and /api/health works.
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from server import config


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Open the Lakebase pool if it has been configured (M1+). Guarded so the
    # scaffold still boots when Lakebase env is absent.
    from server import db

    pool = None
    if db.is_configured():
        db.pool.open(wait=True, timeout=30.0)
        pool = db.pool
        # Idempotent schema bootstrap. Best-effort: the tables normally already
        # exist, and the running identity may lack DDL rights. A bootstrap
        # failure must NOT crash the app — log and continue; real requests will
        # surface any genuinely-missing-table error.
        try:
            from server import repo

            schema_path = os.path.join(os.path.dirname(__file__), "server", "sql", "lakebase_schema.sql")
            with open(schema_path) as fh:
                repo.apply_schema(db.pool, fh.read())
        except Exception as exc:  # noqa: BLE001
            logging.getLogger("mapping_factory").warning("schema bootstrap skipped: %s", exc)
        # Bootstrap the first administrator when the admin list is empty, so there is
        # always someone who can manage admins + bypass maker-checker. Configurable
        # via MF_BOOTSTRAP_ADMIN; defaults to the app owner's identity.
        try:
            from server import repo_admin

            repo_admin.ensure_bootstrap_admin(
                db.pool, os.environ.get("MF_BOOTSTRAP_ADMIN", "pritam.paul@databricks.com")
            )
        except Exception as exc:  # noqa: BLE001
            logging.getLogger("mapping_factory").warning("admin bootstrap skipped: %s", exc)
    yield
    if pool is not None:
        pool.close()


app = FastAPI(title="Mapping Factory", version="0.1.0", lifespan=lifespan)


@app.middleware("http")
async def _obo_user_token(request, call_next):
    """On-behalf-of-user: bind the forwarded user token for this request so
    request-time workspace/warehouse/FM calls run AS THE USER (OBO). Absent
    (local dev, or before the platform injects it) → downstream falls back to the
    app service principal. The contextvar propagates into FastAPI's sync-handler
    threadpool but NOT into background threads, which correctly keep the SP.
    """
    token = request.headers.get("x-forwarded-access-token")
    handle = config.set_user_token(token)
    try:
        return await call_next(request)
    finally:
        config.reset_user_token(handle)


@app.get("/api/health")
def health() -> JSONResponse:
    """Liveness + auth check: confirms we can reach the workspace as some identity."""
    from server import db

    info = {
        "status": "ok",
        "mode": "databricks_app" if config.IS_DATABRICKS_APP else "local",
        "lakebase_configured": db.is_configured(),
        # Which identity this request resolves to: the logged-in USER (OBO) when a
        # forwarded token is present AND we're deployed, else the app SP.
        "auth": "obo_user" if (config.current_user_token() and config.IS_DATABRICKS_APP) else "service_principal",
    }
    try:
        me = config.get_workspace_client().current_user.me()
        info["identity"] = me.user_name
        info["workspace_host"] = config.get_workspace_host()
    except Exception as exc:  # surface auth problems in the health payload
        info["status"] = "degraded"
        info["identity_error"] = str(exc)
    return JSONResponse(info)


# --- API routers (added per milestone) ---------------------------------------
from server.routes import (  # noqa: E402
    admin,
    assets,
    dashboard,
    executions,
    explain,
    metadata,
    pipeline,
    rules,
    specs,
    transformations,
    validations,
)

app.include_router(assets.router, prefix="/api")
app.include_router(specs.router, prefix="/api")
app.include_router(explain.router, prefix="/api")
app.include_router(dashboard.router, prefix="/api")
app.include_router(admin.router, prefix="/api")
app.include_router(rules.router, prefix="/api")
app.include_router(transformations.router, prefix="/api")
app.include_router(validations.router, prefix="/api")
app.include_router(metadata.router, prefix="/api")
app.include_router(executions.router, prefix="/api")
app.include_router(pipeline.router, prefix="/api")


# --- Serve the React SPA (built assets) --------------------------------------
_frontend_dist = os.path.join(os.path.dirname(__file__), "frontend", "dist")
if os.path.isdir(_frontend_dist):
    app.mount(
        "/assets",
        StaticFiles(directory=os.path.join(_frontend_dist, "assets")),
        name="assets",
    )

    @app.get("/{full_path:path}")
    def serve_spa(full_path: str) -> FileResponse:
        # Any non-/api path falls through to the SPA entry point (client routing).
        return FileResponse(os.path.join(_frontend_dist, "index.html"))
