import { useEffect, useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Star, ShieldCheck, Pencil, Check, X, Table2, CheckCircle2, Shuffle, Send, Clock, GitBranch } from "lucide-react";
import { usePage, useIdentity, useIsAdmin } from "../../AppShell";
import { api, type Spec, type Mapping, type Validation, type AuditEvent, type Comment } from "../../api";
import { displayName } from "../../theme";
import { Breadcrumbs, Button, StatusBadge, ConfidenceBar, Card, Tabs, Avatar } from "../../components/primitives";

const TABS = ["Mapping", "Transformations", "Validations", "Lineage", "History", "Comments"];

const PENDING = new Set(["Proposed", "Approving", "Pending Approval", "In Review"]);
const STATE_STYLE: Record<string, string> = {
  accepted: "bg-green-100 text-green-700",
  edited: "bg-blue-100 text-blue-700",
  suggested: "bg-purple-100 text-purple-700",
  rejected: "bg-gray-100 text-gray-500",
};

export function MappingDetails() {
  const { id } = useParams();
  const nav = useNavigate();
  const identity = useIdentity();
  const isAdmin = useIsAdmin();
  const me = displayName(identity);
  const [spec, setSpec] = useState<Spec | null>(null);
  const [vals, setVals] = useState<Validation[]>([]);
  const [tab, setTab] = useState(TABS[0]);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [rationale, setRationale] = useState("");
  const [decision, setDecision] = useState<null | "approved" | "rejected">(null);

  usePage({ title: "Mapping Details" });

  const load = () => {
    if (!id) return;
    api.getSpec(id).then(setSpec).catch((e) => setErr(String(e)));
    // This spec's saved validations (scoped by the spec:<id> tag).
    api.listValidations().then((all) => setVals(all.filter((v) => (v.tags ?? []).includes(`spec:${id}`)))).catch(() => {});
  };
  useEffect(load, [id]);

  if (err) return <div className="p-6 text-red-600 text-sm">Failed to load: {err}</div>;
  if (!spec) return <div className="p-6 text-gray-400 text-sm">Loading…</div>;

  const mappings = (spec.mappings ?? []).filter((m) => m.state !== "rejected");
  const pending = PENDING.has(spec.status);
  const isMaker = spec.owner === me;

  const submitDecision = async (d: "approved" | "rejected") => {
    if (!id) return;
    setBusy(d === "approved" ? "Approving & publishing…" : "Rejecting…");
    try {
      await api.decide(id, { decision: d, rationale: rationale || undefined });
      setDecision(null);
      setRationale("");
      load();
    } catch (e) {
      setErr(String(e instanceof Error ? e.message : e));
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="p-6 space-y-4">
      <Breadcrumbs items={[{ label: "Mapping Studio" }, { label: "Mapping List" }, { label: spec.name }]} />

      {/* Title bar */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-semibold text-gray-900">{spec.name}</h2>
            <StatusBadge status={spec.status} />
          </div>
          <p className="text-sm text-gray-500 mt-0.5">
            {spec.source_system ?? "—"} → {spec.target_system ?? "—"} · Owner: {spec.owner} · v{spec.version_no}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="secondary"><Star className="w-4 h-4" /> Add to Favorites</Button>
          <Button variant="secondary" onClick={() => nav(`/mappings/${spec.id}/edit`)}><Pencil className="w-4 h-4" /> Open in Studio</Button>
        </div>
      </div>

      {/* Reviewer approval bar — shown for a pending mapping. SoD: maker can't approve. */}
      {pending && (
        <ReviewBar
          isMaker={isMaker}
          isAdmin={isAdmin}
          busy={busy}
          decision={decision}
          rationale={rationale}
          onRationale={setRationale}
          onPick={setDecision}
          onConfirm={submitDecision}
        />
      )}
      {spec.status === "Approved" || spec.status === "Published" ? (
        <div className="flex items-center gap-2 text-sm text-green-700 bg-green-50 border border-green-100 rounded-lg px-4 py-2">
          <CheckCircle2 className="w-4 h-4" /> This mapping is published — the approved snapshot is materialized to the governed tier.
        </div>
      ) : null}

      <Tabs tabs={TABS} active={tab} onChange={setTab} />

      {tab === "Validations" ? (
        <ValidationsView vals={vals} />
      ) : tab === "Transformations" ? (
        <TransformationsCode spec={spec} mappings={mappings} />
      ) : tab === "Lineage" ? (
        <UnderConstruction title="Lineage" note="End-to-end column lineage visualization is under construction." />
      ) : tab === "History" ? (
        <HistoryView specId={spec.id} />
      ) : tab === "Comments" ? (
        <CommentsView specId={spec.id} />
      ) : (
        // "Mapping" — the STM overview grid + properties + validations summary.
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
          <div className="xl:col-span-2 space-y-5">
            <TransformationsCard spec={spec} mappings={mappings} />
          </div>
          <div className="space-y-5">
            <PropertiesCard spec={spec} valCount={vals.length} mappingCount={mappings.length} />
            <ValidationsMini vals={vals} />
          </div>
        </div>
      )}
    </div>
  );
}

// Transformations tab — each column's COMPILED SQL code snippet + full metadata.
function TransformationsCode({ spec, mappings }: { spec: Spec; mappings: Mapping[] }) {
  const groups = useMemo(() => groupByTargetTable(spec, mappings), [spec, mappings]);
  if (!mappings.length) {
    return <Card title="Transformations"><p className="text-sm text-gray-500 py-6 text-center">No transformations yet. Open it in the Studio to run AI suggestions.</p></Card>;
  }
  return (
    <div className="space-y-4">
      {groups.map((g) => (
        <Card key={g.table} title={`${g.table} · ${g.rows.length} transformation${g.rows.length === 1 ? "" : "s"}`}>
          <div className="space-y-3">
            {g.rows.map((m) => (
              <div key={m.id} className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 border-b border-gray-100">
                  <Shuffle className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                  <span className="text-sm font-mono font-medium text-gray-800">{m.target_field_name}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700">{m.transform_spec?.op ?? m.transform_kind ?? "spec"}</span>
                  <span className="ml-auto flex items-center gap-2 text-[10px] text-gray-500">
                    <span className={`px-1.5 py-0.5 rounded capitalize ${STATE_STYLE[m.state] ?? "bg-gray-100 text-gray-600"}`}>{m.state}</span>
                    {m.confidence != null && <span>{Math.round((m.confidence <= 1 ? m.confidence * 100 : m.confidence))}%</span>}
                  </span>
                </div>
                {/* Compiled SQL code snippet */}
                <pre className="text-[11px] font-mono bg-[#0d1117] text-emerald-300 px-3 py-2 overflow-x-auto"><code>{m.compiled_sql || m.transform_spec?.expr || "—"}</code></pre>
                {/* Metadata grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-1 px-3 py-2 text-[11px]">
                  <Meta k="Source field(s)" v={(m.provenance?.source_field_names ?? []).join(", ") || "—"} />
                  <Meta k="Origin" v={m.provenance?.origin ?? "—"} />
                  <Meta k="Reviewed by" v={(m.provenance as { reviewed_by?: string })?.reviewed_by ?? "—"} />
                  <Meta k="Transformation" v={m.provenance?.reused_transformation_code ? `Reused: ${m.provenance.reused_transformation_name ?? m.provenance.reused_transformation_code}` : (m.provenance?.is_new_transformation ? "New (contributed on publish)" : m.transform_kind ?? "spec")} />
                </div>
                {(m.transform_description || m.provenance?.rationale) && (
                  <div className="px-3 pb-2 text-[11px] text-gray-500 italic">{m.transform_description || m.provenance?.rationale}</div>
                )}
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
}

function Meta({ k, v }: { k: string; v: string }) {
  return <div><div className="text-[10px] uppercase tracking-wide text-gray-400">{k}</div><div className="text-gray-700 truncate">{v}</div></div>;
}

function UnderConstruction({ title, note }: { title: string; note: string }) {
  return (
    <Card title={title}>
      <div className="py-14 text-center">
        <GitBranch className="w-10 h-10 text-gray-300 mx-auto mb-3" />
        <p className="text-sm font-medium text-gray-600">Under construction</p>
        <p className="text-xs text-gray-400 mt-1">{note}</p>
      </div>
    </Card>
  );
}

// History tab — the mapping's chronological audit work-log.
function HistoryView({ specId }: { specId: string }) {
  const [events, setEvents] = useState<AuditEvent[] | null>(null);
  useEffect(() => { api.auditLog(specId).then((r) => setEvents(r.events)).catch(() => setEvents([])); }, [specId]);
  const KIND: Record<string, string> = { lifecycle: "bg-gray-400", governance: "bg-orange-500", curation: "bg-blue-500" };
  if (events === null) return <Card title="History"><p className="text-sm text-gray-400 py-6 text-center">Loading…</p></Card>;
  return (
    <Card title={`Work log (${events.length})`}>
      {events.length === 0 ? (
        <p className="text-sm text-gray-400 py-6 text-center">No activity recorded yet.</p>
      ) : (
        <ol className="relative border-l border-gray-200 ml-2">
          {[...events].reverse().map((e, i) => (
            <li key={i} className="mb-4 ml-4">
              <span className={`absolute -left-[5px] w-2.5 h-2.5 rounded-full ${KIND[e.kind] ?? "bg-gray-400"}`} />
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-medium text-gray-800 capitalize">{e.action}</span>
                <span className="text-xs text-gray-500">{e.detail}</span>
              </div>
              <div className="text-[11px] text-gray-400 mt-0.5 flex items-center gap-2">
                <Clock className="w-3 h-3" /> {e.at ? new Date(e.at).toLocaleString() : "—"} · {e.actor}
              </div>
            </li>
          ))}
        </ol>
      )}
    </Card>
  );
}

// Comments tab — section-grouped comments + an input to add one.
const COMMENT_SECTIONS = ["General", "Mapping", "Transformations", "Validations", "Lineage"];
function CommentsView({ specId }: { specId: string }) {
  const [comments, setComments] = useState<Comment[] | null>(null);
  const [section, setSection] = useState("General");
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);

  const load = () => api.listComments(specId).then((r) => setComments(r.comments)).catch(() => setComments([]));
  useEffect(() => { load(); }, [specId]);

  const submit = async () => {
    const text = body.trim();
    if (!text) return;
    setBusy(true);
    try { await api.addComment(specId, { body: text, section }); setBody(""); await load(); }
    finally { setBusy(false); }
  };

  const bySection = useMemo(() => {
    const m = new Map<string, Comment[]>();
    for (const c of comments ?? []) (m.get(c.section) ?? m.set(c.section, []).get(c.section)!).push(c);
    return m;
  }, [comments]);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
      <div className="xl:col-span-2 space-y-4">
        {comments === null ? (
          <Card title="Comments"><p className="text-sm text-gray-400 py-6 text-center">Loading…</p></Card>
        ) : comments.length === 0 ? (
          <Card title="Comments"><p className="text-sm text-gray-400 py-6 text-center">No comments yet. Start the discussion on the right.</p></Card>
        ) : (
          COMMENT_SECTIONS.filter((s) => bySection.get(s)?.length).map((s) => (
            <Card key={s} title={`${s} (${bySection.get(s)!.length})`}>
              <ul className="space-y-3">
                {bySection.get(s)!.map((c) => (
                  <li key={c.id} className="flex gap-2.5">
                    <Avatar name={displayName(c.author)} />
                    <div className="min-w-0">
                      <div className="text-xs text-gray-500"><span className="font-medium text-gray-700">{displayName(c.author)}</span> · {new Date(c.created_at).toLocaleString()}</div>
                      <div className="text-sm text-gray-800 whitespace-pre-wrap">{c.body}</div>
                    </div>
                  </li>
                ))}
              </ul>
            </Card>
          ))
        )}
      </div>
      <div>
        <Card title="Add a comment">
          <div className="space-y-2">
            <select value={section} onChange={(e) => setSection(e.target.value)} className="w-full border border-gray-300 rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30">
              {COMMENT_SECTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={4} placeholder="Write a comment…" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30" />
            <Button onClick={submit} disabled={busy || !body.trim()} className="w-full justify-center">
              <Send className="w-4 h-4" /> {busy ? "Posting…" : "Post comment"}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

// The maker-checker action bar for a pending mapping.
function ReviewBar({ isMaker, isAdmin, busy, decision, rationale, onRationale, onPick, onConfirm }: {
  isMaker: boolean; isAdmin: boolean; busy: string | null;
  decision: null | "approved" | "rejected"; rationale: string;
  onRationale: (s: string) => void; onPick: (d: null | "approved" | "rejected") => void;
  onConfirm: (d: "approved" | "rejected") => void;
}) {
  // Admins bypass segregation of duties — they may approve their own mapping.
  const blockApprove = isMaker && !isAdmin;
  return (
    <div className="border border-orange-200 bg-orange-50/50 rounded-xl p-4">
      <div className="flex items-start gap-3">
        <span className="w-9 h-9 rounded-lg bg-orange-100 text-orange-600 grid place-items-center shrink-0"><ShieldCheck className="w-5 h-5" /></span>
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-semibold text-gray-800">Pending your review</h3>
          <p className="text-xs text-gray-500 mt-0.5">
            Review every transformation and validation below, then approve to publish this mapping (its snapshot is
            materialized to the governed tier) or reject with a reason.
          </p>
          {isMaker && isAdmin && (
            <p className="text-xs text-brand mt-1.5">
              You submitted this mapping — as an administrator you may approve your own (segregation of duties bypassed).
            </p>
          )}
          {isMaker && !isAdmin && (
            <p className="text-xs text-amber-700 mt-1.5">
              You submitted this mapping — segregation of duties means a different reviewer must approve it. You can still reject it.
            </p>
          )}

          {decision === null ? (
            <div className="flex gap-2 mt-3">
              <Button onClick={() => onPick("approved")} disabled={blockApprove || !!busy}>
                <Check className="w-4 h-4" /> Approve &amp; Publish
              </Button>
              <Button variant="secondary" onClick={() => onPick("rejected")} disabled={!!busy}>
                <X className="w-4 h-4" /> Reject
              </Button>
            </div>
          ) : (
            <div className="mt-3">
              <label className="text-xs text-gray-600">Rationale {decision === "rejected" ? "(recommended)" : "(optional)"}</label>
              <textarea
                value={rationale}
                onChange={(e) => onRationale(e.target.value)}
                rows={2}
                placeholder={decision === "approved" ? "Looks correct — approving." : "Why is this being rejected?"}
                className="w-full mt-1 border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand/30"
              />
              <div className="flex gap-2 mt-2">
                <Button onClick={() => onConfirm(decision)} disabled={!!busy}>
                  {busy ? busy : decision === "approved" ? "Confirm approve & publish" : "Confirm reject"}
                </Button>
                <Button variant="secondary" onClick={() => onPick(null)} disabled={!!busy}>Cancel</Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Real transformations grid, grouped by target table (matches the studio review).
// Group a spec's field mappings by their target table (shared by the Mapping +
// Transformations tabs). Falls back to a single group for single-table specs.
function groupByTargetTable(spec: Spec, mappings: Mapping[]): { table: string; rows: Mapping[] }[] {
  const targets = spec.targets?.length ? spec.targets : [];
  if (!targets.length) return mappings.length ? [{ table: spec.target_system ?? "Target", rows: mappings }] : [];
  const fieldToTable = new Map<string, string>();
  for (const a of targets) for (const f of a.fields) fieldToTable.set(f.id, a.name);
  const byTable = new Map<string, Mapping[]>();
  for (const a of targets) byTable.set(a.name, []);
  for (const m of mappings) { const t = fieldToTable.get(m.target_field_id); if (t) byTable.get(t)!.push(m); }
  return [...byTable.entries()].filter(([, rows]) => rows.length).map(([table, rows]) => ({ table, rows }));
}

function TransformationsCard({ spec, mappings }: { spec: Spec; mappings: Mapping[] }) {
  const groups = useMemo(() => groupByTargetTable(spec, mappings), [spec, mappings]);

  if (!mappings.length) {
    return (
      <Card title="Source → Target mapping">
        <p className="text-sm text-gray-500 py-6 text-center">
          No field-level rows yet. Open it in the Studio to run AI suggestions and curate mappings.
        </p>
      </Card>
    );
  }

  return (
    <Card title={`Source → Target mapping (${mappings.length} columns)`}>
      <div className="space-y-5">
        {groups.map((g) => (
          <div key={g.table}>
            {groups.length > 1 && (
              <div className="flex items-center gap-1.5 mb-1.5"><Table2 className="w-3.5 h-3.5 text-purple-500" /><span className="text-xs font-semibold text-gray-700">{g.table}</span><span className="text-[11px] text-gray-400">· {g.rows.length}</span></div>
            )}
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-gray-200 text-left text-gray-500">
                    <th className="py-2 pr-3 font-medium">Target column</th>
                    <th className="py-2 pr-3 font-medium">Source field(s)</th>
                    <th className="py-2 pr-3 font-medium">Transformation</th>
                    <th className="py-2 pr-3 font-medium text-right whitespace-nowrap">Conf.</th>
                    <th className="py-2 pr-3 font-medium pr-1">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {g.rows.map((m) => (
                    <tr key={m.id} className="border-b border-gray-100 align-top">
                      <td className="py-2 pr-3 font-mono text-gray-800">{m.target_field_name}</td>
                      <td className="py-2 pr-3 text-gray-600">{(m.provenance?.source_field_names ?? []).join(", ") || "—"}</td>
                      <td className="py-2 pr-3">
                        <div className="text-gray-700">{m.transform_spec?.expr ?? m.transform_spec?.op ?? m.transform_kind ?? "—"}</div>
                        {(m.transform_description || m.provenance?.rationale) && (
                          <div className="text-[11px] text-gray-400 mt-0.5">{m.transform_description || m.provenance?.rationale}</div>
                        )}
                      </td>
                      <td className="py-2 pr-3 text-right whitespace-nowrap text-gray-600">{m.confidence == null ? "—" : `${Math.round((m.confidence <= 1 ? m.confidence * 100 : m.confidence))}%`}</td>
                      <td className="py-2 pr-1"><span className={`inline-block whitespace-nowrap px-1.5 py-0.5 rounded capitalize ${STATE_STYLE[m.state] ?? "bg-gray-100 text-gray-600"}`}>{m.state}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

function ValidationsView({ vals }: { vals: Validation[] }) {
  if (!vals.length) {
    return <Card title="Validations"><p className="text-sm text-gray-500 py-6 text-center">No data-quality checks saved for this mapping. Open it in the Studio and run “Validate mapping”.</p></Card>;
  }
  // Group by dataset (target table).
  const byDs = new Map<string, Validation[]>();
  for (const v of vals) { const d = v.dataset ?? "—"; (byDs.get(d) ?? byDs.set(d, []).get(d)!).push(v); }
  return (
    <div className="space-y-4">
      {[...byDs.entries()].map(([ds, list]) => (
        <Card key={ds} title={`${ds} · ${list.length} check${list.length === 1 ? "" : "s"}`}>
          <div className="space-y-2">
            {list.map((v) => (
              <div key={v.id} className="border border-gray-200 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium text-gray-800 truncate flex-1">{v.name}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-600 capitalize">{(v.rule_type ?? "").replace("_", " ")}</span>
                  <span className="text-[10px] capitalize text-gray-500">{v.severity}</span>
                </div>
                {v.column_name && <div className="text-[11px] text-gray-400 mb-1">column: <span className="font-mono">{v.column_name}</span></div>}
                {v.logic && <div className="font-mono text-[11px] text-gray-700 bg-gray-50 border border-gray-100 rounded p-1.5 break-all">{v.logic}</div>}
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
}

function ValidationsMini({ vals }: { vals: Validation[] }) {
  return (
    <Card title={`Validations (${vals.length})`}>
      {vals.length === 0 ? (
        <p className="text-xs text-gray-400">No data-quality checks yet.</p>
      ) : (
        <ul className="space-y-1.5 text-xs">
          {vals.slice(0, 8).map((v) => (
            <li key={v.id} className="flex items-center gap-1.5">
              <ShieldCheck className="w-3 h-3 text-rose-500 shrink-0" />
              <span className="text-gray-700 truncate flex-1">{v.name}</span>
              <span className="text-gray-400">{v.column_name}</span>
            </li>
          ))}
          {vals.length > 8 && <li className="text-gray-400">+{vals.length - 8} more</li>}
        </ul>
      )}
    </Card>
  );
}

function PropertiesCard({ spec, valCount, mappingCount }: { spec: Spec; valCount: number; mappingCount: number }) {
  const nSrc = spec.sources?.length ?? (spec.source_asset_id ? 1 : 0);
  const nTgt = spec.targets?.length ?? (spec.target_asset_id ? 1 : 0);
  return (
    <Card title="Mapping Properties">
      <dl className="text-sm space-y-2">
        <Row k="Status" v={spec.status} />
        <Row k="Source tables" v={String(nSrc)} />
        <Row k="Target tables" v={String(nTgt)} />
        <Row k="Transformations" v={String(mappingCount)} />
        <Row k="Validations" v={String(valCount)} />
        {spec.joins?.length ? <Row k="Joins" v={String(spec.joins.length)} /> : null}
        <div className="flex justify-between items-center">
          <dt className="text-gray-500">AI Confidence (avg)</dt>
          <dd className="w-28"><ConfidenceBar value={spec.ai_confidence} /></dd>
        </div>
        <div className="flex justify-between items-center">
          <dt className="text-gray-500">Owner</dt>
          <dd><Avatar name={spec.owner} /></dd>
        </div>
      </dl>
    </Card>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between">
      <dt className="text-gray-500">{k}</dt>
      <dd className="text-gray-800 font-medium">{v}</dd>
    </div>
  );
}
