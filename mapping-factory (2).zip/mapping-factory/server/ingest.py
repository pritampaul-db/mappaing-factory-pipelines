"""Deterministic schema ingestion (M2). No LLM — structured sources only.

Three paths, matching the slice's supported source kinds:
  * uc_table     — introspect an existing Unity Catalog table via information_schema.
  * ddl          — parse a pasted CREATE TABLE statement with sqlglot.
  * uploaded_csv — infer field names (+ light type guess) from a CSV header/sample.

Each returns a list of field dicts shaped for repo.create_asset().
"""
from __future__ import annotations

import csv
import io
from typing import Any

import sqlglot
from sqlglot import exp

from server import warehouse


def fields_from_uc_table(fqn: str) -> list[dict[str, Any]]:
    """Introspect catalog.schema.table via information_schema.columns."""
    parts = fqn.split(".")
    if len(parts) != 3:
        raise ValueError("UC table must be fully qualified: catalog.schema.table")
    catalog, schema, table = parts
    rows = warehouse.execute(
        f"""SELECT column_name, full_data_type, is_nullable, ordinal_position
            FROM {catalog}.information_schema.columns
            WHERE table_schema = '{schema}' AND table_name = '{table}'
            ORDER BY ordinal_position""",
    )
    if not rows:
        raise ValueError(f"No columns found for {fqn} (does it exist / do you have access?)")
    out = []
    for r in rows:
        out.append(
            {
                "name": r[0],
                "datatype": str(r[1]).lower(),
                "nullable": str(r[2]).upper() == "YES",
                "ordinal": int(r[3]) if r[3] is not None else None,
            }
        )
    return out


def fields_from_ddl(ddl: str) -> list[dict[str, Any]]:
    """Parse a CREATE TABLE statement (Spark dialect) into fields."""
    try:
        stmt = sqlglot.parse_one(ddl, read="spark")
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"Could not parse DDL: {e}")
    coldefs = list(stmt.find_all(exp.ColumnDef))
    if not coldefs:
        raise ValueError("No column definitions found in DDL.")
    out = []
    for i, c in enumerate(coldefs):
        dtype = c.args.get("kind")
        nullable = not any(
            isinstance(con.kind, exp.NotNullColumnConstraint)
            for con in c.find_all(exp.ColumnConstraint)
        )
        out.append(
            {
                "name": c.name,
                "datatype": dtype.sql(dialect="spark").lower() if dtype else "string",
                "nullable": nullable,
                "ordinal": i,
            }
        )
    return out


def fields_from_csv(text: str, *, sample_rows: int = 50) -> list[dict[str, Any]]:
    """Infer fields from a CSV header + a light scan of sample rows."""
    reader = csv.reader(io.StringIO(text))
    try:
        header = next(reader)
    except StopIteration:
        raise ValueError("Empty CSV.")
    samples: list[list[str]] = []
    for i, row in enumerate(reader):
        if i >= sample_rows:
            break
        samples.append(row)
    out = []
    for i, col in enumerate(header):
        col = col.strip()
        values = [r[i] for r in samples if i < len(r) and r[i] != ""]
        out.append(
            {
                "name": col or f"col_{i}",
                "datatype": _guess_type(values),
                "nullable": True,
                "ordinal": i,
                "sample_profile": {"sample_count": len(values), "examples": values[:3]},
            }
        )
    return out


def _guess_type(values: list[str]) -> str:
    """Conservative type guess from sample values; default to string."""
    if not values:
        return "string"

    def _all(pred) -> bool:
        return all(pred(v) for v in values)

    def _is_int(v: str) -> bool:
        try:
            int(v)
            return True
        except ValueError:
            return False

    def _is_float(v: str) -> bool:
        try:
            float(v)
            return True
        except ValueError:
            return False

    if _all(_is_int):
        return "bigint"
    if _all(_is_float):
        return "double"
    if _all(lambda v: v.lower() in ("true", "false")):
        return "boolean"
    return "string"
