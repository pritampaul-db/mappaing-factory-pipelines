import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, BookOpen, Sparkles, Library, Repeat, Copy, X, CheckCircle2, Clock, ShieldCheck, Check } from "lucide-react";
import { usePage, useIdentity, useIsAdmin } from "../../AppShell";
import { api, type Transformation } from "../../api";
import { Button, Tabs, StatusBadge, Avatar, Card } from "../../components/primitives";
import { DataTable, LinkCell, type Column } from "../../components/DataTable";
import { DonutChart, LegendList, BreakdownBars } from "../../components/charts";

const TABS = ["Overview", "Pending Approval", "Custom Transformations", "AI Assisted Transformers", "Transformation Library"];
const PENDING_STATUSES = new Set(["Proposed", "Pending Approval", "In Review"]);

export function TransformationsLibrary() {
  const nav = useNavigate();
  const identity = useIdentity();
  const [rows, setRows] = useState<Transformation[]>([]);
  const [tab, setTab] = useState(TABS[0]);
  const [selected, setSelected] = useState<Transformation | null>(null);

  usePage({
    title: "Transformations",
    subtitle: "Discover, clone and reuse pre-built transformations across mappings",
    actions: (
      <Button onClick={() => nav("/transformations/new")}>
        <Plus className="w-4 h-4" /> New Transformation
      </Button>
    ),
  });

  const load = () =>
    api.listTransformations().then((r) => {
      setRows(r);
      setSelected((prev) => (prev ? r.find((x) => x.id === prev.id) ?? r[0] ?? null : r[0] ?? null));
    });

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    if (tab === "Pending Approval") return rows.filter((r) => PENDING_STATUSES.has(r.status));
    if (tab === "Custom Transformations") return rows.filter((r) => r.ttype === "custom");
    if (tab === "AI Assisted Transformers") return rows.filter((r) => r.ttype === "ai_assisted");
    if (tab === "Transformation Library") return rows.filter((r) => r.ttype === "library");
    return rows;
  }, [rows, tab]);

  const byType = [
    { name: "Library", value: rows.filter((r) => r.ttype === "library").length, color: "#2563eb" },
    { name: "Custom", value: rows.filter((r) => r.ttype === "custom").length, color: "#16a34a" },
    { name: "AI Assisted", value: rows.filter((r) => r.ttype === "ai_assisted").length, color: "#a855f7" },
  ];
  const catCounts = rows.reduce<Record<string, number>>((a, r) => { const c = r.category ?? "other"; a[c] = (a[c] ?? 0) + 1; return a; }, {});
  const byCat = Object.entries(catCounts).map(([label, value]) => ({ label, value }));

  const kpis = [
    { icon: BookOpen, label: "Total Transformations", value: rows.length },
    { icon: Library, label: "Pre-built (Library)", value: byType[0].value },
    { icon: Sparkles, label: "AI Assisted", value: byType[2].value },
    { icon: Clock, label: "Pending Approval", value: rows.filter((r) => PENDING_STATUSES.has(r.status)).length },
    { icon: Repeat, label: "Published", value: rows.filter((r) => r.status === "Published").length },
  ];

  const columns: Column<Transformation>[] = [
    { key: "name", header: "Transformation Name", sortValue: (r) => r.name, render: (r) => <LinkCell title={r.name} subtitle={r.code} /> },
    { key: "type", header: "Type", render: (r) => <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded capitalize">{r.ttype.replace("_", " ")}</span> },
    { key: "cat", header: "Category", render: (r) => <span className="text-gray-600 capitalize">{r.category ?? "—"}</span> },
    { key: "desc", header: "Description", render: (r) => <span className="text-gray-500 text-xs line-clamp-1">{r.description}</span> },
    { key: "owner", header: "Owner", render: (r) => <Avatar name={r.owner ?? "—"} /> },
    { key: "reuse", header: "Used By", align: "right", sortValue: (r) => r.used_by ?? r.reuse_count, render: (r) => <span className="text-gray-700" title="Mappings reusing this transformation">{r.used_by ?? 0} mapping{(r.used_by ?? 0) === 1 ? "" : "s"}</span> },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];

  const clone = (t: Transformation) => {
    // Open the builder prefilled with a copy — nothing is persisted until the user
    // saves. The builder reads this off router location state.
    nav("/transformations/new", {
      state: {
        clone: {
          name: `Copy of ${t.name}`,
          description: t.description ?? "",
          logic_expr: t.logic_expr ?? "",
          logic_sql: t.logic_sql ?? "",
          category: t.category ?? null,
          tags: t.tags ?? [],
          clonedFrom: t.name,
        },
      },
    });
  };

  return (
    <div className="p-6 space-y-4">
      <Tabs tabs={TABS} active={tab} onChange={setTab} />
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white rounded-xl border border-gray-200 p-3 flex items-center gap-3">
            <span className="w-9 h-9 rounded-lg grid place-items-center bg-brand-soft text-brand shrink-0"><k.icon className="w-4 h-4" /></span>
            <div><div className="text-[11px] text-gray-500">{k.label}</div><div className="text-lg font-semibold text-gray-900">{k.value}</div></div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 items-start">
        <div className="xl:col-span-2 bg-white rounded-xl border border-gray-200 p-4">
          <DataTable columns={columns} rows={filtered} rowKey={(r) => r.id} onRowClick={setSelected} />
        </div>
        {selected && <XformDetail t={selected} identity={identity} onClose={() => setSelected(null)} onClone={clone} onChanged={load} />}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card title="Transformations by Type">
          <div className="grid grid-cols-2 gap-2 items-center">
            <DonutChart data={byType} totalLabel="Total" />
            <LegendList data={byType} />
          </div>
        </Card>
        <Card title="Top Categories"><BreakdownBars data={byCat} /></Card>
      </div>
    </div>
  );
}

function XformDetail({ t, identity, onClose, onClone, onChanged }: {
  t: Transformation; identity?: string | null;
  onClose: () => void; onClone: (t: Transformation) => void; onChanged: () => void;
}) {
  const tests = t.test_cases ?? [];
  const isPending = PENDING_STATUSES.has(t.status);
  const maker = (t.submitted_by || t.owner || "").toLowerCase();
  const isMaker = !!maker && maker === (identity ?? "").toLowerCase();
  return (
    <Card className="self-start sticky top-4">
      <div className="flex items-start justify-between mb-2">
        <div>
          <h3 className="font-semibold text-gray-800 leading-tight">{t.name}</h3>
          <div className="text-[11px] text-gray-400 font-mono mt-0.5">{t.code}</div>
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
      </div>

      <div className="flex items-center gap-2">
        <StatusBadge status={t.status} />
        <span className="text-xs bg-gray-100 text-gray-700 px-2 py-0.5 rounded capitalize">{t.ttype.replace("_", " ")}</span>
      </div>

      {isPending && <ReviewBar t={t} isMaker={isMaker} onChanged={onChanged} />}
      {t.status === "Published" && t.approved_by && (
        <p className="text-[11px] text-green-700 bg-green-50 border border-green-100 rounded px-2 py-1.5 mt-3">
          Approved &amp; published by {t.approved_by}.
        </p>
      )}
      {t.status === "Rejected" && (
        <p className="text-[11px] text-red-700 bg-red-50 border border-red-100 rounded px-2 py-1.5 mt-3">
          Rejected{t.rationale ? `: ${t.rationale}` : "."} You can edit a clone and resubmit.
        </p>
      )}

      {t.description && <p className="text-xs text-gray-600 mt-3 leading-relaxed">{t.description}</p>}

      <dl className="text-sm mt-3 space-y-1.5">
        <Row k="Category" v={t.category ?? "—"} />
        <Row k="Owner" v={t.owner ?? "—"} />
        <Row k="Used by" v={`${t.used_by ?? 0} mapping${(t.used_by ?? 0) === 1 ? "" : "s"}`} />
      </dl>

      {t.logic_expr && (
        <div className="mt-3">
          <div className="text-xs font-medium text-gray-500 mb-1">Expression</div>
          <pre className="bg-[#0d1117] text-emerald-300 rounded px-2.5 py-2 text-[11px] font-mono overflow-x-auto whitespace-pre-wrap">{t.logic_expr}</pre>
        </div>
      )}
      {t.logic_sql && t.logic_sql !== t.logic_expr && (
        <div className="mt-3">
          <div className="text-xs font-medium text-gray-500 mb-1">Spark SQL</div>
          <pre className="bg-[#0d1117] text-emerald-300 rounded px-2.5 py-2 text-[11px] font-mono overflow-x-auto whitespace-pre-wrap">{t.logic_sql}</pre>
        </div>
      )}

      {tests.length > 0 && (
        <div className="mt-3">
          <div className="text-xs font-medium text-gray-500 mb-1">Test Cases</div>
          <ul className="space-y-1">
            {tests.map((tc, i) => (
              <li key={i} className="flex items-center justify-between text-xs gap-2">
                <span className="text-gray-600 truncate">{tc.name}</span>
                {(tc.input !== undefined || tc.output !== undefined) ? (
                  <span className="font-mono text-[10px] text-gray-500 shrink-0">
                    {fmt(tc.input)} <span className="text-gray-300">→</span> {fmt(tc.output)}
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-green-600 shrink-0"><CheckCircle2 className="w-3 h-3" /> Pass</span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}

      {t.tags && t.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1">{t.tags.map((tg) => <span key={tg} className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{tg}</span>)}</div>
      )}

      <Button className="w-full justify-center mt-4" onClick={() => onClone(t)}>
        <Copy className="w-4 h-4" /> Clone to New Transformation
      </Button>
    </Card>
  );
}

function ReviewBar({ t, isMaker, onChanged }: { t: Transformation; isMaker: boolean; onChanged: () => void }) {
  const isAdmin = useIsAdmin();
  // Admins bypass segregation of duties — they may approve their own.
  const blockApprove = isMaker && !isAdmin;
  const [decision, setDecision] = useState<null | "approved" | "rejected">(null);
  const [rationale, setRationale] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const confirm = async (d: "approved" | "rejected") => {
    setBusy(true); setErr(null);
    try {
      await api.decideTransformation(t.id, { decision: d, rationale: rationale || undefined });
      onChanged();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Failed to record decision.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="border border-orange-200 bg-orange-50/50 rounded-lg p-3 mt-3">
      <div className="flex items-center gap-2 text-sm font-semibold text-gray-800">
        <ShieldCheck className="w-4 h-4 text-orange-600" /> Pending approval
      </div>
      <p className="text-[11px] text-gray-500 mt-0.5">
        Submitted by {t.submitted_by ?? t.owner ?? "—"}. Review the logic below, then approve to publish or reject.
      </p>
      {isMaker && isAdmin && (
        <p className="text-[11px] text-brand mt-1">
          You submitted this — as an administrator you may approve your own (segregation of duties bypassed).
        </p>
      )}
      {isMaker && !isAdmin && (
        <p className="text-[11px] text-amber-700 mt-1">
          You submitted this — segregation of duties means a different reviewer must approve it. You can still reject it.
        </p>
      )}
      {decision === null ? (
        <div className="flex gap-2 mt-2">
          <Button onClick={() => setDecision("approved")} disabled={blockApprove || busy}><Check className="w-4 h-4" /> Approve &amp; Publish</Button>
          <Button variant="secondary" onClick={() => setDecision("rejected")} disabled={busy}><X className="w-4 h-4" /> Reject</Button>
        </div>
      ) : (
        <div className="mt-2">
          <textarea
            value={rationale}
            onChange={(e) => setRationale(e.target.value)}
            rows={2}
            placeholder={decision === "approved" ? "Looks correct — approving." : "Why is this being rejected?"}
            className="w-full border border-gray-300 rounded-lg px-2.5 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-brand/30"
          />
          <div className="flex gap-2 mt-1.5">
            <Button onClick={() => confirm(decision)} disabled={busy}>{busy ? "Saving…" : decision === "approved" ? "Confirm approve" : "Confirm reject"}</Button>
            <Button variant="secondary" onClick={() => setDecision(null)} disabled={busy}>Cancel</Button>
          </div>
        </div>
      )}
      {err && <p className="text-[11px] text-red-600 mt-1.5">{err}</p>}
    </div>
  );
}

function fmt(v: unknown): string {
  if (v === null || v === undefined) return "null";
  if (v === "") return '""';
  return String(v);
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between"><dt className="text-gray-500">{k}</dt><dd className="text-gray-800 capitalize">{v}</dd></div>;
}
