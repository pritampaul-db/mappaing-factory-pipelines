"""Lakebase (managed Postgres) connection pool — the hot operational tier.

Uses the OAuthConnection pattern: a fresh OAuth token is minted for every new
physical connection the pool opens, so we never carry a stale/expired token.
max_lifetime recycles connections before the ~1h token expiry.

Import is safe even when Lakebase is not configured — the pool is created with
open=False and only opened by the app lifespan when PGHOST is present.
"""
from __future__ import annotations

import os

import psycopg
from psycopg_pool import ConnectionPool

from server import config


class OAuthConnection(psycopg.Connection):
    """psycopg Connection that injects a fresh Lakebase OAuth token per connect."""

    @classmethod
    def connect(cls, conninfo: str = "", **kwargs):
        # Mint a fresh short-lived credential for this Lakebase instance. The
        # instance-name API is what this deployment uses (vs the project/branch
        # ENDPOINT_NAME form); MF_DB_INSTANCE names the instance.
        instance = os.environ["MF_DB_INSTANCE"]
        # The pool is SHARED across users (PGUSER = the app SP's client id), so the
        # DB credential is always minted as the SERVICE PRINCIPAL — never the
        # per-request user (OBO). get_sp_client() ignores the user-token contextvar.
        w = config.get_sp_client()
        credential = w.database.generate_database_credential(instance_names=[instance])
        kwargs["password"] = credential.token
        return super().connect(conninfo, **kwargs)


def is_configured() -> bool:
    """True when enough env is present to open the Lakebase pool."""
    return bool(os.environ.get("PGHOST") and os.environ.get("MF_DB_INSTANCE"))


def _conninfo() -> str:
    # PGHOST/PGUSER are injected by the Apps runtime when a Database resource is
    # attached; locally we set them (plus MF_DB_INSTANCE). We default the target
    # database to mapping_factory (our dedicated DB inside the shared instance).
    user = os.environ["PGUSER"]
    host = os.environ["PGHOST"]
    port = os.environ.get("PGPORT", "5432")
    database = os.environ.get("PGDATABASE", "mapping_factory")
    sslmode = os.environ.get("PGSSLMODE", "require")
    return f"dbname={database} user={user} host={host} port={port} sslmode={sslmode}"


# Deferred open: created at import, opened explicitly in the app lifespan.
# max_lifetime=2700 (45m) recycles before the 1h OAuth token expiry.
pool = ConnectionPool(
    conninfo=_conninfo() if is_configured() else "",
    connection_class=OAuthConnection,
    min_size=1,
    max_size=10,
    max_lifetime=2700,
    open=False,
)
