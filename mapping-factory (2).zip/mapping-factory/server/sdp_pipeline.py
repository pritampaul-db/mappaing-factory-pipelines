"""Provision + locate the generic Agentic-Mapping-Test SDP pipeline.

One reusable serverless Spark Declarative Pipeline (source in server/sdp/) is
created once at app setup. It reads a per-run config row from a UC config table
and builds a target + DQ table, so testing a new mapping never redeploys it — we
just write a fresh config row and start an update with that run_id.

The pipeline id + config live in Unity Catalog (via the SQL warehouse) so they
survive app restarts and are shared between the local dev process and the
deployed service principal.
"""
from __future__ import annotations

import base64
import os
import posixpath

from server import config, warehouse

PIPELINE_NAME = "mapping-factory-agentic-test"
# Where the pipeline source notebook is uploaded in the workspace.
_SRC_LOCAL = os.path.join(os.path.dirname(__file__), "sdp", "mapping_test_pipeline.py")

CATALOG = config.UC_CATALOG
SCHEMA = config.UC_SCHEMA
SETTINGS_TABLE = f"{CATALOG}.{SCHEMA}.mf_settings"
CONFIG_TABLE = f"{CATALOG}.{SCHEMA}.mf_test_config"


def _ws_source_path() -> str:
    """Shared workspace path for the pipeline source, readable by BOTH a user who
    provisions locally AND the app service principal that triggers runs. A per-user
    (/Workspace/Users/<me>/…) path is NOT readable by the SP, which breaks runs."""
    return "/Workspace/Shared/mapping-factory/sdp/mapping_test_pipeline"


def _ensure_tables() -> None:
    """Idempotently create the settings + per-run config tables in UC."""
    warehouse.execute(
        f"CREATE TABLE IF NOT EXISTS {SETTINGS_TABLE} (key STRING, value STRING, updated_at TIMESTAMP)"
    )
    warehouse.execute(
        f"CREATE TABLE IF NOT EXISTS {CONFIG_TABLE} "
        f"(run_id STRING, config_json STRING, created_at TIMESTAMP)"
    )


def _get_setting(key: str) -> str | None:
    from server.governance import _sql_str

    rows = warehouse.execute(f"SELECT value FROM {SETTINGS_TABLE} WHERE key={_sql_str(key)} LIMIT 1")
    return rows[0][0] if rows else None


def _put_setting(key: str, value: str) -> None:
    from server.governance import _sql_str

    warehouse.execute(f"DELETE FROM {SETTINGS_TABLE} WHERE key={_sql_str(key)}")
    warehouse.execute(
        f"INSERT INTO {SETTINGS_TABLE} (key, value, updated_at) VALUES ({_sql_str(key)}, {_sql_str(value)}, current_timestamp())"
    )


def _find_pipeline_by_name(w) -> str | None:
    for p in w.pipelines.list_pipelines():
        if p.name == PIPELINE_NAME:
            return p.pipeline_id
    return None


def get_pipeline_id() -> str | None:
    """Return the provisioned pipeline id, if any (settings first, then by name)."""
    try:
        _ensure_tables()
        pid = _get_setting("test_pipeline_id")
        if pid:
            return pid
        w = config.get_workspace_client()
        pid = _find_pipeline_by_name(w)
        if pid:
            _put_setting("test_pipeline_id", pid)
        return pid
    except Exception:  # noqa: BLE001 — never hard-fail the caller
        return None


def status() -> dict:
    pid = get_pipeline_id()
    return {"provisioned": bool(pid), "pipeline_id": pid, "name": PIPELINE_NAME}


def _upload_source(w) -> str:
    """Upload the (latest) pipeline source notebook to the workspace; return its path."""
    from databricks.sdk.service.workspace import ImportFormat, Language

    ws_path = _ws_source_path()
    w.workspace.mkdirs(posixpath.dirname(ws_path))
    with open(_SRC_LOCAL, "rb") as fh:
        content_b64 = base64.b64encode(fh.read()).decode()
    w.workspace.import_(
        path=ws_path,
        format=ImportFormat.SOURCE,
        language=Language.PYTHON,
        content=content_b64,
        overwrite=True,
    )
    return ws_path


def sync_source() -> dict:
    """Re-upload the pipeline source to the workspace (after editing it). No create."""
    w = config.get_workspace_client()
    path = _upload_source(w)
    return {"synced": True, "source_path": path}


def _grant_app_sp(w, pid: str) -> None:
    """Ensure the Databricks App's service principal can RUN this pipeline.

    Whoever provisions (a user locally, or the SP in the deployed app) may not be
    the identity that later triggers runs. Grant the app SP CAN_MANAGE so the
    deployed app can always start_update, regardless of who created the pipeline.
    Best-effort: skipped if we can't resolve the SP or lack grant rights.
    """
    from databricks.sdk.service import pipelines as pl

    sp = os.environ.get("DATABRICKS_CLIENT_ID") or os.environ.get("MF_APP_SP_ID")
    if not sp:
        return
    try:
        w.pipelines.update_permissions(
            pipeline_id=pid,
            access_control_list=[pl.PipelineAccessControlRequest(service_principal_name=sp, permission_level=pl.PipelinePermissionLevel.CAN_MANAGE)],
        )
    except Exception:  # noqa: BLE001
        pass


def provision() -> dict:
    """Upload the pipeline source + create the serverless pipeline (idempotent)."""
    from databricks.sdk.service import pipelines as pl

    w = config.get_workspace_client()
    _ensure_tables()

    # Reuse if it already exists — but refresh the source so edits ship.
    existing = get_pipeline_id()
    if existing:
        _upload_source(w)
        _grant_app_sp(w, existing)
        return {"provisioned": True, "pipeline_id": existing, "reused": True, "name": PIPELINE_NAME}

    # 1) Upload the pipeline source notebook to the workspace.
    ws_path = _upload_source(w)

    # 2) Create the serverless, config-driven pipeline.
    created = w.pipelines.create(
        name=PIPELINE_NAME,
        serverless=True,
        catalog=CATALOG,
        schema=SCHEMA,
        development=True,
        continuous=False,
        libraries=[pl.PipelineLibrary(notebook=pl.NotebookLibrary(path=ws_path))],
        configuration={"mf.run_id": ""},
    )
    pid = created.pipeline_id
    _put_setting("test_pipeline_id", pid)
    _grant_app_sp(w, pid)
    return {"provisioned": True, "pipeline_id": pid, "reused": False, "name": PIPELINE_NAME, "source_path": ws_path}
