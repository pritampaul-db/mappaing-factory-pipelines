import { useState, type ReactNode } from "react";
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";

export interface Column<T> {
  key: string;
  header: string;
  render: (row: T) => ReactNode;
  sortValue?: (row: T) => string | number;
  width?: string;
  align?: "left" | "right";
}

// Generic sortable + client-paginated table matching the wireframe list screens.
export function DataTable<T>({
  columns,
  rows,
  pageSize = 10,
  rowKey,
  onRowClick,
}: {
  columns: Column<T>[];
  rows: T[];
  pageSize?: number;
  rowKey: (row: T) => string;
  onRowClick?: (row: T) => void;
}) {
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [dir, setDir] = useState<"asc" | "desc">("asc");
  const [page, setPage] = useState(1);

  const sorted = [...rows];
  if (sortKey) {
    const col = columns.find((c) => c.key === sortKey);
    if (col?.sortValue) {
      sorted.sort((a, b) => {
        const va = col.sortValue!(a);
        const vb = col.sortValue!(b);
        const cmp = va < vb ? -1 : va > vb ? 1 : 0;
        return dir === "asc" ? cmp : -cmp;
      });
    }
  }
  const pages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const cur = Math.min(page, pages);
  const view = sorted.slice((cur - 1) * pageSize, cur * pageSize);

  const toggleSort = (key: string) => {
    if (sortKey === key) setDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setDir("asc");
    }
  };

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-200 text-left text-gray-500">
              {columns.map((c) => (
                <th key={c.key} className={`py-2.5 px-3 font-medium ${c.align === "right" ? "text-right" : ""}`} style={{ width: c.width }}>
                  <button
                    className={`inline-flex items-center gap-1 ${c.sortValue ? "hover:text-gray-800" : "cursor-default"}`}
                    onClick={() => c.sortValue && toggleSort(c.key)}
                  >
                    {c.header}
                    {c.sortValue && sortKey === c.key && (dir === "asc" ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />)}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {view.map((row) => (
              <tr
                key={rowKey(row)}
                onClick={() => onRowClick?.(row)}
                className={`border-b border-gray-100 ${onRowClick ? "hover:bg-gray-50 cursor-pointer" : ""}`}
              >
                {columns.map((c) => (
                  <td key={c.key} className={`py-3 px-3 align-middle ${c.align === "right" ? "text-right" : ""}`}>
                    {c.render(row)}
                  </td>
                ))}
              </tr>
            ))}
            {view.length === 0 && (
              <tr>
                <td colSpan={columns.length} className="py-10 text-center text-gray-400">
                  No records.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between mt-3 text-sm text-gray-500">
        <span>
          Showing {sorted.length === 0 ? 0 : (cur - 1) * pageSize + 1} to {Math.min(cur * pageSize, sorted.length)} of {sorted.length}
        </span>
        <div className="flex items-center gap-1">
          <button disabled={cur <= 1} onClick={() => setPage(cur - 1)} className="p-1.5 rounded border border-gray-200 disabled:opacity-40 hover:bg-gray-50">
            <ChevronLeft className="w-4 h-4" />
          </button>
          {Array.from({ length: pages }, (_, i) => i + 1)
            .filter((p) => p === 1 || p === pages || Math.abs(p - cur) <= 1)
            .map((p, idx, arr) => (
              <span key={p} className="flex items-center">
                {idx > 0 && arr[idx - 1] !== p - 1 && <span className="px-1 text-gray-300">…</span>}
                <button
                  onClick={() => setPage(p)}
                  className={`w-8 h-8 rounded text-sm ${p === cur ? "bg-brand text-white" : "hover:bg-gray-100 text-gray-600"}`}
                >
                  {p}
                </button>
              </span>
            ))}
          <button disabled={cur >= pages} onClick={() => setPage(cur + 1)} className="p-1.5 rounded border border-gray-200 disabled:opacity-40 hover:bg-gray-50">
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

// Two-line cell: bold primary link + muted subtitle (used in most list tables).
export function LinkCell({ title, subtitle, color = "#c9252d" }: { title: string; subtitle?: string; color?: string }) {
  return (
    <div className="min-w-0">
      <div className="font-medium truncate" style={{ color }}>
        {title}
      </div>
      {subtitle && <div className="text-xs text-gray-500 truncate">{subtitle}</div>}
    </div>
  );
}
