import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Workflow,
  Network,
  Shuffle,
  BookOpen,
  ShieldCheck,
  Activity,
  Lightbulb,
  GitBranch,
  Crosshair,
  ClipboardCheck,
  Sparkles,
  Library,
  Settings,
  Hexagon,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

// The 14 nav items from the wireframes. `to` null = not-yet-wireframed → placeholder route.
const NAV: { label: string; icon: typeof LayoutDashboard; to: string }[] = [
  { label: "Dashboard", icon: LayoutDashboard, to: "/" },
  { label: "Mapping Studio", icon: Workflow, to: "/mappings" },
  { label: "Metadata Explorer", icon: Network, to: "/metadata" },
  { label: "Transformations", icon: Shuffle, to: "/transformations" },
  { label: "Rule Library", icon: BookOpen, to: "/rules" },
  { label: "Data Quality", icon: ShieldCheck, to: "/validations" },
  { label: "Execution Monitor", icon: Activity, to: "/executions" },
  { label: "Explainability", icon: Lightbulb, to: "/explainability" },
  { label: "Lineage Explorer", icon: GitBranch, to: "/lineage" },
  { label: "Impact Analysis", icon: Crosshair, to: "/impact" },
  { label: "Governance", icon: ClipboardCheck, to: "/governance" },
  { label: "AI Assistant", icon: Sparkles, to: "/assistant" },
  { label: "Knowledge Hub", icon: Library, to: "/knowledge" },
  { label: "Administration", icon: Settings, to: "/admin" },
];

export function Sidebar({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  return (
    <aside
      className={`shrink-0 h-full flex flex-col text-gray-100 bg-gradient-to-b from-sidebar-from to-sidebar-to transition-all duration-200 ${
        collapsed ? "w-16" : "w-60"
      }`}
    >
      {/* Logo */}
      <div className="flex items-center gap-2 px-4 h-16 shrink-0">
        <Hexagon className="w-7 h-7 text-white shrink-0" strokeWidth={1.5} />
        {!collapsed && <span className="font-semibold text-lg tracking-tight">Mapping Factory</span>}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-2 space-y-0.5">
        {NAV.map(({ label, icon: Icon, to }) => (
          <NavLink
            key={label}
            to={to}
            end={to === "/"}
            title={collapsed ? label : undefined}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors ${
                isActive ? "bg-sidebar-active text-white font-medium" : "text-gray-200/80 hover:bg-sidebar-hover"
              }`
            }
          >
            <Icon className="w-5 h-5 shrink-0" strokeWidth={1.75} />
            {!collapsed && <span className="truncate">{label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* Collapse toggle */}
      <button
        onClick={onToggle}
        className="flex items-center gap-3 px-4 h-12 shrink-0 border-t border-white/10 text-sm text-gray-300 hover:bg-sidebar-hover"
      >
        {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        {!collapsed && <span>Collapse</span>}
      </button>
    </aside>
  );
}
