"""Git credential storage for Deploy-as-Pipeline.

Stores a user's git PAT ENCRYPTED (Fernet, see server/crypto.py) in the SP-owned
Lakebase `git_credential` table so it can be reused for GitHub REST pushes on later
deploys. Also registers the PAT with Databricks Git credentials so a git-backed SDP
pipeline can pull from the repo. The raw token is never returned to the client.
"""
from __future__ import annotations

from typing import Any

from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

from server import config, crypto


def _norm(user: str | None) -> str:
    return (user or "").strip().lower()


def has_credential(pool: ConnectionPool, user: str, provider: str = "github") -> dict[str, Any] | None:
    """Return {git_username, updated_at} if a credential is stored (NEVER the token)."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SET search_path TO mapping_factory, public")
            cur.execute(
                "SELECT git_username, updated_at FROM git_credential WHERE user_name=%s AND provider=%s",
                (_norm(user), provider),
            )
            return cur.fetchone()


def get_token(pool: ConnectionPool, user: str, provider: str = "github") -> tuple[str, str] | None:
    """Return (git_username, decrypted_token) for server-side use, or None."""
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SET search_path TO mapping_factory, public")
            cur.execute(
                "SELECT git_username, token_encrypted FROM git_credential WHERE user_name=%s AND provider=%s",
                (_norm(user), provider),
            )
            row = cur.fetchone()
    if not row:
        return None
    return row.get("git_username") or "", crypto.decrypt(row["token_encrypted"])


def save_credential(pool: ConnectionPool, user: str, *, git_username: str, token: str, provider: str = "github") -> dict[str, Any]:
    """Encrypt + upsert the PAT; also register it with Databricks Git credentials
    (best-effort) so git-backed pipelines can pull. Returns the safe metadata."""
    enc = crypto.encrypt(token)
    with pool.connection() as conn:
        conn.row_factory = dict_row
        with conn.cursor() as cur:
            cur.execute("SET search_path TO mapping_factory, public")
            cur.execute(
                """INSERT INTO git_credential (user_name, provider, git_username, token_encrypted, updated_at)
                   VALUES (%s,%s,%s,%s, now())
                   ON CONFLICT (user_name, provider)
                   DO UPDATE SET git_username=EXCLUDED.git_username, token_encrypted=EXCLUDED.token_encrypted, updated_at=now()
                   RETURNING git_username, updated_at""",
                (_norm(user), provider, git_username, enc),
            )
            row = cur.fetchone()
        conn.commit()
    _register_databricks_git_credential(git_username, token, provider)
    return row


def _register_databricks_git_credential(git_username: str, token: str, provider: str) -> None:
    """Store the PAT in Databricks Git credentials so a git-backed pipeline / Repos can
    pull. Registered on the app SERVICE PRINCIPAL — the SP is the identity that creates
    the Repos git-folder and runs the pipeline, so it needs the credential (not the user).
    Best-effort and idempotent — updates the existing credential for this provider."""
    prov = "gitHub" if provider == "github" else provider
    try:
        w = config.get_sp_client()
        existing = None
        for c in w.git_credentials.list():
            if (c.git_provider or "").lower() == prov.lower():
                existing = c
                break
        if existing is not None:
            w.git_credentials.update(credential_id=existing.credential_id, git_provider=prov,
                                     git_username=git_username, personal_access_token=token)
        else:
            w.git_credentials.create(git_provider=prov, git_username=git_username, personal_access_token=token)
    except Exception:  # noqa: BLE001 — REST push still works from the encrypted copy
        pass
