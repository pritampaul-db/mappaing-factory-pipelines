"""One consistent dummy dataset across every screen.

Everything cross-references: the same source systems, owners, domains, and
entity names appear on the Dashboard, Mapping List, Rule Library, Transformations,
Validation, Metadata Explorer and Execution Monitor, so the app tells one
coherent story (e.g. Reg_Exposures shows up as a mapping, its rules in the
Rule Library, its runs in the Execution Monitor).

Idempotent: keyed by natural codes/names; re-running does not duplicate rows.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from psycopg.types.json import Json
from psycopg_pool import ConnectionPool

NOW = datetime.now(timezone.utc)


def _ago(**kw) -> datetime:
    return NOW - timedelta(**kw)


OWNERS = ["Shivani Das", "Rahul Verma", "Priya Singh", "Amit Sharma", "Neha Gupta"]

SYSTEMS = [
    ("BU_RETAIL", "Retail Business Unit System", 312),
    ("CORP_EDW", "Corporate Data Warehouse", 498),
    ("REG_REPORTING", "Regulatory Reporting System", 128),
    ("SUB_LEDGER", "Sub Ledger System", 210),
    ("REF_SYS", "Reference Data System", 165),
    ("RISK_LEDGER", "Risk Ledger System", 246),
]

GLOSSARY = [
    ("Customer", "An individual or organization that buys goods or services", "business_term", "Customer Management", "Shivani Das"),
    ("Customer Key", "Unique identifier for a customer in the corporate system", "business_term", "Customer Management", "Rahul Verma"),
    ("Exposure", "Total credit exposure for a customer", "business_term", "Risk & Compliance", "Priya Singh"),
    ("RWA", "Risk Weighted Assets calculated as per regulatory guidelines", "business_term", "Risk & Compliance", "Amit Sharma"),
    ("Active Customer", "Customer with at least one active account", "business_rule", "Customer Management", "Neha Gupta"),
    ("Notional Amount", "The face value of a financial instrument", "business_term", "Finance", "Rahul Verma"),
    ("Country Code", "ISO 3166 country code", "business_term", "Reference Data", "Neha Gupta"),
    ("Customer Segment", "Classification of a customer by value tier", "business_term", "Customer Management", "Shivani Das"),
]

# (name, code, rule_type, domain, data_type, description, logic_preview, sample_io, owner, status, usage_count, tags)
RULES = [
    ("Trim Whitespace", "TRIM", "standardization", "Customer", "String", "Removes leading and trailing whitespace characters from the input string.", "TRIM(<input_string>)", [{"input": "' John Doe '", "output": "'John Doe'"}, {"input": "'\\tABC Corp\\n'", "output": "'ABC Corp'"}], "Shivani Das", "Approved", 342, ["standardization", "string", "cleanup"]),
    ("Proper Case", "PROPER_CASE", "standardization", "Customer", "String", "Converts text to proper case.", "INITCAP(<input>)", [{"input": "'john doe'", "output": "'John Doe'"}], "Rahul Verma", "Approved", 298, ["standardization", "string"]),
    ("Lookup – Code to Description", "LOOKUP", "derivation", "Reference Data", "String", "Looks up description from reference table based on code.", "LOOKUP(code, ref_table)", [{"input": "'01'", "output": "'Retail'"}], "Priya Singh", "Approved", 512, ["lookup", "reference"]),
    ("Email Format Validation", "VALID_EMAIL", "validation", "Customer", "String", "Validates email format using regex.", "REGEXP_LIKE(email, '^[..]+@[..]+$')", [{"input": "'a@b.com'", "output": "true"}], "Neha Gupta", "Approved", 421, ["validation", "email"]),
    ("Date Standardization (YYYY-MM-DD)", "DATE_STD", "standardization", "Date", "Date", "Converts date to standard YYYY-MM-DD format.", "TO_DATE(<input>, 'YYYY-MM-DD')", [{"input": "'01/15/2024'", "output": "'2024-01-15'"}], "Amit Sharma", "Approved", 376, ["standardization", "date"]),
    ("Remove Special Characters", "REMOVE_SPECIAL", "standardization", "Customer", "String", "Removes special characters.", "REGEXP_REPLACE(<input>, '[^a-zA-Z0-9]', '')", [{"input": "'A#B!C'", "output": "'ABC'"}], "Shivani Das", "Approved", 265, ["standardization"]),
    ("Age Calculation", "AGE_CALC", "derivation", "Customer", "Numeric", "Calculates age from date of birth.", "DATEDIFF(CURRENT_DATE, dob)/365", [{"input": "'1990-01-01'", "output": "34"}], "Rahul Verma", "Approved", 189, ["derivation"]),
    ("Numeric Range Validation", "NUM_RANGE", "validation", "Finance", "Numeric", "Validates numeric value is within defined range.", "<val> BETWEEN <min> AND <max>", [{"input": "42", "output": "true"}], "Priya Singh", "Approved", 233, ["validation"]),
    ("Country Code Standardization", "COUNTRY_CODE_STD", "standardization", "Reference Data", "String", "Standardizes country codes to ISO format.", "UPPER(country_code)", [{"input": "'us'", "output": "'US'"}], "Neha Gupta", "Draft", 312, ["standardization", "reference"]),
    ("Duplicate Check", "DUPLICATE_CHECK", "validation", "Customer", "String", "Checks for duplicate records.", "COUNT(*) OVER (PARTITION BY key) = 1", [{"input": "dup", "output": "false"}], "Amit Sharma", "Approved", 167, ["validation", "uniqueness"]),
    ("Concatenate Fields", "CONCAT", "derivation", "Customer", "String", "Concatenates multiple fields with a separator.", "CONCAT_WS(' ', a, b)", [{"input": "'John','Doe'", "output": "'John Doe'"}], "Rahul Verma", "Published", 128, ["derivation", "string"]),
    ("Notional Sum", "NOTIONAL_SUM", "business", "Finance", "Numeric", "Aggregates notional amounts across positions.", "SUM(notional)", [{"input": "[10,20]", "output": "30"}], "Priya Singh", "Approved", 98, ["business", "finance"]),
    ("RWA Calculation", "RWA_CALC", "business", "Risk & Compliance", "Numeric", "Computes risk-weighted assets per regulatory guidelines.", "exposure * risk_weight", [{"input": "1000 x 0.2", "output": "200"}], "Amit Sharma", "In Review", 76, ["business", "regulatory"]),
]

# (name, code, ttype, category, description, logic_expr, test_cases, owner, status, reuse_count, tags)
# Curated SYSTEM transformation library — every entry is a genuinely useful,
# reusable column transformation, owned by 'System' and Published. These are the
# pre-built transformations the Transformations screen showcases; a user Clones one
# to start a new (owned) transformation. Real Spark SQL in both logic_expr and
# logic_sql, and real test cases (name, input, output).
# (name, code, ttype, category, description, logic_expr, logic_sql, test_cases, owner, status, reuse_count, tags)
TRANSFORMATIONS = [
    ("Trim Whitespace", "SYS_TRIM", "library", "string",
     "Remove leading and trailing whitespace from a string.",
     "TRIM(input)", "TRIM(input)",
     [{"name": "Leading/trailing spaces", "input": "  Acme  ", "output": "Acme"},
      {"name": "Already clean", "input": "Acme", "output": "Acme"},
      {"name": "Null input", "input": None, "output": None}],
     "System", "Published", 0, ["string", "cleanup", "standardization"]),
    ("Upper Case", "SYS_UPPER", "library", "string",
     "Convert text to upper case.",
     "UPPER(input)", "UPPER(input)",
     [{"name": "Mixed case", "input": "Acme Corp", "output": "ACME CORP"},
      {"name": "Already upper", "input": "ACME", "output": "ACME"}],
     "System", "Published", 0, ["string"]),
    ("Lower Case", "SYS_LOWER", "library", "string",
     "Convert text to lower case.",
     "LOWER(input)", "LOWER(input)",
     [{"name": "Mixed case", "input": "Acme Corp", "output": "acme corp"}],
     "System", "Published", 0, ["string"]),
    ("Proper Case", "SYS_PROPER", "library", "string",
     "Capitalize the first letter of each word (title case).",
     "INITCAP(input)", "INITCAP(input)",
     [{"name": "Lower name", "input": "ada lovelace", "output": "Ada Lovelace"},
      {"name": "Upper name", "input": "ADA LOVELACE", "output": "Ada Lovelace"}],
     "System", "Published", 0, ["string", "names"]),
    ("Standardize Name", "SYS_STD_NAME", "library", "string",
     "Trim, strip special characters and convert a name to proper case.",
     "INITCAP(REGEXP_REPLACE(TRIM(input), '[^a-zA-Z0-9 ]', ''))",
     "INITCAP(REGEXP_REPLACE(TRIM(input), '[^a-zA-Z0-9 ]', ''))",
     [{"name": "Messy name", "input": "  john_doe-123 ", "output": "John Doe 123"},
      {"name": "Punctuation", "input": "o'brien, sean", "output": "Obrien Sean"}],
     "System", "Published", 0, ["string", "names", "cleanup"]),
    ("Null To Default", "SYS_COALESCE", "library", "other",
     "Replace nulls with a default value.",
     "COALESCE(input, default)", "COALESCE(input, default)",
     [{"name": "Null → default", "input": None, "output": "default"},
      {"name": "Value kept", "input": "X", "output": "X"}],
     "System", "Published", 0, ["cleanup", "completeness"]),
    ("Regex Replace", "SYS_REGEX_REPLACE", "library", "string",
     "Replace all matches of a regular expression with a replacement string.",
     "REGEXP_REPLACE(input, pattern, replacement)", "REGEXP_REPLACE(input, pattern, replacement)",
     [{"name": "Strip non-alnum", "input": "a-b_c!", "output": "abc"}],
     "System", "Published", 0, ["string", "regex"]),
    ("Concatenate", "SYS_CONCAT", "library", "string",
     "Join multiple strings with a separator, skipping nulls.",
     "CONCAT_WS(' ', first_name, last_name)", "CONCAT_WS(' ', first_name, last_name)",
     [{"name": "First + last", "input": "Ada | Lovelace", "output": "Ada Lovelace"},
      {"name": "Null part skipped", "input": "Ada | null", "output": "Ada"}],
     "System", "Published", 0, ["string"]),
    ("Digits Only", "SYS_DIGITS_ONLY", "library", "string",
     "Keep only the digit characters — used to normalize phone numbers and IDs.",
     "REGEXP_REPLACE(input, '[^0-9]', '')", "REGEXP_REPLACE(input, '[^0-9]', '')",
     [{"name": "Formatted phone", "input": "+1 (415) 555-0100", "output": "14155550100"}],
     "System", "Published", 0, ["string", "phone"]),
    ("Date Standardization (YYYY-MM-DD)", "SYS_DATE_STD", "library", "date",
     "Parse and reformat a date to the ISO YYYY-MM-DD format.",
     "DATE_FORMAT(TO_DATE(input), 'yyyy-MM-dd')", "DATE_FORMAT(TO_DATE(input), 'yyyy-MM-dd')",
     [{"name": "ISO in", "input": "2024-01-15", "output": "2024-01-15"}],
     "System", "Published", 0, ["date"]),
    ("Age From Date Of Birth", "SYS_AGE", "library", "numeric",
     "Compute whole-year age from a date of birth.",
     "FLOOR(DATEDIFF(CURRENT_DATE(), TO_DATE(dob)) / 365.25)",
     "FLOOR(DATEDIFF(CURRENT_DATE(), TO_DATE(dob)) / 365.25)",
     [{"name": "Born 2000-01-01", "input": "2000-01-01", "output": "25"}],
     "System", "Published", 0, ["numeric", "date"]),
    ("Cast To Decimal", "SYS_CAST_DECIMAL", "library", "conversion",
     "Cast a string amount to a fixed-precision decimal.",
     "CAST(input AS DECIMAL(18,2))", "CAST(input AS DECIMAL(18,2))",
     [{"name": "Money string", "input": "1050.75", "output": "1050.75"}],
     "System", "Published", 0, ["conversion", "numeric", "finance"]),
    ("Number To String", "SYS_NUM_TO_STR", "library", "conversion",
     "Convert a numeric value to its string representation.",
     "CAST(input AS STRING)", "CAST(input AS STRING)",
     [{"name": "Integer", "input": "42", "output": "42"}],
     "System", "Published", 0, ["conversion"]),
    ("Country Name To ISO Code", "SYS_COUNTRY_ISO", "library", "conversion",
     "Map a country name to its ISO-3166 alpha-2 code via a CASE lookup.",
     "CASE UPPER(input) WHEN 'UNITED STATES' THEN 'US' WHEN 'UNITED KINGDOM' THEN 'GB' WHEN 'INDIA' THEN 'IN' ELSE NULL END",
     "CASE UPPER(input) WHEN 'UNITED STATES' THEN 'US' WHEN 'UNITED KINGDOM' THEN 'GB' WHEN 'INDIA' THEN 'IN' ELSE NULL END",
     [{"name": "US", "input": "United States", "output": "US"},
      {"name": "Unknown", "input": "Atlantis", "output": None}],
     "System", "Published", 0, ["conversion", "reference"]),
]

# (name, code, rule_type, dataset, column, severity, description, logic, owner, last_status, success_rate, failed_records, tags)
# Curated SYSTEM data-quality rule library — a wide variety across all 7 rule
# types, all owner='System', governance status 'Published'. These are the
# system-suggested rules the Validation screen showcases; a user clones/creates
# their own and submits it through the approval workflow.
# (name, code, rule_type, dataset, column, severity, description, logic, owner, status, last_status, success_rate, failed_records, tags)
VALIDATIONS = [
    # completeness
    ("Not Null - Primary Key", "SYS_DQ_PK_NOTNULL", "completeness", "customer_master", "Customer_ID", "critical", "Primary key must always be present.", "Customer_ID IS NOT NULL", "System", "Published", "Passed", 1.0, 0, ["completeness", "key"]),
    ("Not Null - Customer Name", "SYS_DQ_NAME_NOTNULL", "completeness", "customer_master", "Customer_Name", "high", "Customer name must be present.", "Customer_Name IS NOT NULL", "System", "Published", "Passed", 0.998, 8, ["completeness"]),
    ("Not Empty - Address Line 1", "SYS_DQ_ADDR_NOTEMPTY", "completeness", "customer_master", "Address_Line1", "medium", "Address line 1 must be present and non-blank.", "Address_Line1 IS NOT NULL AND TRIM(Address_Line1) <> ''", "System", "Published", "Passed", 0.982, 41, ["completeness"]),
    # validity
    ("Valid Email Format", "SYS_DQ_EMAIL_FMT", "validity", "customer_master", "Email_ID", "high", "Email must match a standard address pattern.", "Email_ID RLIKE '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\\\.[A-Za-z]{2,}$'", "System", "Published", "Passed", 0.987, 120, ["validity", "email"]),
    ("Valid Phone Length", "SYS_DQ_PHONE_LEN", "validity", "customer_master", "Phone_Number", "low", "Normalized phone number must have 10 digits.", "LENGTH(REGEXP_REPLACE(Phone_Number, '[^0-9]', '')) = 10", "System", "Published", "Passed", 0.992, 45, ["validity", "phone"]),
    ("Valid Status Enum", "SYS_DQ_STATUS_ENUM", "validity", "customer_master", "Account_Status", "medium", "Account status must be one of the allowed values.", "Account_Status IN ('ACTIVE','INACTIVE','SUSPENDED','CLOSED')", "System", "Published", "Passed", 0.999, 3, ["validity", "enum"]),
    # accuracy
    ("Age In Valid Range", "SYS_DQ_AGE_RANGE", "accuracy", "customer_master", "Age", "medium", "Age must be within a plausible range.", "Age BETWEEN 18 AND 120", "System", "Published", "Failed", 0.921, 642, ["accuracy", "range"]),
    ("Credit Score In Range", "SYS_DQ_CREDIT_RANGE", "accuracy", "customer_master", "Credit_Score", "medium", "Credit score must be between 300 and 850.", "Credit_Score BETWEEN 300 AND 850", "System", "Published", "Passed", 0.996, 22, ["accuracy", "range"]),
    ("Non-Negative Balance", "SYS_DQ_BALANCE_NONNEG", "accuracy", "account_fact", "Account_Balance", "high", "Account balance may not be negative.", "Account_Balance >= 0", "System", "Published", "Passed", 0.978, 190, ["accuracy"]),
    # business_rule
    ("Order Amount Positive", "SYS_DQ_ORDER_POS", "business_rule", "orders_fact", "Order_Amount", "high", "Order amount must be strictly positive.", "Order_Amount > 0", "System", "Published", "Failed", 0.893, 842, ["business_rule"]),
    ("High-Value Order Flagged", "SYS_DQ_HIGHVAL_FLAG", "business_rule", "orders_fact", "Order_Amount", "medium", "Orders over 10,000 must carry a review flag.", "Order_Amount <= 10000 OR Review_Flag = TRUE", "System", "Published", "Passed", 0.965, 88, ["business_rule"]),
    # consistency
    ("Order Date Not Future", "SYS_DQ_ORDERDATE_PAST", "consistency", "orders_fact", "Order_Date", "high", "Order date cannot be in the future.", "Order_Date <= CURRENT_DATE()", "System", "Published", "Passed", 1.0, 0, ["consistency", "date"]),
    ("Ship After Order", "SYS_DQ_SHIP_AFTER_ORDER", "consistency", "orders_fact", "Ship_Date", "medium", "Ship date must be on or after the order date.", "Ship_Date IS NULL OR Ship_Date >= Order_Date", "System", "Published", "Passed", 0.994, 31, ["consistency", "date"]),
    # uniqueness
    ("Unique Customer ID", "SYS_DQ_CUST_UNIQUE", "uniqueness", "customer_master", "Customer_ID", "critical", "Customer ID must be unique across the dataset.", "COUNT(*) = COUNT(DISTINCT Customer_ID)", "System", "Published", "Failed", 0.856, 1248, ["uniqueness", "key"]),
    ("Unique Email", "SYS_DQ_EMAIL_UNIQUE", "uniqueness", "customer_master", "Email_ID", "high", "Email addresses should not be duplicated.", "COUNT(*) = COUNT(DISTINCT Email_ID)", "System", "Published", "Passed", 0.973, 268, ["uniqueness", "email"]),
    # referential
    ("Country Code In Reference", "SYS_DQ_COUNTRY_REF", "referential", "customer_master", "Country_Code", "medium", "Country code must exist in the ISO reference table.", "Country_Code IN (SELECT code FROM ref_country)", "System", "Published", "Passed", 0.998, 12, ["referential"]),
    ("Account Owner Exists", "SYS_DQ_ACCT_OWNER_FK", "referential", "account_fact", "Customer_ID", "high", "Every account must reference an existing customer.", "Customer_ID IN (SELECT Customer_ID FROM customer_master)", "System", "Published", "Passed", 0.991, 76, ["referential", "key"]),
]

VAL_RUNS = [("Data Quality Run - Daily", "Daily", 0.926, 0), ("Data Quality Run - Hourly", "Hourly", 0.891, 3), ("Data Quality Run - Daily", "Daily", 0.933, 27), ("Data Quality Run - Adhoc", "Adhoc", 0.764, 50)]

# (name, type, system, domain, criticality, owner, impact_score)
DATA_ASSETS = [
    ("Customer_Master", "table", "BU_RETAIL", "Customer Management", "Critical", "Shivani Das", 92),
    ("Corporate_Customer_Dim", "table", "CORP_EDW", "Customer Management", "High", "Rahul Verma", 88),
    ("Reg_Exposures_Report", "report", "REG_REPORTING", "Risk & Compliance", "Critical", "Priya Singh", 92),
    ("Risk_Calculation_Pipeline", "pipeline", "RISK_LEDGER", "Risk & Compliance", "Critical", "Amit Sharma", 85),
    ("Customer_Profile_Dashboard", "dashboard", "CORP_EDW", "Customer Management", "High", "Neha Gupta", 88),
    ("Country_Code_Reference", "table", "REF_SYS", "Reference Data", "Medium", "Rahul Verma", 40),
    ("GL_Account_Master", "table", "SUB_LEDGER", "Finance", "High", "Shivani Das", 65),
    ("Risk_Exposure_Report", "report", "REG_REPORTING", "Risk & Compliance", "High", "Amit Sharma", 85),
    ("GL_Mapping_Pipeline", "pipeline", "SUB_LEDGER", "Finance", "Medium", "Priya Singh", 65),
    ("Reference_Data_Pipeline", "pipeline", "REF_SYS", "Reference Data", "Medium", "Neha Gupta", 60),
]

# Relationship graph edges (business meaning → executed report).
EDGES = [
    ("Customer", "business_term", "Customer_Master", "table", "defines"),
    ("Customer Key", "business_term", "Customer_Master", "table", "defines"),
    ("Customer_Master", "table", "Customer Standardization Mapping", "mapping", "source_of"),
    ("Customer Standardization Mapping", "mapping", "Corporate_Customer_Dim", "table", "targets"),
    ("Corporate_Customer_Dim", "table", "Risk_Calculation_Pipeline", "pipeline", "feeds"),
    ("Corporate_Customer_Dim", "table", "Customer_Profile_Dashboard", "dashboard", "feeds"),
    ("Risk_Calculation_Pipeline", "pipeline", "Reg_Exposures_Report", "report", "produces"),
]

# (pipeline, status, duration_sec, cost, row_count, validation_status, error, hours_ago)
EXECUTIONS = [
    ("Reg_Exposures_Pipeline", "succeeded", 214, 12.40, 1_240_000, "Passed", None, 1),
    ("Customer_Standardization_Pipeline", "succeeded", 132, 8.10, 480_000, "Passed", None, 2),
    ("Risk_Calculation_Pipeline", "running", None, None, None, "Running", None, 0),
    ("GL_Mapping_Pipeline", "warning", 98, 4.20, 210_000, "Warning", "3 rows failed range check", 3),
    ("Reference_Data_Pipeline", "succeeded", 46, 1.90, 165_000, "Passed", None, 4),
    ("Customer_Address_Validation", "failed", 61, 2.10, 0, "Failed", "Duplicate customer check failed", 3),
    ("P&L_Mapping_Pipeline", "succeeded", 152, 9.30, 320_000, "Passed", None, 6),
]

ACTIVITY = [
    ("Rahul Verma", "published", "Reg_Exposures mapping", "mapping", 2 / 60),
    ("Mapping Factory", "AI generated 24 new mappings", "", "system", 15 / 60),
    ("Shivani Das", "updated", "Corporate EDW mapping", "mapping", 1),
    ("System", "completed", "CORP_EDW pipeline", "pipeline", 2),
    ("System", "validation failed for", "Customer Address", "validation", 3),
]


def seed(pool: ConnectionPool) -> dict:
    """Load the consistent dataset. Idempotent via natural-key existence checks."""
    counts: dict[str, int] = {}
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SET search_path TO mapping_factory, public")

            def ins(table: str, key_col: str, key_val, cols: list[str], vals: list):
                cur.execute(f"SELECT 1 FROM {table} WHERE {key_col} = %s", (key_val,))
                if cur.fetchone():
                    return 0
                placeholders = ",".join(["%s"] * len(cols))
                cur.execute(f"INSERT INTO {table} ({','.join(cols)}) VALUES ({placeholders})", vals)
                return 1

            # Retire the old demo system codes (GABBY/FINREP) so re-seeding replaces
            # them with the renamed catalog rather than leaving stale rows alongside.
            # source_system + mapping_spec are keyed by code/name (skip-if-exists), so
            # they need an explicit cleanup; the clear-and-reload tables below don't.
            cur.execute("DELETE FROM source_system WHERE code IN ('BU_GABBY','CORP_GABBY','FINREP')")
            cur.execute(
                "UPDATE mapping_spec SET source_system='BU_RETAIL' WHERE source_system='BU_GABBY'"
            )
            cur.execute("UPDATE mapping_spec SET source_system='CORP_EDW' WHERE source_system='CORP_GABBY'")
            cur.execute("UPDATE mapping_spec SET source_system='REG_REPORTING' WHERE source_system='FINREP'")
            cur.execute("UPDATE mapping_spec SET target_system='BU_RETAIL' WHERE target_system='BU_GABBY'")
            cur.execute("UPDATE mapping_spec SET target_system='CORP_EDW' WHERE target_system='CORP_GABBY'")
            cur.execute("UPDATE mapping_spec SET target_system='REG_REPORTING' WHERE target_system='FINREP'")
            # Retire the old demo display-only mapping_spec rows (no assets, no mappings) —
            # the Mapping List should show only REAL, asset-backed specs. Scoped to the
            # known demo names AND guarded to rows that never became real (no field_mapping),
            # so a real spec that happens to share a name is never touched.
            _DEMO_MAPPING_NAMES = [
                "FINREP_Exposures Mapping", "Reg_Exposures Mapping", "Customer Standardization",
                "RWA Mapping", "Risk Exposure Mapping", "GL Account Mapping", "Reference Data Mapping",
                "Data Quality Rules Mapping", "FINREP Liquidity Mapping", "Liquidity Mapping",
                "Derivatives Mapping", "Profit & Loss Mapping", "Country Code Mapping",
            ]
            cur.execute(
                """DELETE FROM mapping_spec s
                   WHERE s.name = ANY(%s) AND s.source_asset_id IS NULL AND s.target_asset_id IS NULL
                     AND NOT EXISTS (SELECT 1 FROM field_mapping fm WHERE fm.spec_id = s.id)""",
                (_DEMO_MAPPING_NAMES,),
            )

            counts["source_system"] = sum(
                ins("source_system", "code", c, ["code", "name", "asset_count"], [c, n, a]) for c, n, a in SYSTEMS
            )
            counts["glossary_term"] = sum(
                ins("glossary_term", "name", g[0], ["name", "definition", "term_type", "domain", "steward"], list(g)) for g in GLOSSARY
            )
            # NOTE: the dummy display-only MAPPINGS list is intentionally NO LONGER seeded —
            # the Mapping List shows only real, asset-backed specs created through the app.
            counts["mapping_spec"] = 0
            # Backfill display metadata on any pre-existing (real test) specs so the
            # Mapping List looks coherent instead of showing blank source/target.
            cur.execute(
                """UPDATE mapping_factory.mapping_spec
                   SET source_system = COALESCE(source_system, 'BU_RETAIL'),
                       target_system = COALESCE(target_system, 'CORP_EDW'),
                       mapping_type  = COALESCE(mapping_type, 'Standardization'),
                       description   = COALESCE(description, 'Field-level mapping'),
                       ai_confidence = COALESCE(ai_confidence, 0.90)
                   WHERE source_system IS NULL OR mapping_type IS NULL"""
            )
            # Re-own any pre-existing seeded rule rows (they had fake owners/statuses
            # from an earlier seed) to the clean System/Published catalog. Scoped to the
            # known seed codes so user-created Rule Library rules are never touched.
            _SEED_RULE_CODES = [r[1] for r in RULES]
            cur.execute(
                "UPDATE rule SET owner='System', status='Published' WHERE code = ANY(%s)",
                (_SEED_RULE_CODES,),
            )
            # System-owned, Published library rules (dataset-agnostic). owner/status are
            # normalized to System/Published regardless of the tuple's legacy values so
            # the Rule Library shows a clean system-suggested catalog (no fake owners).
            counts["rule"] = sum(
                ins("rule", "code", r[1],
                    ["name", "code", "rule_type", "domain", "data_type", "description", "logic_preview", "sample_io", "owner", "status", "usage_count", "tags", "updated_at"],
                    [r[0], r[1], r[2], r[3], r[4], r[5], r[6], Json(r[7]), "System", "Published", 0, r[11], _ago(days=SYSTEMS.index(SYSTEMS[0]))])
                for r in RULES
            )
            # Retire the legacy dummy transformations (the old fake-owner rows) so the
            # screen shows only the curated System library. Explicit code list — never
            # touches user-created transformations. Idempotent; SYS_* rows seeded below.
            _LEGACY_XFORM_CODES = [
                "TRIM_001", "UPPER_001", "DATE_STD_001", "NULL_DEF_001", "REGEX_REPLACE_001",
                "CONCAT_001", "AGE_CALC_001", "NUM_STR_001", "DATE_DIFF_001", "PHONE_STD_001",
                "PROPER_001", "CCY_CONV_001",
            ]
            cur.execute("DELETE FROM transformation WHERE code = ANY(%s)", (_LEGACY_XFORM_CODES,))
            counts["transformation"] = sum(
                ins("transformation", "code", t[1],
                    ["name", "code", "ttype", "category", "description", "logic_expr", "logic_sql", "test_cases", "owner", "status", "reuse_count", "tags"],
                    [t[0], t[1], t[2], t[3], t[4], t[5], t[6], Json(t[7]), t[8], t[9], t[10], t[11]])
                for t in TRANSFORMATIONS
            )
            # Retire the legacy dummy DQ rules (old RULE_00xxx fake-owner rows) so the
            # screen shows only the curated System library. Idempotent; SYS_DQ_* below.
            cur.execute("DELETE FROM validation_rule WHERE code LIKE 'RULE_00%'")
            counts["validation_rule"] = sum(
                ins("validation_rule", "code", v[1],
                    ["name", "code", "rule_type", "dataset", "column_name", "severity", "description", "logic", "owner", "status", "last_status", "success_rate", "failed_records", "tags", "last_run_at"],
                    [v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11], v[12], v[13], _ago(hours=6)])
                for v in VALIDATIONS
            )
            # validation_run + activity + executions have no natural unique key → clear+reload for idempotency
            for tbl in ("validation_run", "execution", "activity", "metadata_edge", "data_asset"):
                cur.execute(f"DELETE FROM {tbl}")
            for rn, cad, pct, _f in VAL_RUNS:
                cur.execute("INSERT INTO validation_run (run_name, cadence, passed_pct, run_at) VALUES (%s,%s,%s,%s)", (rn, cad, pct, _ago(hours=6)))
            counts["validation_run"] = len(VAL_RUNS)
            for a in DATA_ASSETS:
                cur.execute("INSERT INTO data_asset (name, asset_type, system, domain, criticality, owner, impact_score) VALUES (%s,%s,%s,%s,%s,%s,%s)", a)
            counts["data_asset"] = len(DATA_ASSETS)
            for e in EDGES:
                cur.execute("INSERT INTO metadata_edge (src_name, src_type, dst_name, dst_type, edge_type) VALUES (%s,%s,%s,%s,%s)", e)
            counts["metadata_edge"] = len(EDGES)
            for p, st, dur, cost, rc, vs, err, h in EXECUTIONS:
                cur.execute(
                    "INSERT INTO execution (pipeline_name, status, duration_sec, cost, row_count, validation_status, error, started_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
                    (p, st, dur, cost, rc, vs, err, _ago(hours=h)),
                )
            counts["execution"] = len(EXECUTIONS)
            for actor, action, target, ttype, h in ACTIVITY:
                cur.execute("INSERT INTO activity (actor, action, target, target_type, at) VALUES (%s,%s,%s,%s,%s)", (actor, action, target, ttype, _ago(hours=h)))
            counts["activity"] = len(ACTIVITY)
        conn.commit()
    return counts
