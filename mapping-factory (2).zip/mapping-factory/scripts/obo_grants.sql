-- Mapping Factory — Unity Catalog grants for OBO (on-behalf-of-user) auth.
--
-- After OBO is enabled (User Authorization scopes sql/serving/files added in the
-- app settings UI), request-time workspace/warehouse/Foundation-Model calls run as
-- the LOGGED-IN USER, not the app service principal. So each user who logs in needs
-- their own grants on the objects the app touches during a request. Grant to the
-- group of app users.
--
-- Run these on the app's SQL warehouse (cd54b9f16b2bf7ed) as a user/admin that owns
-- or can MANAGE these objects. Grantee group: `mapping factory users`.
--
-- NOTE: warehouse CAN USE and serving-endpoint CAN QUERY are NOT SQL grants — see
-- scripts/obo_grants.sh for those (they go through the permissions API/CLI).

-- === Catalog + schema (governed tier: artifact_version, approved_field_mapping,
--     compiled_artifact, lineage_edge live here; a schema grant covers them all) ===
GRANT USE CATALOG ON CATALOG pritam_demo_workspace_catalog TO `mapping factory users`;
GRANT USE SCHEMA  ON SCHEMA  pritam_demo_workspace_catalog.mapping_factory TO `mapping factory users`;

-- Read + write the governed Delta artifacts (compile / approve-publish / run).
GRANT SELECT ON SCHEMA pritam_demo_workspace_catalog.mapping_factory TO `mapping factory users`;
GRANT MODIFY ON SCHEMA pritam_demo_workspace_catalog.mapping_factory TO `mapping factory users`;
-- First-ever approve in a fresh schema bootstraps the Delta tables — needed only if
-- the artifact tables don't exist yet. Safe to include.
GRANT CREATE TABLE ON SCHEMA pritam_demo_workspace_catalog.mapping_factory TO `mapping factory users`;

-- === Source tables users map FROM (register-from-UC-table + demos introspect these
--     via information_schema, and Run reads them). Grant SELECT on whatever source
--     schemas your users map. The schema grant above already covers sources that
--     live in mapping_factory (e.g. src_customers, src_customer_raw). Add others as
--     needed, e.g.: ===
-- GRANT USE CATALOG ON CATALOG <src_catalog> TO `mapping factory users`;
-- GRANT USE SCHEMA  ON SCHEMA  <src_catalog>.<src_schema> TO `mapping factory users`;
-- GRANT SELECT      ON SCHEMA  <src_catalog>.<src_schema> TO `mapping factory users`;

-- === UC volumes (document upload / parse-tables, and Publish-to-Knowledge-Assistant
--     evidence). READ + WRITE VOLUME. ===
GRANT READ VOLUME  ON VOLUME pritam_demo_workspace_catalog.mapping_factory.documents TO `mapping factory users`;
GRANT WRITE VOLUME ON VOLUME pritam_demo_workspace_catalog.mapping_factory.documents TO `mapping factory users`;
GRANT READ VOLUME  ON VOLUME pritam_demo_workspace_catalog.mapping_factory.evidence  TO `mapping factory users`;
GRANT WRITE VOLUME ON VOLUME pritam_demo_workspace_catalog.mapping_factory.evidence  TO `mapping factory users`;
