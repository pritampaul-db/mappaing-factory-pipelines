"""Agentic Mapping Validation — the "Test mapping" orchestrator.

Runs a real, end-to-end test of a mapping as a sequence of agentic steps, each
reporting live progress (surfaced in the New Mapping screen's bottom panel):

  1. Generate dummy source data  — an LLM invents realistic, messy rows for the
     source data model; written to a scratch UC table.
  2. Compile config              — the mapping's transforms (deterministically
     lowered to SQL) + its validation rules are turned into the pipeline config.
  3. Run the SDP pipeline        — the generic serverless pipeline is started with
     that config + input table; we poll it to completion. It builds the target +
     a DQ table.
  4. Validate                    — target row count, target-schema conformance,
     and per-rule DQ pass rates are checked against the metadata.

Runs are executed on a background thread; the route layer polls `get_run`.
Nothing here is on the interactive request path — a run takes minutes (a real
serverless pipeline update).
"""
from __future__ import annotations

import json
import threading
import time
import uuid
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from server import compiler, config, llm, repo, repo_library, sdp_pipeline, warehouse
from server.governance import _sql_str

CATALOG = config.UC_CATALOG
SCHEMA = config.UC_SCHEMA

# In-memory run registry (run_id -> state). A run is short-lived and polled by the
# UI; we don't need to persist it across app restarts.
_RUNS: dict[str, dict[str, Any]] = {}
_LOCK = threading.Lock()

# The agent workflow — six named agents, mirrored in the UI's Agent Workflow panel.
_STEP_DEFS = [
    ("metadata", "Metadata Agent", "Analyze models & metadata"),
    ("dummy_data", "Dummy Data Agent", "Generate synthetic source data"),
    ("compile_config", "Config Agent", "Generate transformation & validation config"),
    ("run_pipeline", "Pipeline Agent", "Deploy & run SDP pipeline"),
    ("validate", "Validation Agent", "Validate output data & rules"),
    ("analysis", "Analysis Agent", "Analyze results & recommend"),
]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_run(spec_id: str) -> dict[str, Any]:
    run_id = uuid.uuid4().hex[:12]
    run = {
        "run_id": run_id,
        "spec_id": spec_id,
        "status": "running",  # running | succeeded | failed
        "started_at": _now(),
        "steps": [
            {"key": k, "agent": a, "description": d, "status": "pending", "detail": None, "elapsed_sec": None}
            for k, a, d in _STEP_DEFS
        ],
        "pipeline": None,  # {name, cluster, environment, compute, target} — filled by Pipeline Agent
        "config": None,    # compiled transforms + validations — downloadable artifact
        "result": None,
        "error": None,
    }
    with _LOCK:
        _RUNS[run_id] = run
    return run


def get_run(run_id: str) -> dict[str, Any] | None:
    import time as _t

    with _LOCK:
        r = _RUNS.get(run_id)
        if not r:
            return None
        # Advance the live timer for any running step so the UI counts up.
        for s in r["steps"]:
            if s["status"] == "running" and s.get("_started_mono") is not None:
                s["elapsed_sec"] = round(_t.monotonic() - s["_started_mono"], 1)
        snap = json.loads(json.dumps(r))  # deep copy for safe reads
    for s in snap["steps"]:
        s.pop("_started_mono", None)  # internal; don't leak to the client
    return snap


def _set_step(run: dict, key: str, status: str, detail: str | None = None) -> None:
    """Update a step's status + detail, tracking per-step elapsed time.

    Time starts when a step goes 'running' and is frozen when it reaches a terminal
    state (done/failed) — so the UI shows a live-then-final duration per agent.
    """
    import time as _t

    with _LOCK:
        for s in run["steps"]:
            if s["key"] == key:
                if status == "running" and s.get("_started_mono") is None:
                    s["_started_mono"] = _t.monotonic()
                if s.get("_started_mono") is not None:
                    s["elapsed_sec"] = round(_t.monotonic() - s["_started_mono"], 1)
                s["status"] = status
                if detail is not None:
                    s["detail"] = detail
                break


def start(spec_id: UUID) -> dict[str, Any]:
    """Kick off a validation run on a background thread; return the initial run state."""
    run = _new_run(str(spec_id))
    t = threading.Thread(target=_execute, args=(str(spec_id), run), daemon=True)
    t.start()
    return run


def _execute(spec_id: str, run: dict) -> None:
    try:
        spec = repo.get_spec(db_pool(), UUID(spec_id))
        if spec is None:
            raise ValueError("spec not found")
        sources = spec.get("sources") or ([s] if (s := repo.get_asset(db_pool(), spec["source_asset_id"])) else [])
        targets = spec.get("targets") or ([t] if (t := repo.get_asset(db_pool(), spec["target_asset_id"])) else [])
        if not sources or not targets:
            raise ValueError("spec is missing its source or target asset(s)")

        # Pooled source types across all source tables — qualified `Table.col` AND bare,
        # so a transform's ref resolves whichever form the AI used.
        source_types: dict[str, str] = {}
        for a in sources:
            for f in a["fields"]:
                source_types[f["name"]] = f["datatype"]
                source_types[f"{a['name']}.{f['name']}"] = f["datatype"]
        tgt_asset_by_field = {str(f["id"]): a for a in targets for f in a["fields"]}
        active_maps = [m for m in spec["mappings"] if m["state"] != "rejected"]

        # --- Metadata Agent: analyze the source/target models --------------
        _set_step(run, "metadata", "running")
        _set_step(
            run, "metadata", "done",
            f"{len(sources)} source table(s), {len(targets)} target table(s), {len(active_maps)} mappings, {len(spec.get('joins') or [])} join(s)",
        )

        # Resolve joins to source table + column names up front (needed BOTH to make
        # the dummy data referentially consistent and for the pipeline join plan).
        # left/right are qualified `Table.col`.
        joins = []
        for j in (spec.get("joins") or []):
            lt, _, lc = (j.get("left") or "").partition(".")
            rt, _, rc = (j.get("right") or "").partition(".")
            if lt and lc and rt and rc:
                joins.append({"left_table": lt, "left_col": lc, "right_table": rt, "right_col": rc})

        # --- Dummy Data Agent: synthetic data for EACH source table -------
        # One LLM call per source table; a slow/failing call must NOT stall the run,
        # so each is bounded (client timeout) and falls back to deterministic rows.
        _set_step(run, "dummy_data", "running")
        rows_by_table: dict[str, list[list]] = {}
        for i, a in enumerate(sources):
            _set_step(run, "dummy_data", "running", f"generating {a['name']} ({i + 1}/{len(sources)})…")
            try:
                rows = llm.generate_dummy_rows(a["fields"], n=25)
            except Exception as e:  # noqa: BLE001 — never let one table's gen freeze the run
                print(f"[agentic] dummy-data LLM failed for {a['name']}: {e}; using synthetic fallback")
                rows = _synthetic_rows(a["fields"], n=25)
            if not rows:
                rows = _synthetic_rows(a["fields"], n=25)
            rows_by_table[a["name"]] = rows

        # Make the data REFERENTIALLY CONSISTENT: the LLM generates each table
        # independently, so join keys (e.g. CUSTOMER_ID on master vs address) never
        # overlap and every LEFT JOIN misses → columns from joined tables come out all
        # NULL (a NOT-NULL rule then reads 0%). Align each join's key columns so the
        # child's FK values are drawn from the parent's actual key values.
        _align_join_keys(sources, joins, rows_by_table)

        input_tables: dict[str, dict] = {}
        total_rows = 0
        for a in sources:
            rows = rows_by_table[a["name"]]
            fqn = f"{CATALOG}.{SCHEMA}.mf_test_input_{run['run_id']}_{_slug(a['name'])}"
            _write_dummy_table(fqn, a["fields"], rows)
            input_tables[a["name"]] = {"table": fqn, "columns": [f["name"] for f in a["fields"]]}
            total_rows += len(rows)
        _set_step(run, "dummy_data", "done", f"{total_rows} rows across {len(input_tables)} source table(s)")

        # --- Config Agent: build the v2 (multi-table) config ---------------
        _set_step(run, "compile_config", "running")

        # Only THIS spec's saved validations (scoped by the spec:<id> tag) — dataset
        # name alone isn't unique across mappings, so don't test with another's rules.
        spec_tag = f"spec:{spec_id}"
        all_vals = []
        try:
            all_vals = [v for v in repo_library.list_validations(db_pool()) if spec_tag in (v.get("tags") or [])]
        except Exception:  # noqa: BLE001
            pass

        cfg_targets = []
        total_transforms = 0
        total_rules = 0
        source_names = {a["name"] for a in sources}
        for tgt in targets:
            dataset = tgt["name"]
            cols = []
            src_contrib: dict[str, int] = {}  # source table -> # of this target's columns it feeds
            referenced_tables: set[str] = set()  # every source table any expr actually references
            for m in active_maps:
                if tgt_asset_by_field.get(str(m["target_field_id"])) is not tgt:
                    continue
                sql = _lower(m, source_types)
                if sql:
                    cols.append({"target_field": m["target_field_name"], "sql": sql})
                    for st in (m.get("provenance") or {}).get("source_tables") or []:
                        src_contrib[st] = src_contrib.get(st, 0) + 1
                    # Parse the ACTUAL qualified table refs in the expression — provenance
                    # can be stale (e.g. an Optimize edit folds in a 2nd table via COALESCE),
                    # and the FROM clause MUST include every table the SQL touches or the
                    # run fails with UNRESOLVED_COLUMN.
                    referenced_tables |= _tables_in_expr(sql, source_names)
            # GRAIN = the source table that feeds the MOST of this target's columns
            # (the spine), NOT alphabetical. The SDP pipeline anchors FROM on the
            # first entry and LEFT-JOINs the rest, so anchoring on the spine keeps the
            # target's own key/columns non-null (alphabetical could anchor a child dim
            # → the parent's columns get nulled where the join misses).
            src_tables_used = sorted(src_contrib, key=lambda t: (-src_contrib[t], t))
            # Union in any table the expressions reference but provenance missed, so the
            # JOIN plan always covers every column used (order-stable: grain-ranked first).
            for t in sorted(referenced_tables):
                if t not in src_tables_used:
                    src_tables_used.append(t)
            vals = [
                {"name": v["code"] or v["name"], "column": v["column_name"], "logic": _sanitize_logic(v["logic"])}
                for v in all_vals
                if v.get("dataset") == dataset and v.get("column_name") and v.get("logic")
            ]
            cfg_targets.append({
                "target_name": dataset,
                "columns": cols,
                "validations": vals,
                # tables this target draws from, GRAIN FIRST (see above). Default to
                # all sources (grain = first) when provenance didn't record any.
                "source_tables": src_tables_used or [a["name"] for a in sources],
            })
            total_transforms += len(cols)
            total_rules += len(vals)

        cfg = {
            "version": 2,
            "run_id": run["run_id"],
            "inputs": input_tables,     # {source_table_name: {table, columns}}
            "joins": joins,             # [{left_table,left_col,right_table,right_col}]
            "targets": cfg_targets,     # [{target_name, columns[], validations[], source_tables[]}]
        }
        _write_config_row(run["run_id"], cfg)
        with _LOCK:
            run["config"] = cfg
        _set_step(run, "compile_config", "done", f"{len(cfg_targets)} target(s), {total_transforms} transforms, {total_rules} DQ rules")

        # --- Pipeline Agent: deploy & run the SDP pipeline -----------------
        _set_step(run, "run_pipeline", "running")
        pid = sdp_pipeline.get_pipeline_id()
        if not pid:
            raise RuntimeError("SDP pipeline is not provisioned — run Setup (provision-pipeline) first.")
        with _LOCK:
            run["pipeline"] = {
                "name": sdp_pipeline.PIPELINE_NAME,
                "pipeline_id": pid,
                "environment": "Dev",
                "compute": "Serverless",
                "target": ", ".join(f"{t['target_name']}_target" for t in cfg_targets),
            }
        _run_pipeline(run, pid)
        _set_step(run, "run_pipeline", "done", "pipeline update completed")

        # --- Validation Agent: validate EACH target's output & rules ------
        _set_step(run, "validate", "running")
        result = _validate_targets(cfg_targets)
        _set_step(run, "validate", "done", result["summary"])

        # --- Analysis Agent: analyze results & recommend ------------------
        _set_step(run, "analysis", "running")
        analysis = _analyze(result)
        result["analysis"] = analysis
        _set_step(run, "analysis", "done", analysis["headline"])

        with _LOCK:
            run["status"] = "succeeded"
            run["result"] = result
            run["finished_at"] = _now()
    except Exception as e:  # noqa: BLE001 — record failure on whichever step was running
        with _LOCK:
            run["status"] = "failed"
            run["error"] = str(e)
            run["finished_at"] = _now()
            for s in run["steps"]:
                if s["status"] == "running":
                    s["status"] = "failed"


# --- helpers -----------------------------------------------------------------

def db_pool():
    from server import db

    return db.pool


import re as _re

# Match a bare (unquoted) regex literal right after RLIKE/REGEXP and quote it, e.g.
#   col RLIKE ^[a-z]+$   ->   col RLIKE '^[a-z]+$'
# Some stored rules lost their quotes; Spark then fails to parse. Quote them so the
# rule actually runs. Already-quoted regexes are left untouched.
_BARE_RE = _re.compile(r"(\b(?:RLIKE|REGEXP)\s+)(?![\"'])(\S+)", _re.IGNORECASE)


def _sanitize_logic(logic: str) -> str:
    def _q(m):
        return f"{m.group(1)}'{m.group(2)}'"
    return _BARE_RE.sub(_q, logic)


def _tables_in_expr(sql: str, known_tables: set[str]) -> set[str]:
    """Return the set of source-table names a SQL expression QUALIFIES a column against
    (e.g. `RAW_GL_JOURNAL_ENTRY.COST_CENTER_CODE` → {RAW_GL_JOURNAL_ENTRY}). Only names in
    `known_tables` are returned. Parses with sqlglot; falls back to a regex scan so a
    parse hiccup never drops a needed join table."""
    import sqlglot
    from sqlglot import exp

    found: set[str] = set()
    try:
        ast = sqlglot.parse_one(sql, read=compiler.DIALECT)
        for col in ast.find_all(exp.Column):
            if col.table and col.table in known_tables:
                found.add(col.table)
    except Exception:  # noqa: BLE001 — fall back to a literal scan below
        pass
    # Belt-and-braces: also catch `Table.` prefixes textually (covers any parse gap).
    for t in known_tables:
        if _re.search(rf"(?<![\w`]){_re.escape(t)}\s*\.", sql) or f"`{t}`." in sql:
            found.add(t)
    return found


def _lower(m: dict, source_types: dict) -> str | None:
    try:
        if (m.get("transform_kind") or "spec") == "spec" and m.get("transform_spec"):
            expr, _ = compiler._lower_spec_to_sql(m["transform_spec"], source_types)
            return expr
        if m.get("transform_sql"):
            return m["transform_sql"]
    except Exception:  # noqa: BLE001
        return None
    return None


def _slug(name: str) -> str:
    """Lowercase, keep alnum + underscore — a safe table-name suffix per source table."""
    return _re.sub(r"[^0-9a-z]+", "_", str(name).lower()).strip("_") or "src"


def _align_join_keys(sources: list[dict], joins: list[dict], rows_by_table: dict[str, list[list]]) -> None:
    """Rewrite child FK columns IN PLACE so each join actually matches.

    The LLM generates every source table independently, so a child's FK values never
    overlap the parent's PK values → LEFT JOINs miss → joined columns are all NULL
    (a NOT-NULL rule reads 0%). For each join we treat one side as the parent (the
    key it exposes) and copy real parent-key values into the child's join column,
    cycling through them so every child row points at an existing parent row.

    Direction: prefer keeping the table that OWNS the key as-is (the side whose join
    column is a declared key / named like the table's id) and overwriting the other.
    Falls back to making the LEFT side the parent. Idempotent per column.
    """
    # name -> {col -> ordinal} and the key-column set, from the asset schema.
    idx: dict[str, dict[str, int]] = {}
    keycols: dict[str, set[str]] = {}
    for a in sources:
        idx[a["name"]] = {f["name"]: i for i, f in enumerate(a["fields"])}
        keycols[a["name"]] = {f["name"] for f in a["fields"] if (f.get("semantic_type") == "key")}

    def _col_values(tbl: str, col: str) -> list:
        pos = idx.get(tbl, {}).get(col)
        if pos is None:
            return []
        return [r[pos] for r in rows_by_table.get(tbl, []) if pos < len(r) and r[pos] not in (None, "")]

    for j in joins:
        lt, lc, rt, rc = j["left_table"], j["left_col"], j["right_table"], j["right_col"]
        if lt not in idx or rt not in idx or lt == rt:
            continue
        lpos, rpos = idx[lt].get(lc), idx[rt].get(rc)
        if lpos is None or rpos is None:
            continue
        # Decide parent (source of truth for the key) vs child (gets overwritten).
        # The parent is the side whose join column is a PK-ish key with distinct values;
        # heuristic: if right col is a key and left isn't, right is parent; else left.
        left_is_key = lc in keycols.get(lt, set())
        right_is_key = rc in keycols.get(rt, set())
        if right_is_key and not left_is_key:
            parent_t, parent_c, child_t, child_c = rt, rc, lt, lc
        else:
            parent_t, parent_c, child_t, child_c = lt, lc, rt, rc
        parent_vals = _col_values(parent_t, parent_c)
        if not parent_vals:
            continue
        cpos = idx[child_t][child_c]
        child_rows = rows_by_table.get(child_t, [])
        for k, r in enumerate(child_rows):
            while len(r) <= cpos:
                r.append(None)
            r[cpos] = parent_vals[k % len(parent_vals)]


def _synthetic_rows(fields: list[dict], n: int = 25) -> list[list[str | None]]:
    """Deterministic fallback rows (used if the LLM dummy-data call fails/times out) so
    a run always has input to test with. Values are type-plausible strings by datatype."""
    from datetime import date, timedelta

    def _val(dt: str, i: int) -> str:
        dt = (dt or "string").lower()
        if "int" in dt:
            return str(1000 + i)
        if dt in ("double", "float") or "decimal" in dt or "numeric" in dt:
            return f"{100 + i}.{i % 100:02d}"
        if dt == "boolean":
            return "true" if i % 2 == 0 else "false"
        if dt == "date":
            return str(date(2020, 1, 1) + timedelta(days=i))
        if dt == "timestamp":
            return f"{date(2020, 1, 1) + timedelta(days=i)} 12:00:00"
        return f"sample_{i}"

    return [[_val(f.get("datatype", "string"), i) for f in fields] for i in range(n)]


def _lit(v: Any) -> str:
    if v is None:
        return "NULL"
    return "'" + str(v).replace("'", "''") + "'"


def _write_dummy_table(fqn: str, fields: list[dict], rows: list[list]) -> None:
    """Create a scratch all-STRING table (landing-zone style) + insert the dummy rows."""
    cols = ", ".join(f"`{f['name']}` STRING" for f in fields)
    warehouse.execute(f"DROP TABLE IF EXISTS {fqn}")
    warehouse.execute(f"CREATE TABLE {fqn} ({cols})")
    n = len(fields)
    # Batch inserts to keep statements a sane size.
    batch: list[str] = []
    for r in rows:
        vals = list(r) + [None] * (n - len(r)) if len(r) < n else list(r)[:n]
        batch.append("(" + ", ".join(_lit(v) for v in vals) + ")")
    if batch:
        colnames = ", ".join(f"`{f['name']}`" for f in fields)
        warehouse.execute(f"INSERT INTO {fqn} ({colnames}) VALUES {', '.join(batch)}")


def _write_config_row(run_id: str, cfg: dict) -> None:
    # base64-encode the JSON so the transform SQL's single quotes + backslashes
    # survive the SQL-literal round-trip intact (the pipeline base64-decodes it).
    import base64

    sdp_pipeline._ensure_tables()
    encoded = base64.b64encode(json.dumps(cfg).encode()).decode()
    warehouse.execute(
        f"INSERT INTO {sdp_pipeline.CONFIG_TABLE} (run_id, config_json, created_at) "
        f"VALUES ({_sql_str(run_id)}, {_sql_str(encoded)}, current_timestamp())"
    )


def _run_pipeline(run: dict, pipeline_id: str) -> None:
    """Start a full-refresh update and poll to a terminal state.

    The pipeline reads the MOST RECENT config row from mf_test_config (this run
    just wrote its row in step 2), so we don't need to mutate the pipeline spec's
    configuration per run — a full `pipelines.update` would require re-sending the
    entire spec (libraries/catalog/schema) and risks clobbering it.
    """
    w = config.get_workspace_client()
    upd = w.pipelines.start_update(pipeline_id=pipeline_id, full_refresh=True)
    update_id = upd.update_id
    # Record a deep link to this specific pipeline run so the UI can offer "View run".
    try:
        host = config.get_workspace_host().rstrip("/")
        with _LOCK:
            if run.get("pipeline"):
                run["pipeline"]["update_id"] = update_id
                run["pipeline"]["run_url"] = f"{host}/pipelines/{pipeline_id}/updates/{update_id}"
                run["pipeline"]["pipeline_url"] = f"{host}/pipelines/{pipeline_id}"
    except Exception:  # noqa: BLE001
        pass
    deadline = time.time() + 900  # 15 min guard
    while time.time() < deadline:
        time.sleep(12)
        info = w.pipelines.get_update(pipeline_id=pipeline_id, update_id=update_id)
        state = getattr(info.update, "state", None)
        sval = getattr(state, "value", str(state)) if state else "UNKNOWN"
        _set_step(run, "run_pipeline", "running", f"pipeline {sval.lower()}")
        if sval in ("COMPLETED",):
            return
        if sval in ("FAILED", "CANCELED"):
            raise RuntimeError(f"pipeline update {sval}")
    raise RuntimeError("pipeline update timed out")


def _analyze(result: dict) -> dict:
    """Analysis Agent: turn the validation result into a headline + recommendations.

    Deterministic (no LLM) — summarizes the metadata checks + DQ pass rates and
    flags the columns most worth a human's attention.
    """
    dq = result.get("dq") or []
    rated = [d for d in dq if d.get("pass_rate") is not None]
    full = [d for d in rated if d["pass_rate"] == 1.0]
    weak = sorted([d for d in rated if d["pass_rate"] < 1.0], key=lambda d: d["pass_rate"])
    checks_ok = sum(1 for c in result.get("checks", []) if c["passed"])
    checks_total = len(result.get("checks", []))

    recs: list[str] = []
    for d in weak[:5]:
        recs.append(f"Review `{d['column']}` — {round(d['pass_rate'] * 100)}% pass ({d.get('passed')}/{d.get('total')}); tighten the transform or relax the rule.")
    if result.get("overall") != "passed":
        recs.insert(0, "One or more metadata checks did not pass — inspect target schema/rows before publishing.")
    if not recs:
        recs.append("All checks passed — the mapping looks ready to publish.")

    headline = f"{checks_ok}/{checks_total} checks OK · {len(full)}/{len(rated)} DQ rules clean" + (f" · {len(weak)} need attention" if weak else "")
    return {
        "headline": headline,
        "recommendations": recs,
        "clean_rules": len(full),
        "weak_rules": len(weak),
        "verdict": "ready" if (result.get("overall") == "passed" and not weak) else "review",
    }


def _validate_targets(cfg_targets: list[dict]) -> dict:
    """Validate EACH target table the pipeline produced; aggregate into one report.

    Per target: row count, schema conformance (produced cols vs the config's target
    columns), and per-rule DQ pass rates from its `_dq` table. Results are rolled up
    across all targets AND broken out per-table (`tables`) for the UI.
    """
    checks: list[dict] = []      # flat, spec-wide (drives overall + analysis)
    dq_summary: list[dict] = []  # flat, spec-wide
    per_table: list[dict] = []

    def _add(name: str, ok: bool, detail: str) -> None:
        checks.append({"name": name, "passed": bool(ok), "detail": detail})

    for t in cfg_targets:
        dataset = t["target_name"]
        expected = {c["target_field"] for c in t.get("columns", [])}
        validations = t.get("validations", [])
        target_tbl = f"{CATALOG}.{SCHEMA}.{dataset}_target"
        dq_tbl = f"{CATALOG}.{SCHEMA}.{dataset}_dq"
        t_checks: list[dict] = []
        t_dq: list[dict] = []

        try:
            rc = int(warehouse.execute(f"SELECT COUNT(*) FROM {target_tbl}")[0][0])
        except Exception as e:  # noqa: BLE001 — a missing target table is a real failure to report
            _add(f"{dataset}: rows produced", False, f"target table not found ({str(e)[:80]})")
            per_table.append({"target_table": dataset, "row_count": 0, "checks": [{"name": "rows produced", "passed": False, "detail": "target table not found"}], "dq": []})
            continue

        c1 = {"name": f"{dataset}: rows produced", "passed": rc > 0, "detail": f"{rc} rows"}
        checks.append(c1); t_checks.append({"name": "rows produced", "passed": rc > 0, "detail": f"{rc} rows"})

        produced = {r[0] for r in warehouse.execute(f"DESCRIBE {target_tbl}") if r[0] and not r[0].startswith("#")}
        missing = expected - produced
        detail = f"{len(expected & produced)}/{len(expected)} columns present" + (f"; missing {sorted(missing)}" if missing else "")
        checks.append({"name": f"{dataset}: schema conformance", "passed": not missing, "detail": detail})
        t_checks.append({"name": "schema conformance", "passed": not missing, "detail": detail})

        total_rows = rc or 1
        for v in validations:
            try:
                passed = warehouse.execute(f"SELECT COUNT(*) FROM {dq_tbl} WHERE {v['logic']}")[0][0]
            except Exception:  # noqa: BLE001
                passed = None
            row = {"rule": v["name"], "column": v["column"], "target_table": dataset}
            if passed is None:
                row["pass_rate"] = None
            else:
                row.update({"pass_rate": round(int(passed) / total_rows, 3), "passed": int(passed), "total": total_rows})
            dq_summary.append(row); t_dq.append(row)

        t_ok = sum(1 for d in t_dq if d.get("pass_rate") == 1.0)
        checks.append({"name": f"{dataset}: DQ rules (100% pass)", "passed": True, "detail": f"{t_ok}/{len(t_dq)} rules fully pass" if t_dq else "no DQ rules"})
        per_table.append({"target_table": dataset, "row_count": rc, "checks": t_checks, "dq": t_dq})

    dq_ok = sum(1 for d in dq_summary if d.get("pass_rate") == 1.0)
    passed_checks = sum(1 for c in checks if c["passed"])
    overall = all(c["passed"] for c in checks)
    primary = per_table[0] if per_table else {}
    return {
        "overall": "passed" if overall else "attention",
        "summary": f"{passed_checks}/{len(checks)} checks passed across {len(per_table)} target(s)" + (f"; {dq_ok}/{len(dq_summary)} DQ rules 100%" if dq_summary else ""),
        # top-level target/dq_table kept for back-compat (first target)
        "target_table": f"{CATALOG}.{SCHEMA}.{primary.get('target_table')}_target" if primary else None,
        "row_count": primary.get("row_count", 0),
        "checks": checks,
        "dq": dq_summary,
        "tables": per_table,
    }
