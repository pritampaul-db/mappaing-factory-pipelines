"""Explanation endpoints — Knowledge Assistant grounded Q&A (explainability layer)."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from server import config, explain

router = APIRouter(tags=["explain"])


class Question(BaseModel):
    question: str


@router.get("/explain/status")
def ka_status() -> dict:
    """Report the Knowledge Assistant's endpoint (configured override preferred)."""
    endpoint = explain.resolve_endpoint()
    return {"ready": bool(endpoint), "endpoint_name": endpoint}


@router.post("/explain")
def explain_question(body: Question) -> dict:
    """Ask the Knowledge Assistant a grounded question about approved mappings."""
    endpoint = explain.resolve_endpoint()
    if not endpoint:
        raise HTTPException(status_code=409, detail="Knowledge Assistant is still provisioning; try again shortly.")

    from openai import OpenAI

    client = OpenAI(
        api_key=config.get_bearer_token(),
        base_url=f"{config.get_workspace_host()}/serving-endpoints",
    )
    # Knowledge Assistant endpoints speak the Responses API (input=...), not
    # chat-completions. Extract the text from the response output.
    try:
        resp = client.responses.create(
            model=endpoint,
            input=[{"role": "user", "content": body.question}],
        )
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"KA query failed: {e}")

    answer = getattr(resp, "output_text", None)
    if not answer:
        # Fall back to walking the output items for text content.
        parts: list[str] = []
        for item in getattr(resp, "output", []) or []:
            for c in getattr(item, "content", []) or []:
                t = getattr(c, "text", None)
                if t:
                    parts.append(t)
        answer = "\n".join(parts)
    return {"answer": answer, "endpoint": endpoint}
