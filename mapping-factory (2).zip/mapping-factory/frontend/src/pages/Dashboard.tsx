import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Map as MapIcon,
  Sparkles,
  UserCheck,
  CheckCircle2,
  GitBranch,
  Layers,
  Play,
  XCircle,
  AlertTriangle,
  ChevronRight,
  Plus,
} from "lucide-react";
import { usePage } from "../AppShell";
import { api, type DashboardSummary } from "../api";
import { Card, Button } from "../components/primitives";
import { DonutChart, LegendList, ExecutionsBarChart, Sparkline } from "../components/charts";
import { timeAgo } from "../theme";

const KPI_ICONS = [MapIcon, Sparkles, UserCheck, CheckCircle2, GitBranch, Layers];

export function Dashboard() {
  const nav = useNavigate();
  const [d, setD] = useState<DashboardSummary | null>(null);
  const [err, setErr] = useState<string | null>(null);

  usePage({
    title: "Dashboard",
    subtitle: "Welcome back",
    actions: (
      <Button onClick={() => nav("/mappings/new")}>
        <Plus className="w-4 h-4" /> New Mapping
      </Button>
    ),
  });

  useEffect(() => {
    api.dashboard().then(setD).catch((e) => setErr(String(e)));
  }, []);

  if (err) return <div className="p-6 text-red-600 text-sm">Failed to load dashboard: {err}</div>;
  if (!d) return <div className="p-6 text-gray-400 text-sm">Loading…</div>;

  const health = d.pipeline_health;
  const statusColors: Record<string, string> = {
    Published: "#16a34a",
    Approved: "#16a34a",
    Draft: "#dc2626",
    Proposed: "#d97706",
    "Pending Approval": "#d97706",
    "AI Suggested": "#a855f7",
    Rejected: "#9ca3af",
  };

  return (
    <div className="p-6 space-y-5">
      {/* KPI row */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        {d.kpis.map((k, i) => (
          <div key={k.label} className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="flex items-start justify-between">
              <KpiInline icon={KPI_ICONS[i % KPI_ICONS.length]} label={k.label} value={k.value.toLocaleString()} />
            </div>
            <div className="flex items-center justify-between mt-2">
              <span className="text-xs text-green-600">▲ {k.delta}</span>
              <Sparkline points={k.spark} />
            </div>
          </div>
        ))}
      </div>

      {/* Middle row: health / approvals / activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card title="Pipeline Health Overview" action={<a className="text-xs text-brand" href="#">View all</a>}>
          <div className="grid grid-cols-4 gap-2 text-center">
            <HealthTile icon={Play} color="#16a34a" label="Running" n={health.running} />
            <HealthTile icon={CheckCircle2} color="#16a34a" label="Succeeded" n={health.succeeded} />
            <HealthTile icon={XCircle} color="#dc2626" label="Failed" n={health.failed} />
            <HealthTile icon={AlertTriangle} color="#d97706" label="Warning" n={health.warning} />
          </div>
        </Card>

        <Card title="Pending Approvals" action={<a className="text-xs text-brand" href="#">View all</a>}>
          <ul className="divide-y divide-gray-100">
            {d.pending_approvals.map((a) => (
              <li key={a.label} className="flex items-center justify-between py-2.5">
                <span className="text-sm text-gray-700">{a.label}</span>
                <span className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-gray-900">{a.count}</span>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </span>
              </li>
            ))}
          </ul>
        </Card>

        <Card title="Recent Activity" action={<a className="text-xs text-brand" href="#">View all</a>}>
          <ul className="space-y-3">
            {d.recent_activity.map((a, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-brand mt-1.5 shrink-0" />
                <div className="min-w-0 flex-1">
                  <span className="text-gray-800">
                    {a.target ? (
                      <>
                        <b className="font-medium">{a.target}</b> {a.action}
                      </>
                    ) : (
                      a.action
                    )}
                  </span>
                  <div className="text-xs text-gray-400">
                    {a.actor} · {timeAgo(a.at)}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      {/* Bottom row: mappings-by-status / executions / top impacted */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card title="Mappings by Status">
          <div className="grid grid-cols-2 gap-2 items-center">
            <DonutChart
              data={d.mappings_by_status.map((s) => ({ ...s, color: statusColors[s.name] }))}
              totalLabel="Total"
            />
            <LegendList data={d.mappings_by_status.map((s) => ({ ...s, color: statusColors[s.name] }))} />
          </div>
        </Card>

        <Card title="Executions (Last 7 Days)">
          <ExecutionsBarChart data={d.executions_7d} />
        </Card>

        <Card title="Top Impacted Assets" action={<a className="text-xs text-brand" href="#">View all</a>}>
          <table className="w-full text-sm">
            <tbody>
              {d.top_impacted.map((a) => (
                <tr key={a.name} className="border-b border-gray-100 last:border-0">
                  <td className="py-2">
                    <div className="font-medium text-gray-800 truncate">{a.name}</div>
                    <div className="text-xs text-gray-400 capitalize">{a.type}</div>
                  </td>
                  <td className="py-2 text-right w-32">
                    <div className="flex items-center gap-2 justify-end">
                      <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${a.impact}%`, background: a.impact >= 80 ? "#dc2626" : "#d97706" }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 w-8">{a.impact}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
}

function KpiInline({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="w-10 h-10 rounded-lg grid place-items-center bg-brand-soft text-brand shrink-0">
        <Icon className="w-5 h-5" />
      </span>
      <div>
        <div className="text-xs text-gray-500">{label}</div>
        <div className="text-2xl font-semibold text-gray-900 leading-tight">{value}</div>
      </div>
    </div>
  );
}

function HealthTile({ icon: Icon, color, label, n }: { icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>; color: string; label: string; n: number }) {
  return (
    <div>
      <Icon className="w-6 h-6 mx-auto" style={{ color }} />
      <div className="text-xs text-gray-500 mt-1">{label}</div>
      <div className="text-xl font-semibold text-gray-900">{n}</div>
    </div>
  );
}
