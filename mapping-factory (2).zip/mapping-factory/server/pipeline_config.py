"""Build the deterministic mapping config (v2) from a spec — shared by the
Deploy-as-Pipeline bundle generator. Mirrors the agentic-validation config shape
(inputs / joins / targets) but is standalone so it can run outside a test run.

The transform SQL is lowered by the deterministic compiler (never the LLM here);
each target's source-table JOIN set is derived from BOTH provenance and the actual
columns referenced in the expressions (so an optimized multi-table expr can't
reference an unjoined table).
"""
from __future__ import annotations

import re
from typing import Any

import sqlglot
from sqlglot import exp

from server import compiler


def _lower(m: dict, source_types: dict) -> str | None:
    try:
        if (m.get("transform_kind") or "spec") == "spec" and m.get("transform_spec"):
            expr, _ = compiler._lower_spec_to_sql(m["transform_spec"], source_types)
            return expr
        if m.get("transform_sql"):
            return m["transform_sql"]
    except Exception as e:  # noqa: BLE001 — surface, don't silently drop the column
        # A dropped column later breaks any validation that references it, so make the
        # failure visible in the app logs instead of producing a silently-partial target.
        print(f"[pipeline_config] failed to lower transform for "
              f"{m.get('target_field_name')!r}: {e}; column will be omitted")
        return None
    return None


def _ident(name: str) -> str:
    """Sanitize an asset name into a bare SQL identifier for a table name."""
    return re.sub(r"[^0-9A-Za-z_]+", "_", str(name)).strip("_") or "src"


# Rule types that gate the target by default (a violation quarantines the row); everything
# else defaults to 'warn' (row still lands in the target, violation only logged). This is
# the AI-suggested default — a human can override per rule (dq_action) in the Designer.
_FAIL_BY_DEFAULT = {"completeness", "uniqueness", "referential", "business_rule"}


def default_dq_action(rule_type: str | None) -> str:
    return "fail" if (rule_type or "") in _FAIL_BY_DEFAULT else "warn"


def _action_of(v: dict) -> str:
    a = (v.get("dq_action") or "").strip().lower()
    if a in ("warn", "fail"):
        return a
    return default_dq_action(v.get("rule_type"))


def _tables_in_expr(sql: str, known: set[str]) -> set[str]:
    found: set[str] = set()
    try:
        for c in sqlglot.parse_one(sql, read=compiler.DIALECT).find_all(exp.Column):
            if c.table and c.table in known:
                found.add(c.table)
    except Exception:  # noqa: BLE001
        pass
    for t in known:
        if re.search(rf"(?<![\w`]){re.escape(t)}\s*\.", sql) or f"`{t}`." in sql:
            found.add(t)
    return found


def build_mapping_config(spec: dict, validations: list[dict], *,
                         catalog: str | None = None, source_schema: str | None = None) -> dict[str, Any]:
    """Return the v2 config {version, inputs, joins, targets} for a published spec.

    `validations` = the spec's applied validation rows (dataset-scoped).
    `catalog`/`source_schema`: when both given, each source input is stamped with a
    fully-qualified `table` (`catalog.source_schema.<asset>`), so sources are read from
    the SOURCE schema — independent of the pipeline's target schema where results land.
    An asset whose locator already looks fully-qualified (a.b.c) is used verbatim."""
    sources = spec.get("sources") or []
    targets = spec.get("targets") or []
    source_types: dict[str, str] = {}
    for a in sources:
        for f in a["fields"]:
            source_types[f["name"]] = f["datatype"]
            source_types[f"{a['name']}.{f['name']}"] = f["datatype"]
    source_names = {a["name"] for a in sources}
    tgt_asset_by_field = {str(f["id"]): a for a in targets for f in a["fields"]}
    active = [m for m in spec.get("mappings", []) if m["state"] != "rejected"]

    # joins → split shape (left_table/left_col/right_table/right_col)
    joins = []
    for j in spec.get("joins") or []:
        lt, _, lc = (j.get("left") or "").partition(".")
        rt, _, rc = (j.get("right") or "").partition(".")
        if lt and lc and rt and rc:
            joins.append({"left_table": lt, "left_col": lc, "right_table": rt, "right_col": rc})

    def _source_table(a: dict) -> str | None:
        # Prefer an already-qualified locator (catalog.schema.table); else qualify the
        # asset name under the given catalog + source_schema. None → runtime fallback.
        loc = (a.get("locator") or "").strip()
        if loc.count(".") >= 2:
            return loc
        if catalog and source_schema:
            return f"{catalog}.{source_schema}.{_ident(loc or a['name'])}"
        return None

    inputs = {}
    for a in sources:
        meta: dict[str, Any] = {"columns": [f["name"] for f in a["fields"]]}
        tbl = _source_table(a)
        if tbl:
            meta["table"] = tbl
        inputs[a["name"]] = meta

    cfg_targets = []
    for tgt in targets:
        dataset = tgt["name"]
        cols, src_contrib, referenced = [], {}, set()
        for m in active:
            if tgt_asset_by_field.get(str(m["target_field_id"])) is not tgt:
                continue
            sql = _lower(m, source_types)
            if sql:
                cols.append({"target_field": m["target_field_name"], "sql": sql})
                for st in (m.get("provenance") or {}).get("source_tables") or []:
                    src_contrib[st] = src_contrib.get(st, 0) + 1
                referenced |= _tables_in_expr(sql, source_names)
        src_tables_used = sorted(src_contrib, key=lambda t: (-src_contrib[t], t))
        for t in sorted(referenced):
            if t not in src_tables_used:
                src_tables_used.append(t)
        vals = [
            {"name": v.get("code") or v.get("name"), "column": v.get("column_name"),
             "logic": v.get("logic"), "action": _action_of(v), "severity": v.get("severity")}
            for v in validations
            if v.get("dataset") == dataset and v.get("column_name") and v.get("logic")
        ]
        cfg_targets.append({
            "target_name": dataset,
            "columns": cols,
            "validations": vals,
            "source_tables": src_tables_used or [a["name"] for a in sources],
        })

    return {"version": 2, "inputs": inputs, "joins": joins, "targets": cfg_targets}
